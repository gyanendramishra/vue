<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{ 

    /**
     * Show the user dashboard.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {
        return view('dashboard.index');
    }

    /**
     * Switch account.
     *
     * @param  Request $request
     * @param  (string) $accountType
     * @return \Illuminate\Http\Response
     */
    public function switchAccountAs(Request $request, $accountType){
        $user = $request->session()->get('auth_user');
        if($accountType == 'service-provider'){
            $user->isServiceProvider = true;
        }else{
            $user->isServiceProvider = false;
        }
        $request->session()->forget('auth_user');
        $request->session()->put('auth_user', $user);
        return redirect()->route('user.dashboard');
    }
}
