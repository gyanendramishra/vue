<template>
    <div class="formBox editProfileForm">
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div class="field-required">
                    <p>Change your password</p>
                </div>
                <form @submit.prevent="changePassword">
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                Old Password
                                <span class="red-color">*</span>
                            </label>
                            <input type="password" placeholder="Password" name="old_password" v-model="password.old_password" v-validate="'required|min:6|max:12'" data-vv-as="old password">
                            <div v-if="errors.has('old_password')" class="text-danger">
                                {{ errors.first('old_password') }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                New Password
                                <span class="red-color">*</span>
                            </label>
                            <input type="password" placeholder="Password" name="password" v-model="password.password" v-validate="'required|min:6|max:12'" ref="password">
                            <div v-if="errors.has('password')" class="text-danger">
                                {{ errors.first('password') }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                Confirm Password
                                <span class="red-color">*</span>
                            </label>
                            <input type="password" placeholder="Confirm Password" name="confirm_password" v-model="password.confirm_password" v-validate="'required|confirmed:password'" data-vv-as="confirm password">
                            <div v-if="errors.has('confirm_password')" class="text-danger">
                                {{ errors.first('confirm_password') }}
                            </div>
                        </div>
                    </div>
                    <div class="full-btn-col">
                        <div v-if="!loading">
                            <input type="submit" value="Update" :disabled="errors.any()">
                        </div>
                        <div v-else>
                            <input type="submit" value="loading..." disable="disabled">
                        </div>
                    </div>
                </form>
                
            </div>
        </div>
    </div>
</template>
<script>
    import VeeValidate from 'vee-validate';
    Vue.use(VeeValidate);
    export default {
        name: "change-password-component",
        data: function () {
            return {
                password: {},
                loading: false
            }
        },
        methods: {
            changePassword() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        axios.post('/update-password', this.password).then(response => {
                            if(response.data.status === true){
                                this.password = {};
                                flash(response.data.message, 'success');
                            }else{
                                if(response.data.error){
                                    var message =  response.data.error[0];
                                    flash(message.replace('_', ' '), 'error');
                                }else{
                                    flash(response.data.message, 'error');
                                }
                            }
                            this.loading = false;
                        }).catch(error => {
                            this.loading = false;
                            console.log(error);
                        });
                    }else{
                        this.loading = false;
                    }
                });
            }
        }
    }
</script>

