<template>
    <div class="row">
        <div class="col-sm-12 col-md-4 col-lg-3 order-md-2">
            <div class="product-filter-bar">
                <div class="product-filter-col">
                    <div class="panel-heading">
                        <h5 class="panel-title">
                            <a href="#categories-fiter" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
                                <h4>Categories</h4>
                                <span class="plus-minus-icons"></span>
                            </a>
                        </h5>
                    </div>
                    <div class="panel-collapse collapse" id="categories-fiter" style="height:auto;">
                        <div class="product-filter-col-inner">
                            <div class="rightTabList">
                                <div id="accordion" class="panel-group">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h5 class="panel-title">
                                                <a href="#callps01" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
                                                    Lifestyle
                                                    <span class="plus-minus-icons"></span>
                                                </a>
                                            </h5>
                                        </div>
                                        <div class="panel-collapse collapse" id="callps01" style="height: 0px;">
                                            <div class="panel-body">
                                                <ul>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca-chek1">
                                                            <label for="ca-chek1">Cleaning </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca-chek2">
                                                            <label for="ca-chek2">Assembly </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca-chek3">
                                                            <label for="ca-chek3">Handyman </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca-chek4">
                                                            <label for="ca-chek4">Delivery </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca-chek5">
                                                            <label for="ca-chek5">Gardning </label>
                                                        </div>
                                                    </li>
                                            
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca-chek6">
                                                            <label for="ca-chek6">Removal listing </label>
                                                        </div>
                                                    </li>  
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca-chek7">
                                                            <label for="ca-chek7">Assembly </label>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h5 class="panel-title">
                                                <a href="#callps02" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
                                                    Business
                                                    <span class="plus-minus-icons"></span>
                                                </a>
                                            </h5>
                                        </div>
                                        <div class="panel-collapse collapse" id="callps02" style="height: 0px;">
                                            <div class="panel-body">
                                                <ul>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca2-chek1">
                                                            <label for="ca2-chek1">Cleaning </label>
                                                        </div>
                                                    </li> 
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca2-chek2">
                                                            <label for="ca2-chek2">Assembly </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca2-chek3">
                                                            <label for="ca2-chek3">Handyman </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca2-chek4">
                                                            <label for="ca2-chek4">Delivery </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca2-chek5">
                                                            <label for="ca2-chek5">Gardning </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca2-chek6">
                                                            <label for="ca2-chek6">Removal listing </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca2-chek7">
                                                            <label for="ca2-chek7">Assembly </label>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h5 class="panel-title">
                                                <a href="#callps03" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
                                                    Writing & Translation
                                                    <span class="plus-minus-icons"></span>
                                                </a>
                                            </h5>
                                        </div>
                                        <div class="panel-collapse collapse" id="callps03" style="height: 0px;">
                                            <div class="panel-body">
                                                <ul>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca3-chek1">
                                                            <label for="ca3-chek1">Cleaning </label>
                                                        </div>
                                                    </li> 
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca3-chek2">
                                                            <label for="ca3-chek2">Assembly </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca3-chek3">
                                                            <label for="ca3-chek3">Handyman </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca3-chek4">
                                                            <label for="ca3-chek4">Delivery </label>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h5 class="panel-title">
                                                <a href="#callps04" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
                                                    Human Resources
                                                    <span class="plus-minus-icons"></span>
                                                </a>
                                            </h5>
                                        </div>
                                        <div class="panel-collapse collapse" id="callps04" style="height: 0px;">
                                            <div class="panel-body">
                                                <ul>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca4-chek1">
                                                            <label for="ca4-chek1">Cleaning </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca4-chek2">
                                                            <label for="ca4-chek2">Assembly </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca4-chek3">
                                                            <label for="ca4-chek3">Handyman </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca4-chek4">
                                                            <label for="ca4-chek4">Delivery </label>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h5 class="panel-title">
                                                <a href="#callps05" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
                                                    Programming & Tech 
                                                    <span class="plus-minus-icons"></span>
                                                </a>
                                            </h5>
                                        </div>
                                        <div class="panel-collapse collapse" id="callps05" style="height: 0px;">
                                            <div class="panel-body">
                                                <ul>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca5-chek1">
                                                            <label for="ca5-chek1">Cleaning </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca5-chek2">
                                                            <label for="ca5-chek2">Assembly </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="checkbox abc-checkbox propertyCheck">
                                                            <input type="checkbox" class="styled" id="ca5-chek3">
                                                            <label for="ca5-chek3">Handyman </label>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="border-btn-sec">
                                <a href="#" class="border-btn">Apply</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="product-filter-col">
                    <div class="panel-heading">
                        <h5 class="panel-title">
                            <a href="#price-fiter" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
                                <h4>Filter by Price</h4>
                                <span class="plus-minus-icons"></span>
                            </a>
                        </h5>
                    </div>
                    <div class="panel-collapse collapse" id="price-fiter" style="height:auto;">
                        <div class="product-filter-col-inner fl-price-col">
                            <div class="fl-price-outer">
                                <div class="fl-price-left">
                                    <label>Min</label>
                                    <input type="text" placeholder="$">
                                </div>
                            
                                <div class="fl-price-right">
                                    <label>Max</label>
                                    <input type="text" placeholder="$">
                                </div>
                            </div>
                            <div class="border-btn-sec">
                                <a href="#" class="border-btn">Apply</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="product-filter-col">
                    <div class="panel-heading">
                        <h5 class="panel-title">
                            <a href="#availability-fiter" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
                                <h4>Filter by Availability</h4>
                                <span class="plus-minus-icons"></span>
                            </a>
                        </h5>
                    </div>
                    <div class="panel-collapse collapse" id="availability-fiter" style="height:auto;">
                        <div class="product-filter-col-inner fl-availability-col">
                            <label>Availability</label>
                            <input type="text" placeholder="18-03-2014">
                            <div class="border-btn-sec">
                                <a href="#" class="border-btn">Apply</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="product-filter-col">
                    <div class="panel-heading">
                        <h5 class="panel-title">
                            <a href="#rating-fiter" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
                                <h4>Filter by Rating</h4>
                                <span class="plus-minus-icons"></span>
                            </a>
                        </h5>
                    </div>
                    <div class="panel-collapse collapse" id="rating-fiter" style="height:auto;">	   
                        <div class="product-filter-col-inner">
                            <div class="serching-radio star-rating-col">
                                <div class="radio radio-inline">
                                    <input type="radio" id="rating01" value="option1" name="radioInline" checked="">
                                    <label for="rating01"> 
                                        <img src="/images/star_rate01.png" alt="" /> 
                                    </label>
                                </div>
                                <div class="radio radio-inline">
                                    <input type="radio" id="rating02" value="option1" name="radioInline" checked="">
                                    <label for="rating02"> 
                                        <img src="/images/star_rate02.png" alt="" />  
                                    </label>
                                </div>
                                <div class="radio radio-inline">
                                    <input type="radio" id="rating03" value="option1" name="radioInline" checked="">
                                    <label for="rating03"> 
                                        <img src="/images/star_rate03.png" alt="" />  
                                    </label>
                                </div>
                                <div class="radio radio-inline">
                                    <input type="radio" id="rating04" value="option1" name="radioInline" checked="">
                                    <label for="rating04"> 
                                        <img src="/images/star_rate04.png" alt="" />  
                                    </label>
                                </div>
                                <div class="radio radio-inline">
                                    <input type="radio" id="rating05" value="option1" name="radioInline" checked="">
                                    <label for="rating05">
                                        <img src="/images/star_rate05.png" alt="" />
                                    </label>
                                </div>
                            </div> 
                            <div class="border-btn-sec">
                                <a href="#" class="border-btn">Apply</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-9 order-md-1">
            <div class="product-list-bar">
                <div class="product-list-col">
                    <div class="product-list-row row">
                        <div v-if="results.users.length > 0">
                            <div class="col-xs-12 col-sm-6 col-md-12 col-lg-4" v-for="user in results.users">
                                <div class="pro-category-col">
                                    <div class="category-img-col">
                                        <a href="javascript:;">
                                            <img src="/images/feature_img02.jpg" alt="gallery">
                                        </a>
                                    </div>
                                    <div class="pro-category-text">
                                        <div class="cat-title-cal"> 
                                            <img class="" alt="" src="images/top_category_img01.jpg">
                                            <div class="cat-title-inner">
                                                <a class="lis-dark" href="#">
                                                    <h4>Andrew Blair</h4>
                                                </a>
                                                <div class="rating-icon-col">
                                                    <i class="fa fa-star"></i> 5.0
                                                </div> 
                                            </div>
                                        </div>
                                        <div class="category-price-col">
                                            <div class="category-price-left">
                                                <span>Category</span>
                                                <strong>Lifestyle</strong>
                                            </div>
                                            <div class="category-price-right">
                                                <span> Starting at</span>
                                                <strong class="category-price">$20.00</strong>
                                            </div>
                                        </div>
                                        <h5>I will do a great market ...</h5>
                                        <p>The most well-known dummy text is the 'Lorem Ipsum' </p>
                                        <a href="javascript:;" class="view-detail-btn">View Detail</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div v-else>
                            <p>No records found</p>
                        </div>
                    </div>
                    <div class="pro-pagination">
                        <div class="pager-result"> 50 Items found</div>
                        <div class="pager">
                            <ul>
                                <li class="pager-arrow">
                                    <a href="#"><i class="fa fa-angle-left"></i></a>
                                </li>
                                <li>
                                    <a href="#">1</a>
                                </li>
                                <li>
                                    <a href="#">2</a>
                                </li>
                                <li>
                                    <a href="#">3</a>
                                </li>
                                <li>
                                    <a href="#">4</a>
                                </li>
                                <li class="pager-arrow">
                                    <a href="#"><i class="fa fa-angle-right"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </div>
</template>
<script>
    import VeeValidate from 'vee-validate';
    Vue.use(VeeValidate);
    export default {
        name: "service-providers-component",
        props: ["initialFilters"],
        data: function () {
            return {
                loading: true,
                filters: {},
                results: {
                    next_page: "",
                    last_page: "",
                    users: {}
                }
            }
        },
        beforeMount () {
            
        },
        mounted: function () {
            this.filters = {
                page: 1,
                keyword: this.initialFilters.keyword,
                category_id: this.initialFilters.category_id,
                price_range: this.initialFilters.price_range,
                rating: this.initialFilters.rating,
                service_date: this.initialFilters.service_date
            }
            console.log(this.filters);
            this.getResults();
        },
        methods: {
            getResults() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        axios.post('/filter-servcie-providers', this.filters).then(response => {
                            if(response.data.status === true){
                                this.results = response.data.data;
                            }else{
                                if(response.data.error){
                                    var message =  response.data.error[0];
                                    flash(message.replace('_', ' '), 'error');
                                }else{
                                    flash(response.data.message, 'error');
                                }
                            }
                            this.loading = false;
                        }).catch(error => {
                            this.loading = false;
                            console.log(error);
                        });
                    }else{
                        this.loading = false;
                    }
                });
            }
        }
    }
</script>

