<template>
    <div class="row">
        <div class="col-sm-12 col-md-4 col-lg-3 order-md-2">
            <div class="product-filter-bar">
                <div class="product-filter-col">
                    <div class="panel-heading">
                        <h5 class="panel-title">
                            <a href="#categories-fiter" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
                                <h4>Categories</h4>
                                <span class="plus-minus-icons"></span>
                            </a>
                        </h5>
                    </div>
                    <div class="panel-collapse collapse" id="categories-fiter" style="height:auto;">
                        <div class="product-filter-col-inner">
                            <form @submit.prevent="getResults()">
                                <div class="rightTabList">
                                    <div id="accordion" class="panel-group">
                                        <div class="panel panel-default" v-for="(category, index) in categories">
                                            <div class="panel-heading">
                                                <h5 class="panel-title">
                                                    <a :href="'#callps-'+ index" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
                                                        {{ category.title }}
                                                        <span class="plus-minus-icons"></span>
                                                    </a>
                                                </h5>
                                            </div>
                                            <div class="panel-collapse collapse" :id="'callps-'+index" style="height: 0px;">
                                                <div class="panel-body">
                                                    <ul>
                                                        <li v-for="subcategory in category.subcategories">
                                                            <div class="checkbox abc-checkbox propertyCheck">
                                                                <input type="checkbox" class="styled" :id="'ca-chek-'+subcategory.id" :value="subcategory.id" v-model="filters.category_id">
                                                                <label for="ca-chek1">{{ subcategory.title }} </label>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="border-btn-sec">
                                    <div v-if="loading === false">
                                        <button type="submit" class="border-btn">Apply</button>
                                    </div>
                                    <div v-else>
                                        <button type="submit" class="border-btn" disabled="disabled">Apply</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="product-filter-col">
                    <div class="panel-heading">
                        <h5 class="panel-title">
                            <a href="#price-fiter" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
                                <h4>Filter by Price</h4>
                                <span class="plus-minus-icons"></span>
                            </a>
                        </h5>
                    </div>
                    <div class="panel-collapse collapse" id="price-fiter" style="height:auto;">
                        <div class="product-filter-col-inner fl-price-col">
                            <form @submit.prevent="getResults()">
                                <div class="fl-price-outer">
                                    <div class="fl-price-left">
                                        <label>Min</label>
                                        <input type="text" placeholder="$" v-model="filters.min_price">
                                    </div>
                                
                                    <div class="fl-price-right">
                                        <label>Max</label>
                                        <input type="text" placeholder="$" v-model="filters.max_price">
                                    </div>
                                </div>
                                <div class="border-btn-sec">
                                    <div v-if="loading === false">
                                        <button type="submit" class="border-btn">Apply</button>
                                    </div>
                                    <div v-else>
                                        <button type="submit" class="border-btn" disabled="disabled">Apply</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="product-filter-col">
                    <div class="panel-heading">
                        <h5 class="panel-title">
                            <a href="#availability-fiter" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
                                <h4>Filter by Availability</h4>
                                <span class="plus-minus-icons"></span>
                            </a>
                        </h5>
                    </div>
                    <div class="panel-collapse collapse" id="availability-fiter" style="height:auto;">
                        <div class="product-filter-col-inner fl-availability-col">
                            <form @submit.prevent="getResults()">
                                <label>Availability</label>
                                <input type="text" placeholder="Availability" ref="availability" v-model="filters.availability">
                                <div class="border-btn-sec">
                                    <div v-if="loading === false">
                                        <button type="submit" class="border-btn">Apply</button>
                                    </div>
                                    <div v-else>
                                        <button type="submit" class="border-btn" disabled="disabled">Apply</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="product-filter-col">
                    <div class="panel-heading">
                        <h5 class="panel-title">
                            <a href="#rating-fiter" data-parent="#accordion" data-toggle="collapse" class="accordion-toggle collapsed">
                                <h4>Filter by Rating</h4>
                                <span class="plus-minus-icons"></span>
                            </a>
                        </h5>
                    </div>
                    <div class="panel-collapse collapse" id="rating-fiter" style="height:auto;">	   
                        <div class="product-filter-col-inner">
                            <form @submit.prevent="getResults()">
                                <div class="serching-radio star-rating-col">
                                    <div class="radio radio-inline">
                                        <input type="radio" id="rating01" value="1" name="radioInline" v-model="filters.rating">
                                        <label for="rating01"> 
                                            <img src="/images/star_rate01.png" alt="" /> 
                                        </label>
                                    </div>
                                    <div class="radio radio-inline">
                                        <input type="radio" id="rating02" value="2" name="radioInline" v-model="filters.rating">
                                        <label for="rating02"> 
                                            <img src="/images/star_rate02.png" alt="" />  
                                        </label>
                                    </div>
                                    <div class="radio radio-inline">
                                        <input type="radio" id="rating03" value="3" name="radioInline" v-model="filters.rating">
                                        <label for="rating03"> 
                                            <img src="/images/star_rate03.png" alt="" />  
                                        </label>
                                    </div>
                                    <div class="radio radio-inline">
                                        <input type="radio" id="rating04" value="4" name="radioInline" v-model="filters.rating">
                                        <label for="rating04"> 
                                            <img src="/images/star_rate04.png" alt="" />  
                                        </label>
                                    </div>
                                    <div class="radio radio-inline">
                                        <input type="radio" id="rating05" value="5" name="radioInline" v-model="filters.rating">
                                        <label for="rating05">
                                            <img src="/images/star_rate05.png" alt="" />
                                        </label>
                                    </div>
                                </div> 
                                <div class="border-btn-sec">
                                    <div v-if="loading === false">
                                        <button type="submit" class="border-btn">Apply</button>
                                    </div>
                                    <div v-else>
                                        <button type="submit" class="border-btn" disabled="disabled">Apply</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-9 order-md-1">
            <div class="product-list-bar">
                <div class="product-list-col">
                    <div v-if="loading === false">
                        <div v-if="results.users.length > 0">
                            <div class="product-list-row row">
                                <div class="col-xs-12 col-sm-6 col-md-12 col-lg-4" v-for="user in results.users">
                                    <div class="pro-category-col">
                                        <div class="category-img-col">
                                            <a href="javascript:;">
                                                <img :src="user.service_image" alt="gallery">
                                            </a>
                                        </div>
                                        <div class="pro-category-text">
                                            <div class="cat-title-cal"> 
                                                <img class="" alt="" :src="user.profile_photo">
                                                <div class="cat-title-inner">
                                                    <a class="lis-dark" href="javascript:;">
                                                        <h4>{{ user.name }}</h4>
                                                    </a>
                                                    <div class="rating-icon-col">
                                                        <i class="fa fa-star"></i> {{ user.star_rate | formatNumber }}
                                                    </div> 
                                                </div>
                                            </div>
                                            <div class="category-price-col">
                                                <div class="category-price-left">
                                                    <span>Category</span>
                                                    <strong>{{ user.category_name }}</strong>
                                                </div>
                                                <div class="category-price-right">
                                                    <span> Starting at</span>
                                                    <strong class="category-price">${{ user.price | formatNumber }}</strong>
                                                </div>
                                            </div>
                                            <h5>{{ user.title | prepareLimitedData(20) }}</h5>
                                            <p>{{ user.short_description | prepareLimitedData(30) }}</p>
                                            <a :href="'/service/'+user.title, user.id | prepareSlug(user.id)" class="view-detail-btn">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pro-pagination">
                                <div class="pager-result"> {{ results.total_count }} Items found</div>
                                <div class="pager">
                                    <ul>
                                        <li class="pager-arrow">
                                            <a href="#"><i class="fa fa-angle-left"></i></a>
                                        </li>
                                        <li>
                                            <a href="#">1</a>
                                        </li>
                                        <li>
                                            <a href="#">2</a>
                                        </li>
                                        <li>
                                            <a href="#">3</a>
                                        </li>
                                        <li>
                                            <a href="#">4</a>
                                        </li>
                                        <li class="pager-arrow">
                                            <a href="#"><i class="fa fa-angle-right"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div v-else>
                            <p>Sorry there are no service providers matching with your criteria</p>
                        </div>
                    </div>
                    <div v-else>
                        loading...
                    </div>
                </div>
            </div>
        </div> 
    </div>
</template>
<script>
    import "bootstrap-datepicker/dist/css/bootstrap-datepicker.css";
    import datepicker from "bootstrap-datepicker";
    export default {
        name: "service-providers-component",
        props: ["filters"],
        data: function () {
            return {
                loading: false,
                results: {
                    next_page: "",
                    last_page: "",
                    users: {}
                },
                categories: {}
            }
        },
        created: function () {
            this.getCategories();
            this.getResults();
        },
        
        mounted: function () {
            var vm = this;
            Vue.nextTick(function(){
                $(vm.$refs.availability).datepicker({
                    format: "yyyy-mm-dd",
                    autoclose: true
                }).on('changeDate', function(e) {
                    vm.filters.availability = e.format();
                }).on('changeMonth', function(e) {
                    vm.filters.availability = e.format();
                }).on('changeYear', function(e) {
                    vm.filters.availability = e.format();
                });
            }.bind(this));
        },
        methods: {
            getResults() {
                this.loading = true;
                let data = {};
                if(this.filters.page){
                    data.page = this.filters.page;
                }
                if(this.filters.keyword){
                    data.keyword = this.filters.keyword;
                }
                if(this.filters.category_id){
                    data.category_id = this.filters.category_id.join(",");
                }
                if(this.filters.min_price && this.filters.max_price){
                    data.price_range = this.filters.min_price +"-"+ this.filters.max_price;
                }
                if(this.filters.availability){
                    data.service_date = this.filters.availability;
                }
                if(this.filters.rating){
                    data.star_rating = this.filters.rating;
                }
                axios.post('/service-providers/filter', data).then(response => {
                    if(response.data.status === true){
                        this.results = response.data.data;
                        this.loading = false;
                    }else{
                        if(response.data.error){
                            console.log(response.data.error[0]);
                        }else{
                            console.log(response.data.message);
                        }
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            getCategories() {
                axios.get('/service-providers/categories').then(response => {
                    if(response.data.status === true){
                        this.categories = response.data.data;
                    }
                }).catch(error => {
                    console.log(error);
                });
            }
        },
        filters: {
            prepareLimitedData (str, limit) {
                return str.length > limit ? str.substring(0, limit) + '...' : str;           
            },
            formatNumber(value) {
                return (value/1).toFixed(2);
            },
            prepareSlug (str, id) {
                return str.replace(/ /g, '-')+"-"+id;
            }
        }
    }
</script>

