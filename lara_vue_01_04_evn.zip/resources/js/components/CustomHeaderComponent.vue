<template>
</template>
<script>
    export default {
        name: "custom-header-component",
        mounted() {
            var html = $('html, body'),
            navContainer = $('.nav-container'),
            navToggle = $('.nav-toggle'),
            navDropdownToggle = $('.has-dropdown');

            // Nav toggle
            navToggle.on('click', function(e) {
                var $this = $(this);
                e.preventDefault();
                $this.toggleClass('is-active');
                navContainer.toggleClass('is-visible');
                html.toggleClass('nav-open');
            });
            // Nav dropdown toggle
            navDropdownToggle.on('click', function() {
                var $this = $(this);
                $this.toggleClass('is-active').children('ul').toggleClass('is-visible');
            });
        
            // Prevent click events from firing on children of navDropdownToggle
            navDropdownToggle.on('click', '*', function(e) {
                e.stopPropagation();
            });

            $('.dropdown').hover(function() {
                $(this).addClass('open');
                $(this).find('.dropdown').stop(true, true).delay(0).fadeIn(0);
            }, function() {
                $(this).removeClass('open');
                $(this).find('.dropdown').stop(true, true).delay(0).fadeOut(0);
            });

            $(window).scroll(function() {    
                var scroll = $(window).scrollTop();
                if (scroll >= 110) {
                    $(".header").addClass("header-sticky");
                } else {
                    $(".header").removeClass("header-sticky");
                }
            });
        }
    }
</script>
