@extends('layouts.dashboard')
@section('page_header_title')
	 Operational <strong>Times</strong>
@endsection
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        Operational times
    </li>
@endsection

@section('dashboard_content')
  	<div class="formBox editProfileForm">
        <div class="formBoxInner">
            <div class="dashbord-sec operational-time-page">
                <div class="form-row">
                    <div class="day-title-col">
                        <h5>Monday</h5>
                        <div class="day-on-of-btn-sec">
                            <div class="onoffswitch">
                                <input type="checkbox" class="onoffswitch-checkbox" name="" value="1" checked="true">
                                <label class="onoffswitch-label" for="">
                                    <span class="onoffswitch-inner"></span>
                                    <span class="onoffswitch-switch"></span>
                                </label>
                            </div>
                            <input type="hidden" class="days_cls" id="day" name="" value="Monday" placeholder="Days">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>
                            Opening Time 
                            <span class="red-color">*</span>
                        </label>
                        <input type="text" placeholder="" name="">
                    </div>
                    <div class="form-group last-input">
                        <label>
                            Closing Time 
                            <span class="red-color">*</span>
                        </label>
                        <input type="text" placeholder="" name="">
                    </div>
                </div>
                <div class="form-row">
                    <div class="day-title-col">
                        <h5>tuesday</h5>
                        <div class="day-on-of-btn-sec">
                            <div class="onoffswitch">
                                <input type="checkbox" class="onoffswitch-checkbox" name="" value="1" checked="true">
                                <label class="onoffswitch-label" for="">
                                    <span class="onoffswitch-inner"></span>
                                    <span class="onoffswitch-switch"></span>
                                </label>
                            </div> 
                            <input type="hidden" class="days_cls" id="day" name="" value="Monday" placeholder="Days">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>
                            Opening Time 
                            <span class="red-color">*</span>
                        </label>
                        <input type="text" placeholder="" name="">
                    </div>
                    <div class="form-group last-input">
                        <label>
                            Closing Time 
                            <span class="red-color">*</span>
                        </label>
                        <input type="text" placeholder="" name="">
                    </div>
                </div>
                <div class="full-btn-col">
                    <input type="submit" value="Submit" name="">
                </div>
            </div>
        </div>
    </div>
@endsection

