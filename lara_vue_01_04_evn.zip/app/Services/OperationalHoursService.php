<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class OperationalHoursService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/users/';


    /**
     * Get the user operational hours.
     *
     * @return Illuminate\Http\Response
     */
    public function getOperationalHoursService() {
        $uri = $this->base_uri;
        $uri .= 'profile'; 
        return $this->getServiceRequest($uri);
    }

    /**
     * Update the user operational hours.
     *
     * @param  array  $data
     * @return Illuminate\Http\Response
     */
    public function updateOperationalHoursService(array $data) {
        $uri = $this->base_uri;
        $uri .= 'profile'; 
        return $this->postFileRequest($uri, $data);
    }

    

}