<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\OperationalHoursService;

class OperationalTimesController extends Controller
{ 

    /**
     * Show the user operational hours.
     *
     * @param Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request){
    
        return view('operational_hours.index');
    }

    /**
     * Get the user operational Times.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\OperationalHoursService $service
     * @return \Illuminate\Http\Response
     */
    public function getOperationalTimes(Request $request, OperationalHoursService $service){
        try{
            $response = $service->getOperationalHoursService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Update the user operational hours.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\OperationalHoursService $service
     * @return \Illuminate\Http\Response
     */
    public function updateOperationalTimes(Request $request, OperationalHoursService $service){
        try{
            $response = $service->updateOperationalHoursService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
