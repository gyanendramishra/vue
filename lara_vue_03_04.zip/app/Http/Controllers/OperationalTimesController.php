<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\OperationalTimesService;

class OperationalTimesController extends Controller
{ 

    /**
     * Show the user operational hours.
     *
     * @param Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request){
    
        return view('operational_times.index');
    }

    /**
     * Get the user operational Times.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\OperationalTimesService $service
     * @return \Illuminate\Http\Response
     */
    public function getOperationalTimes(Request $request, OperationalTimesService $service){
        try{
            $response = $service->getOperationalTimesService();
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Update the user operational hours.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\OperationalTimesService $service
     * @return \Illuminate\Http\Response
     */
    public function updateOperationalTimes(Request $request, OperationalTimesService $service){
        try{
            $response = $service->updateOperationalTimesService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
