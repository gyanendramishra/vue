@extends('layouts.app')

@section('content')

<div class="topInnerBanner" style="background-image:url(/images/login_body_bg.jpg);">
	<div class="container">
	    <div class="topBannerMidCol">
	      	<h1>
	      		Service <strong>Detail</strong>
	      	</h1>
	    </div>
	</div>
</div>
<div class="breadcrumb-sec">
  	<div class="container">
	    <ul>
		    <li>
		      	<a href="{{ route('home') }}">
			      	Home
			    </a>
		    </li>
		    <li>
		      	<a href="{{ route('service.providers') }}">
			      	Service providers
			    </a>
		    </li>
	        <li>
		        Service detail
		    </li>
	    </ul>
  	</div>
</div>
<div class="mainWpapContainer">
 	<service-detail-component :service-id='{{ $serviceId }}' :is-logged-in='{{ $isLoggedIn }}'></service-detail-component>
</div>

@endsection
