
/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue');

window.events = new Vue();
window.flash = function(message, variant) {
    window.events.$emit('flash', { message, variant});
}

/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

// const files = require.context('./', true, /\.vue$/i);
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default));

Vue.component('flash-component', require('./components/FlashComponent.vue').default);

/* Auth component */
Vue.component('login-component', require('./components/auth/LoginComponent.vue').default);
Vue.component('register-component', require('./components/auth/RegisterComponent.vue').default);
Vue.component('forgot-password-component', require('./components/auth/ForgotPasswordComponent.vue').default);

/* Guest component */
Vue.component('main-sliders-component', require('./components/home/MainSlidersComponent.vue').default);
Vue.component('how-it-works-component', require('./components/home/HowItWorksComponent.vue').default);
Vue.component('near-service-providers-component', require('./components/home/NearServiceProvidersComponent.vue').default);
Vue.component('custom-header-component', require('./components/CustomHeaderComponent.vue').default);

/* Service provider component */

Vue.component('service-providers-component', require('./components/service/ServiceProvidersComponent.vue').default);

/* Service detail component */

Vue.component('service-detail-component', require('./components/service/ServiceDetailComponent.vue').default);

/* Change password component */

Vue.component('change-password-component', require('./components/change_password/ChangePasswordComponent.vue').default);

/* My profile component */

Vue.component('my-profile-component', require('./components/my_profile/MyProfileComponent.vue').default);

/* Operational time  component */

Vue.component('operational-time-component', require('./components/operational_time/OperationalTimeComponent.vue').default);

/* Bookings component  */

Vue.component('booking-component', require('./components/booking/BookingComponent.vue').default);

/* My service component */

Vue.component('my-service-component', require('./components/my_service/MyServiceComponent.vue').default);

/* Payment component */
Vue.component('payment-component', require('./components/payment/PaymentComponent.vue').default);

/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

const app = new Vue({
    el: '#app'
});
