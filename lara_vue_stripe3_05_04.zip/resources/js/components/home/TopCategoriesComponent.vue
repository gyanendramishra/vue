<template>
    <div class="top-category-sec global-slider-controls" v-if="most_popular_categories.length > 0">
        <div class="container">
            <div class="titleSec">
                <h2>Top Category</h2>
            </div>
            <div id="top-category-slider" class="owl-carousel top-category-slider">
                <div class="item" v-for="user in most_popular_categories[0].users">
                    <div class="top-category-col">
                        <div class="userCol">
                            <img :src="user.profile_photo" alt="" />
                            <h4>{{ user.name }}</h4>
                            <span>{{ user.service_name }}</span>
                            <div class="category-rating-col">
                                <i class="fa fa-star"></i> {{ user.star_rate }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border-btn-sec">
                <a href="#" class="border-btn">View all</a>
            </div>
        </div>
    </div>
</template>
<script>
    import 'owl.carousel/dist/assets/owl.carousel.css';
    import 'owl.carousel';
    export default {
        name: "top-categories-component",
        props:["most_popular_categories"],
        mounted: function(){
            Vue.nextTick(function(){
                alert();
                window.$(".top-category-slider").owlCarousel({
                    loop:true,
                    margin:0,
                    nav:true,
                    dots:false,
                    autoplay:false,
                    center: true,
                    responsive:{
                        0:{
                            items:1 
                        },
                        767:{
                            items:1
                        },
                        1199:{
                            items:2
                        },
                        1200:{
                            items:3
                        },
                        1400:{
                            items:3
                        }
                        
                    }
                });
            }.bind(this));
        }
    };
</script>
