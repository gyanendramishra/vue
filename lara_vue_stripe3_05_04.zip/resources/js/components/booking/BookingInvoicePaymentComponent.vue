<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div class="my-booking-sec my-booking-detail">
                    <h3>{{ booking.title }}</h3>
                    <div class="invoice-date">
                        <span>{{ booking.request_date_time | formatDate }}</span>
                    </div>
                    <div class="book-pay-status-sec invoice-status">
                        <ul>
                            <li>
                                <div class="book-status-left">
                                <strong>Payable Amount:</strong>
                                </div>
                                <div class="book-status-right">
                                    <span class="price-booking">
                                        <strong>
                                            ${{ booking.payable_amount }}
                                        </strong>
                                        <small>(incl. all taxes)</small>
                                    </span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <form @submit.prevent="makePayment">
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                Card Number
                                <span class="red-color">*</span>
                            </label>
                            <div ref="card_number"></div>
                            <div v-if="cardNumberError" class="text-danger">
                                {{ cardNumberError }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                Expiry
                                <span class="red-color">*</span>
                            </label>
                            <div ref="card_expiry"></div>
                            <div v-if="cardExpiryError" class="text-danger">
                                {{ cardExpiryError }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                Card CVC
                                <span class="red-color">*</span>
                            </label>
                            <div ref="card_cvc"></div>
                            <div v-if="cardCvcError" class="text-danger">
                                {{ cardCvcError }}
                            </div>
                        </div>
                    </div>
                    <div class="full-btn-col">
                        <input type="submit" value="Pay">
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
    import moment from "moment";
    import VeeValidate from 'vee-validate';
    import LoaderComponent from "../LoaderComponent.vue";
    Vue.use(VeeValidate);
    export default {
        name: "booking-invoice-payment-component",
        components:{
            LoaderComponent
        },
        props:["bookingId"],
        data: function () {
            return {
                loading: false,
                booking: {},
                card: {
                    cvc: '',
                    number: '',
                    expiry: ''
                },
                cardNumber: '',
                cardExpiry: '',
                cardCvc: '',
                stripe: null,
                stripeError: '',
                cardCvcError: '',
                cardExpiryError: '',
                cardNumberError: '',
            }
        },
        created: function(){
            this.loading = true;
            this.getBooking();
        },
        filters: {
            formatDate : function(date){
                return moment(date, 'YYYY-MM-DD H:i:s').format('DD MMM YYYY h:mm a');
            },
            formatNumber(value) {
                return (value/1).toFixed(2);
            }
        },
        methods: {
            getBooking() {
                this.loading = true;
                axios.post('/booking/get/data', {
                    id: this.bookingId
                }).then(response => {
                    if(response.data.status === true){
                        this.booking = response.data.data;
                        this.setUpStripe();
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            makePayment() {
                this.loading = true;
                this.clearCardErrors();
                let valid = true;
                if (!this.card.number) {
                    valid = false;
                    this.cardNumberError = "Card Number is Required";
                }
                if (!this.card.cvc) {
                    valid = false;
                    this.cardCvcError = "CVC is Required";
                }
                if (!this.card.expiry) {
                    valid = false;
                    this.cardExpiryError = "Month is Required";
                }
                if (this.stripeError) {
                    valid = false;
                }
                if (valid) {
                    this.createToken()
                }else{
                    this.loading = false;
                }
            },
            setUpStripe() {
                if (window.Stripe === undefined) {
                    flash('Stripe V3 library not loaded!', 'error');
                } else {
                    const stripe = window.Stripe(this.booking.stripe_public_key);
                    this.stripe = stripe;

                    const elements = stripe.elements();
                    this.cardCvc = elements.create('cardCvc');
                    this.cardExpiry = elements.create('cardExpiry');
                    this.cardNumber = elements.create('cardNumber');

                    this.cardCvc.mount(this.$refs.card_cvc);
                    this.cardExpiry.mount(this.$refs.card_expiry);
                    this.cardNumber.mount(this.$refs.card_number);
                    this.listenForErrors();
                }
            },
            listenForErrors() {
                const vm = this;

                this.cardNumber.addEventListener('change', (event) => {
                    vm.toggleError(event);
                    vm.cardNumberError = '';
                    vm.card.number = event.complete ? true : false
                });
                        
                this.cardExpiry.addEventListener('change', (event) => {
                    vm.toggleError(event);
                    vm.cardExpiryError = '';
                    vm.card.expiry = event.complete ? true : false
                });
                
                this.cardCvc.addEventListener('change', (event) => {
                    vm.toggleError(event);
                    vm.cardCvcError = '';
                    vm.card.cvc = event.complete ? true : false
                });
            },

            toggleError (event) {
                if (event.error) {
                    this.stripeError = event.error.message;
                    flash(event.error.message, 'error');
                } else {
                    this.stripeError = '';
                }
            },
            createToken() {
                this.stripe.createToken(this.cardNumber).then((result) => {
                    if (result.error) {
                        this.stripeError = result.error.message;
                        flash(result.error.message, 'error');
                        this.loading = false;
                    } else {
                        const token = result.token.id;
                        axios.post('/booking/invoice/payment/make-payment', {
                            stripeToken: token,
                            booking_id: this.booking.id,
                        }).then(response => {
                            if(response.data.status === true){
                                flash(response.data.message, 'success');
                                window.location = '/booking/detail/'+this.booking.title.toLowerCase().replace(/ /g, '-')+"-"+this.booking.id; 
                            }else{
                                if(response.data.error){
                                    var message =  response.data.error[0];
                                    flash(message.replace('_', ' '), 'error');
                                }else{
                                    flash(response.data.message, 'error');
                                }
                            }
                            this.loading = false;
                        }).catch(error => {
                            this.loading = false;
                            console.log(error);
                        });
                    }
                });
            },
            clearCardErrors() {
                this.stripeError = ''
                this.cardCvcError = ''
                this.cardExpiryError = ''
                this.cardNumberError = ''
            },
        }
    }
</script>
