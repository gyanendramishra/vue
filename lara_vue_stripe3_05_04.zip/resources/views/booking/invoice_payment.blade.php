@extends('layouts.dashboard')
@section('page_header_title', 'Invoice Payment')
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
      	<a href="{{ route('user.booking') }}">
	      	Booking
	    </a>
    </li>
    <li>
        Invoice payment
    </li>
@endsection

@section('dashboard_content')
  	<booking-invoice-payment-component :booking-id='{{ $bookingId }}'></booking-invoice-payment-component>
@endsection

