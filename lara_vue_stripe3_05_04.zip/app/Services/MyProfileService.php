<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class MyProfileService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/users/';


    /**
     * Get the user profile.
     *
     * @return Illuminate\Http\Response
     */
    public function getProfileService() {
        $uri = $this->base_uri;
        $uri .= 'profile'; 
        return $this->getServiceRequest($uri);
    }

    /**
     * Update the user prifle.
     *
     * @param  array  $data
     * @return Illuminate\Http\Response
     */
    public function updateProfileService(array $data) {
        $uri = $this->base_uri;
        $uri .= 'profile'; 
        return $this->postFileRequest($uri, $data);
    }

    

}