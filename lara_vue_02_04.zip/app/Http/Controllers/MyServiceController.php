<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\MyServiceService;

class MyServiceController extends Controller
{ 

    /**
     * Show the user profile.
     *
     * @param Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request){
    
        return view('my_service.index');
    }

    /**
     * Get the user service.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\MyServiceService $service
     * @return \Illuminate\Http\Response
     */
    public function getService(Request $request, MyServiceService $service){
        try{
            $response = $service->getMyService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Update the user service.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\MyServiceService $service
     * @return \Illuminate\Http\Response
     */
    public function saveUpdateService(Request $request, MyServiceService $service){
        try{
            $file = $request->file('image_file');
            $formUrlencodedHeader=['content-type' => 'application/x-www-form-urlencoded'];
            $formMultipartHeader = ['content-type' => 'multipart/form-data'];
            $data = [
                        [
                            'name'     => 'title',
                            'contents' => $request->title,
                            'headers'  => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'category_id',
                            'contents' => $request->category_id,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'address',
                            'contents' => $request->address,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'longitude',
                            'contents' => $request->longitude,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'latitude',
                            'contents' => $request->latitude,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'description',
                            'contents' => $request->description,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'price',
                            'contents' => $request->price,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'image_file',
                            'filename' => $file->getClientOriginalName(),
                            'Mime-Type'=> $file->getmimeType(),
                            'contents' => fopen($file->getPathname(), 'r'),
                            'headers' => $formMultipartHeader
                        ],  
                    ];
            $response = $service->saveUpdateMyService($data);
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
