<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class ServiceProvidersService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/categories/';


    /**
     * Get the user profile.
     *
     * @param array $filter
     * @return Illuminate\Http\Response
     */
    public function getServiceProvidersService($filter) {
        $uri = $this->base_uri;
        $uri .= 'getServiceProvider'; 
        return $this->postServiceRequest($uri, $filter);
    }

}