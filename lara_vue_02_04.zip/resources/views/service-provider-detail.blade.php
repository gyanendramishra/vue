@extends('layouts.app')

@section('content')

<div class="topInnerBanner" style="background-image:url(/images/login_body_bg.jpg);">
	<div class="container">
	    <div class="topBannerMidCol">
	      	<h1>
	      		Service <strong>Detail</strong>
	      	</h1>
	    </div>
	</div>
</div>
<div class="breadcrumb-sec">
  	<div class="container">
	    <ul>
		    <li>
		      	<a href="{{ route('home') }}">
			      	Home
			    </a>
		    </li>
	        <li>
		        Service detail
		    </li>
	    </ul>
  	</div>
</div>
<div class="mainWpapContainer">
  	<div class="product-detail-page">
	    <div class="product-detail-top-sec">
		    <div class="container">
		        <div class="row">
			       	<div class="col-md-6">
			            <div class="product-detail-img-col"> 
			            	<img src="/images/pro_detail_img01.jpg" alt=""> 
			            </div>
			        </div>
		          	<div class="col-md-6">
		            	<div class="product-detail-content">
		              		<div class="pro-user-sec">
		                		<div class="pro-user-pic">
		                			<a href="#">
		                				<img src="/images/top_category_img01.jpg" alt="">
		                			</a>
		                		</div>
				                <div class="user-profile-txt">
				                  	<div class="user-profile-name">
				                  		Daniel Christopher
				                  	</div>
				                  	<div class="rating-icon-col">
				                  		<i class="fa fa-star"></i> 5.0
				                  	</div>
				                </div>
				            </div>
				            <ul class="product-price-info">
				                <li>
				                  	<div class="left-info-label"> 
				                  		<img src="/images/price_info_icon01.png" alt="" /> 
				                  		<span>Category:</span> 
				                  	</div>
				                  	<div class="right-info-detail">
				                  		Lifestyle
				                  	</div>
				                </li>
				                <li>
				                  	<div class="left-info-label"> 
				                  		<img src="/images/price_info_icon02.png" alt="" /> 
				                  		<span>Starting At:</span> 
				                  	</div>
				                  	<div class="right-info-detail">
				                  		<strong class="price-text">
				                  			$20.00
				                  		</strong>
				                  	</div>
				                </li>
				            </ul>
		              		<a href="#" class="border-btn">
			              		Book Now
			              	</a> 
		              	</div>
		          	</div>
		        </div>
		    </div>
	    </div>
    	<div class="content-sec">
	      	<div class="container">
	        	<div class="content-inner">
			        <div class="inner-page-sec-title">
			            <h3>Description</h3>
			        </div>
		          	<h5>
		          		Cras ultrices ligula sed nulla cursus commodo. Vivamus a tristique massa. 
		          	</h5>
		          	<p>
		          		Cras at interdum risus, mattis ornare tellus. Duis nec erat et tellus vestibulum vehicula. Ut consequat pulvinar felis ac pharetra. Donec maximus augue a sollicitudin egestas. Vestibulum dictum iaculis egestas. Cras mauris mi, fermentum et venenatis sit amet, condimentum et lacus. Nunc fermentum luctus est eget placerat. Integer vel urna tincidunt, facilisis tellus vitae, varius ante. Duis ut venenatis orci. Vestibulum non quam a ligula dignissim facilisis. Vivamus imperdiet finibus nunc, ut convallis odio gravida at. 
		          	</p>
		        </div>
	      	</div>
    	</div>
	    <div class="content-sec reviews-sec">
	      	<div class="container">
	        	<div class="content-inner">
          			<div class="inner-page-sec-title">
            			<h3>Customer Reviews</h3>
          			</div>
          			<div class="review-col">
            			<div class="review-icon-col">
            				<img src="/images/top_category_img03.jpg" alt="">
            			</div>
			            <div class="review-text-col">
			              	<h4>
			              		David Filintop
			              	</h4>
			              	<div class="review-date">
			              		Posted on December 25, 2013 at 6:57 am
			                	<div class="rating-icon-col">
			                		<i class="fa fa-star"></i> 5.0
			                	</div>
			              	</div>
			             	<p>
			             		Curabitur vitae leo sed justo aliquet euismod aliquam sit amet tortor. Vivamus laoreet dui libero, quis elementum arcu pharetra eu. Donec tortor lorem, ultricies a dictum eget, porttitor et est. In aliquam odio id posuere volutpat.
			             	</p>
			            </div>
          			</div>
			        <div class="review-col">
			            <div class="review-icon-col">
			            	<img src="/images/top_category_img01.jpg" alt="">
			            </div>
			            <div class="review-text-col">
			              	<h4>Andrew Philip</h4>
				            <div class="review-date">
				            	Posted on December 25, 2013 at 6:57 am
				                <div class="rating-icon-col">
				                	<i class="fa fa-star"></i> 5.0
				                </div>
				            </div>
			              	<p>
			              		Curabitur vitae leo sed justo aliquet euismod aliquam sit amet tortor. Vivamus laoreet dui libero, quis elementum arcu pharetra eu. Donec tortor lorem, ultricies a dictum eget, porttitor et est. In aliquam odio id posuere volutpat.
			              	</p>
			            </div>
			        </div>
			        <div class="review-col">
			            <div class="review-icon-col">
			            	<img src="/images/top_category_img02.jpg" alt="">
			            </div>
			            <div class="review-text-col">
			              	<h4>
			              		Stacy Clark
			              	</h4>
				            <div class="review-date">
				            	Posted on December 25, 2013 at 6:57 am
				                <div class="rating-icon-col">
				                	<i class="fa fa-star"></i> 5.0
				                </div>
				            </div>
			              	<p>
			              		Curabitur vitae leo sed justo aliquet euismod aliquam sit amet tortor. Vivamus laoreet dui libero, quis elementum arcu pharetra eu. Donec tortor lorem, ultricies a dictum eget, porttitor et est. In aliquam odio id posuere volutpat.
			              	</p>
			            </div>
			        </div>
	        	</div>
	      	</div>
	    </div>
	</div>
</div>

@endsection
