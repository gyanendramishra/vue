<template>
    <div class="formBox editProfileForm">
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div ref="add_account_form">
                    <div class="field-required">
                        <p>Add payment detail</p>
                    </div>
                    <form @submit.prevent="addAccount">
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Country Code
                                    <span class="red-color">*</span>
                                </label>
                                <select v-model="fields.stripe_country" class="country-picker" ref="stripe_country">
                                </select>
                                <div v-if="errors && errors.stripe_country" class="text-danger">
                                    {{ errors.stripe_country[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Email
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Email" v-model="fields.stripe_email">
                                <div v-if="errors && errors.stripe_email" class="text-danger">
                                    {{ errors.stripe_email[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="full-btn-col">
                            <div v-if="!loading">
                                <input type="submit" value="Submit" name="">
                            </div>
                            <div v-else>
                                <input type="submit" value="loading..." disable="disabled">
                            </div>
                        </div>
                    </form>
                </div>
                <div ref="update_account_form" style="display:none">
                    <div class="field-required">
                        <p>Update payment detail</p>
                    </div>
                    <form @submit.prevent="UpdateAccount">
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    First Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="First Name" v-model="fields.first_name">
                                <div v-if="errors && errors.first_name" class="text-danger">
                                    {{ errors.first_name[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Last Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Last Name" v-model="fields.last_name">
                                <div v-if="errors && errors.last_name" class="text-danger">
                                    {{ errors.last_name[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Date of birth (must be atleast 13 year old)
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" ref="dob" placeholder="Date of birth" v-model="fields.dob">
                                <div v-if="errors && errors.dob" class="text-danger">
                                    {{ errors.dob[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Address
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Address" v-model="fields.address">
                                <div v-if="errors && errors.address" class="text-danger">
                                    {{ errors.address[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Country Code
                                    <span class="red-color">*</span>
                                </label>
                                <select v-model="fields.country" ref="country">
                                </select>
                                <div v-if="errors && errors.country" class="text-danger">
                                    {{ errors.country[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    State
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Address" v-model="fields.state">
                                <div v-if="errors && errors.state" class="text-danger">
                                    {{ errors.state[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    City
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="City" v-model="fields.city">
                                <div v-if="errors && errors.city" class="text-danger">
                                    {{ errors.city[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Postal Code
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Postal Code" v-model="fields.postal_code">
                                <div v-if="errors && errors.postal_code" class="text-danger">
                                    {{ errors.postal_code[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Business Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Business Name" v-model="fields.stripe_business_name">
                                <div v-if="errors && errors.stripe_business_name" class="text-danger">
                                    {{ errors.stripe_business_name[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Legal Business Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Legal Business Name" v-model="fields.legal_business_name">
                                <div v-if="errors && errors.legal_business_name" class="text-danger">
                                    {{ errors.legal_business_name[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Personal Id Number
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Personal Id Number" v-model="fields.personal_id_number">
                                <div v-if="errors && errors.personal_id_number" class="text-danger">
                                    {{ errors.personal_id_number[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Account Holder Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Account Holder Name" v-model="fields.account_holder_name">
                                <div v-if="errors && errors.account_holder_name" class="text-danger">
                                    {{ errors.account_holder_name[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Account Number
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Account Number" v-model="fields.account_number">
                                <div v-if="errors && errors.account_number" class="text-danger">
                                    {{ errors.account_number[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Sort Code
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Sort Code" v-model="fields.sort_code">
                                <div v-if="errors && errors.sort_code" class="text-danger">
                                    {{ errors.sort_code[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Currency
                                    <span class="red-color">*</span>
                                </label>
                                <select v-model="fields.currency" ref="currency">
                                </select>
                                <div v-if="errors && errors.currency" class="text-danger">
                                    {{ errors.currency[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="full-btn-col">
                            <div v-if="!loading">
                                <input type="submit" value="Submit" name="">
                            </div>
                            <div v-else>
                                <input type="submit" value="loading..." disable="disabled">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import "bootstrap-datepicker/dist/css/bootstrap-datepicker.css";
    import "select2/dist/css/select2.css";
    import "flag-icon-css/css/flag-icon.css";
    import datepicker from "bootstrap-datepicker";
    import 'select2/dist/js/select2.full.js'
    export default {
        name: "payment-component",
        data: function () {
            return {
                fields:{},
                errors: {},
                loading: false,
                isPaymentAdded : false,
                isoCountries : [
                    { id: '', text: 'Select Country'},
                    { id: 'AF', text: 'Afghanistan'},
                    { id: 'AL', text: 'Albania'},
                    { id: 'DZ', text: 'Algeria'},
                    { id: 'AS', text: 'American Samoa'},
                    { id: 'AD', text: 'Andorra'},
                    { id: 'AO', text: 'Angola'},
                    { id: 'AI', text: 'Anguilla'},
                    { id: 'AG', text: 'Antigua And Barbuda'},
                    { id: 'AR', text: 'Argentina'},
                    { id: 'AM', text: 'Armenia'},
                    { id: 'AW', text: 'Aruba'},
                    { id: 'AU', text: 'Australia'},
                    { id: 'AT', text: 'Austria'},
                    { id: 'AZ', text: 'Azerbaijan'},
                    { id: 'BS', text: 'Bahamas'},
                    { id: 'BH', text: 'Bahrain'},
                    { id: 'BD', text: 'Bangladesh'},
                    { id: 'BB', text: 'Barbados'},
                    { id: 'BY', text: 'Belarus'},
                    { id: 'BE', text: 'Belgium'},
                    { id: 'BZ', text: 'Belize'},
                    { id: 'BJ', text: 'Benin'},
                    { id: 'BM', text: 'Bermuda'},
                    { id: 'BT', text: 'Bhutan'},
                    { id: 'BO', text: 'Bolivia'},
                    { id: 'BA', text: 'Bosnia And Herzegovina'},
                    { id: 'BW', text: 'Botswana'},
                    { id: 'BV', text: 'Bouvet Island'},
                    { id: 'BR', text: 'Brazil'},
                    { id: 'IO', text: 'British Indian Ocean Territory'},
                    { id: 'BN', text: 'Brunei Darussalam'},
                    { id: 'BG', text: 'Bulgaria'},
                    { id: 'BF', text: 'Burkina Faso'},
                    { id: 'BI', text: 'Burundi'},
                    { id: 'KH', text: 'Cambodia'},
                    { id: 'CM', text: 'Cameroon'},
                    { id: 'CA', text: 'Canada'},
                    { id: 'CV', text: 'Cape Verde'},
                    { id: 'KY', text: 'Cayman Islands'},
                    { id: 'CF', text: 'Central African Republic'},
                    { id: 'TD', text: 'Chad'},
                    { id: 'CL', text: 'Chile'},
                    { id: 'CN', text: 'China'},
                    { id: 'CX', text: 'Christmas Island'},
                    { id: 'CC', text: 'Cocos (Keeling) Islands'},
                    { id: 'CO', text: 'Colombia'},
                    { id: 'KM', text: 'Comoros'},
                    { id: 'CG', text: 'Congo'},
                    { id: 'CD', text: 'Congo}, Democratic Republic'},
                    { id: 'CK', text: 'Cook Islands'},
                    { id: 'CR', text: 'Costa Rica'},
                    { id: 'CI', text: 'Cote D\'Ivoire'},
                    { id: 'HR', text: 'Croatia'},
                    { id: 'CU', text: 'Cuba'},
                    { id: 'CY', text: 'Cyprus'},
                    { id: 'CZ', text: 'Czech Republic'},
                    { id: 'DK', text: 'Denmark'},
                    { id: 'DJ', text: 'Djibouti'},
                    { id: 'DM', text: 'Dominica'},
                    { id: 'DO', text: 'Dominican Republic'},
                    { id: 'EC', text: 'Ecuador'},
                    { id: 'EG', text: 'Egypt'},
                    { id: 'SV', text: 'El Salvador'},
                    { id: 'GQ', text: 'Equatorial Guinea'},
                    { id: 'ER', text: 'Eritrea'},
                    { id: 'EE', text: 'Estonia'},
                    { id: 'ET', text: 'Ethiopia'},
                    { id: 'FK', text: 'Falkland Islands (Malvinas)'},
                    { id: 'FO', text: 'Faroe Islands'},
                    { id: 'FJ', text: 'Fiji'},
                    { id: 'FI', text: 'Finland'},
                    { id: 'FR', text: 'France'},
                    { id: 'GF', text: 'French Guiana'},
                    { id: 'PF', text: 'French Polynesia'},
                    { id: 'TF', text: 'French Southern Territories'},
                    { id: 'GA', text: 'Gabon'},
                    { id: 'GM', text: 'Gambia'},
                    { id: 'GE', text: 'Georgia'},
                    { id: 'DE', text: 'Germany'},
                    { id: 'GH', text: 'Ghana'},
                    { id: 'GI', text: 'Gibraltar'},
                    { id: 'GR', text: 'Greece'},
                    { id: 'GL', text: 'Greenland'},
                    { id: 'GD', text: 'Grenada'},
                    { id: 'GP', text: 'Guadeloupe'},
                    { id: 'GU', text: 'Guam'},
                    { id: 'GT', text: 'Guatemala'},
                    { id: 'GG', text: 'Guernsey'},
                    { id: 'GN', text: 'Guinea'},
                    { id: 'GW', text: 'Guinea-Bissau'},
                    { id: 'GY', text: 'Guyana'},
                    { id: 'HT', text: 'Haiti'},
                    { id: 'HM', text: 'Heard Island & Mcdonald Islands'},
                    { id: 'VA', text: 'Holy See (Vatican City State)'},
                    { id: 'HN', text: 'Honduras'},
                    { id: 'HK', text: 'Hong Kong'},
                    { id: 'HU', text: 'Hungary'},
                    { id: 'IS', text: 'Iceland'},
                    { id: 'IN', text: 'India'},
                    { id: 'ID', text: 'Indonesia'},
                    { id: 'IR', text: 'Iran}, Islamic Republic Of'},
                    { id: 'IQ', text: 'Iraq'},
                    { id: 'IE', text: 'Ireland'},
                    { id: 'IM', text: 'Isle Of Man'},
                    { id: 'IL', text: 'Israel'},
                    { id: 'IT', text: 'Italy'},
                    { id: 'JM', text: 'Jamaica'},
                    { id: 'JP', text: 'Japan'},
                    { id: 'JE', text: 'Jersey'},
                    { id: 'JO', text: 'Jordan'},
                    { id: 'KZ', text: 'Kazakhstan'},
                    { id: 'KE', text: 'Kenya'},
                    { id: 'KI', text: 'Kiribati'},
                    { id: 'KR', text: 'Korea'},
                    { id: 'KW', text: 'Kuwait'},
                    { id: 'KG', text: 'Kyrgyzstan'},
                    { id: 'LA', text: 'Lao People\'s Democratic Republic'},
                    { id: 'LV', text: 'Latvia'},
                    { id: 'LB', text: 'Lebanon'},
                    { id: 'LS', text: 'Lesotho'},
                    { id: 'LR', text: 'Liberia'},
                    { id: 'LY', text: 'Libyan Arab Jamahiriya'},
                    { id: 'LI', text: 'Liechtenstein'},
                    { id: 'LT', text: 'Lithuania'},
                    { id: 'LU', text: 'Luxembourg'},
                    { id: 'MO', text: 'Macao'},
                    { id: 'MK', text: 'Macedonia'},
                    { id: 'MG', text: 'Madagascar'},
                    { id: 'MW', text: 'Malawi'},
                    { id: 'MY', text: 'Malaysia'},
                    { id: 'MV', text: 'Maldives'},
                    { id: 'ML', text: 'Mali'},
                    { id: 'MT', text: 'Malta'},
                    { id: 'MH', text: 'Marshall Islands'},
                    { id: 'MQ', text: 'Martinique'},
                    { id: 'MR', text: 'Mauritania'},
                    { id: 'MU', text: 'Mauritius'},
                    { id: 'YT', text: 'Mayotte'},
                    { id: 'MX', text: 'Mexico'},
                    { id: 'FM', text: 'Micronesia}, Federated States Of'},
                    { id: 'MD', text: 'Moldova'},
                    { id: 'MC', text: 'Monaco'},
                    { id: 'MN', text: 'Mongolia'},
                    { id: 'ME', text: 'Montenegro'},
                    { id: 'MS', text: 'Montserrat'},
                    { id: 'MA', text: 'Morocco'},
                    { id: 'MZ', text: 'Mozambique'},
                    { id: 'MM', text: 'Myanmar'},
                    { id: 'NA', text: 'Namibia'},
                    { id: 'NR', text: 'Nauru'},
                    { id: 'NP', text: 'Nepal'},
                    { id: 'NL', text: 'Netherlands'},
                    { id: 'AN', text: 'Netherlands Antilles'},
                    { id: 'NC', text: 'New Caledonia'},
                    { id: 'NZ', text: 'New Zealand'},
                    { id: 'NI', text: 'Nicaragua'},
                    { id: 'NE', text: 'Niger'},
                    { id: 'NG', text: 'Nigeria'},
                    { id: 'NU', text: 'Niue'},
                    { id: 'NF', text: 'Norfolk Island'},
                    { id: 'MP', text: 'Northern Mariana Islands'},
                    { id: 'NO', text: 'Norway'},
                    { id: 'OM', text: 'Oman'},
                    { id: 'PK', text: 'Pakistan'},
                    { id: 'PW', text: 'Palau'},
                    { id: 'PS', text: 'Palestinian Territory}, Occupied'},
                    { id: 'PA', text: 'Panama'},
                    { id: 'PG', text: 'Papua New Guinea'},
                    { id: 'PY', text: 'Paraguay'},
                    { id: 'PE', text: 'Peru'},
                    { id: 'PH', text: 'Philippines'},
                    { id: 'PN', text: 'Pitcairn'},
                    { id: 'PL', text: 'Poland'},
                    { id: 'PT', text: 'Portugal'},
                    { id: 'PR', text: 'Puerto Rico'},
                    { id: 'QA', text: 'Qatar'},
                    { id: 'RE', text: 'Reunion'},
                    { id: 'RO', text: 'Romania'},
                    { id: 'RU', text: 'Russian Federation'},
                    { id: 'RW', text: 'Rwanda'},
                    { id: 'BL', text: 'Saint Barthelemy'},
                    { id: 'SH', text: 'Saint Helena'},
                    { id: 'KN', text: 'Saint Kitts And Nevis'},
                    { id: 'LC', text: 'Saint Lucia'},
                    { id: 'MF', text: 'Saint Martin'},
                    { id: 'PM', text: 'Saint Pierre And Miquelon'},
                    { id: 'VC', text: 'Saint Vincent And Grenadines'},
                    { id: 'WS', text: 'Samoa'},
                    { id: 'SM', text: 'San Marino'},
                    { id: 'ST', text: 'Sao Tome And Principe'},
                    { id: 'SA', text: 'Saudi Arabia'},
                    { id: 'SN', text: 'Senegal'},
                    { id: 'RS', text: 'Serbia'},
                    { id: 'SC', text: 'Seychelles'},
                    { id: 'SL', text: 'Sierra Leone'},
                    { id: 'SG', text: 'Singapore'},
                    { id: 'SK', text: 'Slovakia'},
                    { id: 'SI', text: 'Slovenia'},
                    { id: 'SB', text: 'Solomon Islands'},
                    { id: 'SO', text: 'Somalia'},
                    { id: 'ZA', text: 'South Africa'},
                    { id: 'GS', text: 'South Georgia And Sandwich Isl.'},
                    { id: 'ES', text: 'Spain'},
                    { id: 'LK', text: 'Sri Lanka'},
                    { id: 'SD', text: 'Sudan'},
                    { id: 'SR', text: 'Suriname'},
                    { id: 'SJ', text: 'Svalbard And Jan Mayen'},
                    { id: 'SZ', text: 'Swaziland'},
                    { id: 'SE', text: 'Sweden'},
                    { id: 'CH', text: 'Switzerland'},
                    { id: 'SY', text: 'Syrian Arab Republic'},
                    { id: 'TW', text: 'Taiwan'},
                    { id: 'TJ', text: 'Tajikistan'},
                    { id: 'TZ', text: 'Tanzania'},
                    { id: 'TH', text: 'Thailand'},
                    { id: 'TL', text: 'Timor-Leste'},
                    { id: 'TG', text: 'Togo'},
                    { id: 'TK', text: 'Tokelau'},
                    { id: 'TO', text: 'Tonga'},
                    { id: 'TT', text: 'Trinidad And Tobago'},
                    { id: 'TN', text: 'Tunisia'},
                    { id: 'TR', text: 'Turkey'},
                    { id: 'TM', text: 'Turkmenistan'},
                    { id: 'TC', text: 'Turks And Caicos Islands'},
                    { id: 'TV', text: 'Tuvalu'},
                    { id: 'UG', text: 'Uganda'},
                    { id: 'UA', text: 'Ukraine'},
                    { id: 'AE', text: 'United Arab Emirates'},
                    { id: 'GB', text: 'United Kingdom'},
                    { id: 'US', text: 'United States'},
                    { id: 'UM', text: 'United States Outlying Islands'},
                    { id: 'UY', text: 'Uruguay'},
                    { id: 'UZ', text: 'Uzbekistan'},
                    { id: 'VU', text: 'Vanuatu'},
                    { id: 'VE', text: 'Venezuela'},
                    { id: 'VN', text: 'Viet Nam'},
                    { id: 'VG', text: 'Virgin Islands}, British'},
                    { id: 'VI', text: 'Virgin Islands}, U.S.'},
                    { id: 'WF', text: 'Wallis And Futuna'},
                    { id: 'EH', text: 'Western Sahara'},
                    { id: 'YE', text: 'Yemen'},
                    { id: 'ZM', text: 'Zambia'},
                    { id: 'ZW', text: 'Zimbabwe'}
                ],
                isoCurrencies : [
                    { id: '', text: 'Select currency', country_code: ''},
                    { id: 'AFN', text: 'AFN', country_code: 'AF'},
                    { id: 'ALL', text: 'ALL', country_code: 'AL'},
                    { id: 'DZD', text: 'DZD', country_code: 'DZ'},
                    { id: 'USD', text: 'USD', country_code: 'AS'},
                    { id: 'EUR', text: 'EUR', country_code: 'AD'},
                    { id: 'AOA', text: 'AOA', country_code: 'AO'},
                    { id: 'XCD', text: 'XCD', country_code: 'AI'},
                    { id: 'XCD', text: 'XCD', country_code: 'AG'},
                    { id: 'ARS', text: 'ARS', country_code: 'AR'},
                    { id: 'AMD', text: 'AMD', country_code: 'AM'},
                    { id: 'AWG', text: 'AWG', country_code: 'AW'},
                    { id: 'AUD', text: 'AUD', country_code: 'AU'},
                    { id: 'EUR', text: 'EUR', country_code: 'AT'},
                    { id: 'AZN', text: 'AZN', country_code: 'AZ'},
                    { id: 'BSD', text: 'BSD', country_code: 'BS'},
                    { id: 'BHD', text: 'BHD', country_code: 'BH'},
                    { id: 'BDT', text: 'BDT', country_code: 'BD'},
                    { id: 'BBD', text: 'BBD', country_code: 'BB'},
                    { id: 'BYR', text: 'BYR', country_code: 'BY'},
                    { id: 'EUR', text: 'EUR', country_code: 'BE'},
                    { id: 'BZD', text: 'BZD', country_code: 'BZ'},
                    { id: 'XOF', text: 'XOF', country_code: 'BJ'},
                    { id: 'BMD', text: 'BMD', country_code: 'BM'},
                    { id: 'BTN', text: 'BTN', country_code: 'BT'},
                    { id: 'BOB', text: 'BOB', country_code: 'BO'},
                    { id: 'BAM', text: 'BAM', country_code: 'BA'},
                    { id: 'BWP', text: 'BWP', country_code: 'BW'},
                    { id: 'NOK', text: 'NOK', country_code: 'BV'},
                    { id: 'BRL', text: 'BRL', country_code: 'BR'},
                    { id: 'USD', text: 'USD', country_code: 'IO'},
                    { id: 'BND', text: 'BND', country_code: 'BN'},
                    { id: 'BGN', text: 'BGN', country_code: 'BG'},
                    { id: 'XOF', text: 'XOF', country_code: 'BF'},
                    { id: 'BIF', text: 'BIF', country_code: 'BI'},
                    { id: 'KHR', text: 'KHR', country_code: 'KH'},
                    { id: 'XAF', text: 'XAF', country_code: 'CM'},
                    { id: 'CAD', text: 'CAD', country_code: 'CA'},
                    { id: 'BOB', text: 'BOB', country_code: 'CV'},
                    { id: 'KYD', text: 'KYD', country_code: 'KY'},
                    { id: 'XAF', text: 'XAF', country_code: 'CF'},
                    { id: 'XAF', text: 'XAF', country_code: 'TD'},
                    { id: 'CLF', text: 'CLF', country_code: 'CL'},
                    { id: 'CNY', text: 'CNY', country_code: 'CN'},
                    { id: 'AUD', text: 'AUD', country_code: 'CX'}
                ]
            }
        },
        methods: {
            addAccount() {
                this.loading = true;
                this.errors = {};
                axios.post('/payment/add/account', this.fields).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                        $(this.$refs.add_account_form).hide();
                        $(this.$refs.update_account_form).show();
                    }else{
                        if(response.data.error){
                            var message =  response.data.error[0];
                            flash(message.replace('_', ' '), 'error');
                        }else{
                            flash(response.data.message, 'error');
                        }
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },
            UpdateAccount() {
                this.loading = true;
                this.errors = {};
                axios.post('/payment/update/account', this.fields).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                        window.location = "/dashboard"
                    }else{
                        if(response.data.error){
                            var message =  response.data.error[0];
                            flash(message.replace('_', ' '), 'error');
                        }else{
                            flash(response.data.message, 'error');
                        }
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },

            formatCountry(country) {
                if (!country.id) { return country.text; }
                var $country = $(
                    '<span class="flag-icon flag-icon-'+ country.id.toLowerCase() +' flag-icon-squared"></span> ' +
                    '<span class="flag-text">'+ country.text+"</span>"
                );
                return $country;
            },

            formatCurrency(country) {
                if (!country.id) { return country.currency; }
                var $currency = $(
                    '<span class="flag-icon flag-icon-'+ country.country_code.toLowerCase() +' flag-icon-squared"></span> ' +
                    '<span class="flag-text">'+ country.text+"</span>"
                );
                return $currency;
            }

        },
        mounted(){
            var vm = this;
            Vue.nextTick(function(){
                $(vm.$refs.dob).datepicker({
                    format: "dd-mm-yyyy"
                }).on('changeDate', function(e) {
                    vm.fields.dob = e.format();
                }).on('changeMonth', function(e) {
                    vm.fields.dob = e.format();
                }).on('changeYear', function(e) {
                    vm.fields.dob = e.format();
                });

                $(vm.$refs.stripe_country).select2({
                    placeholder: "Select a country",
                    templateResult: this.formatCountry,
                    data: this.isoCountries
                }).on('change', function () {
                    vm.fields.stripe_country = this.value;
                });

                $(vm.$refs.country).select2({
                    placeholder: "Select a country",
                    templateResult: this.formatCountry,
                    data: this.isoCountries
                }).on('change', function () {
                    vm.fields.country = this.value;
                });

                $(vm.$refs.currency).select2({
                    placeholder: "Select a country",
                    templateResult: this.formatCurrency,
                    data: this.isoCurrencies
                }).on('change', function () {
                    vm.fields.currency = this.value;
                });
            }.bind(this));
        }
    }
</script>
<style scoped>
    .flag-text { margin-left: 10px; }
</style>

