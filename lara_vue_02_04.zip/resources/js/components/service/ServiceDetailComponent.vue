<template>
    <div>
        <div class="product-detail-page">
            <div class="product-detail-top-sec">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="product-detail-img-col"> 
                                <img :src="service.service_image" alt=""> 
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="product-detail-content">
                                <div class="pro-user-sec">
                                    <div class="pro-user-pic">
                                        <a href="javascript:;">
                                            <img :src="service.full_image_path" alt="">
                                        </a>
                                    </div>
                                    <div class="user-profile-txt">
                                        <div class="user-profile-name">
                                            {{ service.provider_name }}
                                        </div>
                                        <div class="rating-icon-col">
                                            <i class="fa fa-star"></i> {{ service.star_rate | formatNumber }}
                                        </div>
                                        <div class="user-share-icons">
                                            <a href=""><i class="fa fa-facebook-f"></i></a>
                                            <a href=""><i class="fa fa-twitter"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <ul class="product-price-info">
                                    <li>
                                        <div class="left-info-label"> 
                                            <img src="/images/price_info_icon01.png" alt="" /> 
                                            <span>Category:</span> 
                                        </div>
                                        <div class="right-info-detail">
                                            {{ service.category_title }}
                                        </div>
                                    </li>
                                    <li>
                                        <div class="left-info-label"> 
                                            <img src="/images/price_info_icon02.png" alt="" /> 
                                            <span>Starting At:</span> 
                                        </div>
                                        <div class="right-info-detail">
                                            <strong class="price-text">
                                                ${{ service.price | formatNumber }}
                                            </strong>
                                        </div>
                                    </li>
                                </ul>
                                <a href="javascript:;" class="border-btn" @click="processBooking">
                                    Book Now
                                </a> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-sec">
                <div class="container">
                    <div class="content-inner">
                        <div class="inner-page-sec-title">
                            <h3>Description</h3>
                        </div>
                        <h5>
                            {{ service.title }}
                        </h5>
                        <p>
                            {{ service.description }}
                        </p>
                    </div>
                </div>
            </div>
            <div class="content-sec reviews-sec">
                <div class="container">
                    <div class="content-inner">
                        <div class="inner-page-sec-title">
                            <h3>Customer Reviews</h3>
                        </div>
                        <div v-if="service.review_count > 0">
                            <div class="review-col" v-for="service_review in service.review">
                                <div class="review-icon-col">
                                    <img :src="service_review.full_image_path" alt="">
                                </div>
                                <div class="review-text-col">
                                    <h4>
                                        {{ service_review.name }}
                                    </h4>
                                    <div class="review-date">
                                        Posted on {{ service_review.dateTime | formatDate }}
                                        <div class="rating-icon-col">
                                            <i class="fa fa-star"></i> {{ service_review.rate | formatNumber }}
                                        </div>
                                    </div>
                                    <p>
                                        {{ service_review.comment }}
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div v-else>
                            <p>No reviews exists yet.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Booking Form modal -->
        <div class="modal fade my-popup" ref="booking_form">
            <div class="modal-dialog">
                <div class="modal-content">
                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title">Add Requirement</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="booking-form-popup">
                            <div class="formBox">
                                <div class="formBoxInner">
                                    <form @submit.prevent="bookService">
                                        <div class="form-row">
                                            <div class="form-group">
                                                <label>
                                                    Job Title 
                                                    <span class="red-color">*</span>
                                                </label>
                                                <input type="text" placeholder="Job Title" v-model="booking.title" data-vv-name="title" v-validate="'required|max:255'" data-vv-as="job title">
                                                <div v-if="errors.has('title')" class="text-danger">
                                                    {{ errors.first('title') }}
                                                </div>
                                            </div>
                                            <div class="form-group last-input">
                                                <label>
                                                    Budget
                                                    <span class="red-color">*</span>
                                                </label>
                                                <input type="text" placeholder="$" v-model="booking.budget" data-vv-name="budget" v-validate="'required|numeric|max:8'" data-vv-as="budget">
                                                <div v-if="errors.has('budget')" class="text-danger">
                                                    {{ errors.first('budget') }}
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group">
                                                <label>
                                                    Date 
                                                    <span class="red-color">*</span>
                                                </label>
                                                <input type="text" placeholder="" ref="date" v-model="booking.date" data-vv-name="date" v-validate="'required|date_format:yyyy-mm-dd'" data-vv-as="date">
                                                <div v-if="errors.has('date')" class="text-danger">
                                                    {{ errors.first('date') }}
                                                </div>
                                            </div>
                                            <div class="form-group last-input">
                                                <label>
                                                    Time 
                                                    <span class="red-color">*</span>
                                                </label>
                                                <input type="text" placeholder="" ref="time" v-model="booking.time" data-vv-name="time" v-validate="'required|date_format:h:mm a'" data-vv-as="budget">
                                                <div v-if="errors.has('time')" class="text-danger">
                                                    {{ errors.first('time') }}
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-row full-input-box">
                                            <div class="form-group">
                                                <label>
                                                    Description 
                                                    <span class="red-color">*</span>
                                                </label>
                                                <textarea v-model="booking.description" data-vv-name="description" v-validate="'required'" data-vv-as="description"></textarea>
                                                <div v-if="errors.has('description')" class="text-danger">
                                                    {{ errors.first('description') }}
                                                </div>
                                            </div>
                                        </div>
                                        <div class="full-btn-col">
                                            <div v-if="!loading">
                                                <input type="submit" value="Post Your Requirement" :disabled="errors.any()">
                                            </div>
                                            <div v-else>
                                                <input type="submit" value="loading..." disable="disabled">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>     
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import "bootstrap-datepicker/dist/css/bootstrap-datepicker.css";
    import "bootstrap-timepicker/css/bootstrap-timepicker.css";
    import datepicker from "bootstrap-datepicker";
    import timepicker from "bootstrap-timepicker";
    import VeeValidate from 'vee-validate';
    import moment from "moment";
    Vue.use(VeeValidate);
    export default {
        name: "service-detail-component",
        props: ["serviceId", 'isLoggedIn'],
        data: function () {
            return {
                service:{},
                loading: false,
                booking: {},
            }
        },
        methods: {
            getService() {
                axios.post('/service/data', {
                    id:this.serviceId
                }).then(response => {
                    if(response.data.status === true){
                        this.service = response.data.data;
                    }else{
                        flash(response.data.message, 'error');
                    }
                }).catch(error => {
                    console.log(error);
                });
            },
            processBooking() {
                this.booking = {};
                $(this.$refs.booking_form).modal();
                /*if(this.isLoggedIn === true){
                    $(this.$refs.booking_form).modal();
                }else{
                    flash("Your are not logged in. Please login first to continue.", 'warning');
                    //window.location = '/login?refrer='+this.service.title.replace(/ /g, '-')+"-"+this.service.id;
                }*/
            },
            bookService() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        axios.post('/service/book-service', {
                            id:this.serviceId
                        }).then(response => {
                            if(response.data.status === true){
                                this.service = response.data.data;
                            }else{
                                flash(response.data.message, 'error');
                            }
                        }).catch(error => {
                            console.log(error);
                        });
                    }else{
                        this.loading = false;
                    }
                });
            }
        },
        created: function () {
            this.getService();
        },
        mounted: function () {
            var vm = this;
            Vue.nextTick(function(){
                $(vm.$refs.date).datepicker({
                    format: "yyyy-mm-dd",
                    autoclose: true
                }).on('changeDate', function(e) {
                    vm.booking.date = e.format();
                }).on('changeMonth', function(e) {
                    vm.booking.date = e.format();
                }).on('changeYear', function(e) {
                    vm.booking.date = e.format();
                });

                $(vm.$refs.time).timepicker({
                    format: "h:mm a",
                    autoclose: true
                }).on('changeTime.timepicker', function(e) {
                    vm.booking.time = e.time.value;
                });

            }.bind(this));
        },
        filters: {
            formatDate: function (value) {
                return moment(value, 'YYYY-MM-DD H:i:s').format('DD MMM YYYY h:mm a');
            },
            formatNumber(value) {
                return (value/1).toFixed(2);
            }
        }
    }
</script>

