<template>
    <div>
        <div class="mainWpapContainer">
            <div class="login-sec register-page">
                <div class="container">
                    <div v-if="step === 1">
                        <div class="login-title">
                            <h1>Regis<span>ter</span></h1>
                        </div>
                        <div class="login-box">
                            <div class="loginForm">
                                <form @submit.prevent="registerAccount">
                                    <div class="field-required">
                                        <p>Please fill the fields given below</p>
                                    </div>
                                    <div class="login-form-row">
                                        <div class="form-group">
                                            <label>
                                                Name 
                                                <span class="red-color">*</span>
                                            </label>
                                            <div class="form-icon-col">
                                                <i class="fa fa-user"></i> 
                                                <input type="text" placeholder="Enter Your Name" name="name" v-model="register.name" v-validate="'required|max:255'" data-vv-as="name" key="name">
                                            </div>
                                            <div v-if="errors.has('name')" class="text-danger">
                                                {{ errors.first('name') }}
                                            </div>
                                        </div>
                                        <div class="form-group last-input">
                                            <label>
                                                E-Mail Address 
                                                <span class="red-color">*</span>
                                            </label>
                                            <div class="form-icon-col">
                                                <i class="fa fa-envelope"></i> 
                                                <input type="text" placeholder="Enter Your Email" name="email" v-model="register.email" v-validate="'required|email|max:255'" data-vv-as="email address" key="email">
                                            </div>
                                            <div v-if="errors.has('email')" class="text-danger">
                                                {{ errors.first('email') }}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="login-form-row">
                                        <div class="form-group">
                                            <label>
                                                Password 
                                                <span class="red-color">*</span>
                                            </label>
                                            <div class="form-icon-col">
                                                <i class="fa fa-lock"></i> 
                                                <input type="password" placeholder="Enter Your Password" name="password" v-model="register.password" v-validate="'required|min:6|max:12'" ref="password" key="password">
                                            </div>
                                            <div v-if="errors.has('password')" class="text-danger">
                                                {{ errors.first('password') }}
                                            </div>
                                        </div>
                                        <div class="form-group last-input">
                                            <label>
                                                Confirm Password 
                                                <span class="red-color">*</span>
                                            </label>
                                            <div class="form-icon-col">
                                                <i class="fa fa-lock"></i> 
                                                <input type="password" placeholder="Confirm Your Password" name="confirm_password" v-model="register.confirm_password" v-validate="'required|confirmed:password'" data-vv-as="confirm password" key="confirm_password">
                                            </div>
                                            <div v-if="errors.has('confirm_password')" class="text-danger">
                                                {{ errors.first('confirm_password') }}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="login-form-row">
                                        <div class="form-group">
                                            <label>
                                                Mobile number 
                                                <span class="red-color">*</span>
                                            </label>
                                            <div class="form-icon-col">
                                                <i class="fa fa-phone"></i> 
                                                <input type="text" placeholder="Enter Your Mobile Number" name="mobile" v-model="register.mobile" v-validate="'required|numeric|min:4|max:16'" data-vv-as="mobile" key="mobile">
                                            </div>
                                            <div v-if="errors.has('mobile')" class="text-danger">
                                                {{ errors.first('mobile') }}
                                            </div>
                                        </div>
                                        <div class="form-group last-input">
                                            <div class="form-group">
                                                <label>
                                                    Profile Photo
                                                </label>
                                                <input type="file" placeholder="" name="profile_photo_file" ref="profile_photo_file" v-validate="'required|image|ext:jpeg,jpg,png'" data-vv-as="profile photo" v-on:change="handleFileUpload()" key="profile_photo_file">
                                                <div v-if="errors.has('profile_photo_file')" class="text-danger">
                                                    {{ errors.first('profile_photo_file') }}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="login-form-row">
                                        <div class="form-group-1">
                                            <div class="checkbox abc-checkbox propertyCheck">
                                                <input type="checkbox" class="styled" id="checkbox1" name="accept" v-model="register.accept" v-validate="'required'" data-vv-as="accept terms and conditions" key="accept">
                                                <label for="checkbox1"> Accept <span><a href="/terms-and-conditions" target="_blank">terms & conditions</a> </span></label>
                                            </div>
                                            <div v-if="errors.has('accept')" class="text-danger">
                                                {{ errors.first('accept') }}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="full-btn-col">
                                        <div v-if="!loading">
                                            <input type="submit" value="Register" :disabled="errors.any()">
                                        </div>
                                        <div v-else>
                                            <input type="submit" value="loading..." disable="disabled">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div v-else>
                        <div class="login-title">
                            <h1>Verify <span>Account</span></h1>
                        </div>
                        <div class="login-box verify-email-box">
                            <div class="loginForm">
                                <form @submit.prevent="verifyAccount">
                                    <div class="field-required">
                                        <p>Please verify your account</p>
                                    </div>
                                    <div class="login-form-row">
                                        <div class="form-group">
                                            <label>
                                                OTP 
                                                <span class="red-color">*</span>
                                            </label>
                                            <div class="form-icon-col">
                                                <i class="fa fa-user"></i> 
                                                <input type="text" placeholder="OTP" name="verification_otp" v-model="verify.verification_otp" v-validate="'required|numeric|digits:4'" data-vv-as="OTP" key="verification_otp">
                                            </div>
                                            <div v-if="errors.has('verification_otp')" class="text-danger">
                                                {{ errors.first('verification_otp') }}
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div v-if="!loading">
                                                <div>
                                                    <input type="submit" value="Verify" :disabled="errors.any()">
                                                </div> 
                                                <div class="forgotPassword">
                                                    <a href="javascript:;" @click="resendOtp">Resend OTP</a>
                                                </div>
                                            </div>
                                            <div v-else>
                                                <input type="submit" value="loading..." disable="disabled">
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="login-type-step" v-show="step === 3">
            <div class="login-type-step-inner">
                <h3>Switch account as</h3>
                <div class="login-type-btn-col">
                    <a href="/switch-account-to/service-provider">
                        Service Provider
                    </a>
                    <a href="/switch-account-to/user">
                        User
                    </a>
                </div>
            </div> 
        </div>
    </div>
</template>
<script>
    import VeeValidate from 'vee-validate';
    Vue.use(VeeValidate);
    export default {
        data() {
            return {
                step : 1,
                loading : false,
                register: {
                    name: "",
                    email: "",
                    password: "",
                    confirm_password: "",
                    mobile: "",
                    profile_photo_file: "",
                    accept: ""
                },
                verify: {
                    verification_otp: ""
                },
            }
        },
        methods: {
            registerAccount() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        let formData = new FormData();
                        formData.append('name', this.register.name);
                        formData.append('email', this.register.email);
                        formData.append('password', this.register.password);
                        formData.append('confirm_password', this.register.confirm_password);
                        formData.append('mobile', this.register.mobile);
                        formData.append('profile_photo_file', this.register.profile_photo_file);
                        formData.append('accept', this.register.accept);
                        
                        axios.post('/register', formData, {
                            headers:{
                                'Content-Type': 'multipart/form-data'
                            }
                        }).then(response => {
                            if(response.data.status === true){
                                this.step = 2;
                                window.scrollTo(0, 0);
                                flash(response.data.message, 'success');
                            }else{
                                if(response.data.error){
                                    var message =  response.data.error[0];
                                    flash(message.replace('_', ' '), 'error');
                                }else{
                                    flash(response.data.message, 'error');
                                }
                            }
                            this.loading = false;
                        }).catch(error => {
                            this.loading = false;
                            console.log(error);
                        });
                    }else{
                        this.loading = false;
                    }
                });
            },

            resendOtp() {
                axios.post('/resend/otp', {
                    email : this.register.email
                }).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                    }else{
                        if(response.data.error){
                            var message =  response.data.error[0];
                            flash(message.replace('_', ' '), 'error');
                        }else{
                            flash(response.data.message, 'error');
                        }
                    }
                }).catch(error => {
                    console.log(error);
                });
            },

            verifyAccount() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        axios.post('/email/verify', {
                            email : this.register.email,
                            verification_otp : this.verify.verification_otp
                        }).then(response => {
                            if(response.data.status === true){
                                this.step = 3;
                                flash(response.data.message, 'success');
                            }else{
                                if(response.data.error){
                                    var message =  response.data.error[0];
                                    flash(message.replace('_', ' '), 'error');
                                }else{
                                    flash(response.data.message, 'error');
                                }
                            }
                            this.loading = false;
                        }).catch(error => {
                            this.loading = false;
                            console.log(error);
                        });
                    }else{
                        this.loading = false;
                    }
                });
            },
            /*
                Handles a change on the file upload
            */
            handleFileUpload(){
                this.register.profile_photo_file = this.$refs.profile_photo_file.files[0];
            }
        },
    }
</script>
