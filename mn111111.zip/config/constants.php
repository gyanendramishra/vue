<?php

return [
    'GEARS' => [
        1 => "1",
        2 => "2",
        3 => "3",
        4 => "4",
        5 => "5",
        6 => "6",
        7 => "7",
        8 => "8",
        9 => "9",
        10 => "10",
       
    ],
    'FUEL_ECONOMY' => [
        1 => "1L/10km Or Less",
        2 => "1L/20km Or Less",
        3 => "1L/30km Or Less",
        4 => "1L/40km Or Less",
        5 => "1L/50km Or Less",
        6 => "1L/100km Or Less",
    ],
    'FUEL_ECONOMYS' => [
        array('id' => 1, 'name' => '1L/10km Or Less'),
        array('id' => 2, 'name' => '1L/20km Or Less'),
        array('id' => 3, 'name' => '1L/30km Or Less'),
        array('id' => 4, 'name' => '1L/40km Or Less'),
        array('id' => 5, 'name' => '1L/50km Or Less'),
        array('id' => 6, 'name' => '1L/100km Or Less'),
    ],
    'Cylinders' => [
        array('id' => 1, 'name' => '1'),
        array('id' => 2, 'name' => '2'),
        array('id' => 3, 'name' => '3'),
        array('id' => 4, 'name' => '4'),
        array('id' => 5, 'name' => '5'),
        array('id' => 6, 'name' => '6'),
        array('id' => 7, 'name' => '7'),
        array('id' => 8, 'name' => '8'),
        array('id' => 9, 'name' => '9'),
        array('id' => 10, 'name' => '10'),
       
    ],
    'Cylinder' => [
        1 => "1",
        2 => "2",
        3 => "3",
        4 => "4",
        5 => "5",
        6 => "6",
        7 => "7",
        8 => "8",
        9 => "9",
        10 => "10",
       
    ],
    'DOOR' => [
         1 => "1",
        2 => "2",
        3 => "3",
        4 => "4",
        5 => "5",
        6 => "6",
        7 => "7",
        8 => "8",
        9 => "9",
        10 => "10",
        
    ],
    'DOORS' => [
        array('id' => 1, 'name' => '1'),
        array('id' => 2, 'name' => '2'),
        array('id' => 3, 'name' => '3'),
        array('id' => 4, 'name' => '4'),
        array('id' => 5, 'name' => '5'),
        array('id' => 6, 'name' => '6'),
        array('id' => 7, 'name' => '7'),
        array('id' => 8, 'name' => '8'),
        array('id' => 9, 'name' => '9'),
        array('id' => 10, 'name' => '10'),
        
    ],
    'SEATS' => [
        1 => "1",
        2 => "2",
        3 => "3",
        4 => "4",
        5 => "5",
        6 => "6",
        7 => "7",
        8 => "8",
        9 => "9",
        10 => "10",
       
    ],
    'ROLE' => [
        'ADMIN' => 1, /* will change it after marketplace categories */
        "BUYER" => 2, /* will change it after marketplace categories */
        "DEALER" => 3, /* will change it after marketplace categories */
        "SELLER" => 4, /* will change it after marketplace categories */
    ],
    'email_template_types' => [
        'welcome_mail_to_user' => 'Registration Welcome Mail',
        'inquiry_mail' => 'Inquiry Mail To Admin',
        'vehicle_inquiry_mail_to_admin' => 'Vehicle Inquiry Mail To Admin',
        'vehicle_report_ad_mail_to_admin' => 'Vehicle Report Ad Mail To Admin',
        'vehicle_added_mail_to_admin' => 'Vehicle Added Mail To Admin',
        'vehicle_added_mail_to_user' => 'Vehicle Added Mail To User',
        'vehicle_approve_mail_to_user' => 'Vehicle Approved Mail To User',
        'vehicle_disapprove_mail_to_user' => 'Vehicle  Disapproved Mail To User',
        'vehicle_review_approve_mail_to_selle/dealer' => 'Vehicle Review Approved Mail To Seller/Dealer',
        'vehicle_review_disapprove_mail_to_user' => 'Vehicle Review Disapproved Mail To User',
    ],
    'types' => [
        "New" => "New",
        "Used" => "Used",
        "Demo" => "Demo"
    ],
    'turbosuperchargie' => [
        "1" => "Yes",
        "0" => "No",
    ],
    'Months' => [
        "Janaury" => "Janaury",
        "February" => "February",
        "March" => "March",
        "April" => "April",
        "May" => "May",
        "June" => "June",
        "July" => "July",
        "August" => "August",
        "September" => "September",
        "October" => "October",
        "November" => "November",
        "December" => "December",
    ],
    'imageType' => [
        "front" => "Front",
        "rear" => "Rear",
        "side" => "Side",
        "other" => "Other"
    ],
    'cetified' => [
        "1" => "Certified/Approved",
    ],
    'POSITION' => [
        "Top" => "1",
        "Side" => "2",
        "Bottom" => "3"
    ],
    'pageLocation' => [
        "vehicle_detail" => "1",
        "vehicle_list" => "2"
    ],
    'USERTYPE' => [
      
        "Dealer" => "Dealer",
        "Seller" => "Seller"
    ],
    ### Frontend ###
    "INQUERY_FOR" => [
        "Selling",
        "Buying",
        "Privacy",
        "General Feedback",
        "I want to report suspicious acivity",
        "Shareholder enquiry"
    ],
    ### Frontend ###
    "REPORT_FOR" => [
        "Suspected fraud or scam",
        "Advert infringes intellectual property (e.g. copyright)",
        "Incorrect or misleading",
        "Sold and/or no response from seller",
    ],
    'FILTER_PRICE_LISTS' => [
        3000 => "$3,000",
        5000 => "$5,000",
        7500 => "$7,500",
        10000 => "$10,000",
        15000 => "$15,000",
        20000 => "$20,000",
        25000 => "$25,000",
        30000 => "$30,000",
        35000 => "$35,000",
        40000 => "$40,000",
        45000 => "$45,000",
        50000 => "$50,000",
        60000 => "$60,000",
        70000 => "$70,000",
        80000 => "$80,000",
        90000 => "$90,000",
        100000 => "$100,000",
        150000 => "$150,000",
    ],
];
