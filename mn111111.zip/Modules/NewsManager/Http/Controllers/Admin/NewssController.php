<?php

namespace Modules\NewsManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Input;
use Modules\NewsManager\Entities\News;
use Yajra\DataTables\Utilities\Request as DatatableRequest;

class NewssController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        $title = "News";
        return view('newsmanager::Admin.news.index', compact('title'));
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $newss = News::query();
        if ($request->status != '') {
            $newss = $newss->where('status', $request->status);
        }
        if ($request->slug != '') {
            $slug = $request->slug;
            $newss = $newss->whereHas('NewsTranslation', function($q) use($slug) {
                $q->where('title', 'LIKE', ucfirst($slug) . '%');
                $q->orWhere('title', 'LIKE', $slug . '%');
            });
        }
        $newss = $newss->get();

        return datatables()->of($newss)
                        ->addColumn('action', function ($newss) {
                            $actions = "";
                            $actions .= "<a href=\"" . route('admin.news.show', ['id' => $newss->id]) . "\" class=\"\"><i class=\"rounded outline primary icon user profile link\"></i></a>";
                            $actions .= "&nbsp;<a href=\"" . route('admin.news.edit', ['id' => $newss->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                            $actions .= "&nbsp;<a title='Delete' data-id='" . $newss->id . "' class='Delete' data-set='{&quot;title&quot;: &quot;Delete Listing&quot;, &quot;parent&quot;: &quot;tr&quot;, &quot;option&quot;: &quot;deleteListing&quot;, &quot;id&quot;: 17, &quot;name&quot;: &quot;Infiniti Coupe Concept&quot;}''><i class='rounded outline icon negative trash link'></i></a>";

                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        $title = "Add News";
        return view('newsmanager::Admin.news.createOrUpdate', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request) {

        $locales = config('app.locales');
        $valRule = [
            'start_date' => 'required|date',
            'end_date' => 'required|date',
            'news_type' => 'required',
            'icon' => 'required_if:news_type,==,0|mimes:jpeg,jpg,png|max:5000',
            'video' => 'required_if:news_type,==,1',
        ];
        $valMessage = [
            'start_date.required' => 'The start date field is required.',
            'start_date.date' => 'Please enter the date.',
            'end_date.required' => 'The end date field is required.',
            'end_date.date' => 'Please enter the date.',
            'news_type.required' => 'The news type field is required.',
            'icon.required_if' => 'The image field is required.',
            'icon.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
            'icon.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
            'video.required_if' => 'The video field is required.',
        ];

        foreach ($locales as $key => $value) {
            $valRule[$key . '_title'] = 'required|max:200|unique:news_translations,title|unique_space_check:news_translations,title';
            $valRule[$key . '_description'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_title.required'] = ' The title field is required in ' . $value . ' language.';
            $valMessage[$key . '_description.required'] = ' The description field is required in ' . $value . ' language.';
            $valMessage[$key . '_title.max'] = ' Sorry, you can\'t add the title more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_title.unique'] = ' Title must be unique in ' . $value . ' language.';
            $valMessage[$key . '_title.unique_space_check'] = ' Title must be unique in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $news_data = array();

            foreach ($locales as $key => $value) {
                $news_data[$key]['title'] = $request->input($key . '_title');
                $news_data[$key]['description'] = $request->input($key . '_description');
            }
            $news_data['status'] = $request->input('status');
            $news_data['start_date'] = $request->input('start_date');
            $news_data['end_date'] = $request->input('end_date');
            $news_data['news_type'] = $request->input('news_type');

            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $is_dest = "uploads/newsImages/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('image');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $news_data['image'] = $filenameOrig;
                }
            } else {
                $news_data['video'] = $request->input('video');
            }

            $ad = News::create($news_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.news.index')->with('success', 'News has been saved Successfully');
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show($id) {
        $title = "News Detail";
        $news = News::findOrFail($id)->where('id', '=', $id)->first();
        return view('newsmanager::Admin.news.show', compact('title', 'news'));
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id) {
        $title = "Add News";
        $news = News::where('id', '=', $id)->first();
        return view('newsmanager::Admin.news.createOrUpdate', compact('title', 'news'));
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id) {

        $locales = config('app.locales');
        $valRule = [
            'start_date' => 'required|date',
            'end_date' => 'required|date',
            'news_type' => 'required',
            'icon' => 'required_if:news_type,==,0|mimes:jpeg,jpg,png|max:5000',
            'video' => 'required_if:news_type,==,1',
        ];
        $valMessage = [
            'start_date.required' => 'The start date field is required.',
            'start_date.date' => 'Please enter the date.',
            'end_date.required' => 'The end date field is required.',
            'end_date.date' => 'Please enter the date.',
            'news_type.required' => 'The news type field is required.',
            'icon.required_if' => 'The image field is required.',
            'icon.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
            'icon.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
            'video.required_if' => 'The video field is required.',
        ];

        foreach ($locales as $key => $value) {
            $valRule[$key . '_title'] = 'required|max:200|unique:news_translations,title,'. $request->segment(3).',news_id|unique_space_check:news_translations,title,'. $request->segment(3).',news_id';
            $valRule[$key . '_description'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_title.required'] = ' The title field is required in ' . $value . ' language.';
            $valMessage[$key . '_description.required'] = ' The description field is required in ' . $value . ' language.';
            $valMessage[$key . '_title.max'] = ' Sorry, you can\'t add the title more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_title.unique'] = ' Title must be unique in ' . $value . ' language.';
            $valMessage[$key . '_title.unique_space_check'] = ' Title must be unique in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {

            $news_data = array();

            foreach ($locales as $key => $value) {
                $news_data[$key]['title'] = $request->input($key . '_title');
                $news_data[$key]['description'] = $request->input($key . '_description');
            }
            $news_data['status'] = $request->input('status');
            $news_data['start_date'] = $request->input('start_date');
            $news_data['end_date'] = $request->input('end_date');
            $news_data['news_type'] = $request->input('news_type');

            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $is_dest = "uploads/newsImages/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('image');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $news_data['image'] = $filenameOrig;
                }
            } else {
                $news_data['video'] = $request->input('video');
            }

            $News = News::find($id);

            $News->update($news_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.news.index')->with('success', 'News has been updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id) {

        try {
            News::where('id', $id)->delete();

            $responce = ['status' => true, 'message' => 'This news has been deleted Successfully!'];
        } catch (\Exception $e) {
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

}
