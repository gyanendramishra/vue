@extends('layouts.admin.app')
@section('title', !empty($ads) ? 'Edit Subscription' : 'Add Subscription')
@section('content')

<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.subscription.index'],['label' => !empty($ads) ? 'Edit Subscription' : 'Add Subscription' ]]]) }}
    </div>
</div>

<div class="wojo-grid">


    @if(session()->has('success'))
    <div class="alert alert-success">
        {{ session()->get('success') }}
    </div>
    @endif

    <div class="wojo form segment">
        <div class="wojo secondary icon message"> 
            <div class="content">
                <div class="header">  {{ !empty($subscription) ? 'Edit Subscription' : 'Add Subscription' }} </div>
                <!-- <p>Here you can edit your vehicle make </p> -->
            </div>
        </div>

        @if(session()->has('success'))
        <div class="alert alert-success">
            {{ session()->get('success') }}
        </div>
        @endif

        @if(isset($subscription))

        {{ Form::model($subscription, ['route' => ['admin.subscription.update', $subscription->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}

        @else
        {{ Form::open(['route' => 'admin.subscription.store','enctype'=>'multipart/form-data']) }}

        @endif

        @php

        $locales = config('app.locales');

        @endphp

        @include('layouts.flash.alert')

        <div class="wojo secondary message">

            <ul class="wojo tabs fixed clearfix">
                @foreach($locales as $key=>$val)
                <li class="{{ ($key=='en')?'active':'' }}">
                    <a data-tab="#{{ $key.'_tab' }}" class="{{ ($key=='en')?'active show':'' }}">
                        {{ $val }}
                    </a>
                </li>
                @endforeach
            </ul>
             @foreach($locales as $key=>$val)
            <div id="{{ $key.'_tab' }}" class="wojo tab item " style="{{ ($key=='en')?'display: block;':'' }}">
                <div class="two fields">
                    <div class="field required {{ $errors->has($key.'_name') ? 'has-error' : '' }}">
                        <label for="name">{{ __('Title') }} </label>

                        {{ Form::text($key.'_title',old($key.'_title', (isset($subscription))?$subscription->translate($key)['title']:"") , ['class' => 'form-control','placeholder' => 'Title']) }}

                        @if($errors->has($key.'_title'))
                        <span class="help-block">{{ $errors->first($key.'_title') }}</span>
                        @endif

                    </div>
                </div>

            </div>
            @endforeach
            <div class="two fields">
                <div class="field required {{ $errors->has('user_type') ? 'has-error' : '' }}">
                    <label for="name">{{ __('User Type') }} </label>

                    {{ Form::select('user_type', Config::get('constants.USERTYPE'), old('user_type'), ['class' => 'form-control', 'placeholder' => 'Select User Type']) }}

                    @if($errors->has('user_type'))
                    <span class="help-block">{{ $errors->first('user_type') }}</span>
                    @endif
                </div>
<!--                <div class="field required {{ $errors->has('type') ? 'has-error' : '' }}">
                    <label for="name">{{ __('Type') }} </label>

                    {{ Form::select('type', [0=>'Free',1=>'Paid'], ['class' => 'form-control', 'placeholder' => 'Select Type']) }}

                    @if($errors->has('type'))
                    <span class="help-block">{{ $errors->first('type') }}</span>
                    @endif
                </div>-->
            </div>
            
           

            <div class="two fields">

                <div class="field required {{ $errors->has('total_listing_count') ? 'has-error' : '' }}">
                    <label for="name">{{ __('Number Of Listing') }} <span class="asterisk">*</span> </label>

                    {{ Form::number('total_listing_count', old('total_listing_count'), ['class' => 'form-control','placeholder' => 'Listing','min'=>0]) }}

                    @if($errors->has('total_listing_count'))
                    <span class="help-block">{{ $errors->first('total_listing_count') }}</span>
                    @endif
                </div>

                <div class="field required ">
                    <label for="name">{{ __('Number Of Featured Listing') }} <span class="asterisk"></span></label>

                    {{ Form::number('total_featured_count', old('total_featured_count'), ['class' => 'form-control','placeholder' => 'Featured Listing','min'=>0]) }}

                </div>
            </div>

            <div class="two fields">

                <div class="field required">
                    <label for="name">{{ __('Number Of On Sale Listing') }} <span class="asterisk"></span> </label>

                    {{ Form::number('total_on_sale_count', old('total_on_sale_count'), ['class' => 'form-control','placeholder' => 'On Sale Listing','min'=>0]) }}


                </div>
                <div class="field required">
                    <label for="title">Number Of Until Sold Listing <span class="asterisk"></span></label>
                    {{ Form::number('count_of_until_sold', old('count_of_until_sold'), ['class' => 'form-control','placeholder' => 'Until Sold Listing','min'=>0]) }}

                </div>

            </div>

            <div class="two fields">
                <div class="field required {{ $errors->has('price') ? 'has-error' : '' }}">
                    <label for="title">Price ($)<span class="asterisk">*</span></label>
                    {{ Form::text('price',old('price') , ['class' => 'form-control','placeholder' => 'Price','min'=>0]) }}
                    @if($errors->has('price'))
                    <span class="help-block">{{ $errors->first('price') }}</span>
                    @endif
                </div>
                <div class="field required">
                    <label for="title">Minimum Ad's Price ($) <span class="asterisk"> Applicable Only Free Listing </span></label>
                    {{ Form::text('minimum_price',old('minimum_price') , ['class' => 'form-control','placeholder' => 'Minimum Price Ad','min'=>0]) }}
                </div>
            </div>

            <div class="two fields">

                <div class="field required {{ $errors->has('total_on_sale_count') ? 'has-error' : '' }}">
                    <label for="name">{{ __('Duration') }} <span class="asterisk">*</span> </label>

                    {{ Form::number('duration', old('duration'), ['class' => 'form-control','placeholder' => 'Duration','min'=>0]) }}

                    @if($errors->has('duration'))
                    <span class="help-block">{{ $errors->first('duration') }}</span>
                    @endif
                </div>

                <div class="field required {{ $errors->has('duration_type') ? 'has-error' : '' }}">
                    <label for="name">{{ __('Duration Type') }} <span class="asterisk">*</span></label>

                    {{ Form::select('duration_type',['Day'=>'Day', 'Month'=>'Month', 'Week'=>'Week', 'Year'=>'Year'], old('duration_type'), ['class' => 'form-control','placeholder' => 'Select Duration Type']) }}

                    @if($errors->has('price'))
                    <span class="help-block">{{ $errors->first('duration_type') }}</span>
                    @endif
                </div>
            </div>



            <div class="container">
                <div class="two fields">
                    <div class="field">
                        <label for="title">Order <span class="asterisk"></span></label>
                        {{ Form::number('sort_order', isset($sort_order)?$sort_order:$subscription->sort_order, ['class' => 'form-control','placeholder' => 'Order']) }}
                    </div>
                    <div class="field">
                        <div class="form-group required {{ $errors->has('status') ? 'has-error' : '' }}">
                            <label for="status">{{ __('Status') }} </label>
                            {{ Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => '']) }}

                            @if($errors->has('status'))
                            <span class="help-block">{{ $errors->first('status') }}</span>
                            @endif
                        </div>
                    </div>

                </div>

            </div>

            <div class="wojo fitted divider"></div>
            <div class="wojo footer">
                <button type="submit" data-action="updateAccount" name="dosubmit" class="wojo positive button">Save</button>
                <a href="{{ route('admin.subscription.index') }}" class="wojo negative button" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
            </div>
        </div>

        {{ Form::close() }}
    </div>
</div>
@stop


@push('per_page_scripts')
<script src="{{asset('ckeditor/ckeditor.js')}}"></script>

@endpush
