<?php

namespace Modules\DiscountCoupon\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\DiscountCoupon\Entities\DiscountCoupon;
use Yajra\DataTables\Utilities\Request as DatatableRequest;

class DiscountCouponsController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        return view('discountcoupon::index');
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $discountCoupon = DiscountCoupon::query();
        if ($request->status != '') {
            $discountCoupon = $discountCoupon->where('is_publish', $request->is_publish);
        }

        $discountCoupon = $discountCoupon->get();

        return datatables()->of($discountCoupon)
                        ->addColumn('action', function ($discountCoupon) {
                            $actions = "";
                            $actions .= "&nbsp;<a href=\"" . route('admin.discountcoupon.edit', ['id' => $discountCoupon->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                            $actions .= "&nbsp;<a title='Delete' data-id='" . $discountCoupon->id . "' class='Delete' data-set='{&quot;title&quot;: &quot;Delete Listing&quot;, &quot;parent&quot;: &quot;tr&quot;, &quot;option&quot;: &quot;deleteListing&quot;, &quot;id&quot;: 17, &quot;name&quot;: &quot;Infiniti Coupe Concept&quot;}''><i class='rounded outline icon negative trash link'></i></a>";

                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        $title = "Add Discount Coupons";
        $subscriptions = \Modules\SubscriptionManager\Entities\SubscriptionPlan::select('id')
                        ->with('translations:id,subscription_plan_id,title,locale')
                        ->where('status', 1)
                        ->get()->pluck('title', 'id');
        return view('discountcoupon::createOrUpdate', compact('title','subscriptions'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request) {
        //
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id) {
        return view('discountcoupon::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id) {
        return view('discountcoupon::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id) {
        //
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id) {
        //
    }

}
