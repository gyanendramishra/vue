<?php

namespace Modules\DiscountCoupon\Entities;

use Illuminate\Database\Eloquent\Model;

class DiscountCoupon extends Model
{
    protected $fillable = [];
    
    
     /**
     * Get the features of vehicle.
     */
    public function subscriptionPlans() {
        return $this->belongsToMany('\Modules\SubscriptionManager\Entities\SubscriptionPlan');
    }
}
