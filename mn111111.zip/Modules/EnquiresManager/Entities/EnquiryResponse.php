<?php

namespace Modules\EnquiresManager\Entities;

use Illuminate\Database\Eloquent\Model;


class EnquiryResponse extends Model
{
    protected $table = 'enquiry_responses';
    protected $primaryKey = 'id';
    //protected $dates = ['deleted_at'];
    public $timestamps = true;
   
    protected $fillable = ['email','is_responded','details','action','enquiry_id'];
   
    //protected $casts = ['status'  => 'boolean'];

}
