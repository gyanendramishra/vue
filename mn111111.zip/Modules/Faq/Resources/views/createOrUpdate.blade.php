@extends('layouts.admin.app')
@section('title', !empty($ads) ? 'Edit FAQ' : 'Add FAQ')
@push('styles')
<link href="{{ asset('/css/migration/jquery-ui.css') }}" rel="stylesheet" />
@endpush
@section('content')

<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.faq.index'],['label' => !empty($ads) ? 'Edit FAQ' : 'Add FAQ' ]]]) }}
    </div>
</div>

<div class="wojo-grid">    
    @if(session()->has('success'))
    <div class="alert alert-success">
        {{ session()->get('success') }}
    </div>
    @endif

    <div class="wojo form segment">
        <div class="wojo secondary icon message"> 
            <div class="content">
                <div class="header">  {{ !empty($faq) ? 'Edit FAQ' : 'Add FAQ' }}  </div>
            </div>
        </div>
        @if(isset($faq))
        {{ Form::model($faq, ['route' => ['admin.faq.update', $faq->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}
        @else
        {{ Form::open(['route' => 'admin.faq.store','enctype'=>'multipart/form-data']) }}
        @endif

        @php
        $locales = config('app.locales');
        @endphp

        @include('layouts.flash.alert')

        <div class="wojo secondary message">
            <ul class="wojo tabs fixed clearfix">
                @foreach($locales as $key=>$val)
                <li class="{{ ($key=='en')?'active':'' }}">
                    <a data-tab="#{{ $key.'_tab' }}" class="{{ ($key=='en')?'active show':'' }}">
                        {{ $val }}
                    </a>
                </li>
                @endforeach
            </ul>

            @foreach($locales as $key=>$val)
            <div id="{{ $key.'_tab' }}" class="wojo tab item " style="{{ ($key=='en')?'display: block;':'' }}">
                <div class="two fields">
                    <div class="field">

                        <div class="required {{ $errors->has($key.'_title') ? 'has-error' : '' }}">
                            <label for="name">{{ __('Question') }} </label>

                            {{ Form::text($key.'_question',old($key.'_question', (isset($faq))?$faq->translate($key)['question']:"") , ['class' => 'form-control','placeholder' => 'Question']) }}

                            @if($errors->has($key.'_question'))
                            <span class="help-block">{{ $errors->first($key.'_question') }}</span>
                            @endif
                        </div>
                    </div>
                </div>

                <div class="field">

                    <div class="required {{ $errors->has($key.'_answer') ? 'has-error' : '' }}">
                        <label for="name">{{ __('Answer') }} </label>

                        {{ Form::textarea($key.'_answer',old($key.'_answer',(isset($faq))?$faq->translate($key)['answer']:""), ['class' => 'form-control','placeholder' => 'Answer' , 'id'=>'editor1_'.$key, 'rows' => 8]) }}

                        @if($errors->has($key.'_answer'))
                        <span class="help-block">{{ $errors->first($key.'_answer') }}</span>
                        @endif
                    </div>
                </div>


            </div>
            @endforeach

            <div class="wojo footer">
                <button type="submit" data-action="updateAccount" name="dosubmit" class="wojo positive button">Save</button>
                <a href="{{ route('admin.faq.index') }}" class="wojo negative button" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
            </div>
        </div>

        {{ Form::close() }}
    </div>
</div>
@stop


@push('scripts')

<script src="{{ asset('js/migration/jquery-ui.js') }}"></script>
<script src="{{asset('ckeditor/ckeditor.js')}}"></script>
<script>
$(function () {
    CKEDITOR.replace('editor1_en', {
        // Remove the redundant buttons from toolbar groups defined above.
        removeButtons: 'Font,Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Styles,Specialchar'
                // removeButtons: 'Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Specialchar'
    });

    CKEDITOR.replace('editor1_kh', {
        // Remove the redundant buttons from toolbar groups defined above.
        removeButtons: 'Font,Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Styles,Specialchar'
                // removeButtons: 'Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Specialchar'
    });


});
</script>
@endpush
