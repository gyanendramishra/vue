<?php

namespace Modules\Faq\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\Faq\Entities\Faq;
use Yajra\DataTables\Utilities\Request as DatatableRequest;

class FaqController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        return view('faq::index');
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $faqs = Faq::query();

        $faqs = $faqs->get();

        return datatables()->of($faqs)
                        ->addColumn('action', function ($faqs) {
                            $actions = "";
                            $actions .= "<a href=\"" . route('admin.faq.show', ['id' => $faqs->id]) . "\" class=\"\"><i class=\"rounded outline primary icon user profile link\"></i></a>";
                            $actions .= "&nbsp;<a href=\"" . route('admin.faq.edit', ['id' => $faqs->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                            $actions .= "&nbsp;<a title='Delete' data-id='" . $faqs->id . "' class='Delete' data-set='{&quot;title&quot;: &quot;Delete Listing&quot;, &quot;parent&quot;: &quot;tr&quot;, &quot;option&quot;: &quot;deleteListing&quot;, &quot;id&quot;: 17, &quot;name&quot;: &quot;Infiniti Coupe Concept&quot;}''><i class='rounded outline icon negative trash link'></i></a>";
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        $title = "Add FAQ";
        return view('faq::createOrUpdate', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request) {
        $locales = config('app.locales');

        foreach ($locales as $key => $value) {
            $valRule[$key . '_question'] = 'required|max:191';
            $valRule[$key . '_answer'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_question.required'] = ' The question field is required in ' . $value . ' language.';
            $valMessage[$key . '_answer.required'] = ' The answer field is required in ' . $value . ' language.';
            $valMessage[$key . '_question.max'] = ' Sorry, you can\'t add the question more than the 191 characters in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $faq_data = array();

            foreach ($locales as $key => $value) {
                $faq_data[$key]['question'] = $request->input($key . '_question');
                $faq_data[$key]['answer'] = $request->input($key . '_answer');
            }

            $faq = Faq::create($faq_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.faq.index')->with('success', 'FAQ has been saved Successfully');
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id) {
        return view('faq::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id) {
        $title = "Add FAQ";
        $faq = Faq::find($id);
        return view('faq::createOrUpdate', compact('title', 'faq'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id) {
        $locales = config('app.locales');

        foreach ($locales as $key => $value) {
            $valRule[$key . '_question'] = 'required|max:191';
            $valRule[$key . '_answer'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_question.required'] = ' The question field is required in ' . $value . ' language.';
            $valMessage[$key . '_answer.required'] = ' The answer field is required in ' . $value . ' language.';
            $valMessage[$key . '_question.max'] = ' Sorry, you can\'t add the question more than the 191 characters in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $faq_data = array();

            foreach ($locales as $key => $value) {
                $faq_data[$key]['question'] = $request->input($key . '_question');
                $faq_data[$key]['answer'] = $request->input($key . '_answer');
            }

            $faq = Faq::find($id);

            $faq->update($faq_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.faq.index')->with('success', 'FAQ has been updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id) {
        try {
            Faq::where('id', $id)->delete();

            $responce = ['status' => true, 'message' => 'This FAQ has been deleted Successfully!'];
        } catch (\Exception $e) {
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

}
