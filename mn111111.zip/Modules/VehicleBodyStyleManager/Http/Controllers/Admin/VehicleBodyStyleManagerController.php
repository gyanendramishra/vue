<?php

namespace Modules\VehicleBodyStyleManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Input;
use Modules\VehicleBodyStyleManager\Entities\VehicleBodyStyle;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use File;

class VehicleBodyStyleManagerController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        $title = "Vehicle Body Style";
        return view('vehiclebodystylemanager::Admin.vehiclebodystylemanager.index', compact('title'));
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $vehiclebodystyle = VehicleBodyStyle::query();
        if ($request->status != '') {
            $vehiclebodystyle = $vehiclebodystyle->where('status', $request->status);
        }
        if ($request->slug != '') {
            $slug = $request->slug;
            $vehiclebodystyle = $vehiclebodystyle->whereHas('VehicleBodyStyleTranslation', function($q) use($slug) {
                $q->where('name', 'LIKE', lcfirst($slug) . '%');
                $q->orWhere('name', 'LIKE', $slug . '%');
            });
        }
        $vehiclebodystyle = $vehiclebodystyle->get();

        return datatables()->of($vehiclebodystyle)
                        ->addColumn('action', function ($vehiclebodystyle) {
                            $actions = "";
                            $actions .= "<a href=\"" . route('admin.vehiclebodystylemanager.edit', ['id' => $vehiclebodystyle->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                            return $actions;
                        })
                        ->addColumn('image', function ($vehiclebodystyle) {
                            $actions = "";

                            if ($vehiclebodystyle->icon) {

                                $actions = url('uploads/bodyStyle/' . $vehiclebodystyle->icon);
                            } else {
                                $actions = url('images/no-img-202x187.png');
                            }

                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        return view('vehiclebodystylemanager::Admin.vehiclebodystylemanager.createOrUpdate');
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request) {
        $locales = config('app.locales');
        $valRule = [
            'icon' => 'sometimes|mimes:jpeg,jpg,png|max:5000'
        ];
        $valMessage = [
            'icon.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
            'icon.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
            'en_name.regex' => 'The name format is invalid In english language.'
        ];
        foreach ($locales as $key => $value) {
            $valRule[$key . '_name'] = 'required|max:200|unique:vehicle_body_style_translations,name|unique_space_check:vehicle_body_style_translations,name';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_name.required'] = ' The name field is required in ' . $value . ' language.';
            $valMessage[$key . '_name.max'] = ' Sorry, you can\'t add the name more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_name.unique'] = ' Name must be unique in ' . $value . ' language.';
            $valMessage[$key . '_name.unique_space_check'] = ' Name must be unique in ' . $value . ' language.';
        }

        $valRule['en_name'] = 'required|string|regex:/^[\pL\pN\s\-\_]+$/u|max:200|unique:vehicle_body_style_translations,name|unique_space_check:vehicle_body_style_translations,name';

        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['name'] = $request->input($key . '_name');
            }
            $article_data['status'] = $request->input('status');

            if ($request->hasFile('icon')) {
                $image = $request->file('icon');
                $is_dest = "uploads/bodyStyle/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('icon');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $article_data['icon'] = $filenameOrig;
                }
            }
            VehicleBodyStyle::create($article_data);
        } catch (\Illuminate\Database\QueryException $e) {

            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.vehiclebodystylemanager.index')->with('success', 'Vehicle body style has been saved Successfully');
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show(VehicleBodyStyle $vehiclebodystyle) {
        return view('vehiclebodystylemanager::Admin.vehiclebodystylemanager.show', compact('vehiclebodystyle'));
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id) {
        $vehiclebodystyle = VehicleBodyStyle::find($id);
        return view('vehiclebodystylemanager::Admin.vehiclebodystylemanager.createOrUpdate', compact('vehiclebodystyle'));
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id) {
        $locales = config('app.locales');
        $valRule = [
            'icon' => 'sometimes|mimes:jpeg,jpg,png|max:5000'
        ];
        $valMessage = [
            'icon.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
            'icon.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
            'en_name.regex' => 'The name format is invalid In english language.'
        ];
        foreach ($locales as $key => $value) {
            $valRule[$key . '_name'] = 'required|max:200|unique:vehicle_body_style_translations,name,' . $request->segment(3) . ',vehicle_body_style_id|unique_space_check:vehicle_body_style_translations,name,' . $request->segment(3) . ',vehicle_body_style_id';
        }

        $valRule['en_name'] = 'required|string|regex:/^[\pL\pN\s\-\_]+$/u|max:200|unique:vehicle_body_style_translations,name,' . $request->segment(3) . ',vehicle_body_style_id|unique_space_check:vehicle_body_style_translations,name,' . $request->segment(3) . ',vehicle_body_style_id';

        foreach ($locales as $key => $value) {
            $valMessage[$key . '_name.required'] = ' The name field is required in ' . $value . ' language.';
            $valMessage[$key . '_name.max'] = 'Sorry, you can\'t add the name more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_name.unique'] = ' Name must be unique in ' . $value . ' language.';
            $valMessage[$key . '_name.unique_space_check'] = ' Name must be unique in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);


        try {

            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['name'] = $request->input($key . '_name');
            }
            $article_data['status'] = $request->input('status');


            if ($request->hasFile('icon')) {
                $image = $request->file('icon');
                $is_dest = "uploads/bodyStyle/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('icon');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $article_data['icon'] = $filenameOrig;
                }
            }
            $VehicleBodyStyle = VehicleBodyStyle::find($id);

            $VehicleBodyStyle->update($article_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.vehiclebodystylemanager.index')->with('success', 'Vehicle Body Style has been updated Successfully');
    }

}
