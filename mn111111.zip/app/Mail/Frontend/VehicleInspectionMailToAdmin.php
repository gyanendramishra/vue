<?php

namespace App\Mail\Frontend;

use App\EmailTemplate;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Modules\VehicleInspectionsManager\Entities\VehicleInspection;

class VehicleInspectionMailToAdmin extends Mailable {

    use Queueable,
        SerializesModels;
    
    /**
     * The VehicleInspection instance.
     *
     * @var VehicleInspection
     */
    public $vehicleInspection;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(VehicleInspection $vehicleInspection)
    {
        $this->vehicleInspection = $vehicleInspection;
    }
   
    /**
     * Build the message.
     *
     * @return $this
     */
    public function build() {
        $et = EmailTemplate::whereType('vehicle_inspection_mail_to_admin')
                ->with('translations:id,email_template_id,locale,subject,template')
                ->first(['id']);
        if ($et) {
            $subject = $et->subject;
            $body = $et->template;
            $role = $this->vehicleInspection->user->roles->pluck('name')->implode(',');
            $body = str_replace('##VEHICLE_TITLE##', $this->vehicleInspection->vehicle->title, $body);
            $body = str_replace('##VEHICLE_CODE##',$this->vehicleInspection->vehicle->id, $body);
            $body = str_replace('##NAME##', $this->vehicleInspection->name, $body);
            $body = str_replace('##ROLE##', $role, $body);
            $body = str_replace('##EMAIL##', $this->vehicleInspection->email, $body);
            $body = str_replace('##PHONE##', $this->vehicleInspection->phone, $body);
            $body = str_replace('##MESSAGE##', $this->vehicleInspection->message, $body);
            $this->subject($subject)
                    ->view('frontend.emails.template')
                    ->with(['template' => $body]);
        }
    }

}
