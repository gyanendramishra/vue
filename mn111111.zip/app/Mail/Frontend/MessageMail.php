<?php

namespace App\Mail\Frontend;

use App\EmailTemplate;
use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class MessageMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The mailData instance.
     *
     * @var mailData
     */

    public $mailData;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($mailData)
    {
        $this->mailData = $mailData;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $et = EmailTemplate::whereType('vehicle_message_mail_to_receiver')
            ->with('translations:id,email_template_id,locale,subject,template')
            ->first(['id']);
        if($et){
            $subject = $et->subject;
            $body = $et->template;
            $body = str_replace('##USER##', $this->mailData['name'], $body);
            $body = str_replace('##VEHICLE_TITLE##', $this->mailData['vehicle_title'], $body);
            $body = str_replace('##MESSAGE##', $this->mailData['message'], $body);

            $this->subject($subject)
                ->view('frontend.emails.template')
                ->with(['template'=>$body]);
        }
    }
}
