<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class ProfileRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('user')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [];
        $rules['name'] = 'bail|required|max:50';
        $user = \Auth::guard('user')->user();
        if($user->hasRole('Dealer')){
            $rules['company_name'] = 'bail|required|max:100';
            $rules['address'] = 'bail|required|max:150';
        }
        return $rules;
    }

}
