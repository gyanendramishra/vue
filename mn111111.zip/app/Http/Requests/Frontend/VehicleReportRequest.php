<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class VehicleReportRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'vehicle_id'            =>'bail|required',
            'type'                  =>'bail|required|integer|max:100',
            'name'                  =>'bail|required|string|max:100',
            'email'                 =>'bail|required|email|max:100',
            'phone'                 =>'bail|required|numeric|digits_between:4,16',
            'message'               =>'bail|required|string|min:100|max:500'
        ];
    }
}
