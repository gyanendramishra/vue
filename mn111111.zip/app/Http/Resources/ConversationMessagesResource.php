<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ConversationMessagesResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
         return [
             
            'id' => $this->id,
            'user_id' => $this->user_id,
            'date_time' => $this->date_time,
            'created_at' => $this->human_time,
            'content' => $this->content,
            'username' => ($this->user)?$this->user->name:'',
            'profile_image' => ($this->user)?url('storage/'.$this->user->profile_image):'',
        ];
    }
}
