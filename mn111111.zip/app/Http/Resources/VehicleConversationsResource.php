<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class VehicleConversationsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
    
         return [
            'id' => $this->id,
            'name' => ($this->participants[0])?$this->participants[0]->name:'',
            'image' => ($this->participants[0])?url('storage/'.$this->participants[0]->profile_image):'',
             'message'=>    $this->messages->last(),
        ];
    }
}
