<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\VehicleEnquiresManager\Entities\Conversation;
use Modules\VehicleEnquiresManager\Entities\ConversationMessage;
use Modules\VehicleManager\Entities\Vehicle;
use App\Http\Resources\Collection\UserVehiclesHasConversationCollection;
use App\Http\Resources\Collection\VehicleConversationsCollection;
use App\Http\Resources\Collection\ConversationMessagesCollection;
use App\Repositories\ConversationRepository;

class ConversationController extends Controller {

    public $successStatus = 200;
    private $conversationRepository;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request, ConversationRepository $conversationRepository) {
        //$authInformation = $request->header();
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
        $this->conversationRepository = $conversationRepository;
    }

    /**
     * 
     * @return type
     */
    public function getVehicleHasConversation() {
        try {
            $userId = \Auth::guard('api')->id();

            $allVehicles = new UserVehiclesHasConversationCollection(
                    Vehicle::select('id', 'title')
                            ->with([
                                'main_image:id,vehicle_id,image,caption',
                            ])
                            ->approved()
                            ->where('user_id', $userId)
                            ->has('conversations')
                            ->get());
            $data['data'] = $allVehicles;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function getVehicleConversations(Request $request) {

        try {
            $userId = \Auth::guard('api')->id();
            $allVehicles = new VehicleConversationsCollection(
                    Conversation::select('id', 'vehicle_id')
                            ->where('vehicle_id', $request->vehicle_id)
                            ->with([
                                'participants' => function($query) use($userId) {
                                    $query->select('users.id', 'users.name', 'users.profile_image');
                                    $query->where('user_id', '!=', $userId);
                                },
                            ])->orderBy('id', 'DESC')
                            ->get());

            $data['data'] = $allVehicles;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function getConversationMessages(Request $request) {
        try {

            $allMessages = new ConversationMessagesCollection(
                    ConversationMessage::select('id', 'user_id', 'content', 'created_at')
                            ->where('conversation_id', $request->conversation_id)
                            ->with('user:id,name,profile_image')
                            ->orderBy('id', 'DESC')
                            ->paginate(20));
            $data['data'] = $allMessages;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function sendMessages(Request $request) {
        try {
            \DB::beginTransaction();
            $conversation = \Modules\VehicleEnquiresManager\Entities\Conversation::find($request->conversation_id);
            if ($conversation) {
                if ($conversation->vehicle->is_approved == 0) {

                    $data['data'] = (object) [];
                    $data['status'] = FALSE;
                    $data['message'] = __('frontend.CONVERSATION_VEHICLE_UNAPPROVED');
                    $data['code'] = 200;
                    return response()->json($data);
                }
                if ($conversation->vehicle->is_sold == 1) {
                    $data['data'] = (object) [];
                    $data['status'] = FALSE;
                    $data['message'] = __('frontend.CONVERSATION_VEHICLE_SOLD');
                    $data['code'] = 200;
                    return response()->json($data);
                }
                $message = new \Modules\VehicleEnquiresManager\Entities\ConversationMessage($request->all());
                $message->user_id = \Auth::guard('api')->id();
                if ($message->save()) {
                    $allMessages = new \App\Http\Resources\ConversationMessagesResource($message);
                    
                   
                   
                    // DB commit
                    \DB::commit();

                    //$message = $this->conversationRepository->getMessageById($message->id);
                    $data['data'] = $allMessages;
                    $data['status'] = TRUE;
                    $data['message'] = 'Message has been sent successfully.';
                    $data['code'] = 200;
                    return response()->json($data);
                }
            }
            throw new Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = $e->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

}
