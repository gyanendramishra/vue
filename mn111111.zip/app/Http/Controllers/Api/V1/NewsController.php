<?php

namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use \Modules\NewsManager\Entities\News;
use App\Http\Resources\Collection\NewsCollection;
use App\Http\Resources\NewsResource as NewsResource;

class NewsController extends Controller {

    public $successStatus = 200;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request) {
        //$authInformation = $request->header();
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
    }

    /**
     *  get all news list
     * @param Request $request
     * @return type
     */
    public function index(Request $request) {
        try {
            $news = new NewsCollection(News::select('id', 'news_type', 'image', 'video', 'start_date', 'end_date', 'slug')
                            ->with('translations:id,news_id,locale,title')
                            ->whereDate('start_date', '<=', \Carbon\Carbon::now())
                            ->whereDate('end_date', '>=', \Carbon\Carbon::now())
                            ->active()
                            ->paginate(15));
            $data['data'] = $news;
            $data['status'] = true;
            $data['message'] = "lists";
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {

            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function getNewsDetail(Request $request) {

        try {
            if (!empty($request->slug)) {
                if (!News::whereSlug($request->slug)->exists()) {
                    $data['data'] = (object) [];
                    $data['status'] = false;
                    $data['message'] = "Slug Incorrect.";
                    $data['code'] = 200;
                    return response()->json($data);
                }
                $news = new NewsResource(News::select('id', 'news_type', 'image', 'video', 'start_date', 'end_date')
                                ->with('translations:id,news_id,locale,title,description')
                                ->whereDate('start_date', '<=', \Carbon\Carbon::now())
                                ->whereDate('end_date', '>=', \Carbon\Carbon::now())
                                ->whereSlug($request->slug)
                                ->active()
                                ->first());
                $data['data'] = $news;
                $data['status'] = true;
                $data['message'] = "lists";
                $data['code'] = 200;
                return response()->json($data);
            } else {
                $data['data'] = (object) [];
                $data['status'] = false;
                $data['message'] = "Something went wrong.";
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {

            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

}
