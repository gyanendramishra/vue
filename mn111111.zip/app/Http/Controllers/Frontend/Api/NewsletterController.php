<?php

namespace App\Http\Controllers\Frontend\Api;

use Newsletter;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Http\Requests\Frontend\NewsLetterRequest;

class NewsletterController extends Controller {

    /**
     * Get conversation messages.
     *
     * @return \Illuminate\Http\Response
     */
    public function subscribeToNewsletter(NewsLetterRequest $request) {
        try {
            $newsletter = new \App\Newsletter();
            $newsletter->email = $request->email;
            if ($newsletter->save()) {
                Newsletter::subscribe($request->email);
                return response()->json([
                            "status" => "success",
                            "messages" => __('frontend.SUBSCRIBED_NEWSLETTER')
                                ], 200);
            }
            throw new Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

}
