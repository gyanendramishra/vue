<?php

namespace App\Http\Controllers\Frontend\Auth;

use App\User;
use Aloha\Twilio\Twilio;
use App\Models\VerifyUser;
use Illuminate\Support\Str;
use \Illuminate\Http\Request;
use App\Mail\Frontend\WelcomeMail;
use App\Http\Controllers\Controller;
use App\Http\Requests\Frontend\RegisterRequest;

class RegisterController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest:user');
    }

    /**
     * Display a register view of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {
        $roles=  \Modules\User\Entities\Role::where('slug', '!=', 'admin')->get(['id','name']);
        return view('frontend.auth.register', compact('roles'));
    }

    /**
     * Register user into system.
     *
     * @param  \App\Http\Requests\Backend\RegisterRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function register(RegisterRequest $request) {

        $RandomNumber = rand(100000, 999999);
        $account_id = env('TWILIO_SID');
        $auth_token = env('TWILIO_TOKEN');
        $from_phone_number = env('TWILIO_FROM');
        $twilio = new Twilio($account_id, $auth_token, $from_phone_number);

        try {
            \DB::beginTransaction();

            $user = new User;
            $user->name = $request->name;
            $user->phone = $request->phone;
            $user->email = $request->email;
            $user->country_code = $request->countryCode;
            $user->password = bcrypt($request->password);
            $user->status = 1;
            if($request->role_id == 3){
                $user->company_name = $request->company_name;
                $user->address = $request->address;
                $user->city = $request->city;
                $user->state = $request->state;
                $user->country = $request->country;
                $user->latitude = $request->latitude;
                $user->longitude = $request->longitude;
            }
            if ($user->save()) {
                // attach user role to user
                $user->roles()->attach($request->role_id);
                // Attach verification otp with user
                $userVerification = new \App\UserVerification();
                $userVerification->otp = "123456";
                $userVerification->otp_type = 1;
                $user->userVerification()->save($userVerification);
                $str = '123456' . ' is your one time password (OTP) for car market phone verification';

                $phoneNo = $request->countryCode . $user->phone;
                $twilio->message($phoneNo, $str);
                // Commit db
                \DB::commit();

                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.REGISTERED')
                                ], 200);
            } else {
                \DB::rollBack();
                return response()->json([
                            "status" => "error",
                            "message" => __('frontend.OOPS')
                                ], 200);
            }
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * @desc verify otp for mobile verification 
     * @param Request $request
     * @return type
     */
    public function verifyOtp(Request $request) {
        try {

            if ($request->otp) {
                $userOtp = \App\User::whereHas('userVerification', function($q) use($request) {
                            $q->where('otp', $request->otp)->where('otp_type', $request->otpType);
                        })->where('phone', $request->phone)->first();

                if ($userOtp) {

                    $to = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $userOtp->userVerification->created_at);
                    $from = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', date('Y-m-d H:i:s'));
                    $diff_in_minutes = $to->diffInMinutes($from);
                    if ($diff_in_minutes > 120) {
                        return response()->json([
                                    "status" => "error",
                                    "message" => __('frontend.OTP_EXPIRED')
                                        ], 200);
                    }
                    if ($request->otpType == 1) {
                        $userOtp->update(['is_otp_verified' => 1]);
                    }
                    $userOtp->userVerification()->where('otp_type', $request->otpType)->delete();
                    return response()->json([
                                "status" => "success",
                                "message" => __('frontend.VERIFIED')
                                    ], 200);
                } else {
                    return response()->json([
                                "status" => "error",
                                "message" => __('frontend.INCORRECT_OTP')
                                    ], 200);
                }
            } else {
                return response()->json([
                            "status" => "error",
                            "message" => __('frontend.OOPS')
                                ], 200);
            }
        } catch (Exception $ex) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * @desc Resend otp to registerd phone number
     * @param Request $request
     */
    public function resendOtp(Request $request) {
        try {
            if ($request->phone) {
                $user = \App\User::where('phone', $request->phone)->first();
                if ($user) {
                    $RandomNumber = rand(100000, 999999);
                    $account_id = env('TWILIO_SID');
                    $auth_token = env('TWILIO_TOKEN');
                    $from_phone_number = env('TWILIO_FROM');
                    $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                    \App\UserVerification::where('user_id',$user->id)->where('otp_type',$request->otpType)->delete();
                    \App\UserVerification::updateOrCreate(
                        [
                            'user_id' => $user->id,
                            'otp_type' => $request->otpType
                        ], 
                        [
                            'user_id' => $user->id,
                            'otp' => '123456',
                            'otp_type' => $request->otpType,
                        ]
                    );

                    $str = '123456' . ' is your one time password (OTP) for car market phone verification';
                    $phoneNo = $user->country_code . $user->phone;
                    $twilio->message($phoneNo, $str);
                    return response()->json([
                                "status" => "success",
                                "message" => __('frontend.RESEND_OTP')
                                    ], 200);
                } else {
                    return response()->json([
                                "status" => "error",
                                "message" => __('frontend.OOPS')
                                    ], 200);
                }
            } else {
                return response()->json([
                            "status" => "error",
                            "message" => __('frontend.OOPS')
                                ], 200);
            }
        } catch (Exception $ex) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

}
