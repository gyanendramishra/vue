<?php

namespace App\Http\Controllers\Frontend\Auth;

use Socialite;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;

class SocialiteController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Login Controller
      |--------------------------------------------------------------------------
      |
      | This controller handles authenticating users for the application and
      | redirecting them to your home screen. The controller uses a trait
      | to conveniently provide its functionality to your applications.
      |
     */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest:user');
    }

    /**
     * Redirect the user to the GitHub authentication page.
     *
     * @return \Illuminate\Http\Response
     */
    public function redirectToProvider($provider) {
        return Socialite::driver($provider)->redirect();
    }

    /**
     * Obtain the user information from GitHub.
     *
     * @return \Illuminate\Http\Response
     */
    public function handleProviderCallback(Request $request, $provider) {


        try {
            \DB::beginTransaction();
            $s_user = Socialite::driver($provider)->user();

            if ($s_user && $s_user->id) {

                if ($provider == 'google') {
                    $providerId = 'google_id';
                }
                if ($provider == 'facebook') {
                    $providerId = 'facebook_id';
                }
                $user = User::where($providerId, $s_user->id)->first();  // cgeck user behalf on token

                if ($user) {  // if user exists
                    // Check if user is active
                    if ($user->status == 0) {
                        return redirect()
                                        ->route('frontend.login')
                                        ->withFlashError(__('frontend.LOGIN FAILED DUE TO ACCOUNT ACTIVATION'));
                    }
                    // login the user
                    Auth::guard('user')->login($user);

                    return redirect()
                                    ->intended('/')
                                    ->withFlashSuccess(__('frontend.LOGIN SUCCESS'));
                } else {   // not exits user
                    if (($s_user->has('phone') && !empty($s_user->phone)) || $s_user->has('email') && !empty($s_user->email)) {  // check phone or email has 
                        $user = User::where('phone', $s_user->phone)->orWhere('email', $s_user->email)->first();
                        if ($user) {  // if user exists
                            if ($user->phone == null) {
                                return redirect()
                                                ->back()
                                                ->with(['status' => true, 'code' => 105]);
                            }

                            if (!empty($s_user->email)) {
                                if (User::where('email', $s_user->email)->where('id', '!=', $user->id)->exists()) {
                                    return redirect()
                                                    ->back()
                                                    ->withFlashSuccess(__('frontend.EMAIL_ALREADY_EXISTS'));
                                }
                            }

                            $user->name = $s_user->name ?? '';
                            $user->email = $s_user->email ?? '';
                            $user->phone = $s_user->phone ?? '';
                            $user->$providerId = $s_user->id ?? '';
                            $user->status = 1;
                            $user->is_otp_verified = 1;
                            $user->save();
                            
                            // Commit db
                            \DB::commit();
                        } else {
                            if ($s_user->phone == null) {
                                return redirect()
                                                ->back()
                                                ->with(['status' => true, 'code' => 105]);
                            }

                            return redirect()
                                            ->back()
                                            ->with(['status' => true, 'code' => 106]);
                        }
                    } else {
                        return redirect()
                                        ->back()
                                        ->with(['status' => true, 'code' => 105]);
                    }
                }
            }
            return redirect()
                            ->route('frontend.login')
                            ->withFlashError(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return redirect()
                            ->route('frontend.login')
                            ->withFlashError(__('frontend.OOPS'));
        }
    }

//    if (!empty($s_user->email)) {
//                if (!$user = User::whereEmail($s_user->email)->first()) {
//                    $user = new User();
//                    $user->name = $s_user->name ?? '';
//                    $user->email = $s_user->email ?? '';
//                    $user->status = 1;
//                    $user->is_otp_verified = 1;
//                    $user->save();
//                    // attach user role to user
//                    $user->roles()->attach(2);
//                    // Commit db
//                    \DB::commit();
//                }
//                if ($user) {
//
//                    // Check if user is active
//                    if ($user->status == 0) {
//                        return redirect()
//                                        ->route('frontend.login')
//                                        ->withFlashError(__('frontend.LOGIN FAILED DUE TO ACCOUNT ACTIVATION'));
//                    }
//                    // login the user
//                    Auth::guard('user')->login($user);
//
//                    return redirect()
//                                    ->intended('/')
//                                    ->withFlashSuccess(__('frontend.LOGIN SUCCESS'));
//                }
//            }
}
