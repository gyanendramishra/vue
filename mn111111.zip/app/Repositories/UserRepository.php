<?php

namespace App\Repositories;

use Illuminate\Http\Request;
use App\Repositories\SubscriptionRepository;
use App\Repositories\Interfaces\UserInterface;
use Modules\VehicleManager\Entities\Vehicle;

class UserRepository implements UserInterface {
    
    /* Get user saved vehicles */
    public function savedVehicle($user) {
        return  $user->favouriteVehicles()
                    ->where('is_favourite', 1)
                    ->select(
                        'id', 
                        'category_id', 
                        'makes_id', 
                        'models_id', 
                        'badge_id', 
                        'body_styles_id',
                        'fuel_types_id',
                        'series_id',
                        'transmissions_id',
                        'title',
                        'role',
                        'odometer',
                        'price',
                        'address',
                        'is_featured',
                        'slug'
                    )
                    ->with([
                        'main_image:id,vehicle_id,image,caption',
                        'transmissions:id',
                        'transmissions.translations:id,vehicle_transmissions_id,name,locale',
                        'bodystyle:id',
                        'bodystyle.translations:id,vehicle_body_style_id,locale,name',
                        'fuel_type:id',
                        'fuel_type.translations:id,vehicle_fuel_types_id,locale,name',
                    ])
                    ->approved()
                    ->orderBy('id', 'DESC')
                    ->paginate(10);
    }

    /* Get user vehicles */
    public function vehicles($user) {
        return  $user->vehicles()
                    ->select(
                        'id', 
                        'category_id', 
                        'makes_id', 
                        'models_id', 
                        'badge_id', 
                        'body_styles_id',
                        'fuel_types_id',
                        'series_id',
                        'transmissions_id',
                        'title',
                        'role',
                        'odometer',
                        'price',
                        'address',
                        'is_approved',
                        'is_featured',
                        'is_on_sale',
                        'is_until_sold',
                        'is_sold',
                        'slug'
                    )
                    ->with([
                        'main_image:id,vehicle_id,image,caption',
                        'favouriteUsers:is_favourite',
                        'category:id',
                        'category.translations:id,category_id,name,locale',
                        'make:id',
                        'make.translations:id,vehicle_make_id,name,locale',
                        'model:id,makes_id',
                        'model.translations:id,vehicle_model_id,name,locale',
                        'badge:id,models_id',
                        'badge.translations:id,vehicle_badge_id,name,locale',
                        'series:id,badges_id',
                        'series.translations:id,vehicle_series_id,name,locale',
                        'transmissions:id',
                        'transmissions.translations:id,vehicle_transmissions_id,name,locale',
                        'bodystyle:id',
                        'bodystyle.translations:id,vehicle_body_style_id,locale,name',
                        'fuel_type:id',
                        'fuel_type.translations:id,vehicle_fuel_types_id,locale,name'
                        
                    ])
                    ->orderBy('id', 'DESC')
                    ->paginate(10);
    }

    /* Check user has active subscription or not */
    public function hasActiveSubscription($user){
        $subscriptions = $user->subscriptions;
        if($subscriptions->isNotEmpty()){
            $subscription = $subscriptions->last();
            if($user->subscribed($subscription->name)){
                return true;
            }
        }
        return false;
    }

    /**
     * Get user current active subscription
     */
    public function subscription($user){
        if($this->hasActiveSubscription($user)){
            $subscription =  $user->subscriptions->last();
            return $subscription->setAttribute('plan', SubscriptionRepository::getSubscriptionPlanByGatewayId($subscription->gateway_plan_id));
        }
        return '';
    }

    /**
     * Get user vehicles listing count
     */
    public function listingCount($user){
        return $user->vehicles->count();
    }

    /**
     * Get user remaining vehicles listing count as per subscription
     */
    public function remaininglistingCount($user){
        if($subscription = $this->subscription($user)){
            $totalListingCount = $subscription->plan->total_listing_count;
            $existingListingCount = $this->listingCount($user);
            return ($totalListingCount - $existingListingCount);
        }
        return 0;
    }
    
    /**
     * Get user featured vehicles listing count
     */
    public function featuredCount($user){
        return $user->vehicles->where('is_featured', 1)->count();
    }

    /**
     * Get user remaining vehicles featured listing count as per subscription
     */
    public function remainingFeaturedCount($user){
        if($subscription = $this->subscription($user)){
            $totalFeaturedCount = $subscription->plan->total_featured_count;
            $existingFeaturedCount = $this->featuredCount($user);
            return ($totalFeaturedCount - $existingFeaturedCount);
        }
        return 0;
    }

    /**
     * Get user on sale vehicles count
     */
    public function onSaleCount($user){
        return $user->vehicles->where('is_on_sale', 1)->count();
    }

    /**
     * Get user remaining vehicles onsle listing count as per subscription
     */
    public function remainingOnSaleCount($user){
        if($subscription = $this->subscription($user)){
            $totalOnSaleCount = $subscription->plan->total_on_sale_count;
            $existingOnSaleCount = $this->onSaleCount($user);
            return ($totalOnSaleCount - $existingOnSaleCount);
        }
        return 0;
    }

    /**
     * Get user until sold vehicles count
     */
    public function untilSoldCount($user){
        return $user->vehicles->where('is_until_sold', 1)->count();
    }

    /**
     * Get user remaining vehicles featured until sold count as per subscription
     */
    public function remainingUntilSoldCount($user){
        if($subscription = $this->subscription($user)){
            $totalUntilSoldCount = $subscription->plan->count_of_until_sold;
            $existingUntilSoldCount = $this->untilSoldCount($user);
            return ($totalUntilSoldCount - $existingUntilSoldCount);
        }
        return 0;
    }
    
    /**
     * Get user sold vehicles count
     */
    public function soldCount($user){
        return $user->vehicles->where('is_sold', 1)->count();
    }

    /**
     * Get user favourite vehicles count
     */
    public function favouriteCount($user) {
        return $user->favouriteVehicles()->approved()->count();
    }

    /**
     * Get user vehicles inquiries count
     */
    public function vehicleInquiriesCount($user) {
        return $user->conversations()->count();
    }

}
