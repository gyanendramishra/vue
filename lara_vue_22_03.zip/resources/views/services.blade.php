@extends('layouts.app')

@section('content')

<div class="mainWpapContainer">
	<div class="container" style="padding-top: 150px; min-height: 500px">
		<h1>Services</h1>
		<p>Description</p>
	</div>
</div>

@endsection
