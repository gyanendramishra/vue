<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/animate.css') }}" media="all">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}" media="all"/>
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<body>
    <div id="app">
        <div class="header">
            <div class="mainMenuWrap">
                <div class="container">
                    <div class="mainMenuBar">
                        <nav class="nav" role="navigation">
                            <div class="wrapper-flush">
                                <!-- Nav toggle component -->
                                <nav-toggle-component></nav-toggle-component>
                                <!-- -->
                                <div class="logo">
                                    <a href="{{ route('home') }}">
                                      <img src="{{ asset('images/logo.png') }}" alt="logo" title="" />
                                    </a>
                                </div>
                                <div class="nav-container">
                                    <ul class="nav-menu menu">
                                        <li class="menu-item {{ (\Request::is('about-us')) ? 'active': '' }}">
                                            <a href="{{ route('about.us') }}" class="menu-link">about us</a>
                                        </li>
                                        <li class="menu-item {{ (\Request::is('services')) ? 'active': '' }}">
                                            <a href="{{ route('services') }}" class="menu-link">Services</a>
                                        </li>
                                        <li class="menu-item {{ (\Request::is('faq')) ? 'active': '' }}">
                                            <a href="{{ route('faq') }}" class="menu-link"> fAQ’S</a>
                                        </li>
                                    </ul>
                                    <div class="top-right-login">
                                        <ul class="login-menu">
                                            @if(\Session::has('auth_user'))
                                                <li>
                                                    <a href="">
                                                        {{ \Session::get('auth_user')->name }}
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="{{ route('user.logout') }}"> 
                                                        Logout
                                                    </a>
                                                </li>
                                            @else
                                                <li class="{{ (\Request::is('login')) ? 'active': '' }}">
                                                    <a href="{{ route('user.login.form') }}">
                                                        <img src="{{ asset('images/login_icon.png') }}" /> Login
                                                    </a>
                                                </li>
                                                <li class="{{ (\Request::is('register')) ? 'active': '' }}">
                                                    <a href="{{ route('user.register.form') }}">
                                                        <img src="{{ asset('images/signup_icon.png') }}" /> Signup
                                                    </a>
                                                </li>
                                            @endif
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        @yield('content')

        <footer class="footer">
            <div class="footer-top-sec">
                <div class="container">
                    <div class="footer-logo">
                        <a href="{{ route('home') }}">
                            <img src="{{ asset('images/logo.png') }}" alt="logo" title="" />
                        </a>
                    </div>
                    <div class="ft-menu clearfix">
                        <ul>
                            <li>
                                <a href="{{ route('home') }}">Home</a>
                            </li>
                            <li>
                                <a href="{{ route('about.us') }}">About Us</a>
                            </li>
                            <li>
                                <a href="{{ route('services') }}">Services</a>
                            </li>
                            <li>
                                <a href="{{ route('faq') }}">Faq’s</a>
                            </li>
                            <li>
                                <a href="">Contact Us</a>
                            </li>
                            <li>
                                <a href="">Privacy Policy</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="copyright-sec">
                <div class="container">
                    <p>Copyright © 2018 CGS Group LCC. All Rights Reserved.</p>
                    <div class="footer-social">
                        <span>Social Connect:</span>
                        <ul class="social-icon">
                            <li>
                                <a href=""><i class="fa fa-facebook-f"></i></a>
                            </li>
                            <li>
                                <a href=""><i class="fa fa-twitter"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
        {{-- flash messages component --}}

        <flash-component></flash-component>

        {{-- end flash messages component --}}
    </div>
    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>
</body>
</html>
