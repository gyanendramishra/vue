@extends('layouts.app')

@section('content')

<div class="mainWpapContainer">
    <div class="container">
        You are logged in!
    </div>
</div>
@endsection
