<template>
    <div class="mainWpapContainer">
        <div class="login-sec">
            <div v-if="isPasswordResetLinkSent === false">
                <div class="container">
                    <div class="login-title">
                        <h1>Forgot <span>Password</span></h1>
                    </div>
                    <div class="login-box">
                        <form @submit.prevent="sendPasswordResetLink">
                            <div class="row">
                                <div class="col-md-12">
                                <div class="loginForm">
                                    <div class="form-group">
                                        <label>
                                            Email address 
                                            <span class="red-color">*</span>
                                        </label>
                                        <div class="form-icon-col">
                                            <i class="fa fa-envelope"></i> 
                                            <input type="text" placeholder="Email address" name="email" v-model="fields.email">
                                            <div v-if="errors && errors.password" class="text-danger">
                                                {{ errors.password[0] }}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" value="Send Password Reset Link" name="">
                                    </div>
                                </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div v-else>
                <div class="container">
                    <div class="login-title">
                        <h1>Reset <span>Password</span></h1>
                    </div>
                    <div class="login-box">
                        <form @submit.prevent="resetPassword">
                            <div class="row">
                                <div class="col-md-12">
                                <div class="loginForm">
                                    <div class="form-group">
                                        <label>
                                            OTP 
                                            <span class="red-color">*</span>
                                        </label>
                                        <div class="form-icon-col">
                                            <i class="fa fa-envelope"></i> 
                                            <input type="text" placeholder="OTP" name="verification_code" v-model="fields.verification_code">
                                            <div v-if="errors && errors.verification_code" class="text-danger">
                                                {{ errors.verification_code[0] }}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>
                                            Password 
                                            <span class="red-color">*</span>
                                        </label>
                                        <div class="form-icon-col">
                                            <i class="fa fa-lock"></i> 
                                            <input type="password" placeholder="Password" name="password" v-model="fields.password">
                                            <div v-if="errors && errors.password" class="text-danger">
                                                {{ errors.password[0] }}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>
                                            Confirm Password 
                                            <span class="red-color">*</span>
                                        </label>
                                        <div class="form-icon-col">
                                            <i class="fa fa-lock"></i> 
                                            <input type="password" placeholder="Password" name="confirm_password" v-model="fields.confirm_password">
                                            <div v-if="errors && errors.confirm_password" class="text-danger">
                                                {{ errors.confirm_password[0] }}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" value="Reset Password" name="">
                                    </div>
                                </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                isPasswordResetLinkSent : false,
                loading : false,
                fields: {},
                errors: {},
            }
        },
        methods: {
            sendPasswordResetLink() {
                this.loading = true;
                this.errors = {};
                axios.post('/password/email', this.fields).then(response => {
                    if(response.data.status === true){
                        this.isPasswordResetLinkSent = true;
                        flash(response.data.message, 'success');
                    }else{
                        flash(response.data.message, 'error');
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },

            resetPassword() {
                this.loading = true;
                this.errors = {};
                axios.post('/password/reset', this.fields).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                        window.location = '/login';
                    }else{
                        flash(response.data.message, 'error');
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },
        },
    }
</script>
