<template>
    <div class="top-category-sec global-slider-controls" v-if="most_popular_categories.length > 0">
        <div class="container">
            <div class="titleSec">
                <h2>Top Category</h2>
            </div>
            <div id="top-category-slider" class="owl-carousel top-category-slider">
                <div class="item" v-for="most_popular_category in most_popular_categories">
                    <div class="top-category-col">
                        <div class="userCol">
                            <img src="/images/top_category_img01.jpg" alt="" />
                            <h4>{{ most_popular_category.name }}</h4>
                            <span>{{ most_popular_category.name }}</span>
                            <div class="category-rating-col">
                                <i class="fa fa-star"></i> 5.0
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border-btn-sec">
                <a href="#" class="border-btn">View all</a>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        name: "top-categories-component",
        props:["most_popular_categories"],
        mounted: function(){
            Vue.nextTick(function(){
                window.$(".top-category-slider").owlCarousel({
                    loop:true,
                    margin:0,
                    nav:true,
                    dots:false,
                    autoplay:true,
                    responsive:{
                        0:{
                            items:1 
                        },
                        767:{
                            items:2
                        },
                        1024:{
                            items:3
                        },
                        1300:{
                            items:4
                        }
                        
                    }
                });
            }.bind(this));
        }
    };
</script>
