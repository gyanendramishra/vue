<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\HomeService;

class HomeController extends Controller
{ 

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(){}

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(){
        return view('home');
    }

    /**
     * Get near by data.
     * @param HomeService $service
     * @return Illuminate\Http\Response
     */
    public function getNearByData(Request $request, HomeService $service){
        /*$data = [
            'latitude' => 26.9124,
            'longitude' => 75.7873,
        ];*/
        $response = $service->nearCategoryNServiceProviders($request->all());
        return response()->json($response, 200);
    }
}
