<?php

namespace App\Http\Controllers\Auth;

use App\Services\AuthService;
use App\Http\Controllers\Controller;
use App\Http\Requests\ForgotPasswordRequest;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest');
    }

    /**
     * Show the application password reset form.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(){
        return view('auth.passwords.email');
    }

    /**
     * Reset the user password.
     *
     * @param  ForgotPasswordRequest $request
     * @param  AuthService $service
     * @return Illuminate\Http\Response
     */
    public function sendResetPasswordEmail(ForgotPasswordRequest $request, AuthService $service){
        $response = $service->forgotPasswordService($request->only('email'));
        return response()->json($response, 200);
    }
}
