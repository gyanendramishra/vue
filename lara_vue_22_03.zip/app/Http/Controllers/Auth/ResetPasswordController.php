<?php

namespace App\Http\Controllers\Auth;

use App\Services\AuthService;
use App\Http\Controllers\Controller;
use App\Http\Requests\ResetPasswordRequest;

class ResetPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset requests
    | and uses a simple trait to include this behavior. You're free to
    | explore this trait and override any methods you wish to tweak.
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest');
    }

    /**
     * Reset the user password.
     *
     * @param  ResetPasswordRequest $request
     * @param  AuthService $service
     * @return Illuminate\Http\Response
     */
    public function resetPassword(ResetPasswordRequest $request, AuthService $service){
    
        $data = $request->only(['verification_code', 'email', 'password', 'confirm_password']);
        $response = $service->resetPasswordService($data);
        
        return response()->json($response, 200);
    }
}
