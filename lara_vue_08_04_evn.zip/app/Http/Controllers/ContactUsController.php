<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\CmsService;

class ContactUsController extends Controller
{
    /**
     * Show the contact us.
     *
     * @param Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request, CmsService $service) {
    	try{
    		$page = $service->getContactUs();
        	return view('contact-us', compact('page'));
    	}catch(\Exception $e){
    		$message = $e->getMessage();
    		return view('errors.500', compact('message'));
    	}
    }

    /**
     * Get contact us.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\CmsService $service
     * @return \Illuminate\Http\Response
     */
    public function getContactUs(Request $request, CmsService $service){
        try{
            $response = $service->getContactUs();
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Inquire.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\CmsService $service
     * @return \Illuminate\Http\Response
     */
    public function inquire(Request $request, CmsService $service){
        try{
            $response = $service->sendInquiryService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
