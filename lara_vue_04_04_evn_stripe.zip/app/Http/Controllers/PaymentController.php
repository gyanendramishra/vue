<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\PaymentService;
use App\Http\Requests\AddPaymentRequest;
use App\Http\Requests\UpdatePaymentRequest;

class PaymentController extends Controller
{ 


    /**
     * Show payment form.
     *
     * @param Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request){
        $user = $request->session()->get('auth_user');
        if(!$user->isServiceProvider){
            return redirect()->route('user.dashboard');
        }
        return view('payment.index');
    }


    /**
     * Add the user payment account.
     *
     * @param App\Http\Requests\AddPaymentRequest
     * @param App\Services\PaymentService $service
     * @return \Illuminate\Http\Response
     */
    public function addPaymentAccount(AddPaymentRequest $request, PaymentService $service){
        try{
            $response = $service->addPaymentAccountService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Update the user payment account.
     *
     * @param App\Http\Requests\UpdatePaymentRequest $request
     * @param App\Services\PaymentService $service
     * @return \Illuminate\Http\Response
     */
    public function updatePaymentAccount(UpdatePaymentRequest $request, PaymentService $service){
        try{
            $response = $service->updatePaymentAccountService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
