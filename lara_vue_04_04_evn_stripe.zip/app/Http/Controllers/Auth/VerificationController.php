<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Services\AuthService;
use App\Http\Controllers\Controller;

class VerificationController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Email Verification Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling email verification for any
    | user that recently registered with the application. Emails may also
    | be re-sent if the user didn't receive the original email message.
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest');
    }

    /**
     * Login the user.
     *
     * @param  Illuminate\Http\Request $request
     * @param  AuthService $service
     * @return Illuminate\Http\Response
     */
    public function verify(Request $request, AuthService $service){

        try{
            $data = $request->only(['email', 'verification_otp']);
            $data['device_type'] = 'WEB';
            $data['device_id'] = 123456;
            $response = $service->verifyService($data);
            if($response->status == true){
                $response->data->account_status = "";
                $response->data->isServiceProvider = false;
                $request->session()->forget('auth_user');
                $request->session()->put('auth_user', $response->data);
            }
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=> $e->getMessage()
            ], 200);
        }
        
    }
}
