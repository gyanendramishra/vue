<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\PaymentService;

class BookingInvoicePaymentController extends Controller
{ 

    /**
     * Show the user bookings.
     *
     * @param Illuminate\Http\Request $request
     * @param string $slug
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request, $slug){
        $slug_array = explode('-', $slug);
        $bookingId = last($slug_array);
        return view('booking.invoice_payment', compact('bookingId'));
    }

    /**
     * Get the user booking.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\PaymentService $service
     * @return \Illuminate\Http\Response
     */
    public function makeInvoicePayment(Request $request, PaymentService $service){
        try{
            //{"stripeToken":"tok_1EIGCNL0oT4HG7neX1bq5Ew8","booking_id":"84"}
            $response = $service->makeInvoicePaymentService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }


    /**
     * Book the service.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\BookingService $service
     * @return \Illuminate\Http\Response
     */
    public function bookService(Request $request, BookingService $service){
        try{
            $response = $service->addBookingService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Book the service.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\BookingService $service
     * @return \Illuminate\Http\Response
     */
    public function changeBookingStatus(Request $request, BookingService $service){
        try{
            $response = $service->changeStatusService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
