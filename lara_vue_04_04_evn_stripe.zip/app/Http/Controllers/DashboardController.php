<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\DashboardService;

class DashboardController extends Controller
{ 

    /**
     * Show the user dashboard.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {
        $user = $request->session()->get('auth_user');
        $isServiceProvider = "false";
        if($user->isServiceProvider){
            $isServiceProvider = "true";
        }
        return view('dashboard.index', compact('isServiceProvider'));
    }

    /**
     * Get the user dashboard.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\DashboardService $service
     * @return \Illuminate\Http\Response
     */
    public function getDashboard(Request $request, DashboardService $service){
        try{
            $response = $service->getDashboardService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Switch account.
     *
     * @param  Request $request
     * @param  (string) $accountType
     * @return \Illuminate\Http\Response
     */
    public function switchAccountAs(Request $request, $accountType){
        $user = $request->session()->get('auth_user');
        if($accountType == 'service-provider'){
            $user->isServiceProvider = true;
        }else{
            $user->isServiceProvider = false;
        }
        $request->session()->forget('auth_user');
        $request->session()->put('auth_user', $user);
        return redirect()->back();
    }
}
