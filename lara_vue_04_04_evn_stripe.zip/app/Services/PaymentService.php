<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class PaymentService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/stripes/';

    /**
     * Add payment account detail.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function addPaymentAccountService($data) {
        $uri = $this->base_uri;
        $uri .= 'addAccount';
        return $this->postServiceRequest($uri, $data);
    }

    /**
     * Update payment account detail.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function updatePaymentAccountService($data) {
        $uri = $this->base_uri;
        $uri .= 'updateAccount';
        return $this->postServiceRequest($uri, $data);
    }

    /**
     * Make invoice payment.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function makeInvoicePaymentService($data) {
        $uri = $this->base_uri;
        $uri .= 'makePayment';
        return $this->postServiceRequest($uri, $data);
    }

}