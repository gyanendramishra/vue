<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class HomeService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/categories/';

    /**
     * Login the user.
     *
     * @param  array  $data
     * @return Illuminate\Http\Response
     */
    public function nearCategoryNServiceProviders(array $data) {

        $uri = $this->base_uri.'home';

        return $this->postServiceRequest($uri, $data);
    }

    

}