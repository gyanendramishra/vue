<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div class="field-required">
                    <p>Update your profile</p>
                </div>
                <form @submit.prevent="makePayment">
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                Name
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="Name" name="name" v-model="card.name" v-validate="'required|max:255'" data-vv-as="name">
                            <div v-if="errors.has('name')" class="text-danger">
                                {{ errors.first('name') }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                Email
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="Email" name="email" v-model="card.email" v-validate="'required|email|max:255'" data-vv-as="email" readonly>
                            <div v-if="errors.has('email')" class="text-danger">
                                {{ errors.first('email') }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                Mobile Number
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="Mobile Number" name="mobile" v-model="card.mobile" v-validate="'required|numeric|min:4|max:16'" data-vv-as="mobile">
                            <div v-if="errors.has('mobile')" class="text-danger">
                                {{ errors.first('mobile') }}
                            </div>
                        </div>
                    </div>
                    <div class="full-btn-col">
                        <input type="submit" value="Update" :disabled="errors.any()">
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
    import moment from "moment";
    import VeeValidate from 'vee-validate';
    import LoaderComponent from "../LoaderComponent.vue";
    Vue.use(VeeValidate);
    export default {
        name: "booking-invoice-payment-component",
        components:{
            LoaderComponent
        },
        props:["bookingId"],
        data: function () {
            return {
                loading: false,
                booking: {},
                card: {}
            }
        },
        created: function(){
            this.loading = true;
            this.getBooking();
        },
        filters: {
            formatDate : function(date){
                return moment(date, 'YYYY-MM-DD H:i:s').format('DD MMM YYYY h:mm a');
            },
            formatNumber(value) {
                return (value/1).toFixed(2);
            },
            prepareSlug (str, id) {
                if(!str) return "";
                return str.toLowerCase().replace(/ /g, '-')+"-"+id;
            }
        },
        methods: {
            getBooking() {
                var stripe = Stripe('pk_test_TYooMQauvdEDq54NiTphI7jx');
                console.log(stripe);
                return;
                this.loading = true;
                axios.post('/booking/get/data', {
                    id: this.bookingId
                }).then(response => {
                    if(response.data.status === true){
                        this.booking = response.data.data;
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            makePayment() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        axios.post('/booking/invoice/send', this.invoice).then(response => {
                                if(response.data.status === true){
                                    flash(response.data.message, 'success');
                                    window.location = '/booking/detail/'+this.booking.title.toLowerCase().replace(/ /g, '-')+"-"+this.booking.id; 
                                }else{
                                    if(response.data.error){
                                        var message =  response.data.error[0];
                                        flash(message.replace('_', ' '), 'error');
                                    }else{
                                        flash(response.data.message, 'error');
                                    }
                                }
                                this.loading = false;
                            }).catch(error => {
                                this.loading = false;
                                console.log(error);
                            });
                    }else{
                        this.loading = false;
                    }
                });
            }
        }
    }
</script>
