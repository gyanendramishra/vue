<template>
    <div class="formBox editProfileForm">
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div class="field-required">
                    <p>Update Payment Detail</p>
                </div>
                <form @submit.prevent="createUpdateAccount">
                    <div class="form-row">
                        <div class="form-group">
                            <label>
                                First Name
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="First Name" v-model="fields.first_name" v-validate="'required|max:255'" data-vv-as="first name" name="first_name">
                            <div v-if="errors.has('first_name')" class="text-danger">
                                {{ errors.first('first_name') }}
                            </div>
                        </div>
                        <div class="form-group">
                            <label>
                                Last Name
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="Last Name" v-model="fields.last_name" v-validate="'required|max:255'" data-vv-as="last name" name="last_name">
                            <div v-if="errors.has('last_name')" class="text-danger">
                                {{ errors.first('last_name') }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>
                                Date of birth (must be at least 18 year old)
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" ref="dob" placeholder="Date of birth" v-model="fields.dob" v-validate="'required|date_format:dd-mm-yyyy'" data-vv-as="dob" name="dob">
                            <div v-if="errors.has('dob')" class="text-danger">
                                {{ errors.first('dob') }}
                            </div>
                        </div>
                        <div class="form-group">
                            <label>
                                Address
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="Address" v-model="fields.address" v-validate="'required|max:255'" data-vv-as="address" name="address">
                            <div v-if="errors.has('address')" class="text-danger">
                                {{ errors.first('address') }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>
                                State
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="State" v-model="fields.state" v-validate="'required|max:255'" data-vv-as="state" name="state">
                            <div v-if="errors.has('state')" class="text-danger">
                                {{ errors.first('state') }}
                            </div>
                        </div>
                        <div class="form-group">
                            <label>
                                City
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="City" v-model="fields.city" v-validate="'required|max:255'" data-vv-as="city" name="city">
                            <div v-if="errors.has('city')" class="text-danger">
                                {{ errors.first('city') }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>
                                Postal Code
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="Postal Code" v-model="fields.postal_code" v-validate="'required|numeric|min:4|max:8'" data-vv-as="postal code" name="postal_code">
                            <div v-if="errors.has('postal_code')" class="text-danger">
                                {{ errors.first('postal_code') }}
                            </div>
                        </div>
                        <div class="form-group">
                            <label>
                                Account Holder Name
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="Account Holder Name" v-model="fields.account_holder_name" v-validate="'required|max:255'" data-vv-as="account holder name" name="account_holder_name">
                            <div v-if="errors.has('account_holder_name')" class="text-danger">
                                {{ errors.first('account_holder_name') }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>
                                Account Number
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="Account Number" v-model="fields.account_number" v-validate="'required|numeric|min:9|max:11'" data-vv-as="account number" name="account_number">
                            <div v-if="errors.has('account_number')" class="text-danger">
                                {{ errors.first('account_number') }}
                            </div>
                        </div>
                        <div class="form-group">
                            <label>
                                BSB Number
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="BSB Number" v-model="fields.sort_code" v-validate="'required|numeric|min:6|max:10'" data-vv-as="BSB number" name="sort_code">
                            <div v-if="errors.has('sort_code')" class="text-danger">
                                {{ errors.first('sort_code') }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>
                                Upload Document Front
                                <span class="red-color">*</span>
                            </label>
                            <input type="file" ref="document_front" v-validate="'image|ext:jpeg,jpg,png'" data-vv-as="document front" name="document_front" v-on:change="handleDocumentFront()">
                            <div v-if="errors.has('document_front')" class="text-danger">
                                {{ errors.first('document_front') }}
                            </div>
                        </div>
                        <div class="form-group">
                            <label>
                                Upload Document Back
                                <span class="red-color">*</span>
                            </label>
                            <input type="file" ref="document_back" v-validate="'image|ext:jpeg,jpg,png'" data-vv-as="document back" name="document_back" v-on:change="handleDocumentBack()">
                            <div v-if="errors.has('document_back')" class="text-danger">
                                {{ errors.first('document_back') }}
                            </div>
                        </div>
                    </div>
                    <div class="full-btn-col">
                        <div v-if="!loading">
                            <input type="submit" value="Submit" :disabled="errors.any()">
                        </div>
                        <div v-else>
                            <input type="submit" value="loading..." disable="disabled">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
    import "bootstrap-datepicker/dist/css/bootstrap-datepicker.css";
    import datepicker from "bootstrap-datepicker";
    import VeeValidate from 'vee-validate';
    Vue.use(VeeValidate);
    export default {
        name: "payment-component",
        data: function () {
            return {
                fields:{},
                loading: false,
            }
        },
        methods: {
            addAccount() {
                this.loading = true;
                axios.post('/payment/add/account', this.fields).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                    }else{
                        if(response.data.error){
                            var message =  response.data.error[0];
                            flash(message.replace('_', ' '), 'error');
                        }else{
                            flash(response.data.message, 'error');
                        }
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                });
            },
            createUpdateAccount() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        let formData = new FormData();
                        axios.post('/payment/update/account', formData).then(response => {
                            if(response.data.status === true){
                                flash(response.data.message, 'success');
                                window.location = "/dashboard"
                            }else{
                                if(response.data.error){
                                    var message =  response.data.error[0];
                                    flash(message.replace('_', ' '), 'error');
                                }else{
                                    flash(response.data.message, 'error');
                                }
                            }
                            this.loading = false;
                        }).catch(error => {
                            this.loading = false;
                        });
                    }else{
                            this.loading = false;
                        }
                });
            },
            handleDocumentFront() {
                this.fields.document_front = this.$refs.document_front.files[0];
            },
            handleDocumentBack() {
                this.fields.document_back = this.$refs.document_back.files[0];
            }
        },
        mounted(){
            var vm = this;
            Vue.nextTick(function(){
                $(vm.$refs.dob).datepicker({
                    format: "dd-mm-yyyy"
                }).on('changeDate', function(e) {
                    vm.fields.dob = e.format();
                }).on('changeMonth', function(e) {
                    vm.fields.dob = e.format();
                }).on('changeYear', function(e) {
                    vm.fields.dob = e.format();
                });
            }.bind(this));
        }
    }
</script>

