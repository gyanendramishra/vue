@extends('layouts.app')
@section('content')
<div class="topInnerBanner" style="background-image:url(/images/login_body_bg.jpg);">
	<div class="container">
	    <div class="topBannerMidCol">
	      	<h1>
	      		@yield('page_header_title')
	      	</h1>
	    </div>
	</div>
</div>
<div class="breadcrumb-sec">
  	<div class="container">
	    <ul>
	    	@yield('page_breadcrumb')
	    </ul>
  	</div>
</div>

<div class="mainWpapContainer">
	<section class="dashboard-page content-grey-bg">
	    <div class="container">
	      	<div class="row">
		        <div class="col-md-4 col-lg-3 col-xs-12 left-dash-bar">
			        <div class="left-profile-bar">
			            <div class="profileImg">
			              	<div class="profileImgInner">
			              		@if($authUser->profile_photo)
			              			<img src="{{ $authUser->profile_photo }}" alt="">
			              		@else
			              			<img src="/images/service_provider_03.jpg" alt="">
			              		@endif
			              	</div>
			              	<h5>{{ $authUser->name }}</h5>
			              	<div class="day-on-of-btn-sec">
				                <div class="onoffswitch">
					                <input type="checkbox" id="on-off-user" class="onoffswitch-checkbox" name="" value="1" checked="true">
					                <label class="onoffswitch-label" for="on-off-user">
					                	<span class="onoffswitch-inner"></span>
					                	<span class="onoffswitch-switch"></span>
					                </label>
				                </div>
				            </div>
			            </div>
			        
			            <ul class="myAccountMenu">
			              	<li class="{{ \Request::is('user/dashboard')?'active':'' }}">
			              		<a href="{{ route('user.dashboard') }}">
			              			<i class="fa fa-tachometer"></i> 
			              			Dashboard
			              		</a>
			              	</li>
			              	<li class="{{ \Request::is('my-profile')?'active':'' }}">
			              		<a href="{{ route('user.profile') }}">
			              			<i class="fa fa-user"></i> 
			              			My Profile
			              		</a>
			              	</li>
			              	<li class="{{ \Request::is('change-password')?'active':'' }}">
			              		<a href="{{ route('user.change.password') }}">
			              			<i class="fa fa-lock"></i> 
			              			Change Password
			              		</a>
			              	</li>
			              	@if($authUser->isServiceProvider)
			              		<li class="{{ \Request::is('operational-times')?'active':'' }}">
                                    <a href="{{ route('user.operational.times') }}">
                                    	<i class="fa fa-clock-o"></i>
                                        Operational Time
                                    </a>
                                </li>
                                <li class="{{ \Request::is('my-service')?'active':'' }}">
                                    <a href="{{ route('user.service') }}">
                                    	<i class="fa fa-plus"></i>
                                        My services
                                    </a>
                                </li>
                                <li class="{{ \Request::is('payment')?'active':'' }}">
                                    <a href="{{ route('user.payment') }}">
                                    	<i class="fa fa-money"></i>
                                        Payment
                                    	@if($authUser->account_status == "verified")
                                    		<i class="payment-varified"></i>
                                    	@endif
                                    </a>
                                </li>
                                <li>
                                    <a href="{{ route('user.switch.account', 'user') }}">
                                    	<i class="fa fa-toggle-on"></i>
                                        Switch to user
                                    </a>
                                </li>
                            @else
                                <li>
                                    <a href="{{ route('user.switch.account', 'service-provider') }}">
                                    	<i class="fa fa-toggle-on"></i>
                                        Switch to service provider
                                    </a>
                                </li>
                            @endif
			            </ul>
			        </div>
		        </div>
		        <div class="col-md-8 col-lg-9 col-xs-12 right-dash-bar">

		        	@yield('dashboard_content')
		          	
		        </div>
	      	</div>
	    </div>
	</section>
</div>
@if($authUser->isServiceProvider && !$authUser->is_complete)
	@if(!\Request::is('my-service') && !\Request::is('payment'))
		<service-provider-alert-component></service-provider-alert-component>
	@endif
@endif

@endsection
