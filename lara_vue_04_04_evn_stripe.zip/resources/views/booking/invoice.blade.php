@extends('layouts.dashboard')
@section('page_header_title', 'Invoice')
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
      	<a href="{{ route('user.booking') }}">
	      	Booking
	    </a>
    </li>
    <li>
        Invoice
    </li>
@endsection

@section('dashboard_content')
  	<booking-invoice-component :booking-id='{{ $bookingId }}'></booking-invoice-component>
@endsection

