@extends('layouts.dashboard')
@section('page_header_title')
	 Operational Times
@endsection
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        Operational times
    </li>
@endsection

@section('dashboard_content')
    <operational-time-component></operational-time-component>
@endsection

