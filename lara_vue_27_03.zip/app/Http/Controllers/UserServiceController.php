<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserServiceController extends Controller
{ 

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {}

    /**
     * Show the application user dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(){
    
        //return view('users.dashboard');
    }

    /**
     * Show the application user profile.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function createService(Request $request){
        $user = $request->session()->get('auth_user');
        if(!$user->isServiceProvider){
            $message = "You can't perform this actions. please switch your accout to as service provider.";
            return view('errors.500', compact('message'));
        }
        return view('users.services.add');
    }
}
