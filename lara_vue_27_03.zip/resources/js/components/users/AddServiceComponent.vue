<template>
    <div class="loginForm">
        <div class="field-required">
            <p>Please fill the detail given below</p>
        </div>
    
        <div class="login-form-row">
            <div class="form-group">
                <label>
                    Job Title 
                    <span class="red-color">*</span>
                </label>
                <div class="form-icon-col">
                    <i class="fa fa-user"></i> 
                    <input type="text" placeholder="Job Title" name="">
                </div>
            </div>
            <div class="form-group last-input">
                <label>
                    Select Service 
                    <span class="red-color">*</span>
                </label>
                <select>
                    <option>Select Service</option>
                    <option>Test01</option>
                    <option>Test02</option>
                    <option>Test03</option>
                    <option>Test04</option>
                </select>
            </div>
        </div>
        <div class="login-form-row">
            <div class="form-group">
                <label>
                    Select Service Category 
                    <span class="red-color">*</span>
                </label>
                <select>
                    <option>Select Service Category</option>
                    <option>Test01</option>
                    <option>Test02</option>
                    <option>Test03</option>
                    <option>Test04</option>
                </select>
            </div>
            <div class="form-group last-input">
                <AddressOnMapComponent></AddressOnMapComponent>
            </div>
        </div>
        <div class="login-form-row">
            <div class="form-group form-group-full">
                <label>
                    Min Ammount 
                    <span class="red-color">*</span>
                </label>
                <div class="form-icon-col">
                    <i class="fa fa-dollar"></i> 
                    <input type="text" placeholder="" name="">
                </div>
            </div>
        </div>
        <div class="login-form-row">
            <div class="form-group">
                <label>
                    Description 
                    <span class="red-color">*</span>
                </label>
                <textarea></textarea>
            </div>
            <div class="form-group">
                <label>
                    Choose Banner image 
                    <span class="red-color">*</span>
                </label>
                <input type="file" placeholder="" name="">
            </div>
        </div>
        <div class="full-btn-col">
            <input type="submit" value="Submit" name="">
        </div>
    </div>
</template>
<script>
    //require('bootstrap-datepicker/dist/js/bootstrap-datepicker.js');
    import AddressOnMapComponent from './../fields/AddressOnMapComponent.vue';
    export default {
        name: "add-service-component",
        components:{
            AddressOnMapComponent
        },
        data: function () {
            return {
                fields:{},
                country: 0,
                countries: '',
                state: 0,
                states: '',
                city: 0,
                cities: ''
            }
        },
        methods: {
           

        },

        mounted: function () {
            
        }
        
    }
</script>

