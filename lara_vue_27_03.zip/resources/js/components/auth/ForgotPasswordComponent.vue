<template>
    <div class="mainWpapContainer">
        <div class="login-sec">
            <div class="container">
                <div class="login-title">
                    <h1>
                        {{ title }} <span>Password</span>
                    </h1>
                </div>
                <div class="login-box">
                    <div class="row">
                        <div class="col-md-6 left-log-bar">
                            <div class="left-log">
                                <h2>Login with</h2>
                                <div class="or-icon">or</div>
                                <div class="login-social-icons">
                                    <a href="login/facebook">
                                        <img src="/images/fb_icon.png" alt="" />
                                    </a>
                                    <a href="login/google">
                                        <img src="/images/google_plus_icon.png" alt="" />
                                    </a>
                                </div>
                                <div class="login-left-bg">
                                    <img src="/images/login_laft_pannel_bg.png" alt="" />
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 right-log-bar">
                            <div class="loginForm">
                                <div v-if="title === 'Forgot'">
                                    <form @submit.prevent="sendPasswordResetOtp">
                                        <div class="form-group">
                                            <label>
                                                Email address 
                                                <span class="red-color">*</span>
                                            </label>
                                            <div class="form-icon-col">
                                                <i class="fa fa-envelope"></i> 
                                                <input type="text" placeholder="Email address" name="email" v-model="fields.email">
                                            </div>
                                            <div v-if="errors && errors.email" class="text-danger">
                                                {{ errors.email[0] }}
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div v-if="!loading">
                                                <input type="submit" value="Send Password Reset OTP" name="">
                                            </div>
                                            <div v-else>
                                                <input type="submit" value="loading..." disable="disabled">
                                            </div>
                                            <div class="forgotPassword">
                                                <a href="/login">Login?</a> 
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div v-else>
                                    <form @submit.prevent="resetPassword">
                                        <div class="form-group">
                                            <label>
                                                OTP 
                                                <span class="red-color">*</span>
                                            </label>
                                            <div class="form-icon-col">
                                                <i class="fa fa-envelope"></i> 
                                                <input type="text" placeholder="OTP" name="verification_code" v-model="fields.verification_code">
                                            </div>
                                            <div v-if="errors && errors.verification_code" class="text-danger">
                                                {{ errors.verification_code[0] }}
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>
                                                Password 
                                                <span class="red-color">*</span>
                                            </label>
                                            <div class="form-icon-col">
                                                <i class="fa fa-lock"></i> 
                                                <input type="password" placeholder="Password" name="password" v-model="fields.password">
                                            </div>
                                            <div v-if="errors && errors.password" class="text-danger">
                                                {{ errors.password[0] }}
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>
                                                Confirm Password 
                                                <span class="red-color">*</span>
                                            </label>
                                            <div class="form-icon-col">
                                                <i class="fa fa-lock"></i> 
                                                <input type="password" placeholder="Password" name="confirm_password" v-model="fields.confirm_password">
                                            </div>
                                            <div v-if="errors && errors.confirm_password" class="text-danger">
                                                {{ errors.confirm_password[0] }}
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div v-if="!loading">
                                                <input type="submit" value="Reset Password" name="">
                                            </div>
                                            <div v-else>
                                                <input type="submit" value="loading..." disable="disabled">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                title: "Forgot",
                loading : false,
                fields: {},
                errors: {},
            }
        },
        methods: {
            sendPasswordResetOtp() {
                this.loading = true;
                this.errors = {};
                axios.post('/password/email', this.fields).then(response => {
                    if(response.data.status === true){
                        this.title = "Reset";
                        flash(response.data.message, 'success');
                    }else{
                        flash(response.data.message, 'error');
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },

            resetPassword() {
                this.loading = true;
                this.errors = {};
                axios.post('/password/reset', this.fields).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                        window.location = '/login';
                    }else{
                        flash(response.data.message, 'error');
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },
        },
    }
</script>
