<template>
    <div>
        <label>
            Address 
            <span class="red-color">*</span>
        </label>
        <div class="form-icon-col">
            <i class="fa fa-map-marker"></i> 
            <input type="text" placeholder="Address" name="laddress" @click="populateModal" v-model="fields.address">
            <input type="hidden" placeholder="Address" name="latitude" v-model="fields.latitude">
            <input type="hidden" placeholder="Address" name="longitude"  v-model="fields.longitude" lazy>
        </div>
        <div class="modal address-field-map-model" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Select your address</h5>
                </div>
                <div class="modal-body" ref="address_field_google_map"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Use this location</button>
                </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    //require('bootstrap-datepicker/dist/js/bootstrap-datepicker.js');
    import GoogleMapsLoader from 'google-maps'
    GoogleMapsLoader.KEY = 'AIzaSyDViIP3wUAOLAGs1fWCak4PnQuGw4YnSZQ';
    export default {
        name: "address-with-google-map",
        data: function () {
            return {
                fields:{}
            }
        },
        methods: {
            populateModal() {
                $('.modal').modal('show');
            },

        },

        mounted: function () {
            var vm = this;
            vm.fields = {};
            GoogleMapsLoader.load(function(google) {
                let map = new google.maps.Map(vm.$refs.address_field_google_map, {
                zoom: 15,
                center: {
                        lat: 48.160910,
                        lng: 16.383330,
                    }
                });

                var marker = new google.maps.Marker(
                    {
                        position: {
                            lat: 48.160910,
                            lng: 16.383330,
                        }, 
                        map: map,
                        draggable:true
                    }
                );
                google.maps.event.addListener(
                    marker,
                    'dragend',
                    function() {
                        //if (status == google.maps.GeocoderStatus.OK) {
                            vm.fields.latitude = marker.position.lat().toFixed(6);
                            vm.fields.longitude = marker.position.lng().toFixed(6);
                            //vm.fields.address = results[0].formatted_address;
                        //}
                        console.log(vm.fields);
                    }
                );   
            });
        }
        
    }
</script>
<style scoped>
    .address-field-map-model .modal-body {
        width: 100%;
        height: 400px;
    }
</style>

