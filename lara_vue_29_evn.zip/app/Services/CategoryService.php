<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class CategoryService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/categories/';

    /**
     * Get the sub servic categories.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function getSubCategoryService($data) {
        $uri = $this->base_uri;
        $uri .= 'sublisting';

        return $this->postServiceRequest($uri, $data);
    }
}