@extends('layouts.dashboard')
@section('page_header_title')
	My <strong>Services</strong>
@endsection
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        My services
    </li>
@endsection
@section('dashboard_content')
    <my-service-component></my-service-component>
@endsection

