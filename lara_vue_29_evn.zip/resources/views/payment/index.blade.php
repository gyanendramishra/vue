@extends('layouts.dashboard')
@section('page_header_title')
	Payment
@endsection
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        payment
    </li>
@endsection

@section('dashboard_content')
  	<payment-component></payment-component>
@endsection

