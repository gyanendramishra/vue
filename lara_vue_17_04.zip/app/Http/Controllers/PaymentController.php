<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\PaymentService;

class PaymentController extends Controller
{ 


    /**
     * Show payment form.
     *
     * @param Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request){
        $user = $request->session()->get('auth_user');
        if(!$user->isServiceProvider){
            return redirect()->route('user.dashboard');
        }
        return view('payment.index');
    }


    /**
     * Get the user payment account.
     *
     * @param Illuminate\Http\Request
     * @param App\Services\PaymentService $service
     * @return \Illuminate\Http\Response
     */
    public function getPaymentAccount(Request $request, PaymentService $service){
        try{
            $response = $service->getAccountService();
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Update the user payment account.
     *
     * @param Illuminate\Http\Request
     * @param App\Services\PaymentService $service
     * @return \Illuminate\Http\Response
     */
    public function addUpdatePaymentAccount(Request $request, PaymentService $service){
        try{
        	$formUrlencodedHeader=['content-type' => 'application/x-www-form-urlencoded'];
            $formMultipartHeader = ['content-type' => 'multipart/form-data'];
            $data = [
                        [
                            'name'     => 'first_name',
                            'contents' => $request->first_name,
                            'headers'  => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'last_name',
                            'contents' => $request->last_name,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'dob',
                            'contents' => $request->dob,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'address',
                            'contents' => $request->address,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'state',
                            'contents' => $request->state,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'city',
                            'contents' => $request->city,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'postal_code',
                            'contents' => $request->postal_code,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'account_holder_name',
                            'contents' => $request->account_holder_name,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'account_number',
                            'contents' => $request->account_number,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'sort_code',
                            'contents' => $request->sort_code,
                            'headers' => $formUrlencodedHeader
                        ]
                    ];
            if($request->hasFile('document_front')){
                $file = $request->file('document_front');
                $data[] = [
                            'name' => 'document_front',
                            'filename' => $file->getClientOriginalName(),
                            'Mime-Type'=> $file->getmimeType(),
                            'contents' => fopen($file->getPathname(), 'r'),
                            'headers' => $formMultipartHeader
                        ];
            }
            if($request->hasFile('document_back')){
                $file = $request->file('document_back');
                $data[] = [
                            'name' => 'document_back',
                            'filename' => $file->getClientOriginalName(),
                            'Mime-Type'=> $file->getmimeType(),
                            'contents' => fopen($file->getPathname(), 'r'),
                            'headers' => $formMultipartHeader
                        ];
            }
            $response = $service->addUpdatePaymentAccountService($data);
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
