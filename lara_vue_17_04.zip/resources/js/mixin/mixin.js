export default {
    methods: {
        authorize: function (response) {
            let statusCode = response.data.code;
            if(statusCode === 401){
                window.location = "/logout";
                flash(response.data.message, "warning");
            }else{
            	if(response.data.error){
                    var message =  response.data.error[0];
                    flash(message.replace('_', ' '), 'error');
                }else{
                    flash(response.data.message, 'error');
                }
            }
        }
    }
}
