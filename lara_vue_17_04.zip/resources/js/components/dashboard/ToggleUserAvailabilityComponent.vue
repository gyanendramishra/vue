<template>
    <div class="day-on-of-btn-sec">
        <div class="onoffswitch">
            <input type="checkbox" id="on-off-user" class="onoffswitch-checkbox" v-model="user_availability" v-on:click="toggleAvailability">
            <label class="onoffswitch-label" for="on-off-user">
                <span class="onoffswitch-inner"></span>
                <span class="onoffswitch-switch"></span>
            </label>
        </div>
    </div>
</template>
<script>
    import mixin from '../../mixin/mixin.js';
    export default {
        name: "toggle-user-availability-component",
        mixins: [mixin],
        props: ["availability"],
        data: function () {
            return {
                user_availability: ""
            }
        },
        created(){
            this.user_availability = this.availability;
        },
        methods: {
            toggleAvailability() {
                this.loading = true;
                axios.post('/dashboard/toggle-availability', {
                    is_available : this.user_availability
                }).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                    }else{
                        this.authorize(response);
                    }
                }).catch(error => {
                    console.log(error);
                });
            }
        }
    }
</script>

