<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Services\AuthService;
use App\Http\Controllers\Controller;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest');
    }

    /**
     * Show the application password reset form.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(){
        return view('auth.passwords.email');
    }

    /**
     * Reset the user password.
     *
     * @param  Illuminate\Http\Request $request
     * @param  AuthService $service
     * @return Illuminate\Http\Response
     */
    public function sendResetPasswordEmail(Request $request, AuthService $service){
        try{
            $response = $service->forgotPasswordService($request->only('email'));
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=> $e->getMessage()
            ], 200);
        }
    }
}
