@extends('layouts.dashboard')
@section('page_header_title', 'Dashboard')
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        Dashboard
    </li>
@endsection

@section('dashboard_content')
	<div class="formBox editProfileForm">
    	<div class="formBoxInner">
      		<div class="dashbord-sec">
        		<div class="row">
          			<div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter">
            			<div class="infoItem"> 
            				<i class="infoIcon">
            					<img src="/images/booking_dashboard_icon.png">
            				</i>
              				<h3>Booking</h3>
              				<a class="btn btn-sm btn-white" href="{{ route('user.booking') }}">
              					View More
              				</a> 
              			</div>
          			</div>
       				<div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter">
            			<div class="infoItem"> 
            				<i class="infoIcon">
            					<img src="/images/services_dashboard_icon.png">
            				</i>
              				<h3>Services</h3>
                  			<a class="btn btn-sm btn-white" href="{{ route('user.service') }}">
                  				View More
                  			</a> 
                  		</div>
              		</div>
              		<div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter">
                		<div class="infoItem"> 
                			<i class="infoIcon">
                				<img src="/images/earning_dashboard_icon.png">
                			</i>
                  			<h3>Earning</h3>
                  			<a class="btn btn-sm btn-white" href="#">
                  				View More
                  			</a> 
                  		</div>
              		</div>
	                <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter">
	                    <div class="infoItem"> 
	                    	<i class="infoIcon">
	                    		<img src="/images/profile_dashboard_icon.png">
	                    	</i>
	                      	<h3>Profile</h3>
	                      	<a class="btn btn-sm btn-white" href="{{ route('user.profile') }}">
	                      		View More
	                      	</a> 
	                    </div>
	                </div>
	                <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter">
	                    <div class="infoItem"> 
	                    	<i class="infoIcon">
	                    		<img src="/images/setting_dashboard_icon.png">
	                    	</i>
	                      	<h3>Payment</h3>
	                      	<a class="btn btn-sm btn-white" href="{{ route('user.payment') }}">
	                      		View More
	                      	</a> 
	                    </div>
	                </div>
	                <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter">
	                    <div class="infoItem"> 
	                    	<i class="infoIcon">
	                    		<img src="/images/reviews_dashboard_icon.png">
	                    	</i>
	                      	<h3>Reviews</h3>
	                      	<a class="btn btn-sm btn-white" href="#">
	                      		View More
	                      	</a> 
	                    </div>
	                </div>
        		</div>
      		</div>
    	</div>
  	</div>
@endsection
