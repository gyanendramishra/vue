<template>
    <div>
        <div class="service-provider-sec global-slider-controls" v-if="near_by_users.length > 0">
            <div class="container">
                <div class="titleSec">
                    <h2>Near by Service Provider</h2>
                </div>
                <div id="service-provider-slider">
                    <div class="item" v-for="near_by_user in near_by_users">
                        <div class="ser-provider-col">
                            <div class="ser-provider-img-col">
                                <img :src="near_by_user.full_image_path" alt="" />
                                <div class="service-pro-name">
                                    <i class="fa fa-user"></i>
                                    <span>{{ near_by_user.name }}</span>
                                </div>
                                <div class="ser-provider-overlay">
                                    <div class="ser-provider-detail">
                                        <ul>
                                            <li><i class="fa fa-user"></i> {{ near_by_user.name }}</li>
                                            <li><i class="fa fa-briefcase"></i> {{ near_by_user.service_name }}</li>
                                            <li>
                                                <i class="fa fa-map-marker"></i> {{ near_by_user.address }}
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="border-btn-sec">
                    <a href="/service-providers" class="border-btn">View all Service Provider</a>
                </div>
            </div>
        </div>
        
        <div class="top-category-sec global-slider-controls" v-if="most_popular_categories.length > 0">
            <div class="container">
                <div class="titleSec">
                    <h2>Top Category</h2>
                </div>
                <div id="top-category-slider">
                    <div class="item" v-for="user in most_popular_categories[0].users">
                        <div class="top-category-col">
                            <div class="userCol">
                                <img :src="user.profile_photo" alt="" />
                                <h4>{{ user.name }}</h4>
                                <span>{{ user.service_name }}</span>
                                <div class="category-rating-col">
                                    <i class="fa fa-star"></i> {{ user.star_rate }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="border-btn-sec">
                    <a href="#" class="border-btn">View all</a>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import 'owl.carousel';
    export default {
        name: "near-service-providers-component",
        data() {
            return {
                categories: {},
                near_by_users: {},
                most_popular_categories: {},

            };
        },
        mounted: function(){
            var vm = this;
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    function (position) {
                        axios.post('/near-by-data', {latitude: position.coords.latitude, longitude: position.coords.longitude}).then(response => {
                            if(response.data.status === true){
                                var resData = response.data.data;
                                vm.categories = resData.categories;
                                vm.near_by_users = resData.near_by_users;
                                vm.most_popular_categories = resData.most_popular_categories;
                                Vue.nextTick(function(){
                                    
                                    this.initServiceProviderCarousel();
                                    this.initCategoryCarousel();
                                    
                                }.bind(vm));
                                
                            }else{
                                flash(response.data.message, 'danger');
                            }
                        }).catch(error => {
                            console.log(error);
                        });
                    },
                    function (error) {
                        flash(error.message, 'warning');
                    }, 
                    {
                        enableHighAccuracy: true
                        , timeout: 5000
                    }
                );
            } else {
                flash("Geolocation is not supported by this browser.", 'warning');
            }
        },
        methods: {
            initServiceProviderCarousel() {
                window.$("#service-provider-slider").owlCarousel({
                    loop:true,
                    margin:0,
                    nav:true,
                    dots:false,
                    autoplay:true,
                    responsive:{
                        0:{
                            items:1 
                        },
                        767:{
                            items:2
                        },
                        1024:{
                            items:3
                        },
                        1300:{
                            items:4
                        }
                        
                    }
                });
            },
            initCategoryCarousel() {
                window.$("#top-category-slider").owlCarousel({
                    loop:true,
                    margin:0,
                    nav:true,
                    dots:false,
                    autoplay:false,
                    center: true,
                    responsive:{
                        0:{
                            items:1 
                        },
                        767:{
                            items:1
                        },
                        1199:{
                            items:2
                        },
                        1200:{
                            items:3
                        },
                        1400:{
                            items:3
                        }
                        
                    }
                });
            }
        }
    };
</script>
