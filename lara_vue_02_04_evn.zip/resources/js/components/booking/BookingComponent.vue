<template>
    <div v-if="componentLoaded === true">
        <div class="formBox editProfileForm">
            <div class="formBoxInner">
                <div class="dashbord-sec">     
                    <div class="my-booking-sec">
                        <div class="booking-row">
                            <div class="booking-row-inner">
                                <h4>Lorem Ipsum is simply dummy text of the printing.</h4>     
                                <p>Lorem Ipsum is simply dummy text.</p>
                                <div class="booking-bottom-date-sec">
                                    <span class="booking-date-col">
                                        Tue, Jan 01.2018 8:15
                                    </span>
                                    <span class="booking-status-label awaiting">
                                        Awaiting
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="booking-row">
                            <div class="booking-row-inner">
                                <h4>Lorem Ipsum is simply dummy text of the printing.</h4>     
                                <p>Lorem Ipsum is simply dummy text.</p>
                                <div class="booking-bottom-date-sec">
                                    <span class="booking-date-col">
                                        Tue, Jan 01.2018 8:15
                                    </span>
                                    <span class="booking-status-label running">
                                        Running
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="booking-row">
                            <div class="booking-row-inner">
                                <h4>Lorem Ipsum is simply dummy text of the printing.</h4>     
                                <p>Lorem Ipsum is simply dummy text.</p>
                                <div class="booking-bottom-date-sec">
                                    <span class="booking-date-col">Tue, Jan 01.2018 8:15</span>
                                    <span class="booking-status-label accepted">Accepted</span>
                                </div>
                            </div>
                        </div>
                        <div class="booking-row">
                            <div class="booking-row-inner">
                                <h4>Lorem Ipsum is simply dummy text of the printing.</h4>     
                                <p>Lorem Ipsum is simply dummy text.</p>
                                <div class="booking-bottom-date-sec">
                                    <span class="booking-date-col">Tue, Jan 01.2018 8:15</span>
                                    <span class="booking-status-label awaiting">Awaiting</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div v-else>
        loading...
    </div>
</template>
<script>
    export default {
        name: "booking-component",
        props:["isServiceProvider"],
        data: function () {
            return {
                loading: false,
                bookings: {
                    page: 1,
                    provider_id : 1,
                    status: "awaiting"
                },
                componentLoaded:false
            }
        },
        beforeCreate: function(){
            this.componentLoaded = false;
        },
        created: function(){
            this.getBookings();
        },
        mounted : function() {
            this.componentLoaded = true;
            if(this.isServiceProvider === true){
                this.bookings.provider_id = 1;
            }else{
                this.bookings.provider_id = 2;
            }
        },
        methods: {
            getBookings() {

                axios.post('/booking/get', {
                    
                }).then(response => {
                    if(response.data.status === true){
                        this.operational_times = response.data.data;
                    }
                }).catch(error => {
                    console.log(error);
                });
            },
            updateOpeningTimes() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        axios.post('/operational-times/update', {
                            opening_days_data: this.operational_times
                        }).then(response => {
                            if(response.data.status === true){
                                this.operational_times = response.data.data;
                                flash(response.data.message, 'success');
                            }else{
                                if(response.data.error){
                                    var message =  response.data.error[0];
                                    flash(message.replace('_', ' '), 'error');
                                }else{
                                    flash(response.data.message, 'error');
                                }
                            }
                            this.loading = false;
                        }).catch(error => {
                            this.loading = false;
                            console.log(error);
                        });
                    }else{
                        this.loading = false;
                    }
                });
            }
        },
    }
</script>

