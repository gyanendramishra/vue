<footer class="footer">
    <div class="footer-top-sec">
        <div class="container">
            <div class="footer-logo">
                <a href="#Page-Top">
                    <img src="/images/logo.png" alt="logo" title="" />
                </a>
            </div>
            <div class="ft-menu clearfix">
                <ul>
                    <li><a href="">Home</a></li>
                    <li><a href="">About Us</a></li>
                    <li><a href="">Services</a></li>
                    <li><a href="">Faq’s</a></li>
                    <li><a href="">Contact Us</a></li>
                    <li><a href="">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="copyright-sec">
        <div class="container">
            <p>Copyright © 2018 CGS Group LCC. All Rights Reserved.</p>
            <div class="footer-social">
                <span>Social Connect:</span>
                <ul class="social-icon">
                    <li>
                        <a href=""><i class="fa fa-facebook-f"></i></a>
                    </li>
                    <li>
                        <a href=""><i class="fa fa-twitter"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>