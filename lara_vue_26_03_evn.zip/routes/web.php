<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

# Home route
Route::get('/', 'HomeController@index')->name('home');
Route::get('/about-us', 'AboutUsController')->name('about.us');
Route::get('/services', 'ServicesController')->name('services');
Route::get('/frequently-asked-questions', 'FaqController')->name('faq');
Route::get('/privacy-policy', 'PrivacyPolicyController')->name('privacy.policy');
Route::get('/terms-and-conditions', 'TermsAndConditionController')->name('terms.and.conditions');

Route::post('/near-by-data', 'HomeController@getNearByData')->name('near.by.data');
Route::get('/service-providers', 'ServiceProvidersController')->name('service.providers');


# Auth route group
Route::group(['as'=>'user.', 'namespace'=>'Auth'], function(){

	# Login form route
	Route::get('/login', 'LoginController@index')
		->name('login.form');

	# Register form route
	Route::get('/register', 'RegisterController@index')
		->name('register.form');

	# Register route
	Route::post('/register', 'RegisterController@register')
		->name('register');

	# Login route
	Route::post('/login', 'LoginController@login')
		->name('login');

	# Logout route
	Route::get('logout', 'LoginController@logout')
		->name('logout');

	# Forgot password form route
	Route::get('/password/reset', 'ForgotPasswordController@index')
		->name('password.request');

	# Forgot password reset mail route
	Route::post('/password/email', 'ForgotPasswordController@sendResetPasswordEmail')
		->name('password.email');

	# Reset password route
	Route::post('/password/reset', 'ResetPasswordController@resetPassword')
		->name('password.update');

	# Verify email route
	Route::post('/email/verify', 'VerificationController@verify')
		->name('verify.email');

	# Verify email route
	Route::post('/resend/otp', 'RegisterController@resendOtp')
		->name('resend.otp');

	# Social login

	Route::get('/login/{provider}', 'SocialiteController@redirectToProvider');
	Route::get('/login/{provider}/callback', 'SocialiteController@handleProviderCallback');

});

# After Auth route group
Route::group(['as'=>'user.', 'prefix'=>'user', 'middleware'=>'auth'], function(){

	# Dashboard route
	Route::get('/dashboard', 'DashboardController@index')
		->name('dashboard');

	# Switch account

	Route::get('/switch-account-to/{as}', 'DashboardController@switchAccountAs')
		->name('switch.account');

	# Profile route
	Route::get('/profile', 'DashboardController@profile')
		->name('profile');

	Route::get('service/add', 'UserServiceController@createService')
		->name('add.service');
});

Route::get('/clear-cache', function() {
    $exitCode = Artisan::call('cache:clear');
    $exitCode = Artisan::call('view:clear');
    $exitCode = Artisan::call('route:clear');
    $exitCode = Artisan::call('config:clear');
});

