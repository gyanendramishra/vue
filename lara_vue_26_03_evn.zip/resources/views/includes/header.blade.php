<div class="header">
    <div class="mainMenuWrap">
      	<div class="container">
	        <div class="mainMenuBar">
	            <nav class="nav" role="navigation">
		            <div class="wrapper-flush">
			            <button class="nav-toggle">
			                <span class="icon-menu">
			                  	<span class="line line-1"></span>
			                  	<span class="line line-2"></span>
			                  	<span class="line line-3"></span>
			                </span>
			            </button>
		              	<div class="logo">
			                <a href="">
			                  <img src="/images/logo.png" alt="logo" title="" />
			                </a>
		              	</div>
		                <div class="nav-container">
			                <ul class="nav-menu menu">
				                <li class="menu-item active">
				                    <a href="#" class="menu-link">about us</a>
				                </li>
				                <li class="menu-item">
				                    <a href="#" class="menu-link">Services</a>
				                </li>
				                <li class="menu-item">
				                    <a href="#" class="menu-link"> fAQ’S</a>
				                </li>
			                </ul>
			                <div class="top-right-login">
			                    <div class="languageBox">
				                    <div class="dropdown">
					                    <a
					                        href="#"
					                        data-toggle=""
					                        data-hover="dropdown"
					                        class="languageBtn"
					                        aria-expanded="true"
					                      >
					                        <img src="/images/language_icon.png" /> Us
					                        <i class="caret"></i>
					                    </a>
					                    <ul class="dropdown-menu">
					                        <li><a href="#">test</a></li>
					                        <li><a href="#">test</a></li>
					                        <li><a href="#">test</a></li>
					                    </ul>
				                    </div>
			                    </div>
				                <ul class="login-menu" v-else>
				                    <li>
					                    <a href="">
					                        <img src="/images/login_icon.png" /> Login
					                    </a>
				                    </li>
				                    <li>
					                    <a href="">
					                        <img src="/images/signup_icon.png" /> Signup
					                    </a>
				                    </li>
				                </ul>
			                </div>
		              	</div>
		            </div>
	            </nav>
	        </div>
      	</div>
    </div>
</div>