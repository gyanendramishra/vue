@extends('layouts.app')

@section('content')
    <forgot-password-component></forgot-password-component>
@endsection
