@extends('layouts.app')

@section('content')

<div class="topInnerBanner" style="background-image:url(/images/login_body_bg.jpg);">
	<div class="container">
	    <div class="topBannerMidCol">
	      	<h1>
	      		Dashboard
	      	</h1>
	    </div>
	</div>
</div>
<div class="breadcrumb-sec">
  	<div class="container">
	    <ul>
		    <li>
		      	<a href="{{ route('home') }}">
			      	Home
			    </a>
		    </li>
	        <li>
		        Dashboard
		    </li>
	    </ul>
  	</div>
</div>
<div class="mainWpapContainer">
	<div class="container">
		<h4>
			Welcome you are logged in successfully
		</h4>
	</div>
</div>

@if(!isset($authUser->isServiceProvider))
	<div class="login-type-step">
		<div class="login-type-step-inner">
		  	<h3>Switch account as</h3>
		  	<div class="login-type-btn-col">
				<a href="{{ route('user.switch.account', 'service-provider') }}">
					Service Provider
				</a>
				<a href="{{ route('user.switch.account', 'user') }}">
					User
				</a>
			</div>
		</div> 
	</div>
@endif

@endsection
