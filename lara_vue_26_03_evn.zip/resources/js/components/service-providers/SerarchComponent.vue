<template>
    <form method="post" action="/service-providers">
        <div class="booking-input-row">
            <div class="booking-input-col">
                <label>Search</label>
                <input type="text" placeholder="Enter your keyword" />
            </div>
            <div class="booking-input-col">
                <label>Category</label>
                <select>
                    <option>Select</option>
                    <option>Test</option>
                    <option>Test2</option>
                    <option>Test3</option>
                </select>
            </div>
            <div class="booking-input-col">
                <label>Sub Category</label>
                <select>
                    <option>Select</option>
                    <option>Test</option>
                    <option>Test2</option>
                    <option>Test3</option>
                </select>
            </div>
        </div>
        <div class="booking-input-row">
            <div class="booking-input-col calendar-col">
                <label>Availability</label>
                <input type="text" placeholder="Enter your keyword" />
            </div>
            <div class="booking-input-col">
                <label>Rating</label>
                <select>
                    <option>Select</option>
                    <option>Test</option>
                    <option>Test2</option>
                    <option>Test3</option>
                </select>
            </div>
            <div class="booking-input-col price-input-col">
                <label>Price</label>
                <input type="text" placeholder="Min" />
                <input type="text" placeholder="Max" />
            </div>
        </div>
        <button type="submit">
            <i class="fa fa-long-arrow-right"></i>
        </button>
    </form>
</template>
<script>
    export default {
        name: "search-service-provider-component",
        data():{
            return {
                loading : false,
                categories: {},
                subCategory: {},
                errors: {}
            }
        }
        mounted: function(){
            
        },
        methods: {
            getCategory() {
                this.errors = {};
                axios.get('/categories').then(response => {
                    if(response.data.status === true){
                        this.categories = response.data.data;
                    }else{
                        flash(response.data.message, 'danger');
                    }
                }).catch(error => {
                    this.errors= error;
                });
            }
        }
    };
</script>
