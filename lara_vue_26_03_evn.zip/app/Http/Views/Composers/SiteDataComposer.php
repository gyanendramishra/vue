<?php

namespace App\Http\Views\Composers;

use Illuminate\View\View;
use App\Services\CmsService;

class SiteDataComposer
{

    /**
     * The user.
     *
     * @var User
     */
    protected $service;

    /**
     * Create a new user composer.
     *
     * @return void
     */
    public function __construct(CmsService $service)
    {
        $this->service = $service;
    }
    /**
     * Bind data to the view.
     *
     * @param  View  $view
     * @return void
     */
    public function compose(View $view)
    {
        try{
            $data = $this->service->getAboutUs();
            $data = $data->ConfigSettings;
            $socialLinks = json_decode($data->SOCIAL_LINKS);
            $view->with([
                'authUser'=> \Session::get('auth_user'),
                'socialLinks'=> $socialLinks
            ]);
        }catch(\Exception $e){
        }
    }
}