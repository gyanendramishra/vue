<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Services\AuthService;
use App\Http\Controllers\Controller;
use App\Http\Requests\RegisterRequest;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest');
    }

    /**
     * Show the application register form.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(){
        return view('auth.register');
    }

    /**
     * Login the user.
     *
     * @param  RegisterRequest $request
     * @param  AuthService $service
     * @return Illuminate\Http\Response
     */
    public function register(RegisterRequest $request, AuthService $service){
        try{
            $file = $request->file('profile_photo_file');
            $data = [
                        [
                            'name'     => 'name',
                            'contents' => $request->name,
                            'headers'  => [
                                        'content-type' => 'application/x-www-form-urlencoded',
                                    ]
                        ],
                        [
                            'name' => 'email',
                            'contents' => $request->email,
                            'headers' => [
                                        'content-type' => 'application/x-www-form-urlencoded',
                                    ]
                        ],
                        [
                            'name' => 'password',
                            'contents' => $request->password,
                            'headers' => [
                                        'content-type' => 'application/x-www-form-urlencoded',
                                    ]
                        ],
                        [
                            'name' => 'confirm_password',
                            'contents' => $request->confirm_password,
                            'headers' => [
                                        'content-type' => 'application/x-www-form-urlencoded',
                                    ]
                        ],
                        [
                            'name' => 'mobile',
                            'contents' => $request->mobile,
                            'headers' => [
                                        'content-type' => 'application/x-www-form-urlencoded',
                                    ]
                        ],
                        [
                            'name' => 'profile_photo_file',
                            'filename' => $file->getClientOriginalName(),
                            'Mime-Type'=> $file->getmimeType(),
                            'contents' => fopen($file->getPathname(), 'r'),
                            'headers' => [
                                        'content-type' => 'multipart/form-data',
                                    ]
                        ]
                ];
            $response = $service->registerService($data);
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Resend verification otp to user.
     *
     * @param  RegisterRequest $request
     * @param  AuthService $service
     * @return Illuminate\Http\Response
     */
    public function resendOtp(Request $request, AuthService $service){
        try{
            $response = $service->resendVerificationOtpService($request->only('email'));
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>"Somthing went wrong try again later."
            ], 200);
        }
    }
}
