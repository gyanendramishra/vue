<?php

namespace App\Http\Controllers\Auth;

use Socialite;
use Illuminate\Http\Request;
use App\Services\AuthService;
use App\Http\Requests\LoginRequest;
use App\Http\Controllers\Controller;

class SocialiteController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {

        $this->middleware('guest');
    }

    /**
     * Redirect the user to the GitHub authentication page.
     *
     * @return \Illuminate\Http\Response
     */
    public function redirectToProvider($provider)
    {
        return Socialite::driver($provider)->redirect();
    }

    /**
     * Obtain the user information from GitHub.
     *
     * @return \Illuminate\Http\Response
     */
    public function handleProviderCallback(Request $request, $provider, AuthService $service)
    {
    	try{
    		$user = Socialite::driver($provider)->stateless()->user();
	        if($user){

	        	$data = [
	                'email' => $user->email,
	                'device_type' =>'Web',
	                'device_id' => 123456,
	                'social_uid' => $user->id,
	                'social_login' => $provider,
	            ];
                
	            $response = $service->socialLoginService($data);

	            if($response->status == true){
	                $request->session()->forget('auth_user');
	                $request->session()->put('auth_user', $response->data);
	                return redirect()->route('user.dashboard');
	            }else{

                    $message = $response->message;
                    return view('errors.500', compact('message'));
                }
	        }

	        $message = "Somthing went wrong try again later.";
            return view('errors.500', compact('message'));

    	}catch(\Exception $e){
    		$message = $e->getMessage();
            return view('errors.500', compact('message'));
    	}
    }
}
