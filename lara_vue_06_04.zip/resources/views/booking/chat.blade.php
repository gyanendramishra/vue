@extends('layouts.dashboard')
@section('page_header_title', 'Chat')
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
      	<a href="{{ route('user.booking') }}">
	      	Booking
	    </a>
    </li>
    <li>
        Chat
    </li>
@endsection

@section('dashboard_content')
  	<booking-chat-component :booking-id='{{ $bookingId }}'></booking-chat-component>
@endsection

