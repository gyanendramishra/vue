<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'On Demand') }} - @yield('title')</title>
    <meta name="description" content="@yield('description')">
    <meta name="keywords" content="@yield('keywords')">

    <!-- Styles -->
    <link rel="stylesheet" href="{{ asset('css/owl.carousel.css') }}" media="all">
    <link rel="stylesheet" href="{{ asset('css/owlcarouseltheme.css') }}" media="all">
    <link rel="stylesheet" href="{{ asset('css/animate.css') }}" media="all">
    <link rel="stylesheet" href="{{ asset('css/custom.css') }}" media="all"/>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}" media="all"/>
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<body>
    <div id="app">
        <div class="header">
            <div class="mainMenuWrap">
                <div class="container">
                    <div class="mainMenuBar">
                        <nav class="nav" role="navigation">
                            <div class="wrapper-flush">
                                <button class="nav-toggle">
                                    <span class="icon-menu">
                                        <span class="line line-1"></span>
                                        <span class="line line-2"></span>
                                        <span class="line line-3"></span>
                                    </span>
                                </button>
                                <div class="logo">
                                    <a href="{{ route('home') }}">
                                      <img src="{{ asset('images/logo.png') }}" alt="logo" title="" />
                                    </a>
                                </div>
                                @if(isset($authUser))
                                    <div class="user-menu-outer"> 
                                        <div class="dropdown user user-menu">
                                            <a aria-expanded="true" href="#" class="dropdown-toggle" data-toggle="dropdown">
                                                @if($authUser->profile_photo)
                                                    <img src="{{ $authUser->profile_photo }}" alt="" class="user-image">
                                                @else
                                                    <img src="/images/top_category_img01.jpg" alt="" class="user-image">
                                                @endif
                                                <span class="hidden-xs">
                                                    {{ $authUser->name }}
                                                </span>
                                                <i class="fa fa-angle-down"></i>
                                            </a>
                                            <ul class="dropdown-menu">
                                                <li>
                                                    <a href="{{ route('user.dashboard') }}">Dashboard</a>
                                                </li>
                                                <li>
                                                    <a href="{{ route('user.change.password') }}">Change password</a>
                                                </li>
                                                <li class="logout-menu">
                                                    <a href="{{ route('user.logout') }}">
                                                        Logout
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                @endif
                                <div class="nav-container">
                                    <ul class="nav-menu menu">
                                        <li class="menu-item {{ (\Request::is('about-us')) ? 'active': '' }}">
                                            <a href="{{ route('about.us') }}" class="menu-link">about us</a>
                                        </li>
                                        <li class="menu-item {{ (\Request::is('services')) ? 'active': '' }}">
                                            <a href="{{ route('services') }}" class="menu-link">Services</a>
                                        </li>
                                        <li class="menu-item {{ (\Request::is('faq')) ? 'active': '' }}">
                                            <a href="{{ route('faq') }}" class="menu-link"> fAQ’S</a>
                                        </li>
                                    </ul>
                                    @if(!isset($authUser))
                                        <div class="top-right-login">
                                            <ul class="login-menu">
                                                <li class="{{ (\Request::is('login')) ? 'active': '' }}">
                                                    <a href="{{ route('user.login.form') }}">
                                                        <img src="{{ asset('images/login_icon.png') }}" /> Login
                                                    </a>
                                                </li>
                                                <li class="{{ (\Request::is('register')) ? 'active': '' }}">
                                                    <a href="{{ route('user.register.form') }}">
                                                        <img src="{{ asset('images/signup_icon.png') }}" /> Register
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- Nav toggle component -->
            <custom-header-component></custom-header-component>
            <!-- -->
        </div>

        @yield('content')

        <footer class="footer">
            <div class="footer-top-sec">
                <div class="container">
                    <div class="footer-logo">
                        <a href="{{ route('home') }}">
                            <img src="{{ asset('images/logo.png') }}" alt="logo" title="" />
                        </a>
                    </div>
                    <div class="ft-menu clearfix">
                        <ul>
                            <li>
                                <a href="{{ route('home') }}">Home</a>
                            </li>
                            <li>
                                <a href="{{ route('about.us') }}">About Us</a>
                            </li>
                            <li>
                                <a href="{{ route('services') }}">Services</a>
                            </li>
                            <li>
                                <a href="{{ route('faq') }}">FAQ’s</a>
                            </li>
                            <li>
                                <a href="{{ route('contact.us') }}">Contact Us</a>
                            </li>
                            <li>
                                <a href="{{ route('privacy.policy') }}">Privacy Policy</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="copyright-sec">
                <div class="container">
                    <p>Copyright © {{ date('Y') }} CGS Group LCC. All Rights Reserved.</p>
                    <div class="footer-social">
                        <span>Social Connect:</span>
                        <ul class="social-icon">
                            @if(isset($socialLinks))
                                @foreach($socialLinks as $socialLink)
                                    <li>
                                        <a href="{{ $socialLink->url }}" title="{{ $socialLink->title }}" target="_blnak">
                                            <i class="{{ $socialLink->icon }}"></i>
                                        </a>
                                    </li>
                                @endforeach
                            @else
                                <li>
                                    <a href="https://www.facebook.com" target="_blnak">
                                        <i class="fa fa-facebook-f"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.twitter.com" target="_blnak">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                            @endif
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
        {{-- flash messages component --}}

        <flash-component></flash-component>

        {{-- end flash messages component --}}
    </div>
    <!-- Scripts -->
    <script src="https://js.stripe.com/v2/"></script>
    <script src="{{ asset('js/app.js') }}" defer></script>
</body>
</html>

