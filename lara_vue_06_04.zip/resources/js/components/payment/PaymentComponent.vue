<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div v-if="account.verification_status === 'verified'">
                    <div class="my-profile-sec">
                        <div class="my-profile-col">
                            <div class="my-profile-inner">
                                <div class="profile-detail-col">
                                    <ul>
                                        <li> 
                                            <span>First Name:</span> 
                                            <strong>{{ account.first_name }}</strong> 
                                        </li>
                                        <li> 
                                            <span>Last Name:</span> 
                                            <strong>{{ account.last_name }}</strong> 
                                        </li>
                                        <li> 
                                            <span>DOB:</span> 
                                            <strong>{{ account.dob }}</strong> 
                                        </li>
                                        <li> 
                                            <span>Address:</span> 
                                            <strong>{{ account.address }}</strong> 
                                        </li>
                                        <li> 
                                            <span>State:</span> 
                                            <strong>{{ account.state }}</strong> 
                                        </li>
                                        <li> 
                                            <span>City:</span> 
                                            <strong>{{ account.city }}</strong> 
                                        </li>
                                        <li> 
                                            <span>Postal Code:</span> 
                                            <strong>{{ account.postal_code }}</strong> 
                                        </li>
                                        <li> 
                                            <span>Account Holder Name:</span> 
                                            <strong>{{ account.account_holder_name }}</strong> 
                                        </li>
                                        <li> 
                                            <span>Account Number:</span> 
                                            <strong>{{ account.account_number }}</strong> 
                                        </li>
                                        <li> 
                                            <span>BSB Number:</span> 
                                            <strong>{{ account.sort_code }}</strong> 
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div v-else>
                    <div class="field-required">
                        <p>Update Payment Detail</p>
                        <p v-if="account.verification_status === 'unverified'">
                            {{ account.disabled_reason }}
                        </p>
                    </div>
                    <form @submit.prevent="createUpdateAccount">
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    First Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="First Name" v-model="account.first_name" v-validate="'required|max:255'" data-vv-as="first name" name="first_name">
                                <div v-if="errors.has('first_name')" class="text-danger">
                                    {{ errors.first('first_name') }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Last Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Last Name" v-model="account.last_name" v-validate="'required|max:255'" data-vv-as="last name" name="last_name">
                                <div v-if="errors.has('last_name')" class="text-danger">
                                    {{ errors.first('last_name') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Date of birth (must be at least 18 year old)
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" ref="dob" placeholder="Date of birth" v-model="account.dob" v-validate="'required|date_format:dd-mm-yyyy'" data-vv-as="dob" name="dob">
                                <div v-if="errors.has('dob')" class="text-danger">
                                    {{ errors.first('dob') }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Address
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Address" v-model="account.address" v-validate="'required|max:255'" data-vv-as="address" name="address">
                                <div v-if="errors.has('address')" class="text-danger">
                                    {{ errors.first('address') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    State
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="State" v-model="account.state" v-validate="'required|max:255'" data-vv-as="state" name="state">
                                <div v-if="errors.has('state')" class="text-danger">
                                    {{ errors.first('state') }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    City
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="City" v-model="account.city" v-validate="'required|max:255'" data-vv-as="city" name="city">
                                <div v-if="errors.has('city')" class="text-danger">
                                    {{ errors.first('city') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Postal Code
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Postal Code" v-model="account.postal_code" v-validate="'required|numeric|min:4|max:8'" data-vv-as="postal code" name="postal_code">
                                <div v-if="errors.has('postal_code')" class="text-danger">
                                    {{ errors.first('postal_code') }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Account Holder Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Account Holder Name" v-model="account.account_holder_name" v-validate="'required|max:255'" data-vv-as="account holder name" name="account_holder_name">
                                <div v-if="errors.has('account_holder_name')" class="text-danger">
                                    {{ errors.first('account_holder_name') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Account Number
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Account Number" v-model="account.account_number" v-validate="'required|numeric|min:9|max:11'" data-vv-as="account number" name="account_number">
                                <div v-if="errors.has('account_number')" class="text-danger">
                                    {{ errors.first('account_number') }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    BSB Number
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="BSB Number" v-model="account.sort_code" v-validate="'required|numeric|min:6|max:10'" data-vv-as="BSB number" name="sort_code">
                                <div v-if="errors.has('sort_code')" class="text-danger">
                                    {{ errors.first('sort_code') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row full-input-box">
                            <div class="form-group">
                                <label>Verification Documents*</label>
                                <p>
                                    <label>Acceptable ID's:</label>
                                    <small>Passport any government-issued ID, or driver's license</small>
                                </p>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Document - Front side
                                    <span class="red-color">*</span>
                                </label>
                                <input type="file" ref="document_front" v-validate="'image|ext:jpeg,jpg,png'" data-vv-as="document front" data-vv-name="document_front" v-on:change="handleDocumentFront()">
                                <div v-if="errors.has('document_front')" class="text-danger">
                                    {{ errors.first('document_front') }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Document - Back side
                                    <span class="red-color">*</span>
                                </label>
                                <input type="file" ref="document_back" v-validate="'image|ext:jpeg,jpg,png'" data-vv-as="document back" data-vv-name="document_back" v-on:change="handleDocumentBack()">
                                <div v-if="errors.has('document_back')" class="text-danger">
                                    {{ errors.first('document_back') }}
                                </div>
                            </div>
                        </div>
                        <div class="full-btn-col">
                            <input type="submit" value="Submit" :disabled="errors.any()">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import "bootstrap-datepicker/dist/css/bootstrap-datepicker.css";
    import LoaderComponent from "../LoaderComponent.vue";
    import datepicker from "bootstrap-datepicker";
    import VeeValidate from 'vee-validate';
    Vue.use(VeeValidate);
    export default {
        name: "payment-component",
        components:{
            LoaderComponent
        },
        data: function () {
            return {
                account: {
                    bank_account_id: "",
                    first_name: "",
                    last_name: "",
                    dob: "",
                    address: "",
                    state: "",
                    city: "",
                    postal_code: "",
                    account_holder_name: "",
                    account_number: "",
                    sort_code: "",
                    document_front: "",
                    document_back: "",
                    verification_status: "",
                    disabled_reason: "",
                },
                loading: false,
            }
        },
        created() {
            this.loading = true;
            this.getAccount();
        },
        mounted(){
            var vm = this;
            Vue.nextTick(function(){
                $(vm.$refs.dob).datepicker({
                    format: "dd-mm-yyyy",
                    autoclose: true
                }).on('changeDate', function(e) {
                    vm.account.dob = e.format();
                }).on('changeMonth', function(e) {
                    vm.account.dob = e.format();
                }).on('changeYear', function(e) {
                    vm.account.dob = e.format();
                });
            }.bind(this));
        },
        methods: {
            getAccount() {
                this.loading = true;
                axios.get('/payment/get/account').then(response => {
                    if(response.data.status === true){
                        this.account = response.data.data;
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                });
            },
            createUpdateAccount() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        let formData = new FormData();
                        formData.append('first_name', this.account.first_name);
                        formData.append('last_name', this.account.last_name);
                        formData.append('dob', this.account.dob);
                        formData.append('address', this.account.address);
                        formData.append('state', this.account.state);
                        formData.append('city', this.account.city);
                        formData.append('postal_code', this.account.postal_code);
                        formData.append('account_holder_name', this.account.account_holder_name);
                        formData.append('account_number', this.account.account_number);
                        formData.append('sort_code', this.account.sort_code);
                        if(this.account.document_front){
                            formData.append('document_front', this.account.document_front);
                        }
                        if(this.account.document_back){
                            formData.append('document_back', this.account.document_back);
                        }
                        axios.post('/payment/add-update/account', formData).then(response => {
                            if(response.data.status === true){
                                flash(response.data.message, 'success');
                                window.location = "/payment"
                            }else{
                                if(response.data.error){
                                    var message =  response.data.error[0];
                                    flash(message.replace('_', ' '), 'error');
                                }else{
                                    flash(response.data.message, 'error');
                                }
                            }
                            this.loading = false;
                        }).catch(error => {
                            this.loading = false;
                        });
                    }else{
                            this.loading = false;
                        }
                });
            },
            handleDocumentFront() {
                this.account.document_front = this.$refs.document_front.files[0];
            },
            handleDocumentBack() {
                this.account.document_back = this.$refs.document_back.files[0];
            }
        }
    }
</script>

