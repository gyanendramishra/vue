<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div v-if="isUpdated === true">
                    <div class="my-profile-sec">
                        <div class="my-profile-col">
                            <div class="my-profile-inner">
                                <div class="profile-detail-col">
                                    <ul>
                                        <li> 
                                            <span>Name:</span> 
                                            <strong>{{ profile.name }}</strong> 
                                        </li>
                                        <li> 
                                            <span>Email:</span> 
                                            <strong>{{ profile.email }}</strong> 
                                        </li>
                                        <li> 
                                            <span>Mobile:</span> 
                                            <strong>{{ profile.mobile }}</strong> 
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="default-btn-sec text-right">
                                <a href="javascript:;" class="btn-default btn-lg" @click="showformView()">EDIT PROFILE</a> 
                            </div>
                        </div>
                    </div>
                </div>
                <div v-else>
                    <div class="field-required">
                        <p>Update your profile</p>
                    </div>
                    <form @submit.prevent="updateProfile">
                        <div class="form-row full-input-box">
                            <div class="form-group">
                                <label>
                                    Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Name" name="name" v-model="profile.name" v-validate="'required|max:255'" data-vv-as="name">
                                <div v-if="errors.has('name')" class="text-danger">
                                    {{ errors.first('name') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row full-input-box">
                            <div class="form-group">
                                <label>
                                    Email
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Email" name="email" v-model="profile.email" v-validate="'required|email|max:255'" data-vv-as="email" readonly>
                                <div v-if="errors.has('email')" class="text-danger">
                                    {{ errors.first('email') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row full-input-box">
                            <div class="form-group">
                                <label>
                                    Mobile Number
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Mobile Number" name="mobile" v-model="profile.mobile" v-validate="'required|numeric|min:4|max:16'" data-vv-as="mobile">
                                <div v-if="errors.has('mobile')" class="text-danger">
                                    {{ errors.first('mobile') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row full0input-box">
                            <div class="form-group">
                                <label>Profile picture <span class="red-color">*</span></label>
                                <input type="file" placeholder="" name="profile_photo_file" ref="profile_photo_file" v-validate="'image|ext:jpeg,jpg,png'" data-vv-as="profile photo" v-on:change="handleFileUpload()">
                                <div v-if="errors.has('profile_photo_file')" class="text-danger">
                                    {{ errors.first('profile_photo_file') }}
                                </div>
                            </div>
                        </div>
                        <div class="full-btn-col">
                            <input type="submit" value="Update" :disabled="errors.any()">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import VeeValidate from 'vee-validate';
    import LoaderComponent from "../LoaderComponent.vue";
    Vue.use(VeeValidate);
    export default {
        name: "my-profile-component",
        components:{
            LoaderComponent
        },
        data: function () {
            return {
                profile:{
                    name: "",
                    email: "",
                    mobile: "",
                    profile_photo_file: "",
                },
                loading: false,
                isUpdated: true
            }
        },
        created: function(){
            this.getProfile();
        },
        methods: {
            getProfile() {
                this.loading = true;
                axios.get('/my-profile/get').then(response => {
                    if(response.data.status === true){
                        let userData = response.data.data;
                        this.profile.name = userData.name;
                        this.profile.email = userData.email;
                        this.profile.mobile = userData.mobile;
                        this.profile.profile_photo_file = userData.profile_photo_file;
                    }else{
                        flash(response.data.message, 'error');
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            updateProfile() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        let formData = new FormData();

                        formData.append('name', this.profile.name);
                        formData.append('email', this.profile.email);
                        formData.append('mobile', this.profile.mobile);
                        if(this.profile.profile_photo){
                            formData.append('profile_photo_file', this.profile.profile_photo);
                        }
                        axios.post('/my-profile/update', formData, {
                                headers:{
                                    'Content-Type': 'multipart/form-data'
                                }
                            }).then(response => {
                                if(response.data.status === true){
                                    this.isUpdated = true;
                                    flash(response.data.message, 'success');
                                }else{
                                    if(response.data.error){
                                        var message =  response.data.error[0];
                                        flash(message.replace('_', ' '), 'error');
                                    }else{
                                        flash(response.data.message, 'error');
                                    }
                                }
                                this.loading = false;
                            }).catch(error => {
                                this.loading = false;
                                console.log(error);
                            });
                    }else{
                        this.loading = false;
                    }
                });
            },
            handleFileUpload(){
                this.profile.profile_photo = this.$refs.profile_photo_file.files[0];
            },
            showformView() {
                this.isUpdated = false;
            }
        }
    }
</script>

