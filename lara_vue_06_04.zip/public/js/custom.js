
/************Main**Top*Menu******************************/


$(function() {
    var html = $('html, body'),
        navContainer = $('.nav-container'),
        navToggle = $('.nav-toggle'),
        navDropdownToggle = $('.has-dropdown');

    // Nav toggle
    navToggle.on('click', function(e) {
        var $this = $(this);
        e.preventDefault();
        $this.toggleClass('is-active');
        navContainer.toggleClass('is-visible');
        html.toggleClass('nav-open');
    });
  
    // Nav dropdown toggle
    navDropdownToggle.on('click', function() {
        var $this = $(this);
        $this.toggleClass('is-active').children('ul').toggleClass('is-visible');
    });
  
    // Prevent click events from firing on children of navDropdownToggle
    navDropdownToggle.on('click', '*', function(e) {
        e.stopPropagation();
    });
});


/*********************Section**************************/




/*******************************************/

/*******************************************/






$(function(){
$('.dropdown').hover(function() {
$(this).addClass('open');
$(this).find('.dropdown').stop(true, true).delay(0).fadeIn(0);
}, function() {
$(this).removeClass('open');
$(this).find('.dropdown').stop(true, true).delay(0).fadeOut(0);
});
});







$(document).ready(function() {
$('#service-provider-slider').owlCarousel({
    loop:true,
    margin:0,
    nav:true,
	dots:false,
	autoplay:true,
    responsive:{
        0:{
            items:1 
        },
        767:{
            items:2
        },
		1024:{
            items:3
        },
		1300:{
            items:4
        }
		
    }
})
});





$(document).ready(function() {
$('#top-category-slider').owlCarousel({
    loop:true,
    margin:0,
    nav:true,
	dots:false,
	autoplay:false,
	center: true,
    responsive:{
        0:{
            items:1 
        },
        767:{
            items:1
        },
		1199:{
            items:2
        },
		1200:{
            items:3
        },
		1400:{
            items:3
        }
		
    }
})
});
	




$(document).ready(function() {
$('#home-slider').owlCarousel({
    loop:true,
    margin:0,
    nav:true,
	dots:false,
	autoplay:true,
    responsive:{
        0:{
            items:1 
        },
        767:{
            items:1
        },
		1024:{
            items:1
        }
		
    }
})
});






	 
		  

// Enable the Tabs

$('#myTabs a').click(function (e) {
    e.preventDefault()
    $(this).tab('show')
  });

	 


/*$(function(){
$('.dropdown').hover(function() {
$(this).addClass('open');
$(this).find('.dropdown').stop(true, true).delay(0).fadeIn(0);
}, function() {
$(this).removeClass('open');
$(this).find('.dropdown').stop(true, true).delay(0).fadeOut(0);
});
});
*/






/*
  var affixElement = '.header';

$(affixElement).affix({
  offset: {
    // Distance of between element and top page
    top: function () {
      return (this.top = $(affixElement).offset().top)
    },
    // when start #footer 
    bottom: function () { 
      return (this.bottom = $('#footer').outerHeight(true))
    }
  }
});
*/

$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

    if (scroll >= 110) {
        $(".header").addClass("header-sticky");
    } else {
        $(".header").removeClass("header-sticky");
		
        
        
    }
});


  /*  $(".menu a").on('click', function(e) {
       // prevent default anchor click behavior
        e.preventDefault();
 
       $('html, body').animate({
           scrollTop: $(this.hash).offset().top
         }, 1000, function(){
            window.location.hash = this.hash;
         });

 });*/






/*$('#scrollbox3').enscroll({
    showOnHover: true,
    verticalTrackClass: 'track3',
    verticalHandleClass: 'handle3'
});
*/








/********Bootstrap**Modal****Start*************/	

$('#myModal').on('shown.bs.modal', function () {
  $('#myInput').trigger('focus')
})

/********Bootstrap**Modal***End**************/	



$(function () {
    var div = $('.topSearchBar');
    $('#searchBtn').click(function () {
        div.fadeToggle(200);
		css.width== 0;
    });
});
	 
	 
	 
	 /*******************************
* ACCORDION WITH TOGGLE ICONS
*******************************/
	function toggleIcon(e) {
        $(e.target)
            .prev('.panel-heading')
            .find(".more-less")
            .toggleClass('glyphicon-plus glyphicon-minus');
    }
    $('.panel-group').on('hidden.bs.collapse', toggleIcon);
    $('.panel-group').on('shown.bs.collapse', toggleIcon);

	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
$(function(){
$('.dropdown').hover(function() {
$(this).addClass('open');
$(this).find('.dropdown').stop(true, true).delay(0).fadeIn(0);
}, function() {
$(this).removeClass('open');
$(this).find('.dropdown').stop(true, true).delay(0).fadeOut(0);
});
});
	 
	 