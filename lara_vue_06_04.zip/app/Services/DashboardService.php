<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class DashboardService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/users/';

    /**
     * Get user dashboard.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function getDashboardService($data) {
        $uri = $this->base_uri;
        $uri .= 'dashboard';
        return $this->postServiceRequest($uri, $data);
    }

    /**
     * Toggle user availability.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function toggleAvailabilityService($data) {
        $uri = $this->base_uri;
        $uri .= 'setAvailablity';
        return $this->postServiceRequest($uri, $data);
    }

}