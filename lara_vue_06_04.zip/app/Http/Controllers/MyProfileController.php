<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\MyProfileService;

class MyProfileController extends Controller
{ 

    /**
     * Show the user profile.
     *
     * @param Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request){
    
        return view('my_profile.index');
    }

    /**
     * Get the user profile.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\MyProfileService $service
     * @return \Illuminate\Http\Response
     */
    public function getProfile(Request $request, MyProfileService $service){
        try{
            $response = $service->getProfileService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Update the user profile.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\MyProfileService $service
     * @return \Illuminate\Http\Response
     */
    public function updateProfile(Request $request, MyProfileService $service){
        try{
            $formUrlencodedHeader=['content-type' => 'application/x-www-form-urlencoded'];
            $formMultipartHeader = ['content-type' => 'multipart/form-data'];
            $data = [
                        [
                            'name'     => 'name',
                            'contents' => $request->name,
                            'headers'  => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'email',
                            'contents' => $request->email,
                            'headers' => $formUrlencodedHeader
                        ],
                        [
                            'name' => 'mobile',
                            'contents' => $request->mobile,
                            'headers' => $formUrlencodedHeader
                        ] 
                    ];
            if($request->has('profile_photo_file')){
                $file = $request->file('profile_photo_file');
                $data[] = [
                            'name' => 'profile_photo_file',
                            'filename' => $file->getClientOriginalName(),
                            'Mime-Type'=> $file->getmimeType(),
                            'contents' => fopen($file->getPathname(), 'r'),
                            'headers' => $formMultipartHeader
                        ];
            }
            
            $response = $service->updateProfileService($data);
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
