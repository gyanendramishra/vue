<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\CmsService;

class AboutUsController extends Controller
{
    /**
     * Show the about us.
     *
     * @param Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request, CmsService $service){
    	try{
    		$page = $service->getAboutUs();
        	return view('about-us', compact('page'));
    	}catch(\Exception $e){
    		$message = $e->getMessage();
            return view('errors.500', compact('message'));
    	}
    }

    /**
     * Get About us.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\CmsService $service
     * @return \Illuminate\Http\Response
     */
    public function getAboutUs(Request $request, CmsService $service){
        try{
            $response = $service->getAboutUs();
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
