<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class AuthService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/users/';

    /**
     * Login the user.
     *
     * @param  array  $data
     * @return Illuminate\Http\Response
     */
    public function loginService(array $data) {
        
        $uri = $this->base_uri;
        $uri .= 'login';
        return $this->postServiceRequest($uri, $data);
    }

    /**
     * Register the user.
     *
     * @param  array  $data
     * @return Illuminate\Http\Response
     */
    public function registerService(array $data) {
        
        $uri = $this->base_uri;
        $uri .= 'register';
        return $this->postServiceRequest($uri, $data);
    }

    /**
     * Verify the user.
     *
     * @param  array  $data
     * @return Illuminate\Http\Response
     */
    public function verifyService(array $data) {
        
        $uri = $this->base_uri;
        $uri .= 'verifyAccount';
        return $this->postServiceRequest($uri, $data);
    }

    /**
     * Send forgot password email the user.
     *
     * @param  array  $data
     * @return Illuminate\Http\Response
     */
    public function forgotPasswordService(array $data) {
        
        $uri = $this->base_uri;
        $uri .= 'forgot';
        return $this->postServiceRequest($uri, $data);
    }

    /**
     * Reset the user password.
     *
     * @param  array  $data
     * @return Illuminate\Http\Response
     */
    public function resetPasswordService(array $data) {
        
        $uri = $this->base_uri;
        $uri .= 'reset_password';
        return $this->postServiceRequest($uri, $data);
    }

    

}