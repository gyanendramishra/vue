<?php /* D:\xampp\htdocs\ondemand\resources\views/welcome.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="flex-center position-ref full-height">
    <div class="container">
        <div class="card">
            <div class="card-header">Laravel</div>
            <div class="card-body">
                <a class="col" href="https://laravel.com/docs">Docs</a>
                <a class="col" href="https://laracasts.com">Laracasts</a>
                <a class="col" href="https://laravel-news.com">News</a>
                <a class="col" href="https://blog.laravel.com">Blog</a>
                <a class="col" href="https://nova.laravel.com">Nova</a>
                <a class="col" href="https://forge.laravel.com">Forge</a>
                <a class="col" href="https://github.com/laravel/laravel">GitHub</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>