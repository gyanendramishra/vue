<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class ComplaintService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/complains/';

    /**
     * Add payment account detail.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function addComplaintService($data) {
        $uri = $this->base_uri;
        $uri .= 'add';
        return $this->postServiceRequest($uri, $data);
    }

}