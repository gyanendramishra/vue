<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BookingChatController extends Controller
{ 

    /**
     * Show the user booking review form.
     *
     * @param Illuminate\Http\Request $request
     * @param string $slug
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request, $slug){
        $slug_array = explode('-', $slug);
        $bookingId = last($slug_array);
        return view('booking.chat', compact('bookingId'));
    }

    
}
