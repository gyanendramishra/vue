<template>
    <div class="loader-container" v-if="loading === true">
        <div class="loader-inner">
            <div class="loader-relative">
                <div class="loader"></div>
                <div id="loader-text">
                    <img src="/images/loder_logo.png" width="40">
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        name: "loader-component",
        props:["loading"]
    };
</script>
