<template>
    <div class="login-type-step" ref="login_type_step">
        <div class="login-type-step-inner">
            <h3>Alert</h3>
            <p>Please complete your service detail to continue</p>
            <div class="login-type-btn-col">
                <a href="javascript:;" @click="hideAlert">
                    cancel
                </a>
                <a href="/my-service">
                    proceed
                </a>
            </div>
        </div> 
    </div>
</template>
<script>
    export default {
        name: "service-provider-alert-component",
        created: function(){
            this.showAlert();
        },
        methods: {
            hideAlert() {
                $(this.$refs.login_type_step).hide();
            },
            showAlert() {
                $(this.$refs.login_type_step).show();
            },
        }
    }
</script>

