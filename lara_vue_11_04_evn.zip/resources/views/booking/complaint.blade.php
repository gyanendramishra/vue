@extends('layouts.dashboard')
@section('page_header_title', 'Booking Complaint')
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
      	<a href="{{ route('user.booking') }}">
	      	Booking
	    </a>
    </li>
    <li>
        Complaint
    </li>
@endsection

@section('dashboard_content')
  	<booking-complaint-component :booking-id='{{ $bookingId }}'></booking-complaint-component>
@endsection

