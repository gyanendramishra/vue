@extends('layouts.dashboard')
@section('page_header_title', 'My Reviews')
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        My reviews
    </li>
@endsection

@section('dashboard_content')
  	<my-review-component></my-review-component>
@endsection

