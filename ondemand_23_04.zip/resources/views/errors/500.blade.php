@extends('layouts.app')

@section('content')

<div class="topInnerBanner" style="background-image:url(/images/login_body_bg.jpg);">
	<div class="container">
	    <div class="topBannerMidCol">
	      	<h1>
	      		500 Error
	      	</h1>
	    </div>
	</div>
</div>
<div class="breadcrumb-sec">
  	<div class="container">
	    <ul>
		    <li>
		      	<a href="{{ route('home') }}">
			      	Home
			    </a>
		    </li>
	        <li>
		        500
		    </li>
	    </ul>
  	</div>
</div>
<div class="mainWpapContainer">
	<section class="default-contant-page content-grey-bg padding-T-B-30">
	    <div class="container">
			<div class="notfound">
				<div class="notfound-404">
					<h3>500 - INTERNAL SERVER ERROR</h3>
					<h2>5<span class="o-text">0</span>0</h2>
				</div>
				<p>we are sorry, but request could not be processed due to below resons</p>
				<p>{{ $message }}</p>
	            <div class="btn-sec">
	            	<a href="{{ route('home') }}" class="border-btn">Back To Home</a>
	            </div>
			</div>
	  	</div>
	</section>
</div>

@endsection
