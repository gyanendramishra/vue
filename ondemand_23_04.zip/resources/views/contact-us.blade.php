@extends('layouts.app')

@section('title', "contact us")
@section('description', "contact us")
@section('keywords', "contact us")

@section('content')
<div class="topInnerBanner" style="background-image:url(/images/inner_page_banner.jpg);">
	<div class="container">
	    <div class="topBannerMidCol">
	      	<h1>
	      		Contact Us
	      	</h1>
	    </div>
	</div>
</div>
<div class="breadcrumb-sec">
  	<div class="container">
	    <ul>
		    <li>
		      	<a href="{{ route('home') }}">
			      	Home
			    </a>
		    </li>
	        <li>
		        Contact Us
		    </li>
	    </ul>
  	</div>
</div>
<div class="mainWpapContainer">
	<contact-us-component><contact-us-component>
</div>
@endsection
