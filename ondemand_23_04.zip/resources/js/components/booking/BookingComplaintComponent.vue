<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div class="my-booking-sec my-booking-detail">
                    <h3>{{ booking.title }}</h3>
                    <form @submit.prevent="addComplaint">
                        <div class="form-row full-input-box">
                            <div class="form-group">
                                <label>
                                    Title
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Title" v-model="complaint.title" v-validate="'required|max:255'" data-vv-name="title" data-vv-as="title">
                                <div v-if="errors.has('title')" class="text-danger">
                                    {{ errors.first('title') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row full-input-box">
                            <div class="form-group">
                                <label>
                                    Complaint Detail
                                    <span class="red-color">*</span>
                                </label>
                                <textarea placeholder="Complaint Detail" v-model="complaint.reason" v-validate="'required'" data-vv-name="reason" data-vv-as="complaint detail"></textarea>
                                <div v-if="errors.has('reason')" class="text-danger">
                                    {{ errors.first('reason') }}
                                </div>
                            </div>
                        </div>
                        <div class="full-btn-col">
                            <input type="submit" value="Submit" :disabled="errors.any()">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import moment from "moment";
    import mixin from '../../mixin/mixin.js';
    import VeeValidate from 'vee-validate';
    import LoaderComponent from "../LoaderComponent.vue";
    Vue.use(VeeValidate);
    export default {
        name: "booking-complaint-component",
        components:{
            LoaderComponent
        },
        mixins: [mixin],
        props:["bookingId"],
        data: function () {
            return {
                loading: false,
                booking: {},
                complaint: {
                    booking_id: "",
                    title: "",
                    reason: ""
                }
            }
        },
        created: function(){
            this.loading = true;
            this.getBooking();
        },
        filters: {
            prepareSlug (str, uri, id) {
                if(!str) return "";
                str = str.toLowerCase();
                str = str.replace(/[^a-zA-Z0-9]/g, '-');
                str = str.replace(/[-]+/g, '-');
                return uri+"/"+str+"-"+id;
            }
        },
        methods: {
            getBooking() {
                this.loading = true;
                axios.post('/booking/get/data', {
                    id: this.bookingId
                }).then(response => {
                    if(response.data.status === true){
                        this.booking = response.data.data;
                        this.complaint.booking_id = this.booking.id;
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            addComplaint() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        axios.post('/booking/complaint/add', this.complaint).then(response => {
                                if(response.data.status === true){
                                    flash(response.data.message, 'success');
                                    window.location = '/booking/detail/'+this.booking.title.toLowerCase().replace(/ /g, '-')+"-"+this.booking.id; 
                                }else{
                                    this.authorize(response);
                                }
                                this.loading = false;
                            }).catch(error => {
                                this.loading = false;
                                console.log(error);
                            });
                    }else{
                        this.loading = false;
                    }
                });
            }
        }
    }
</script>
