<template>
    <div>
        <loader-component :loading="loading"></loader-component>
        <div class="formBox editProfileForm">
            <div class="formBoxInner">
                <div class="dashbord-sec">
                    <div class="uploaded-img-banner" v-if="service.full_image_path">
                        <img :src="service.full_image_path" alt="">
                    </div>
                    <form @submit.prevent="addService">
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Job Title 
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Job Title" name="title" v-model="service.title" v-validate="'required|max:255'" data-vv-as="title">
                                <div v-if="errors.has('title')" class="text-danger">
                                    {{ errors.first('title') }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Select Service 
                                    <span class="red-color">*</span>
                                </label>
                                <select name="parent_service_id" v-model="service.parent_id" v-on:change="getSubCategories()" v-validate="'required'" data-vv-as="service">
                                    <option disabled value="">Select Service</option>
                                    <option v-for="parentCategory in parentCategories" :value="parentCategory.id">{{ parentCategory.title }}</option>
                                </select>
                                <div v-if="errors.has('parent_service_id')" class="text-danger">
                                    {{ errors.first('parent_service_id') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Select Service Category 
                                    <span class="red-color">*</span>
                                </label>
                                <select name="category_id" v-model="service.category_id" v-validate="'required'" data-vv-as="service category">
                                    <option disabled value="">Select Service Category</option>
                                    <option v-for="subCategory in SubCategories" :value="subCategory.id">{{ subCategory.title }}</option>
                                </select>
                                <div v-if="errors.has('category_id')" class="text-danger">
                                    {{ errors.first('category_id') }}
                                </div>
                            </div>
                            <div class="form-group last-input">
                                <label>
                                    Address 
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Address" name="address" ref="address" @click="populateModal" v-model="service.address" v-validate="'required'" data-vv-as="address">
                                <input type="hidden" placeholder="Address" name="latitude" v-model="service.latitude">
                                <input type="hidden" placeholder="Address" name="longitude"  v-model="service.longitude" lazy>
                                <div v-if="errors.has('address')" class="text-danger">
                                    {{ errors.first('address') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Min Amount ($)
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" name="price" placeholder="" v-model="service.price" v-validate="'required|numeric|max:8'" data-vv-as="min amount">
                                <div v-if="errors.has('price')" class="text-danger">
                                    {{ errors.first('price') }}
                                </div>
                            </div>
                            <div class="form-group" v-if="service.full_image_path">
                                <label>Choose Banner image </label>
                                <input type="file" placeholder="" ref="image_file" v-validate="'image|ext:jpeg,jpg,png'" data-vv-name="image_file" data-vv-as="banner image" v-on:change="handleFileUpload()" key="image_file">
                                <div v-if="errors.has('image_file')" class="text-danger">
                                    {{ errors.first('image_file') }}
                                </div>
                            </div>
                            <div class="form-group" v-else>
                                <label>Choose Banner image <span class="red-color">*</span></label>
                                <input type="file" placeholder="" ref="image_file" v-validate="'required|image|ext:jpeg,jpg,png'" data-vv-name="image_file" data-vv-as="banner image" v-on:change="handleFileUpload()" key="image_file">
                                <div v-if="errors.has('image_file')" class="text-danger">
                                    {{ errors.first('image_file') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row full-input-box">
                            <div class="form-group">
                                <label>
                                    Description 
                                    <span class="red-color">*</span>
                                </label>
                                <textarea name="description" v-model="service.description" v-validate="'required'" data-vv-as="description"></textarea>
                                <div v-if="errors.has('description')" class="text-danger">
                                    {{ errors.first('description') }}
                                </div>
                            </div>
                        </div>
                        <div class="full-btn-col">
                            <input type="submit" value="Submit" :disabled="errors.any()">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal my-popup address-field-map-model" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Type your address here</h4>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Type your address here" name="map_address" v-model="map.address" id="map_address">
                        </div>
                    </div>
                    <div class="modal-body" ref="address_field_google_map"></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Use this location</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import GoogleMapsLoader from 'google-maps'
    import VeeValidate from 'vee-validate';
    import mixin from '../../mixin/mixin.js';
    import LoaderComponent from "../LoaderComponent.vue";
    GoogleMapsLoader.KEY = 'AIzaSyDViIP3wUAOLAGs1fWCak4PnQuGw4YnSZQ';
    GoogleMapsLoader.LIBRARIES = ['geometry', 'places'];
    Vue.use(VeeValidate);
    export default {
        name: "my-service-component",
        mixins: [mixin],
        components:{
            LoaderComponent
        },
        props:['isAccountVerified'],
        data: function () {
            return {
                service:{},
                loading: false,
                parentCategories: {},
                SubCategories: {},
                map:{
                    geocoder:"",
                    infowindow:"",
                    myLatlng:"",
                    marker:"",
                    map:"",
                    address:""
                }
            }
        },
        methods: {
            addService() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        let formData = new FormData();
                        if(this.service.id){
                            formData.append('id', this.service.id);
                        }
                        formData.append('title', this.service.title);
                        formData.append('parent_service_id', this.service.parent_id);
                        formData.append('category_id', this.service.category_id);
                        formData.append('address', this.service.address);
                        formData.append('latitude', this.service.latitude);
                        formData.append('longitude', this.service.longitude);
                        formData.append('price', this.service.price);
                        formData.append('description', this.service.description);
                        if(this.service.image_file){
                            formData.append('image_file', this.service.image_file);
                        }

                        axios.post('/my-service/add-update', formData, {
                            headers:{
                                'Content-Type': 'multipart/form-data'
                            }
                        }).then(response => {
                            if(response.data.status === true){
                                flash(response.data.message, 'success');
                                if(this.isAccountVerified === false){
                                    window.location = '/payment';
                                }else{
                                    window.location = '/my-service';
                                }
                            }else{
                                this.authorize(response);
                            }
                            this.loading = false;
                        }).catch(error => {
                            this.loading = false;
                            console.log(error);
                        });
                    }else{
                        this.loading = false;
                    }
                });
            },
            getMyService() {
                this.loading = true;
                axios.get('/my-service/get').then(response => {
                    if(response.data.status === true){
                        let data = response.data.data;
                        if(data.title){
                            this.service = data;
                            this.initMap();
                        }
                        this.parentCategories = data.main_category;
                        this.SubCategories = data.sub_category;
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },

            getSubCategories() {
                this.loading = true;
                axios.post('/listing/get-sub-categories', {parent_id: this.service.parent_id}).then(response => {
                    if(response.data.status === true){
                        this.SubCategories = response.data.data.categories;
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },

            /*
                Handles a change on the file upload
            */
            handleFileUpload(){
                this.service.image_file = this.$refs.image_file.files[0];
            },

            populateModal() {
                $('.modal').modal('show');
            },
            initMap() {
                var vm = this;
                GoogleMapsLoader.load(function(google) {
                    vm.map.geocoder = new google.maps.Geocoder();
                    vm.map.infowindow = new google.maps.InfoWindow();
                    vm.map.myLatlng = new google.maps.LatLng(-25.734968, 134.489563);
                    if(vm.service.latitude && vm.service.longitude){
                        vm.map.myLatlng = new google.maps.LatLng(vm.service.latitude, vm.service.longitude); 
                    }
                    vm.map.map = new google.maps.Map(vm.$refs.address_field_google_map, {
                        zoom: 15,
                        center: vm.map.myLatlng,
                        mapTypeId: google.maps.MapTypeId.ROADMAP
                    });

                    vm.map.marker = new google.maps.Marker(
                        {
                            position: vm.map.myLatlng,
                            map: vm.map.map,
                            draggable:true
                        }
                    );
                    var autocomplete = new google.maps.places.Autocomplete(document.getElementById('map_address'));
                    autocomplete.bindTo('bounds', vm.map.map);

                    autocomplete.addListener('place_changed', function() {
                        vm.map.infowindow.close();
                        vm.map.marker.setVisible(false);
                        var place = autocomplete.getPlace();
                        // If the place has a geometry, then present it on a map.
                        if (place.geometry.viewport) {
                            vm.map.map.fitBounds(place.geometry.viewport);
                        } else {
                            vm.map.map.setCenter(place.geometry.location);
                            vm.map.map.setZoom(17); 
                        }
                        vm.map.marker.setPosition(place.geometry.location);
                        vm.map.marker.setVisible(true);
                        var address = '';
                        if (place.address_components) {
                            address = [
                            (place.address_components[0] && place.address_components[0].short_name || ''),
                            (place.address_components[1] && place.address_components[1].short_name || ''),
                            (place.address_components[2] && place.address_components[2].short_name || '')
                            ].join(' ');
                        }
                        vm.service.latitude = vm.map.marker.position.lat().toFixed(6);
                        vm.service.longitude = vm.map.marker.position.lng().toFixed(6);
                        vm.service.address = address;
                        vm.map.address = address;
                        vm.$refs.address.value = address;

                        vm.map.infowindow.open(vm.map.map, vm.map.marker);
                    });
                    
                    google.maps.event.addListener(
                        vm.map.marker,
                        'dragend',
                        function() {
                            vm.map.geocoder.geocode({'latLng': vm.map.marker.getPosition()}, function(results, status) {
                                if (status == google.maps.GeocoderStatus.OK) {
                                    if (results[0]) {
                                        vm.service.latitude = vm.map.marker.position.lat().toFixed(6);
                                        vm.service.longitude = vm.map.marker.position.lng().toFixed(6);
                                        vm.service.address = results[0].formatted_address;
                                        vm.$refs.address.value = results[0].formatted_address;
                                        vm.map.infowindow.setContent(results[0].formatted_address);
                                        vm.map.infowindow.open(vm.map.map, vm.map.marker);
                                    }
                                }
                            });
                    }); 
                });
            }

        },
        beforeMount () {
            this.service = {
                title: "",
                parent_id: "",
                category_id: "",
                address: "",
                latitude: "",
                longitude: "",
                price: "",
                image_file: "",
                description: "",
            };
        },
        created() {
            this.getMyService();
        },
        mounted: function () {
            this.initMap();
        }
        
    }
</script>
<style scoped>
    .address-field-map-model .modal-body {
        width: 100%;
        height: 300px;
    }
    
</style>

