<template>
    <div class="contactPage">
        <loader-component :loading="loading"></loader-component>
		<div class="callButtonCol">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
			            <div class="contact-info-col">
							<span class="contact-icon">
								<img src="/images/location_icon.png">
							</span>
						    <h2>Our Location</h2>
							<div class="contact-byline">
								{{ settings.ADDRESS }} 
							</div>
						</div>
					</div>
					<div class="col-md-4">
					    <div class="contact-info-col">
							<span class="contact-icon">
								<img src="/images/phone_icon.png">
							</span>
					        <h2>Contact us Anytime</h2>
							<div class="contact-byline">
								<a href="'tel:+'+settings.TELEPHONE">+{{ settings.TELEPHONE }} </a>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="contact-info-col">
							<span class="contact-icon">
								<img src="images/envelope_icon.png">
							</span>
						    <h2>Write Some Words</h2>
							<div class="contact-byline">
								<a :href="'mailto:'+settings.ADMIN_EMAIL">{{ settings.ADMIN_EMAIL }} </a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="contactFormOuter">
			<div class="container">
				<h2>Leave a Message</h2>
				<div class="contactFormCol">
		            <form @submit.prevent="inquire">
			            <div class="inputRow">
			                <div class="inputCol">
			                  	<input type="text" placeholder="Full Name" v-model="contact.name" v-validate="'required|max:255'" data-vv-name="name" data-vv-as="name">
                                <div v-if="errors.has('name')" class="text-danger">
                                    {{ errors.first('name') }}
                                </div>
			                </div>
			                <div class="inputCol">
			                  	<input type="text" placeholder="Email Address" v-model="contact.email" v-validate="'required|email|max:255'" data-vv-name="email" data-vv-as="email">
                                <div v-if="errors.has('email')" class="text-danger">
                                    {{ errors.first('email') }}
                                </div>
			                </div>
			                <div class="inputCol">
			                  	<input  type="text" placeholder="Subject" v-model="contact.subject" v-validate="'required|max:255'" data-vv-name="subject" data-vv-as="subject">
                                <div v-if="errors.has('subject')" class="text-danger">
                                    {{ errors.first('subject') }}
                                </div>
			                </div>
			            </div>
			            <div class="inputRow">
			                <div class="textareaCol">
			                  	<textarea placeholder="Comment/Request*" v-model="contact.message" v-validate="'required'" data-vv-name="message" data-vv-as="message"></textarea>
                                <div v-if="errors.has('message')" class="text-danger">
                                    {{ errors.first('message') }}
                                </div>
			                </div>
			            </div>
		              	<div class="inputRow">
			               	<div class="inputFullCol"> 
			               		<input value="Send Message" type="submit" :disabled="errors.any()">
			               	</div>
			            </div>
		            </form>
		        </div>
			</div>
		</div>
		<div class="map_info" ref="contact_map"></div>
	</div>
</template>
<script>
    import VeeValidate from 'vee-validate';
    import GoogleMapsLoader from 'google-maps'
    import LoaderComponent from "./LoaderComponent.vue";
    Vue.use(VeeValidate);
    export default {
        name: "contact-us-component",
        components:{
            LoaderComponent
        },
        data: function () {
            return {
                loading: false,
                page: {},
                settings:{},
                contact:{
                    name: "",
                    email: "",
                    subject: "",
                    message: ""
                },
            }
        },
        created(){
            this.loading = true;
            this.getPage();
        },
        mounted() {
            GoogleMapsLoader.KEY = this.settings.GOOGLE_MAP_KEY;
            GoogleMapsLoader.KEY = 'AIzaSyDViIP3wUAOLAGs1fWCak4PnQuGw4YnSZQ';
            var vm = this;
            GoogleMapsLoader.load(function(google) {
                let geocoder = new google.maps.Geocoder();
                let infowindow = new google.maps.InfoWindow();
                let myLatlng = new google.maps.LatLng(-16.9076308,145.7170115);
                let map = new google.maps.Map(vm.$refs.contact_map, {
                    zoom: 15,
                    center: myLatlng,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                });

                var marker = new google.maps.Marker(
                    {
                        position: myLatlng,
                        map: map,
                        draggable:true
                    }
                ); 
            });
        },
        methods: {
            getPage() {
                this.loading = true;
                axios.get('/contact-us/get').then(response => {
                    let data = response.data;
                    this.page = data.page_data;
                    this.settings = data.ConfigSettings;
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            inquire() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        axios.post('/contact-us/send', this.contact).then(response => {
                            if(response.data.status === true){
                                flash(response.data.message, 'success');
                            }else{
                                flash(response.data.message, 'error');
                            }
                            this.loading = false;
                        }).catch(error => {
                            this.loading = false;
                            console.log(error);
                        });
                    }else{
                        this.loading = false;
                    }
                });
            }
        }
    }
</script>
<style scoped>
    .map_info {
        width: 100%;
        height: 400px;
    }
</style>

