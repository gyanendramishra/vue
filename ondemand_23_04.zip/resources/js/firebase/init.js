import firebase from 'firebase/app';
import database from 'firebase/database';
import storage from 'firebase/storage';
// Initialize Firebase

/* local */
/*var config = {
    apiKey: "AIzaSyB6jf9xLG-pvv2v97Tl0CAlUtXjxSjO77s",
    authDomain: "ondemandchat-21014.firebaseapp.com",
    databaseURL: "https://ondemandchat-21014.firebaseio.com",
    projectId: "ondemandchat-21014",
    storageBucket: "ondemandchat-21014.appspot.com",
    messagingSenderId: "688147486482"
};*/

/* Production */
var config = {
    apiKey: "AIzaSyDFE1ANDT-lW53b0lBNQ8dMWIwnmOldyfg",
    authDomain: "ondemand-3ecc3.firebaseapp.com",
    databaseURL: "https://ondemand-3ecc3.firebaseio.com",
    projectId: "ondemand-3ecc3",
    storageBucket: "ondemand-3ecc3.appspot.com",
    messagingSenderId: "939100840163"
};

var fire = firebase.initializeApp(config);
export default fire;
