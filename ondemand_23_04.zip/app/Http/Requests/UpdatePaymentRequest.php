<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdatePaymentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'first_name'=>'bail|required|max:255',
            'last_name'=>'bail|required|max:255',
            'dob'=>'bail|required|date_format:d-m-Y',
            'address'=>'bail|required|max:255',
            'country'=>'bail|required|max:255',
            'state'=>'bail|required|max:255',
            'city'=>'bail|required|max:255',
            'postal_code'=>'bail|required|digits_between:4,8',
            'stripe_business_name'=>'bail|required|max:255',
            'legal_business_name'=>'bail|required|max:255',
            'personal_id_number'=>'bail|required|numeric',
            'account_holder_name'=>'bail|required|max:255',
            'account_number'=>'bail|required|numeric|digits_between:9,11',
            'sort_code'=>'bail|required|numeric|digits_between:4,8',
            'currency'=>'bail|required|max:255'
        ];
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        return [
            
        ];
    }
}
