<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\ComplaintService;

class BookingComplaintController extends Controller
{ 

    /**
     * Show the user complaint form.
     *
     * @param Illuminate\Http\Request $request
     * @param string $slug
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request, $slug){
        $slug_array = explode('-', $slug);
        $bookingId = last($slug_array);
        return view('booking.complaint', compact('bookingId'));
    }

    /**
     * Add the user booking complaint.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\ComplaintService $service
     * @return \Illuminate\Http\Response
     */
    public function addBookingComplaint(Request $request, ComplaintService $service){
        try{
            $response = $service->addComplaintService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

}
