<?php

namespace App\Http\Controllers;

use GuzzleHttp\Client;
use Illuminate\Http\Request;

class BookingChatController extends Controller
{ 

    /**
     * Show the user booking review form.
     *
     * @param Illuminate\Http\Request $request
     * @param string $slug
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request, $slug){
        $slug_array = explode('-', $slug);
        $bookingId = last($slug_array);
        return view('booking.chat', compact('bookingId'));
    }

    /**
     * Get the user booking.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\ReviewService $service
     * @return \Illuminate\Http\Response
     */
    public function notifyUser(Request $request){
        try{
            $curl = curl_init();
            $data = [
                "token"=> $request->token,
                "device_type"=>$request->device_type,
                "message"=>$request->message,
                "model"=>json_encode($request->model)
            ];
            curl_setopt_array($curl, array(
              CURLOPT_URL => "https://us-central1-ondemand-3ecc3.cloudfunctions.net/notifytousers",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => json_encode($data),
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "cache-control: no-cache"
              ),
            ));
            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              echo $response;
            }
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    
}
