@extends('layouts.app')

@section('content')
<div class="flex-center position-ref full-height">
    <div class="container">
        <div class="card">
            <div class="card-header">Laravel</div>
            <div class="card-body">
                <a class="col" href="https://laravel.com/docs">Docs</a>
                <a class="col" href="https://laracasts.com">Laracasts</a>
                <a class="col" href="https://laravel-news.com">News</a>
                <a class="col" href="https://blog.laravel.com">Blog</a>
                <a class="col" href="https://nova.laravel.com">Nova</a>
                <a class="col" href="https://forge.laravel.com">Forge</a>
                <a class="col" href="https://github.com/laravel/laravel">GitHub</a>
            </div>
        </div>
    </div>
</div>
@endsection

