<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/owl.carousel.css') }}" media="all">
    <link rel="stylesheet" href="{{ asset('css/owlcarouseltheme.css') }}" media="all">
    <link rel="stylesheet" href="{{ asset('css/animate.css') }}" media="all">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}" media="all"/>
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<body>
    <div id="app">
        <div class="header">
            <div class="mainMenuWrap">
                <div class="container">
                    <div class="mainMenuBar">
                        <nav class="nav" role="navigation">
                            <div class="wrapper-flush">
                                <button class="nav-toggle">
                                    <span class="icon-menu">
                                        <span class="line line-1"></span>
                                        <span class="line line-2"></span>
                                        <span class="line line-3"></span>
                                    </span>
                                </button>
                                <div class="logo">
                                    <a href="">
                                      <img src="{{ asset('/images/logo.png') }}" alt="logo" title="" />
                                    </a>
                                </div>
                                <div class="nav-container">
                                    <ul class="nav-menu menu">
                                        <li class="menu-item active">
                                            <a href="#" class="menu-link">about us</a>
                                        </li>
                                        <li class="menu-item">
                                            <a href="#" class="menu-link">Services</a>
                                        </li>
                                        <li class="menu-item">
                                            <a href="#" class="menu-link"> fAQ’S</a>
                                        </li>
                                    </ul>
                                    <div class="top-right-login">
                                        <div class="languageBox">
                                            <div class="dropdown">
                                                <a
                                                    href="#"
                                                    data-toggle=""
                                                    data-hover="dropdown"
                                                    class="languageBtn"
                                                    aria-expanded="true"
                                                  >
                                                    <img src="{{ asset('images/language_icon.png') }}" /> Us
                                                    <i class="caret"></i>
                                                </a>
                                                <ul class="dropdown-menu">
                                                    <li><a href="#">test</a></li>
                                                    <li><a href="#">test</a></li>
                                                    <li><a href="#">test</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <ul class="login-menu">
                                            <li>
                                                <a href="">
                                                    <img src="{{ asset('images/login_icon.png') }}" /> Login
                                                </a>
                                            </li>
                                            <li>
                                                <a href="">
                                                    <img src="{{ asset('images/signup_icon.png') }}" /> Signup
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        @yield('content')

        <footer class="footer">
            <div class="footer-top-sec">
                <div class="container">
                    <div class="footer-logo">
                        <a href="#Page-Top">
                            <img src="{{ asset('images/logo.png') }}" alt="logo" title="" />
                        </a>
                    </div>
                    <div class="ft-menu clearfix">
                        <ul>
                            <li><a href="">Home</a></li>
                            <li><a href="">About Us</a></li>
                            <li><a href="">Services</a></li>
                            <li><a href="">Faq’s</a></li>
                            <li><a href="">Contact Us</a></li>
                            <li><a href="">Privacy Policy</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="copyright-sec">
                <div class="container">
                    <p>Copyright © 2018 CGS Group LCC. All Rights Reserved.</p>
                    <div class="footer-social">
                        <span>Social Connect:</span>
                        <ul class="social-icon">
                            <li>
                                <a href=""><i class="fa fa-facebook-f"></i></a>
                            </li>
                            <li>
                                <a href=""><i class="fa fa-twitter"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>
    {{-- <script src="{{ asset('js/jquery.min.js') }}"></script>
    <script src="{{ asset('js/owl.carousel.js') }}"></script> 
    <script src="{{ asset('js/custom.js') }}"></script> --}}
</body>
</html>
