@extends('layouts.app')

@section('content')
<!--
<div class="sliderWrap global-slider-controls">
    <div id="home-slider">
        <div class="item fill" style="background-image: url({{ asset('images/slide_01.jpg') }})"></div>
        <div class="item fill" style="background-image: url({{ asset('images/slide_01.jpg') }})"></div>
        <div class="item fill" style="background-image: url({{ asset('images/slide_01.jpg') }})"></div>
    </div>
    <div class="top-booking-form-sec">
        <div class="container">
            <div class="booking-title-col">
                <div class="booking-title-col-inner">
                    <h2>Offering <span>easy</span></h2>
                    <p>
                        to-book services, in person or<br />
                        virtually on demand.
                    </p>
                </div>
            </div>
            <div class="top-booking-form-col">
                <form method="post">
                    <div class="booking-input-row">
                        <div class="booking-input-col">
                            <label>Search</label>
                            <input type="text" placeholder="Enter your keyword" />
                        </div>
                        <div class="booking-input-col">
                            <label>Category</label>
                            <select>
                                <option>Select</option>
                                <option>Test</option>
                                <option>Test2</option>
                                <option>Test3</option>
                            </select>
                        </div>
                        <div class="booking-input-col">
                            <label>Sub Category</label>
                            <select>
                                <option>Select</option>
                                <option>Test</option>
                                <option>Test2</option>
                                <option>Test3</option>
                            </select>
                        </div>
                    </div>
                    <div class="booking-input-row">
                        <div class="booking-input-col calendar-col">
                            <label>Availability</label>
                            <input type="text" placeholder="Enter your keyword" />
                        </div>
                        <div class="booking-input-col">
                            <label>Rating</label>
                            <select>
                                <option>Select</option>
                                <option>Test</option>
                                <option>Test2</option>
                                <option>Test3</option>
                            </select>
                        </div>
                        <div class="booking-input-col price-input-col">
                            <label>Price</label>
                            <input type="text" placeholder="Min" />
                            <input type="text" placeholder="Max" />
                        </div>
                    </div>
                    <button type="submit">
                        <i class="fa fa-long-arrow-right"></i>
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

-->

<main-sliders-component SLIDER_BASE_URL="{{ asset('') }}"></main-sliders-component>
<how-it-works-component></how-it-works-component>
<!--
<div class="how-it-works-sec">
    <div class="container">
        <div class="titleSec">
            <h2>How it works</h2>
        </div>
        <div class="flip-content-sec">
            <div class="container">
                <div class="row">
                    <div class="col-md-7">
                        <div class="flip-content-img-col">
                            <img src="{{ asset('images/how_it_works_img01.jpg') }}" alt="" />
                            <div class="works-icon-col">
                                <img src="{{ asset('images/how_it_works_icon01.png') }}" alt="" />
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="flip-content-col padd-left-30">
                            <div class="works-no-col">
                                <h2>01</h2>
                            </div>
                            <p>
                                Sign up and tell us all the services you can provide virtually
                                or in person on demand.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row how-it-works-2">
                    <div class="col-md-7 order-md-2">
                        <div class="flip-content-img-col">
                            <img src="{{ asset('images/how_it_works_img02.jpg') }}" alt="" />
                            <div class="works-icon-col">
                                <img src="{{ asset('images/how_it_works_icon02.png') }}" alt="" />
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5 order-1">
                        <div class="flip-content-col padd-right-30">
                            <div class="works-no-col">
                                <h2>02</h2>
                            </div>
                            <p>
                                Receive an alert and tell the client when you can do the job
                                and how much it will cost.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-7">
                        <div class="flip-content-img-col">
                            <img src="{{ asset('images/how_it_works_img03.jpg') }}" alt="" />
                            <div class="works-icon-col">
                                <img src="{{ asset('images/how_it_works_icon03.png') }}" alt="" />
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="flip-content-col padd-left-30">
                            <div class="works-no-col">
                                <h2>03</h2>
                            </div>
                            <p>
                                Complete the job and instantly get paid through our automated
                                payment system.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> -->
<div class="service-provider-sec global-slider-controls">
    <div class="container">
        <div class="titleSec">
            <h2>Near by Service Provider</h2>
        </div>
        <div id="service-provider-slider">
            <div class="item">
                <div class="ser-provider-col">
                    <div class="ser-provider-img-col">
                        <img src="{{ asset('images/service_provider_01.jpg') }}" alt="" />
                        <div class="service-pro-name">
                            <i class="fa fa-user"></i>
                            <span>David Calark</span>
                        </div>
                        <div class="ser-provider-overlay">
                            <div class="ser-provider-detail">
                                <ul>
                                    <li><i class="fa fa-user"></i> David Calark</li>
                                    <li><i class="fa fa-briefcase"></i> Proofreading</li>
                                    <li>
                                        <i class="fa fa-map-marker"></i> Grange Road, Kingston
                                      upon Thames, Surrey KT1 2QJ
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ser-provider-col">
                    <div class="ser-provider-img-col">
                        <img src="{{ asset('images/service_provider_02.jpg') }}" alt="" />
                        <div class="service-pro-name">
                            <i class="fa fa-user"></i><span>Andrew Smith</span>
                        </div>
                        <div class="ser-provider-overlay">
                            <div class="ser-provider-detail">
                                <ul>
                                    <li><i class="fa fa-user"></i> Andrew Smith</li>
                                    <li><i class="fa fa-briefcase"></i> Proofreading</li>
                                    <li>
                                      <i class="fa fa-map-marker"></i> Grange Road, Kingston
                                      upon Thames, Surrey KT1 2QJ
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ser-provider-col">
                    <div class="ser-provider-img-col">
                        <img src="{{ asset('images/service_provider_03.jpg') }}" alt="" />
                        <div class="service-pro-name">
                            <i class="fa fa-user"></i><span>Justin Hague</span>
                        </div>
                        <div class="ser-provider-overlay">
                            <div class="ser-provider-detail">
                                <ul>
                                    <li><i class="fa fa-user"></i> Justin Hague</li>
                                    <li><i class="fa fa-briefcase"></i> Proofreading</li>
                                    <li>
                                      <i class="fa fa-map-marker"></i> Grange Road, Kingston
                                      upon Thames, Surrey KT1 2QJ
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ser-provider-col">
                    <div class="ser-provider-img-col">
                        <img src="{{ asset('images/service_provider_04.jpg') }}" alt="" />
                        <div class="service-pro-name">
                            <i class="fa fa-user"></i>
                            <span>Jamie Philip</span>
                        </div>
                        <div class="ser-provider-overlay">
                            <div class="ser-provider-detail">
                                <ul>
                                    <li><i class="fa fa-user"></i> Jamie Philip</li>
                                    <li><i class="fa fa-briefcase"></i> Proofreading</li>
                                    <li>
                                      <i class="fa fa-map-marker"></i> Grange Road, Kingston
                                      upon Thames, Surrey KT1 2QJ
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="border-btn-sec">
            <a href="#" class="border-btn">View all Service Provider</a>
        </div>
    </div>
</div>

<div class="top-category-sec global-slider-controls">
    <div class="container">
        <div class="titleSec">
            <h2>Top Category</h2>
        </div>
        <div id="top-category-slider">
            <div class="item">
                <div class="top-category-col">
                    <div class="userCol">
                        <img src="{{ asset('images/top_category_img01.jpg') }}" alt="" />
                        <h4>Andrew Blair</h4>
                        <span>15 Link Road</span>
                        <div class="category-rating-col">
                            <i class="fa fa-star"></i> 5.0
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="top-category-col">
                    <div class="userCol">
                        <img src="{{ asset('images/top_category_img02.jpg') }}" alt="" />
                        <h4>Andrew Blair</h4>
                        <span>15 Link Road</span>
                        <div class="category-rating-col">
                            <i class="fa fa-star"></i> 5.0
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="top-category-col">
                    <div class="userCol">
                        <img src="{{ asset('images/top_category_img03.jpg') }}" alt="" />
                        <h4>Andrew Blair</h4>
                        <span>15 Link Road</span>
                        <div class="category-rating-col">
                            <i class="fa fa-star"></i> 5.0
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="border-btn-sec">
            <a href="#" class="border-btn">View all</a>
        </div>
    </div>
</div>
@endsection
