<template>
    <div :class="alertType" role="alert" v-show="show">
        {{ body }}
    </div>
</template>
<script>
    export default {
        props: ['message'],
        data() {
            return {
                alertType : 'alert alert-success spacing',
                show : false,
                body : ''
            }
        },
        created() {
            if(this.message) {
                this.flash(this.message);
            }
            window.events.$on('flash', (message) => this.flash(message));

        },
        methods: {
            flash(data) {
                this.alertType = 'alert alert-'+data.variant+' spacing';
                this.body = data.message;
                this.show = true;
                setTimeout(() => {
                    this.hide()
                }, 3000);

            },
            hide() {
                this.show = false;
            }
        }
    }

</script>

<style>
    .spacing {
        position: fixed;
        right: 5px;
        top: 60px;
        z-index: 1000;
    }
</style>