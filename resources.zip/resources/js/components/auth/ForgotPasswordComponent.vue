<template>
    <div class="card" v-if="isPasswordResetLinkSent === false">
        <div class="card-header">Reset Password</div>
        <div class="card-body">
            <form @submit.prevent="sendPasswordResetLink">
                <div class="form-group row">
                    <label for="email" class="col-md-4 col-form-label text-md-right">E-Mail Address</label>
                    <div class="col-md-6">
                        <input id="email" type="text" class="form-control" name="email" v-model="fields.email">
                        <div v-if="errors && errors.email" class="text-danger">
                            {{ errors.email[0] }}
                        </div>
                    </div>
                </div>
                <div class="form-group row mb-0">
                    <div class="col-md-6 offset-md-4">
                        <button type="submit" class="btn btn-primary">
                            Send Password Reset Link <span v-if="loading">...</span>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="card" v-else>
        <div class="card-header">Reset Password</div>
        <div class="card-body">
            <form @submit.prevent="resetPassword">
                <div class="form-group row">
                    <label for="verification_code" class="col-md-4 col-form-label text-md-right">OTP</label>
                    <div class="col-md-6">
                        <input id="verification_code" type="text" class="form-control" name="verification_code" v-model="fields.verification_code">
                        <div v-if="errors && errors.verification_code" class="text-danger">
                            {{ errors.verification_code[0] }}
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="password" class="col-md-4 col-form-label text-md-right">Password</label>
                    <div class="col-md-6">
                        <input id="password" type="password" class="form-control" name="password" v-model="fields.password">
                        <div v-if="errors && errors.password" class="text-danger">
                            {{ errors.password[0] }}
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="password-confirm" class="col-md-4 col-form-label text-md-right">Confirm Password</label>
                    <div class="col-md-6">
                        <input id="password-confirm" type="password" class="form-control" name="confirm_password" v-model="fields.confirm_password">
                        <div v-if="errors && errors.confirm_password" class="text-danger">
                            {{ errors.confirm_password[0] }}
                        </div>
                    </div>
                </div>
                <div class="form-group row mb-0">
                    <div class="col-md-6 offset-md-4">
                        <button type="submit" class="btn btn-primary">
                            Reset Password <span v-if="loading">...</span>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                isPasswordResetLinkSent : false,
                loading : false,
                fields: {},
                errors: {},
            }
        },
        methods: {
            sendPasswordResetLink() {
                this.loading = true;
                this.errors = {};
                axios.post('/password/email', this.fields).then(response => {
                    if(response.data.status === true){
                        this.isPasswordResetLinkSent = true;
                        flash(response.data.message, 'success');
                    }else{
                        flash(response.data.message, 'danger');
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },

            resetPassword() {
                this.loading = true;
                this.errors = {};
                axios.post('/password/reset', this.fields).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                        window.location = '/login';
                    }else{
                        flash(response.data.message, 'danger');
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },
        },
    }
</script>
