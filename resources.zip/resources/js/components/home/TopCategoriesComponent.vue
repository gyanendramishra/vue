<template>
  <div class="top-category-sec global-slider-controls">
    <div class="container">
      <div class="titleSec">
        <h2>Top Category</h2>
      </div>
      <div id="top-category-slider">
        <div class="item">
          <div class="top-category-col">
            <div class="userCol">
              <img src="@/assets/images/top_category_img01.jpg" alt="" />
              <h4>Andrew Blair</h4>
              <span>15 Link Road</span>
              <div class="category-rating-col">
                <i class="fa fa-star"></i> 5.0
              </div>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="top-category-col">
            <div class="userCol">
              <img src="@/assets/images/top_category_img02.jpg" alt="" />
              <h4>Andrew Blair</h4>
              <span>15 Link Road</span>
              <div class="category-rating-col">
                <i class="fa fa-star"></i> 5.0
              </div>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="top-category-col">
            <div class="userCol">
              <img src="@/assets/images/top_category_img03.jpg" alt="" />
              <h4>Andrew Blair</h4>
              <span>15 Link Road</span>
              <div class="category-rating-col">
                <i class="fa fa-star"></i> 5.0
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="border-btn-sec">
        <a href="#" class="border-btn">View all</a>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "top-categories"
};
</script>
