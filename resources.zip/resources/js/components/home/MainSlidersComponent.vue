<template>
    <div class="sliderWrap global-slider-controls">
        <div id="home-slider" class="home-main-slider">
            <div class="item fill" v-for="slider in sliders" v-bind:key="slider" style="background-image: url(SLIDER_BASE_URL+slider)"></div>
        </div>
        <div class="top-booking-form-sec">
            <div class="container">
                <div class="booking-title-col">
                    <div class="booking-title-col-inner">
                        <h2>Offering <span>easy</span></h2>
                        <p>
                            to-book services, in person or<br />
                            virtually on demand.
                        </p>
                    </div>
                </div>
                <div class="top-booking-form-col">
                    <form method="post">
                        <div class="booking-input-row">
                            <div class="booking-input-col">
                                <label>Search</label>
                                <input type="text" placeholder="Enter your keyword" />
                            </div>
                            <div class="booking-input-col">
                                <label>Category</label>
                                <select>
                                    <option>Select</option>
                                    <option>Test</option>
                                    <option>Test2</option>
                                    <option>Test3</option>
                                </select>
                            </div>
                            <div class="booking-input-col">
                                <label>Sub Category</label>
                                <select>
                                    <option>Select</option>
                                    <option>Test</option>
                                    <option>Test2</option>
                                    <option>Test3</option>
                                </select>
                            </div>
                        </div>
                        <div class="booking-input-row">
                            <div class="booking-input-col calendar-col">
                                <label>Availability</label>
                                <input type="text" placeholder="Enter your keyword" />
                            </div>
                            <div class="booking-input-col">
                                <label>Rating</label>
                                <select>
                                    <option>Select</option>
                                    <option>Test</option>
                                    <option>Test2</option>
                                    <option>Test3</option>
                                </select>
                            </div>
                            <div class="booking-input-col price-input-col">
                                <label>Price</label>
                                <input type="text" placeholder="Min" />
                                <input type="text" placeholder="Max" />
                            </div>
                        </div>
                        <button type="submit">
                            <i class="fa fa-long-arrow-right"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import 'owl.carousel';
export default {
    name: "main-sliders-component",
    data() {
        return {
        SLIDER_BASE_URL: "",
        sliders: ["/images/slide_01.jpg", "/images/slide_02.jpg", "/images/slide_03.jpg"]
        };
    },
    mounted: function(){
        Vue.nextTick(function(){
            window.$(".home-main-slider").owlCarousel({
                loop:true,
                margin:0,
                nav:true,
                dots:false,
                autoplay:true,
                responsive:{
                    0:{
                        items:1 
                    },
                    767:{
                        items:1
                    },
                    1024:{
                        items:1
                    }
                    
                }
            });
        }.bind(this));
    }
};
</script>
