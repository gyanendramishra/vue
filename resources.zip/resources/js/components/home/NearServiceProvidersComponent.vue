<template>
  <div class="service-provider-sec global-slider-controls">
    <div class="container">
      <div class="titleSec">
        <h2>Near by Service Provider</h2>
      </div>
      <div id="service-provider-slider">
        <div class="item">
          <div class="ser-provider-col">
            <div class="ser-provider-img-col">
              <img src="@/assets/images/service_provider_01.jpg" alt="" />
              <div class="service-pro-name">
                <i class="fa fa-user"></i>
                <span>David Calark</span>
              </div>
              <div class="ser-provider-overlay">
                <div class="ser-provider-detail">
                  <ul>
                    <li><i class="fa fa-user"></i> David Calark</li>
                    <li><i class="fa fa-briefcase"></i> Proofreading</li>
                    <li>
                      <i class="fa fa-map-marker"></i> Grange Road, Kingston
                      upon Thames, Surrey KT1 2QJ
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="ser-provider-col">
            <div class="ser-provider-img-col">
              <img src="@/assets/images/service_provider_02.jpg" alt="" />
              <div class="service-pro-name">
                <i class="fa fa-user"></i><span>Andrew Smith</span>
              </div>
              <div class="ser-provider-overlay">
                <div class="ser-provider-detail">
                  <ul>
                    <li><i class="fa fa-user"></i> Andrew Smith</li>
                    <li><i class="fa fa-briefcase"></i> Proofreading</li>
                    <li>
                      <i class="fa fa-map-marker"></i> Grange Road, Kingston
                      upon Thames, Surrey KT1 2QJ
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="ser-provider-col">
            <div class="ser-provider-img-col">
              <img src="@/assets/images/service_provider_03.jpg" alt="" />
              <div class="service-pro-name">
                <i class="fa fa-user"></i><span>Justin Hague</span>
              </div>
              <div class="ser-provider-overlay">
                <div class="ser-provider-detail">
                  <ul>
                    <li><i class="fa fa-user"></i> Justin Hague</li>
                    <li><i class="fa fa-briefcase"></i> Proofreading</li>
                    <li>
                      <i class="fa fa-map-marker"></i> Grange Road, Kingston
                      upon Thames, Surrey KT1 2QJ
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="ser-provider-col">
            <div class="ser-provider-img-col">
              <img src="@/assets/images/service_provider_04.jpg" alt="" />
              <div class="service-pro-name">
                <i class="fa fa-user"></i>
                <span>Jamie Philip</span>
              </div>
              <div class="ser-provider-overlay">
                <div class="ser-provider-detail">
                  <ul>
                    <li><i class="fa fa-user"></i> Jamie Philip</li>
                    <li><i class="fa fa-briefcase"></i> Proofreading</li>
                    <li>
                      <i class="fa fa-map-marker"></i> Grange Road, Kingston
                      upon Thames, Surrey KT1 2QJ
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="border-btn-sec">
        <a href="#" class="border-btn">View all Service Provider</a>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "near-service-providers"
};
</script>
