@extends('layouts.dashboard')
@section('page_header_title')
	Booking
@endsection
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        booking
    </li>
@endsection

@section('dashboard_content')
  	<booking-component :is-service-provider="{{ $isServiceProvider }}"></booking-component>
@endsection

