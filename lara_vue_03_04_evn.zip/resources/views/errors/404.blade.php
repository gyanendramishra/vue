@extends('layouts.app')
@section('content')
<div class="topInnerBanner" style="background-image:url(/images/login_body_bg.jpg);">
	<div class="container">
	    <div class="topBannerMidCol">
	      	<h1>
	      		404 Not Found
	      	</h1>
	    </div>
	</div>
</div>
<div class="breadcrumb-sec">
  	<div class="container">
	    <ul>
		    <li>
		      	<a href="{{ route('home') }}">
			      	Home
			    </a>
		    </li>
	        <li>
		        404
		    </li>
	    </ul>
  	</div>
</div>
<div class="mainWpapContainer">
	<section class="default-contant-page content-grey-bg padding-T-B-30">
	    <div class="container">
			<div class="notfound">
				<div class="notfound-404">
					<h3>Oops! Page not found</h3>
					<h2>4<span class="o-text">0</span>4</h2>
				</div>
				<p>we are sorry, but the page you requested was not found</p>
	            <div class="btn-sec">
	            	<a href="{{ route('home') }}" class="border-btn">Back To Home</a>
	            </div>
			</div>
	  	</div>
	</section>
</div>

@endsection
