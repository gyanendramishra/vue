<template>
    <div v-if="loading === false">
        <div class="formBox editProfileForm">
            <div class="formBoxInner">
                <div class="dashbord-sec">
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter">
                            <div class="infoItem"> 
                                <i class="infoIcon">
                                    <img src="/images/booking_dashboard_icon.png">
                                </i>
                                <h3>Booking</h3>
                                <a class="btn btn-sm btn-white" href="/booking">
                                    View More
                                </a> 
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter" v-show="account_type_id === 1">
                            <div class="infoItem"> 
                                <i class="infoIcon">
                                    <img src="/images/services_dashboard_icon.png">
                                </i>
                                <h3>Services</h3>
                                <a class="btn btn-sm btn-white" href="/my-service">
                                    View More
                                </a> 
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter" v-show="account_type_id === 1">
                            <div class="infoItem"> 
                                <i class="infoIcon">
                                    <img src="/images/earning_dashboard_icon.png">
                                </i>
                                <h3>Earning</h3>
                                <a class="btn btn-sm btn-white" href="/my-earning">
                                    View More
                                </a> 
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter">
                            <div class="infoItem"> 
                                <i class="infoIcon">
                                    <img src="/images/profile_dashboard_icon.png">
                                </i>
                                <h3>Profile</h3>
                                <a class="btn btn-sm btn-white" href="/my-profile">
                                    View More
                                </a> 
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter" v-show="account_type_id === 1">
                            <div class="infoItem"> 
                                <i class="infoIcon">
                                    <img src="/images/setting_dashboard_icon.png">
                                </i>
                                <h3>Payment</h3>
                                <a class="btn btn-sm btn-white" href="/payment">
                                    View More
                                </a> 
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter" v-show="account_type_id === 1">
                            <div class="infoItem"> 
                                <i class="infoIcon">
                                    <img src="/images/reviews_dashboard_icon.png">
                                </i>
                                <h3>Reviews</h3>
                                <a class="btn btn-sm btn-white" href="/reviews">
                                    View More
                                </a> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div v-else></div>
</template>
<script>
    export default {
        name: "dashboard-component",
        props: ["isServiceProvider"],
        data: function () {
            return {
                dashboard:{},
                loading: false,
                account_type_id : 1
            }
        },
        beforeCreate: function(){
            this.loading = true;
        },
        created: function(){
            this.getDashboard();
        },
        mounted : function() {
            if(this.isServiceProvider === true){
                this.account_type_id = 1;
            }else{
                this.account_type_id = 2;
            }
        },
        methods: {
            getDashboard() {
                axios.post('/dashboard/get', {
                    account_type_id:this.account_type_id
                }).then(response => {
                    if(response.data.status === true){
                        this.dashboard = response.data.data;
                    }else{
                        flash(response.data.message, 'error');
                    }
                }).catch(error => {
                    console.log(error);
                });
            }
        }
    }
</script>

