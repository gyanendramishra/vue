<template>
    <div>
        <label>
            Address 
            <span class="red-color">*</span>
        </label>
        <div class="form-icon-col">
            <i class="fa fa-map-marker"></i> 
            <input type="text" placeholder="Address" name="address" ref="address" @click="populateModal" v-model="fields.address">
            <input type="hidden" placeholder="Address" name="latitude" v-model="fields.latitude">
            <input type="hidden" placeholder="Address" name="longitude"  v-model="fields.longitude" lazy>
        </div>
        <div class="modal address-field-map-model" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Select your address</h5>
                </div>
                <div class="modal-body" ref="address_field_google_map"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Use this location</button>
                </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    //require('bootstrap-datepicker/dist/js/bootstrap-datepicker.js');
    import GoogleMapsLoader from 'google-maps'
    GoogleMapsLoader.KEY = 'AIzaSyDViIP3wUAOLAGs1fWCak4PnQuGw4YnSZQ';
    export default {
        name: "address-on-map-component",
        data: function () {
            return {
                fields:{}
            }
        },
        methods: {
            populateModal() {
                $('.modal').modal('show');
            },

        },
        mounted: function () {
            var vm = this;
            vm.fields = {};
            GoogleMapsLoader.load(function(google) {
                let geocoder = new google.maps.Geocoder();
                let infowindow = new google.maps.InfoWindow();
                let myLatlng = new google.maps.LatLng(26.9124,75.7873);
                let map = new google.maps.Map(vm.$refs.address_field_google_map, {
                    zoom: 15,
                    center: myLatlng,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                });

                var marker = new google.maps.Marker(
                    {
                        position: myLatlng,
                        map: map,
                        draggable:true
                    }
                );
                geocoder.geocode({'latLng': myLatlng }, function(results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        if (results[0]) {
                            vm.fields.latitude = marker.position.lat().toFixed(6);
                            vm.fields.longitude = marker.position.lng().toFixed(6);
                            vm.fields.address = results[0].formatted_address;
                            vm.$refs.address.value = results[0].formatted_address;

                            infowindow.setContent(results[0].formatted_address);
                            infowindow.open(map, marker);
                        }
                    }       
                });
                google.maps.event.addListener(
                    marker,
                    'dragend',
                    function() {
                        geocoder.geocode({'latLng': marker.getPosition()}, function(results, status) {
                            if (status == google.maps.GeocoderStatus.OK) {
                                if (results[0]) {
                                    vm.fields.latitude = marker.position.lat().toFixed(6);
                                    vm.fields.longitude = marker.position.lng().toFixed(6);
                                    vm.fields.address = results[0].formatted_address;
                                    vm.$refs.address.value = results[0].formatted_address;
                                    infowindow.setContent(results[0].formatted_address);
                                    infowindow.open(map, marker);
                                }
                            }
                        });
                });  
            });
        }
        
    }
</script>
<style scoped>
    .address-field-map-model .modal-body {
        width: 100%;
        height: 400px;
    }
</style>

