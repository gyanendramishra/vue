<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\BookingService;

class BookingController extends Controller
{ 

    /**
     * Show the user bookings.
     *
     * @param Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request){
        $user = $request->session()->get('auth_user');
        $isServiceProvider = "false";
        if($user->isServiceProvider){
            $isServiceProvider = "true";
        }
        return view('booking.index', compact('isServiceProvider'));
    }

    /**
     * Get the user booking.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\BookingService $service
     * @return \Illuminate\Http\Response
     */
    public function getBookings(Request $request, BookingService $service){
        try{
            $response = $service->getBookingsService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }


    /**
     * Book the service.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\BookingService $service
     * @return \Illuminate\Http\Response
     */
    public function bookService(Request $request, BookingService $service){
        try{
            $response = $service->addBookingService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
