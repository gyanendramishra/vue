<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class BookingService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/bookings/';

    /**
     * Add payment account detail.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function addBookingService($data) {
        $uri = $this->base_uri;
        $uri .= 'add';
        return $this->postServiceRequest($uri, $data);
    }

    /**
     * Get my booking.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function getBookingsService($data) {
        $uri = $this->base_uri;
        $uri .= 'myBooking';
        return $this->postServiceRequest($uri, $data);
    }

}