<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class DashboardService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/users/';

    /**
     * About us cms.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function getDashboardService($data) {
        $uri = $this->base_uri;
        $uri .= 'dashboard';
        return $this->postServiceRequest($uri, $data);
    }

}