-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2020 at 04:47 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carmarket`
--

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `gateway_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gateway_plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('none','stripe','unionpay','paybay','wing') COLLATE utf8mb4_unicode_ci DEFAULT 'none',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `user_id`, `gateway_id`, `gateway_plan_id`, `type`, `name`, `status`, `quantity`, `trial_ends_at`, `ends_at`, `created_at`, `updated_at`) VALUES
(4, 1, 'adasdsfdff', '', 'stripe', '', 'active', 1, NULL, NULL, '2020-01-23 18:30:00', NULL),
(5, 1, 'sub_GbQ4kofp4TQgMt', 'plan_Gas0OjlRYlo6E2', 'stripe', 'Dealer Ultimate', 'active', 1, NULL, NULL, '2020-01-23 15:58:38', '2020-01-23 15:58:38'),
(6, 3, NULL, NULL, 'none', 'Seller Free', NULL, 1, NULL, '2020-01-30 16:06:25', '2020-01-23 16:06:25', '2020-01-23 16:06:25');

-- --------------------------------------------------------

--
-- Table structure for table `subscription_plans`
--

CREATE TABLE `subscription_plans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `gateway_id` varchar(191) DEFAULT NULL,
  `plan_title` varchar(191) NOT NULL,
  `user_type` varchar(50) DEFAULT NULL,
  `plan_type` enum('Free','Paid') NOT NULL DEFAULT 'Paid',
  `duration` int(11) DEFAULT '0',
  `duration_type` enum('Days','Weeks','Months','Years','Unlimited') DEFAULT 'Days',
  `price` decimal(16,2) DEFAULT NULL,
  `minimum_price` double(16,2) DEFAULT NULL,
  `total_on_sale_count` smallint(6) NOT NULL DEFAULT '0',
  `total_featured_count` smallint(6) NOT NULL DEFAULT '0',
  `total_listing_count` smallint(6) NOT NULL DEFAULT '0',
  `count_of_until_sold` smallint(6) NOT NULL DEFAULT '0',
  `image` varchar(191) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `sort_order` smallint(6) NOT NULL DEFAULT '1',
  `slug` varchar(191) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscription_plans`
--

INSERT INTO `subscription_plans` (`id`, `gateway_id`, `plan_title`, `user_type`, `plan_type`, `duration`, `duration_type`, `price`, `minimum_price`, `total_on_sale_count`, `total_featured_count`, `total_listing_count`, `count_of_until_sold`, `image`, `status`, `sort_order`, `slug`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'plan_Gas0OjlRYlo6E2', 'Dealer Ultimate', 'Dealer', 'Paid', 1, 'Months', '50.00', 0.00, 3, 15, 20, 10, NULL, 1, 1, 'dealer-ultimate', '2020-01-21 06:02:29', '2020-01-21 08:40:46', NULL),
(2, 'plan_GarPUrySlVmTAz', 'Dealer Premium', 'Dealer', 'Paid', 1, 'Months', '22.00', 0.00, 0, 3, 10, 0, NULL, 1, 2, 'dealer-premium', '2020-01-21 06:03:28', '2020-01-21 08:40:05', NULL),
(3, 'plan_GardyxgyjS7Gex', 'Seller Premium', 'Seller', 'Paid', 1, 'Months', '10.00', 0.00, 0, 1, 1, 1, NULL, 1, 6, 'seller-premium', '2020-01-21 08:37:24', '2020-01-21 08:37:24', NULL),
(4, 'plan_Gare0MH2uKkKMe', 'Seller Standard', 'Seller', 'Paid', 1, 'Months', '5.00', 0.00, 0, 1, 1, 0, NULL, 1, 5, 'seller-standard', '2020-01-21 08:36:43', '2020-01-21 08:36:43', NULL),
(5, 'plan_GarffgZmu147kk', 'Seller Lite', 'Seller', 'Paid', 1, 'Months', '2.50', 0.00, 0, 0, 1, 0, NULL, 1, 4, 'seller-lite', '2020-01-21 08:31:38', '2020-01-21 08:31:38', NULL),
(6, NULL, 'Seller Free', 'Seller', 'Free', 7, 'Days', '0.00', 3000.00, 0, 0, 1, 0, NULL, 1, 3, 'seller-free', '2020-01-21 08:30:36', '2020-01-21 08:30:36', NULL),
(7, 'plan_GarY8bwIvJfwQJ', 'Dealer Standard', 'Dealer', 'Paid', 1, 'Months', '5.00', 0.00, 0, 0, 5, 0, NULL, 1, 8, 'dealer-standard', '2020-01-21 08:39:13', '2020-01-21 08:39:13', NULL),
(8, 'plan_Garc6qSsGeV3yW', 'Dealer Lite', 'Dealer', 'Paid', 1, 'Months', '2.50', 0.00, 0, 0, 1, 0, NULL, 1, 7, 'dealer-lite', '2020-01-21 08:38:26', '2020-01-21 08:38:26', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `stripe_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` bigint(20) DEFAULT NULL,
  `country_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_brand` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_last_four` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `admin` tinyint(4) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_otp_verified` tinyint(4) NOT NULL DEFAULT '0',
  `api_token` text COLLATE utf8mb4_unicode_ci,
  `temp_plan` bigint(20) DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `stripe_id`, `facebook_id`, `google_id`, `name`, `email`, `password`, `phone`, `country_code`, `address`, `city`, `state`, `country`, `postcode`, `card_brand`, `card_last_four`, `latitude`, `longitude`, `profile_image`, `status`, `admin`, `remember_token`, `is_otp_verified`, `api_token`, `temp_plan`, `trial_ends_at`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, NULL, NULL, NULL, 'Ratanakpisith CarMarket Admin', 'ratanakpisith.dotsquares@yopmail.com', '$2y$10$s6z6Rc8Cv1A7sFxungxM8eWupvRrigSf2/pbC5aWVopEBpLAg0NpO', 1245678894, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 'F1qAHeiR5mlMXHXoP0tWgOB854OCbCMRteR7NDoWZX1KU5otatNj7N3RMj8k', 1, NULL, NULL, NULL, '2020-01-20 18:30:00', '2020-01-20 18:30:00', NULL),
(2, NULL, NULL, NULL, 'Guest', 'carmarketguest@yopmail.com', '43645vd34655475467', 234324, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, NULL, 0, NULL, NULL, NULL, '2020-01-20 18:30:00', '2020-01-20 18:30:00', NULL),
(3, 'cus_GatrpU3E96aU3Y', NULL, NULL, 'Gyan Dealer', 'gyanseller@yopmail.com', '$2y$10$s6z6Rc8Cv1A7sFxungxM8eWupvRrigSf2/pbC5aWVopEBpLAg0NpO', 9694728151, NULL, NULL, NULL, NULL, NULL, NULL, 'visa', '4242', NULL, NULL, NULL, 1, 0, NULL, 1, NULL, 6, NULL, '2020-01-20 18:30:00', '2020-01-23 16:01:09', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subscriptions_user_id_stripe_status_index` (`user_id`,`status`);

--
-- Indexes for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD KEY `users_stripe_id_index` (`stripe_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD CONSTRAINT `subscriptions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
