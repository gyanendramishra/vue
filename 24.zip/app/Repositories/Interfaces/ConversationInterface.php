<?php
namespace App\Repositories\Interfaces;

interface ConversationInterface {
    
    public function getAllConversations();
    
    public function getUserAllConversations($userId);

    public function getConversationMessages($conversationId);

    public function getMessageById($messageId);

    public function getVehicleConversations($vehicleId);
}
