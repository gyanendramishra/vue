<?php
namespace App\Repositories\Interfaces;

use Illuminate\Http\Request;

interface VehicleInterface {
    
    public function extractFilters(Request $request);

    public function search(Request $request);

    public function getAllType();

    public function getAllMake();

    public function getAllBodyType();

    public function getAllFuelType();

    public function getAllFeatures();

    public function getAllLifestyles();

    public function getAllColors();

    public function getAllTransmissions();

    public function getDriveTypes();

    public function getAllCountryWithRegions();

    public function getCambodiaRegions();

    public function getStateCitiesById($regionId);

    public function getMakeModelBySlug($makeSlug);

    public function getMakeModelById($makeId);

    public function getModelBadgeBySlug($modelSlug);

    public function getModelBadgeById($modelId);

    public function getBadgeSeriesById($badgeId);

    public function getMakeBySlug($slug);

    public function getModelBySlug($slug);

    public function getVehicleBySlug($slug);

    public function getVehiclesBySlugs($slugs);

    public function getUserVehicleWithGeneralBySlug($slug);

    public function getUserVehicleWithFeaturesBySlug($slug);

    public function getUserVehicleWithDetailsBySlug($slug);

    public function getUserVehicleWithPhotosBySlug($slug);

    public function getUserVehicleWithPreviewBySlug($slug);

    public function getSimilarVehiclesByPrice($id, $price);

    public function getUserVehiclesHasConversation($userId);
    
    public function getCarOfTheWeek();
}
