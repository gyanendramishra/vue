<?php

namespace App\Providers;

use App\Policies\VehiclePolicy;
use Modules\User\Entities\Role;
use Illuminate\Support\Facades\Gate;
use Modules\VehicleManager\Entities\Vehicle;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Laravel\Passport\Passport;

class AuthServiceProvider extends ServiceProvider {

    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        'App\Model' => 'App\Policies\ModelPolicy',
        Vehicle::class => VehiclePolicy::class,
    ];
    

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot() {
        $this->registerPolicies();
        Passport::routes();

    }

    public function registerComposerViews() {
        \Illuminate\Support\Facades\View::composer('*', function ($view) {
            $view->with('User', Auth::guard('admin')->user());
        });

        \Illuminate\Support\Facades\View::composer('*', function ($view) {
            $action = app('request')->route() ? app('request')->route()->getAction() : '';
            if (isset($action['controller'])) {
                $controller = class_basename($action['controller']);
                list($controller, $action) = explode('@', $controller);
                $view->with(['getController' => str_replace('Controller', '', $controller), 'getAction' => $action]);
            }
        });
    }

}
