<?php

namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\VehicleManager\Entities\Vehicle;
use App\Http\Resources\Collection\VehicalCollection as VehicalCollection;
use App\Http\Resources\VehicalDetailResource as VehicalDetailResource;

class SearchController extends Controller {

    public $successStatus = 200;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request) {
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }
        session()->put('locale', $request->header('language'));
    }

    /**
     * 
     * @param Request $request
     */
    public function index(Request $request) {

        try {
          
            
            $query = Vehicle::where('is_approved',1);
          
            $query->with('vehicleFeatures');
            $query->when($request->has('make') && !empty($request->get('make')), function ($q) use($request) {

                $q->where("makes_id", $request->make);
            });

            /* Filter by added by */
            $query->when($request->has('userType') && !empty($request->get('userType')), function($q) use($request) {
                $q->where(function($q) use($request) {
                    $q->where('role', ucfirst($request->userType));
                    $q->orWhere('role', $request->userType);
                });
            });

            $query->when($request->has('model') && !empty($request->get('model')), function ($q) use($request) {
                $q->where("models_id", $request->model);
            });

            $query->when($request->has('badge') && !empty($request->get('badge')), function ($q) use($request) {
                $q->whereIn("badge_id", explode(',', $request->badge));
            });

            $query->when($request->has('series') && !empty($request->get('series')), function ($q) use($request) {
                $q->whereIn("series_id", explode(',', $request->series));
            });
            $query->when((
                    $request->has('address') &&
                    !empty($request->get('address')) &&
                    $request->has('latitude') &&
                    !empty($request->get('latitude')) &&
                    $request->has('longitude') &&
                    !empty($request->get('longitude')) &&
                    !$request->has('km') &&
                    empty($request->get('kn'))
                    ), function($q) use($request) {
                $q->where('city', $request->get('city'));
            });

            /* Filter by distance */
            $query->when((
                    $request->has('address') &&
                    !empty($request->get('address')) &&
                    $request->has('latitude') &&
                    !empty($request->get('latitude')) &&
                    $request->has('longitude') &&
                    !empty($request->get('longitude')) &&
                    $request->has('km') &&
                    !empty($request->get('kn'))
                    ), function($q) use($request) {
                $q->isWithinMaxDistance($request->get('latitude'), $request->get('longitude'), $request->get('km'));
            });


            $query->when($request->has('min_year') && !empty($request->get('min_year')) && $request->has('max_year') && !empty($request->get('max_year')), function ($q) use($request) {
                $q->whereBetween('year_build', [$request->min_year, $request->max_year]);
            });

            $query->when($request->has('min_price') && !empty($request->get('min_price')) && $request->has('max_price') && !empty($request->get('max_price')), function ($q) use($request) {
                $q->whereBetween('price', [$request->min_price, $request->max_price]);
            });

            $query->when($request->has('category_id') && !empty($request->get('category_id')), function ($q) use($request) {
                $q->where('category_id', $request->category_id);
            });

            $query->when($request->has('transmission') && !empty($request->get('transmission')), function ($q) use($request) {
                $q->where('transmissions_id', $request->transmission);
            });

            $query->when($request->has('fuel_type') && !empty($request->get('fuel_type')), function ($q) use($request) {
                $q->where('fuel_types_id', $request->fuel_type);
            });

            $query->when($request->has('cylinder') && !empty($request->get('cylinder')), function ($q) use($request) {
                $q->where('cylinders_id', $request->cylinder);
            });
            $query->when($request->has('min_engine_size') && !empty($request->get('min_engine_size')) && $request->has('max_engine_size') && !empty($request->get('max_engine_size')), function ($q) use($request) {
                $q->whereBetween('engine_capacity', [$request->min_engine_size, $request->max_engine_size]);
            });
            $query->when($request->has('fuel_economy') && !empty($request->get('fuel_economy')), function ($q) use($request) {
                $q->where('fuel_economy_id', $request->fuel_economy);
            });
            $query->when($request->has('body_style') && !empty($request->get('body_style')), function ($q) use($request) {
                $q->where('body_styles_id', $request->body_style);
            });
            $query->when($request->has('door') && !empty($request->get('door')), function ($q) use($request) {
                $q->where('doors', $request->door);
            });
            $query->when($request->has('lifestyle') && !empty($request->get('lifestyle')), function ($q) use($request) {
                $q->where('lifestyle_id', $request->lifestyle);
            });
            $query->when($request->has('keyword') && !empty($request->get('keyword')), function ($q) use($request) {
                $q->where('title', 'LIKE', '%' . $request->keyword . '%');
            });

            $query->when($request->has('feature') && !empty($request->get('feature')), function ($q) use($request) {
                $q->whereHas('vehicleFeatures', function ($query) use($request) {
                    return $query->whereIn('vehicle_feature_id', explode(',', $request->feature));
                });
            });
            $query->when($request->has('keyword') && !empty($request->get('keyword')), function ($q) use($request) {
                $q->where('title', 'LIKE', '%' . $request->keyword . '%');
            });
            $query->when($request->has('sorting_by') && !empty($request->get('sorting_by')), function ($q) use($request) {

                if ($request->sorting_by == 1) {
                    $q->orderBy('id', 'DESC');
                } elseif ($request->sorting_by == 2) {
                    $q->orderBy('is_featured', 'ASC');
                } elseif ($request->sorting_by == 3) {
                    $q->orderBy('price', 'DESC');
                } elseif ($request->sorting_by == 4) {
                    $q->orderBy('price', 'ASC');
                } elseif ($request->sorting_by == 5) {
                    $q->orderBy('year', 'DESC');
                } elseif ($request->sorting_by == 6) {
                    $q->orderBy('year', 'ASC');
                } elseif ($request->sorting_by == 7) {
                    $q->orderBy('fuel_economy_id', 'DESC');
                } elseif ($request->sorting_by == 8) {
                    $q->orderBy('fuel_economy_id', 'ASC');
                } elseif ($request->sorting_by == 8) {
                    $q->orderBy('fuel_economy_id', 'ASC');
                } elseif ($request->sorting_by == 8) {
                    $q->orderBy('fuel_economy_id', 'ASC');
                } else {
                    $q->orderBy('id', 'DESC');
                }
            });

            $data['data'] = new VehicalCollection($query->withTranslation()->paginate(10));
            $data['status'] = true;
            $data['code'] = 200;


            return response()->json($data);
        } catch (Exception $ex) {
            return response()->json([
                        'status' => FALSE,
                        'message' => $ex->getMessage(),
                        'data' => '',
                            ], 401);
        }
    }

    public function details(Request $request) {
        try {
            if (!$request->slug) {
                return response()->json([
                            'status' => FALSE,
                            'message' => "Oops! Something went wrong.",
                            'data' => '',
                                ], 200);
            }

            if (Vehicle::with('vehicleFeatures')->where('slug', $request->slug)->exists()) {
                $data['data'] = new VehicalDetailResource(Vehicle::with(['vehicleFeatures','vehicleReviews'])->where('slug', $request->slug)->withTranslation()->first());
                $data['status'] = true;
                $data['code'] = 200;
            } else {
                $data['data'] = [];
                $data['message'] = "Slug Not match";
                $data['status'] = false;
                $data['code'] = 401;
            }
            return response()->json($data);
        } catch (Exception $ex) {
            return response()->json([
                        'status' => FALSE,
                        'message' => $ex->getMessage(),
                        'data' => '',
                            ], 401);
        }
    }

}
