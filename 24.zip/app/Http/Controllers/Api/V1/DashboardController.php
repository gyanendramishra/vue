<?php

namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Support\Facades\Auth;
use Validator;

class DashboardController extends Controller {

    public $successStatus = 200;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request) {
//$authInformation = $request->header();
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function changePassword(Request $request) {

        $validator = Validator::make($request->all(), [
                    'old_password' => 'required',
                    'new_password' => 'required',
        ]);
        if ($validator->fails()) {
            $data['status'] = false;
            $data['message'] = implode(' ', $validator->errors()->all());
            $data['code'] = 200;
            return response()->json($data);
        }

        try {
            \DB::beginTransaction();

            $user = \Auth::guard('api')->user();
            if (!\Hash::check($request->old_password, $user->password)) {
                $data['status'] = false;
                $data['message'] = 'Old password do not match.';
                $data['code'] = 200;
                return response()->json($data);
            }

            $user->password = bcrypt($request->new_password);
            if ($user->save()) {
                \DB::commit();
                $data['status'] = true;
                $data['message'] = __('frontend.CHANGE_PASSWORD_SUCCESS');
                $data['code'] = 200;
                return response()->json($data);
            } else {
                $data['status'] = true;
                $data['message'] = __('frontend.CHANGE_PASSWORD_FAILED');
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (\Exception $e) {
            \DB::rollBack();
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = $e->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @return type
     */
    public function profile() {
        try {
            $user = \Auth::guard('api')->user();
            $user->profile_image = url('storage/' . $user->profile_image);
            $data['data'] = $user;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = $e->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    public function updateProfile(Request $request) {

        try {
            $user = \Auth::guard('api')->user();
            $validator = Validator::make($request->all(), [
                        'name' => 'required',
                        'email' => 'required|email|unique:users,email,' . $user->id . ',id',
                        'phone' => 'required|unique:users,phone,' . $user->id . ',id',
                        'address' => 'required',
                        'profile_image' => 'sometimes|mimes:jpeg,jpg,png| max:2000',
            ]);
            if ($validator->fails()) {
                $data['status'] = false;
                $data['message'] = implode(' ', $validator->errors()->all());
                $data['code'] = 200;
                return response()->json($data);
            }

            $user->name = $request->name;
            $user->email = $request->email;
            $user->phone = $request->phone;
            $user->address = $request->address;
            if (!empty($request->latitude) && !empty($request->longitude)) {
                $user->latitude = $request->latitude;
                $user->longitude = $request->longitude;
                $user->city = $request->city;
                $user->state = $request->state;
                $user->country = $request->country;
            }
            if ($request->profile_image) {
                if(\Storage::disk('public')->delete($user->profile_image)){
                    $user->profile_image = "";
                    $user->save();
                }
                $avatar = $request->file('profile_image')->store('avatars', 'public');
                $user->profile_image = $avatar;
               
            }
            $user->save();

            $data['status'] = TRUE;
            $data['message'] = __('frontend.PROFILE_UPDATE_SUCCESS');
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = $e->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

}
