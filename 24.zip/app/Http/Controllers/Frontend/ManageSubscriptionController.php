<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\SubscriptionRepository;
use Modules\VehicleManager\Entities\Vehicle;

class ManageSubscriptionController extends Controller {

    /**
     * Subscription repository.
     *
     * @var string
     */
    private $subscriptionRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        SubscriptionRepository $subscriptionRepository
    ) {
        $this->subscriptionRepository = $subscriptionRepository;
    }

    /**
     * Display subscribe view.
     *
     * @return \Illuminate\Http\Response
     */
    public function subscribeAndPay(Request $request, $slug) {
        
        $user = $request->user('user');
        $vehicle = Vehicle::select('id', 'steps', 'slug')
            ->whereSlug($slug)
            ->first();
        $plan = $this->subscriptionRepository->getSubscriptionById($user->temp_plan);
        if(!$plan){
            abort(404);
        }
        return view('frontend.user.manage-ad.payment', compact('vehicle', 'plan'));
    }

}
