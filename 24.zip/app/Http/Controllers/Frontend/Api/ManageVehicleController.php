<?php

namespace App\Http\Controllers\Frontend\Api;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\VehicleRepository;
use App\Mail\Frontend\VehicleReportAdMail;
use Modules\VehicleManager\Entities\Vehicle;
use Modules\VehicleManager\Entities\VehicleImage;
use App\Http\Requests\Frontend\VehiclePhotosRequest;
use App\Http\Requests\Frontend\VehicleReviewRequest;
use App\Http\Requests\Frontend\VehicleReportRequest;
use App\Http\Requests\Frontend\VehicleDetailsRequest;
use App\Http\Requests\Frontend\VehicleFeaturesRequest;
use App\Http\Requests\Frontend\VehicleGeneralInfoRequest;

class ManageVehicleController extends Controller {

    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(VehicleRepository $vehicleRepository) {
        $this->vehicleRepository = $vehicleRepository;
    }

    /**
     * Store or update resource in storage.
     *
     * @param  \App\Http\Requests\Frontend\VehicleGeneralInfoRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function manageGeneralInfo(VehicleGeneralInfoRequest $request) {
        try {
            \DB::beginTransaction();
            $user = $request->user('user');
            if($request->has('vehicle_slug')){
                $vehicle = Vehicle::where('user_id', $user->id)
                            ->whereSlug($request->vehicle_slug)
                            ->first();
            }else {
                $vehicle = new Vehicle();
                $vehicle->user_id = $user->id;
                $vehicle->role = $user->roles->isNotEmpty() ? $user->roles->first()->name : '';
                $vehicle->is_approved = 0;
            }
            $vehicle->title = $request->title;
            $vehicle->category_id = $request->type;
            $vehicle->makes_id = $request->make_id;
            $vehicle->models_id = $request->model_id;
            $vehicle->badge_id = $request->badge_id;
            $vehicle->series_id = $request->series_id;
            $vehicle->body_styles_id = $request->body_type_id;
            $vehicle->fuel_types_id = $request->fuel_type_id;
            $vehicle->drive_types_id = $request->drive_type_id;
            $vehicle->transmissions_id = $request->transmission_id;
            $vehicle->doors = $request->doors;
            $vehicle->seats = $request->seats;
            $vehicle->gears = $request->gears;
            $vehicle->cylinders_id = $request->cylinders;
            $vehicle->month_build = $request->month_built;
            $vehicle->year_build = $request->year_built;
            $vehicle->turbo = $request->turbo;
            $vehicle->engine_capacity = $request->engine_capacity;
            $vehicle->chassis_number = $request->chassis_number;
            if ($vehicle->steps < 1) {
                $vehicle->steps = 1;
            }
            // save vehicle
            if ($vehicle->save()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "slug" => $vehicle->slug,
                            "message" => __('frontend.VEHICLE_GENERAL_INFO_SAVED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        }catch(\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()//__('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Store or update resource in storage.
     *
     * @param  \App\Http\Requests\Frontend\VehicleFeaturesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function manageFeatures(VehicleFeaturesRequest $request) {
        try {
            \DB::beginTransaction();
            $vehicle = Vehicle::where('user_id', \Auth::guard('user')->id())
                    ->whereSlug($request->vehicle_slug)
                    ->first();
            $vehicle->vehicleFeatures()->sync($request->features);
            if ($vehicle->steps < 2) {
                $vehicle->steps = 2;
            }
            // save vehicle
            if ($vehicle->save()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "slug" => $vehicle->slug,
                            "message" => __('frontend.VEHICLE_FEATURES_SAVED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __($e->getMessage())
                            ], 200);
        }
    }

    /**
     * Store or update resource in storage.
     *
     * @param  \App\Http\Requests\Frontend\VehicleDetailsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function manageDetails(VehicleDetailsRequest $request) {
        try {
            \DB::beginTransaction();
            $vehicle = Vehicle::where('user_id', \Auth::guard('user')->id())
                    ->whereSlug($request->vehicle_slug)
                    ->first();
            // save detail
            $vehicle->address = $request->address;
            $vehicle->country = $request->country;
            $vehicle->state = $request->state;
            $vehicle->city = $request->city;
            $vehicle->postcode = $request->postcode;
            $vehicle->latitude = $request->latitude;
            $vehicle->longitude = $request->longitude;
            $vehicle->odometer = $request->odometer;
            $vehicle->price = $request->sale_price;
            $vehicle->discount_price = $request->discounted_price;
            $vehicle->interior_colour_id = $request->interior_color_id;
            $vehicle->exterior_colour_id = $request->exterior_color_id;
            $vehicle->lifestyle_id = $request->lifestyle_id;
            $vehicle->plate_number = $request->registration_plate_number;
            $vehicle->expiry_month = $request->registration_expiry_month;
            $vehicle->expiry_year = $request->registration_expiry_year;
            $vehicle->fuel_economy_id = $request->fuel_economy_id;
            $vehicle->phone = $request->contact_phone_number;
            $vehicle->written_off = $request->is_written_off;
            $vehicle->is_registered = $request->is_car_registered;
            // prepair locales
            $vehicle->translations()->delete();
            $vehicle->translations()->saveMany([
                new \Modules\VehicleManager\Entities\VehicleTranslation([
                    "locale" => 'en',
                    "description" => $request->english_comment
                        ]),
                new \Modules\VehicleManager\Entities\VehicleTranslation([
                    "locale" => 'kh',
                    "description" => $request->khmer_comment
                        ])
            ]);

            if ($vehicle->steps < 3) {
                $vehicle->steps = 3;
            }
            // save vehicle
            if ($vehicle->save()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "slug" => $vehicle->slug,
                            "message" => __('frontend.VEHICLE_DETAILS_SAVED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Store or update resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function managePhotos(Request $request) {
        try {
            \DB::beginTransaction();
            $vehicle = Vehicle::where('user_id', \Auth::guard('user')->id())
                    ->whereSlug($request->vehicle_slug)
                    ->first();
            // save detail
            if ($vehicle->steps < 4) {
                $vehicle->steps = 4;
            }
            // save vehicle
            if ($vehicle->save()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "slug" => $vehicle->slug,
                            "message" => __('frontend.VEHICLE_PHOTOS_SAVED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Save photos in storage.
     *
     * @param  \App\Http\Requests\Frontend\VehiclePhotosRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function savePhotos(VehiclePhotosRequest $request) {
        try {
            \DB::beginTransaction();
            $vehicle = Vehicle::where('user_id', \Auth::guard('user')->id())
                    ->whereSlug($request->vehicle_slug)
                    ->first();
            if ($request->has('image_id')) {
                $image = VehicleImage::find($request->image_id);
                // delete old image
                \Storage::disk('public')->delete('vehicle/' . $image->image);
            } else {
                $image = new VehicleImage();
            }
            $file = $request->file('file');

            // create image
            $img = \Image::make($file);
            // and insert a watermark for example
            $img->insert(public_path('frontend/images/watermark.png'), 'bottom-right', 50, 50);
            // Store img
            $fileName = ($vehicle->vehicle_images->count() + 1) . '_' . $file->getClientOriginalName();
            //$img = \Storage::disk('public')->put('vehicle/'.$fileName, $img);
            $img->save(public_path('storage/vehicle/') . $fileName);
            $image->vehicle_id = $vehicle->id;
            $image->image = $fileName;
            if ($vehicle->vehicle_images->count() === 0) {
                $image->image_type = 'front';
            } else {
                $image->image_type = 'rear';
            }
            $image->sort_order = ($vehicle->vehicle_images->count() + 1);
            $image->caption = "image";
            // save vehicle image
            if ($image->save()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "id" => $image->id,
                            "message" => __('frontend.VEHICLE_PHOTOS_SAVED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()//__('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Delete resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function deletePhotos(Request $request, VehicleImage $vehicleImage) {
        try {
            \DB::beginTransaction();
            // delete old image
            \Storage::disk('public')->delete('vehicle/' . $vehicleImage->image);
            // delete vehicle image
            if ($vehicleImage->delete()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.VEHICLE_PHOTOS_DELETED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Mark as cover photo in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function markAsCoverPhotos(Request $request) {
        try {
            \DB::beginTransaction();
            $vehicle = Vehicle::where('user_id', \Auth::guard('user')->id())
                    ->whereSlug($request->vehicle_slug)
                    ->first();
            $image = VehicleImage::find($request->image_id);

            if ($vehicle && $image) {
                if ($vehicle->vehicle_images->isNotEmpty()) {
                    foreach ($vehicle->vehicle_images as $vehicleImage) {
                        $vehicleImage->image_type = ($vehicleImage->id == $image->id) ? 'front' : 'rear';
                        $vehicleImage->save();
                    }

                    // DB commit
                    \DB::commit();
                }

                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.VEHICLE_PHOTO_MARKED_AS_COVER')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()//__('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * 
     * @param  \Illuminate\Http\Request  $request
     * @param string  $slug
     * @return \Illuminate\Http\Response
     */
    public function deleteVehicle(Request $request, $slug) {
        try {
            \DB::beginTransaction();
            if (Vehicle::where('user_id', \Auth::guard('user')->id())
                            ->where('slug', $slug)
                            ->delete()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.VEHICLE_DELETE_SUCCESS')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $ex) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Toggle favourite cars in storage.
     *
     * @param  vehicalid  $id
     * @return \Illuminate\Http\Response
     */
    public function toogleFavourite($id) {
        try {
            \DB::beginTransaction();
            if (\Auth::guard('user')->check()) {
                $user = \Auth::guard('user')->user();
                $vehicle = Vehicle::find($id);

                if ($user && $vehicle) {
                    if ($user->id == $vehicle->user_id) {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.VEHICLE_FAVOURITE_SELF_WARNING')
                                        ], 200);
                    } else {
                        if ($user->favouriteVehicles()->where('vehicle_id', $id)->exists()) {
                            if ($vehicle->is_my_favourite) {
                                $user->favouriteVehicles()->updateExistingPivot($id, ['is_favourite' => 0]);
                                \DB::commit();
                                return response()->json([
                                            "status" => "success",
                                            "is_favourite" => false,
                                            "message" => __('frontend.VEHICLE_FAVOURITE_UNSAVED')
                                                ], 200);
                            } else {
                                $user->favouriteVehicles()->updateExistingPivot($id, ['is_favourite' => 1]);
                                \DB::commit();
                                return response()->json([
                                            "status" => "success",
                                            "is_favourite" => true,
                                            "message" => __('frontend.VEHICLE_FAVOURITE_SAVED')
                                                ], 200);
                            }
                        } else {
                            $user->favouriteVehicles()->attach($id, ['is_favourite' => 1]);
                            \DB::commit();
                            return response()->json([
                                        "status" => "success",
                                        "is_favourite" => true,
                                        "message" => __('frontend.VEHICLE_FAVOURITE_SAVED')
                                            ], 200);
                        }
                    }
                }
            } else {
                return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.VEHICLE_FAVOURITE_AUTH_WARNING')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     *  REPORT ADS FOR VEHICLE in storage.
     *
     * @param  App\Http\Requests\Frontend\VehicleReportRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function reportAd(VehicleReportRequest $request) {
        try {
            $vehicle = Vehicle::select('id', 'user_id', 'title')->find($request->vehicle_id);
            if ($vehicle) {
                if (\Auth::guard('user')->check()) {
                    $user = \Auth::guard('user')->user();
                    if ($user->id == $vehicle->user_id) {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.REPORT_AD_SELF_VEHICLE')
                                        ], 200);
                    }
                } else {
                    $user = \App\User::where('phone', $request->phone)->first(['id']);
                    if ($user) {
                        if ($user->id == $vehicle->user_id) {
                            return response()->json([
                                        "status" => "warning",
                                        "message" => __('frontend.REPORT_AD_SELF_VEHICLE')
                                            ], 200);
                        }
                    }
                }

                if (!empty(config('get.ADMIN_EMAIL'))) {
                    \Mail::to(config('get.ADMIN_EMAIL'))->send(new VehicleReportAdMail($vehicle, $request));
                }
                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.REPORT_AD_LOGGED')
                                ], 200);
            }

            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $ex) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     *  REPORT ADS FOR VEHICLE in storage.
     *
     * @param  App\Http\Requests\Frontend\VehicleReviewRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function saveReview(VehicleReviewRequest $request) {
        try {
            \DB::beginTransaction();
            $vehicle = Vehicle::select('id', 'user_id', 'title')->find($request->vehicle_id);
            if ($vehicle) {
                if (\Auth::guard('user')->check()) {
                    $user = \Auth::guard('user')->user();
                    if ($user->id == $vehicle->user_id) {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.REVIEW_SELF_VEHICLE')
                                        ], 200);
                    } else {
                        $review = new \Modules\VehicleReviewsManager\Entities\VehicleReview($request->all());
                        $review->user_id = $user->id;
                        // save vehicle review
                        if ($review->save()) {
                            // DB commit
                            \DB::commit();
                            return response()->json([
                                        "status" => "success",
                                        "message" => __('frontend.VEHICLE_REVIEW_SAVED')
                                            ], 200);
                        }
                    }
                } else {
                    return response()->json([
                                "status" => "warning",
                                "message" => __('frontend.REVIEW_AUTH_WARNING')
                                    ], 200);
                }
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()//__('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * dESC : USER VEHICLE MARK AS FEATURED
     * @param Request $request
     * @return type
     */
    public function vehicleMarkFeatured(Request $request) {
        try {
            \DB::beginTransaction();
            if (\Auth::guard('user')->check()) {
                $user = \Auth::guard('user')->user();
                $FeaturedArr = [];
                if ($request->vehicleId) {

                    foreach ($request->vehicleId as $vehicle_id) {
                        if (!Vehicle::where('id', $vehicle_id)->where('is_approved', 1)->exists()) {

                            return response()->json([
                                        "status" => "warning",
                                        "message" => __('frontend.VEHICLE_NOT_APPROVE')
                                            ], 200);
                        }
                        if (!$user->userFeaturedVehicles()->where('vehicle_id', $vehicle_id)->exists()) {
                            $FeaturedArr[] = new \Modules\VehicleManager\Entities\UserFeaturedVehicle(['vehicle_id' => $vehicle_id]);
                        }
                    }
                    if ($FeaturedArr) {
                        if ($user->userFeaturedVehicles()->saveMany($FeaturedArr)) {
                            // DB commit
                            \DB::commit();
                            return response()->json([
                                        "status" => "success",
                                        "message" => __('frontend.VEHICLE_FEATURED_SAVED')
                                            ], 200);
                        }
                    } else {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.VEHICLE_ALREADY_FEATURED_SAVED')
                                        ], 200);
                    }
                }
            } else {
                return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.OOPS')
                                ], 200);
            }
        } catch (Exception $ex) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()
                            ], 200);
        }
    }

    /**
     * dESC : USER VEHICLE MARK AS ON SALE
     * @param Request $request
     * @return type
     */
    public function vehicleMarkOnSale(Request $request) {
        try {
            \DB::beginTransaction();
            if (\Auth::guard('user')->check()) {
                $user = \Auth::guard('user')->user();
                $OnsaleArr = [];
                if ($request->vehicleId) {
                    foreach ($request->vehicleId as $vehicle_id) {
                        if (!Vehicle::where('id', $vehicle_id)->where('is_approved', 1)->exists()) {

                            return response()->json([
                                        "status" => "warning",
                                        "message" => __('frontend.VEHICLE_NOT_APPROVE')
                                            ], 200);
                        }

                        if (!$user->userOnsaleVehicles()->where('vehicle_id', $vehicle_id)->exists()) {
                            $OnsaleArr[] = new \Modules\VehicleManager\Entities\UserOnsaleVehicle(['vehicle_id' => $vehicle_id]);
                        }
                    }
                    if ($OnsaleArr) {
                        if ($user->userOnsaleVehicles()->saveMany($OnsaleArr)) {
                            // DB commit
                            \DB::commit();
                            return response()->json([
                                        "status" => "success",
                                        "message" => __('frontend.VEHICLE_ONSALE_SAVED')
                                            ], 200);
                        }
                    } else {
                        return response()->json([
                                    "status" => "success",
                                    "message" => __('frontend.VEHICLE_ALREADY_ONSALE_SAVED')
                                        ], 200);
                    }
                }
            } else {
                return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.OOPS')
                                ], 200);
            }
        } catch (Exception $ex) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()
                            ], 200);
        }
    }

    /**
     * dESC : USER VEHICLE MARK AS FEATURED
     * @param Request $request
     * @return type
     */
    public function vehicleMarkUntilSold(Request $request) {
        try {
            \DB::beginTransaction();
            if (\Auth::guard('user')->check()) {
                $user = \Auth::guard('user')->user();
                $untilSoldArr = [];
                if ($request->vehicleId) {
                    foreach ($request->vehicleId as $vehicle_id) {
                        if (!Vehicle::where('id', $vehicle_id)->where('is_approved', 1)->exists()) {

                            return response()->json([
                                        "status" => "warning",
                                        "message" => __('frontend.VEHICLE_NOT_APPROVE')
                                            ], 200);
                        }
                        if (!$user->userUntilsoldVehicles()->where('vehicle_id', $vehicle_id)->exists()) {
                            $untilSoldArr[] = new \Modules\VehicleManager\Entities\UserUntilsoldVehicle(['vehicle_id' => $vehicle_id]);
                        }
                    }
                    if ($untilSoldArr) {
                        if ($user->userUntilsoldVehicles()->saveMany($untilSoldArr)) {
                            // DB commit
                            \DB::commit();
                            return response()->json([
                                        "status" => "success",
                                        "message" => __('frontend.VEHICLE_UNTIL_SOLD_SAVED')
                                            ], 200);
                        }
                    } else {
                        return response()->json([
                                    "status" => "success",
                                    "message" => __('frontend.VEHICLE_ALREADY_UNTIL_SOLD_SAVED')
                                        ], 200);
                    }
                }
            } else {
                return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.OOPS')
                                ], 200);
            }
        } catch (Exception $ex) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()
                            ], 200);
        }
    }

    /**
     * USER VEHICLE REMOVE FEATURED
     * @param type $vehicleId
     * @return type
     */
    public function removeFeatured($vehicleId) {
        try {
            \DB::beginTransaction();
            if (\Auth::guard('user')->check()) {
                $user = \Auth::guard('user')->user();

                if ($vehicleId) {

                    if ($user->userFeaturedVehicles()->where('vehicle_id', $vehicleId)->delete()) {
                        // DB commit
                        \DB::commit();
                        return response()->json([
                                    "status" => "success",
                                    "message" => __('frontend.VEHICLE_REMOVED_FEATURED_LIST')
                                        ], 200);
                    }
                }
            } else {
                return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.OOPS')
                                ], 200);
            }
        } catch (Exception $ex) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()
                            ], 200);
        }
    }

    /**
     * USER VEHICLE MARKED FEATURED
     * @param type $vehicleId
     * @return type
     */
    public function markFeatured($vehicleId) {
        try {
            \DB::beginTransaction();
            if (\Auth::guard('user')->check()) {
                $user = \Auth::guard('user')->user();

                if ($vehicleId) {
                    if (!Vehicle::where('id', $vehicleId)->where('is_approved', 1)->exists()) {

                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.VEHICLE_NOT_APPROVE')
                                        ], 200);
                    }
                    $featured = new \Modules\VehicleManager\Entities\UserFeaturedVehicle();
                    $featured->vehicle_id = $vehicleId;
                    if ($user->userFeaturedVehicles()->save($featured)) {
                        // DB commit
                        \DB::commit();
                        return response()->json([
                                    "status" => "success",
                                    "message" => __('frontend.VEHICLE_FEATURED_SAVED')
                                        ], 200);
                    }
                }
            } else {
                return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.OOPS')
                                ], 200);
            }
        } catch (Exception $ex) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()
                            ], 200);
        }
    }

    /**
     * USER VEHICLE REMOVE ON SALE LIST
     * @param type $vehicleId
     * @return type
     */
    public function removeOnSaleList($vehicleId) {
        try {
            \DB::beginTransaction();
            if (\Auth::guard('user')->check()) {
                $user = \Auth::guard('user')->user();

                if ($vehicleId) {

                    if ($user->userOnsaleVehicles()->where('vehicle_id', $vehicleId)->delete()) {
                        // DB commit
                        \DB::commit();
                        return response()->json([
                                    "status" => "success",
                                    "message" => __('frontend.VEHICLE_REMOVED_ONSALE_LIST')
                                        ], 200);
                    }
                }
            } else {
                return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.OOPS')
                                ], 200);
            }
        } catch (Exception $ex) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()
                            ], 200);
        }
    }

    /**
     * USER VEHICLE MARKED ON SALE LIST
     * @param type $vehicleId
     * @return type
     */
    public function markOnSale($vehicleId) {
        try {
            \DB::beginTransaction();
            if (\Auth::guard('user')->check()) {
                $user = \Auth::guard('user')->user();

                if ($vehicleId) {
                    if (!Vehicle::where('id', $vehicleId)->where('is_approved', 1)->exists()) {

                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.VEHICLE_NOT_APPROVE')
                                        ], 200);
                    }
                    $onSale = new \Modules\VehicleManager\Entities\UserOnsaleVehicle();
                    $onSale->vehicle_id = $vehicleId;
                    if ($user->userOnsaleVehicles()->save($onSale)) {
                        // DB commit
                        \DB::commit();
                        return response()->json([
                                    "status" => "success",
                                    "message" => __('frontend.VEHICLE_ONSALE_SAVED')
                                        ], 200);
                    }
                }
            } else {
                return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.OOPS')
                                ], 200);
            }
        } catch (Exception $ex) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()
                            ], 200);
        }
    }

    /**
     * USER VEHICLE REMOVE ON UNTIL SOLD
     * @param type $vehicleId
     * @return type
     */
    public function removeUntilSoldList($vehicleId) {
        try {
            \DB::beginTransaction();
            if (\Auth::guard('user')->check()) {
                $user = \Auth::guard('user')->user();

                if ($vehicleId) {

                    if ($user->userUntilsoldVehicles()->where('vehicle_id', $vehicleId)->delete()) {
                        // DB commit
                        \DB::commit();
                        return response()->json([
                                    "status" => "success",
                                    "message" => __('frontend.VEHICLE_REMOVED_UNTIL_SOLD_LIST')
                                        ], 200);
                    }
                }
            } else {
                return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.OOPS')
                                ], 200);
            }
        } catch (Exception $ex) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()
                            ], 200);
        }
    }

    /**
     * USER VEHICLE MARKED ON UNTIL SOLD
     * @param type $vehicleId
     * @return type
     */
    public function markUntilSold($vehicleId) {
        try {
            \DB::beginTransaction();
            if (\Auth::guard('user')->check()) {
                $user = \Auth::guard('user')->user();

                if ($vehicleId) {
                    if (!Vehicle::where('id', $vehicleId)->where('is_approved', 1)->exists()) {

                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.VEHICLE_NOT_APPROVE')
                                        ], 200);
                    }
                    $onSale = new \Modules\VehicleManager\Entities\UserUntilsoldVehicle();
                    $onSale->vehicle_id = $vehicleId;
                    if ($user->userUntilsoldVehicles()->save($onSale)) {
                        // DB commit
                        \DB::commit();
                        return response()->json([
                                    "status" => "success",
                                    "message" => __('frontend.VEHICLE_UNTIL_SOLD_SAVED')
                                        ], 200);
                    }
                }
            } else {
                return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.OOPS')
                                ], 200);
            }
        } catch (Exception $ex) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()
                            ], 200);
        }
    }

}
