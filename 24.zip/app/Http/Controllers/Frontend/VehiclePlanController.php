<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\SubscriptionRepository;

class VehiclePlanController extends Controller
{
    /**
     * Subscription repository.
     *
     * @var string
     */
    private $subscriptionRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(SubscriptionRepository $subscriptionRepository){
        $this->subscriptionRepository = $subscriptionRepository;
    }
    
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request){
        try{
            $user = $request->user('user');
            $userSubscriptions = $user->subscriptions;

            if($userSubscriptions->isNotEmpty()){
                $currentSubscription = $userSubscriptions->last();
                if($user->subscribed($currentSubscription->name)){
                    return redirect()->route('frontend.vehicle.create');
                }
            }
            $roles = $user->roles->pluck('name');
            $plans = $this->subscriptionRepository->getSubscriptionPlansAsPerUserRoles($roles); 
            return view('frontend.user.manage-ad.plans', compact('plans'));
        }catch(\Exception $e){
            abort(500);
        }
    }
}
