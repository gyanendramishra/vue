<?php

namespace App\Http\Views\Composers;

use Illuminate\View\View;
use Illuminate\Http\Request;
use App\Repositories\VehicleRepository;

class VehicleComposer
{

    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(VehicleRepository $vehicleRepository)
    {
        $this->vehicleRepository = $vehicleRepository;
    }

    /**
     * Bind data to the view.
     *
     * @param  View  $view
     * @return void
     */
    public function compose(View $view)
    {
        /* Get makes */
        $makes = $this->vehicleRepository->getAllMake();

        /* Get body types */
        $bodyTypes = $this->vehicleRepository->getAllBodyType();
        
        $view->with([
            'makes'=> $makes,
            'bodyTypes'=> $bodyTypes
        ]);
    }
}