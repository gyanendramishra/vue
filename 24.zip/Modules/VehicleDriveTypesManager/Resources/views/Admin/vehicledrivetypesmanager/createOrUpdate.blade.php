@extends('layouts.admin.app')
@section('title', !empty($vehicledrivetypes) ? 'Edit Vehicle Drive Types' : 'Add Vehicle Drive Types')
@section('content')
<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.vehicledrivetypesmanager.index'],['label' => !empty($vehicledrivetypes) ? 'Edit Vehicle Drive Types' : 'Add Vehicle Drive Types' ]]]) }}
    </div>
</div>

<div class="wojo-grid">

    @if(session()->has('success'))
    <div class="alert alert-success">
        {{ session()->get('success') }}
    </div>
    @endif

    <div class="wojo form segment">
        <div class="wojo secondary icon message"> 
            <div class="content">
                <div class="header">  {{ !empty($vehicledrivetypes) ? 'Edit Vehicle Drive Types' : 'Add Vehicle Drive Types' }} </div>
                <!-- <p>Here you can edit your vehicle make </p> -->
            </div>
        </div>
        @if(isset($vehicledrivetypes))

        {{ Form::model($vehicledrivetypes, ['route' => ['admin.vehicledrivetypesmanager.update', $vehicledrivetypes->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}

        @else

        {{ Form::open(['route' => 'admin.vehicledrivetypesmanager.store','enctype'=>'multipart/form-data']) }}

        @endif

        @php

        $locales = config('app.locales');

        @endphp

        @include('layouts.flash.alert')

        <div class="wojo secondary message">

            <ul class="wojo tabs fixed clearfix">
                @foreach($locales as $key=>$val)
                <li class="{{ ($key=='en')?'active':'' }}">
                    <a data-tab="#{{ $key.'_tab' }}" class="{{ ($key=='en')?'active show':'' }}">
                        {{ $val }}
                    </a>
                </li>
                @endforeach
            </ul>

            <div class="container">

                @foreach($locales as $key=>$val)
                <div id="{{ $key.'_tab' }}" class="wojo tab item " style="{{ ($key=='en')?'display: block;':'' }}">
                    <div class="two fields">
                        <div class="field">

                            <div class="form-group required {{ $errors->has($key.'_name') ? 'has-error' : '' }}">
                                <label for="name">{{ __('Name') }} </label>

                                {{ Form::text($key.'_name',old($key.'_name', (isset($vehicledrivetypes))?$vehicledrivetypes->translate($key)['name']:"") , ['class' => '','placeholder' => 'Name']) }}

                                @if($errors->has($key.'_name'))
                                <span class="help-block">{{ $errors->first('status') }}</span>
                                @endif
                            </div>
                        </div>

                    </div>
                </div>
                @endforeach

            </div>

            <div class="container">
                <div class="two fields">
                    <div class="field">
                        <div class="form-group required {{ $errors->has('status') ? 'has-error' : '' }}">
                            <label for="status">{{ __('Status') }} </label>
                            {{ Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => '']) }}

                            @if($errors->has('status'))
                            <span class="help-block">{{ $errors->first('status') }}</span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <div class="wojo fitted divider"></div>
            <div class="wojo footer">
                <button type="submit" data-action="updateAccount" name="dosubmit" class="wojo positive button">Save</button>
                <a href="{{ route('admin.vehicledrivetypesmanager.index') }}" class="wojo negative button" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
            </div>
        </div>

        {{ Form::close() }}
    </div>
</div>
@stop