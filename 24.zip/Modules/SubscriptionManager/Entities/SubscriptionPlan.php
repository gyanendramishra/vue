<?php

namespace Modules\SubscriptionManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use \Dimsav\Translatable\Translatable;

class SubscriptionPlan extends Model {

    use Translatable,
        Sluggable;

    const ACTIVE = 1;
    const IN_ACTIVE = 0;

    public $translatedAttributes = [
        "type", 
        "title", 
        "description"
    ];
    protected $fillable = [
        "stripe_id", 
        "plan_title", 
        "user_type",
        "plan_type", 
        "duration", 
        "duration_type", 
        "price", 
        "total_on_sale_count", 
        "sort_order", 
        "total_featured_count", 
        "count_of_until_sold", 
        "minimum_price", 
        "total_listing_count", 
        "image", 
        "status"
    ];

    /**
     * Scope a query to only include active competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query) {
        return $query->where('status', self::ACTIVE);
    }

    /**
     * Scope a query to include given type of competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfActive($query, $type) {
        return $query->whereStatus($type);
    }

    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function sluggable() {
        return [
            'slug' => [
                'source' => 'title'
            ]
        ];
    }

    /* 07-01 */

    public function SubscriptionPlanTranslation() {

        return $this->hasMany(\Modules\SubscriptionManager\Entities\SubscriptionPlanTranslation::class, 'subscription_plan_id', 'id');
    }

}
