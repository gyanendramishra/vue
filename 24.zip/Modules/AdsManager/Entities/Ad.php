<?php

namespace Modules\AdsManager\Entities;

use Illuminate\Database\Eloquent\Model;
use \Dimsav\Translatable\Translatable;

class Ad extends Model {

    use Translatable;

    const ACTIVE = 1;
    const IN_ACTIVE = 0;

    protected $appends = ['image_full_path'];
    protected $table = 'adsence_advertisements';
    protected $fillable = ["page_location_id", "position_id", "status"];
    public $translatedAttributes = ["title", "description", "image", 'image_type', 'image_scripts', 'url'];

    /**
     * Get the position that owns the ad.
     *
     */
    public function position() {

        return $this->belongsTo(\App\Position::class, 'position_id', 'id');
    }

    /**
     * Get the page location that owns the ad.
     *
     */
    public function page_location() {

        return $this->belongsTo(\App\PageLocation::class, 'page_location_id', 'id');
    }

    /**
     * Scope a query to only include active competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query) {
        return $query->where('status', self::ACTIVE);
    }

    /**
     * Scope a query to include given type of competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfActive($query, $type) {
        return $query->whereStatus($type);
    }

    public function getImageFullPathAttribute() {
        return url('uploads/adsImages/' . $this->image);
    }

    
    /* 07-01 */
    public function adTranslations() 
    {

        return $this->hasMany(\Modules\AdsManager\Entities\AdTranslation::class, 'ad_id', 'id');
    }

}
