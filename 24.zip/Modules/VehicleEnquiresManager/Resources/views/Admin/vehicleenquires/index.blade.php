@extends('layouts.admin.app')

@push('styles')
{!! Html::style('/css/bootstrap.min.css') !!}
{!! Html::style('css/datatables.net-bs/dataTables.bootstrap.min.css') !!}
@endpush
@section('content')
<div id="crumbs" class="clearfix"> 
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> \Request::route()->getName()]]]) }}
    </div>
</div>
<div class="wojo-grid">
    <div class="wojo secondary icon message">
        <div class="content">
            <div class="header">  {{ __( 'Manage Vehicles Enquires' ) }}  
            </div>

        </div>
    </div>
    <div class="wojo quaternary segment">

    </div>

    <div class="wojo tertiary segment">
        <div class="header clearfix"><span>{{ __('List Vehicle Enquires') }}</span>
        </div>

        {{ Form::hidden('searchslug', '',array('id'=>'searchslug')) }}

        <table class="wojo sortable table"  id="vehicle_enquires-datatable" data-table="vehicle_enquires">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>                           
                    <th>Email</th>                          
                    <th>Phone</th>                          
                    <th>Postcode</th>                           
                    <th>Details</th>                            
                   <!--  <th>Status</th>
                    <th>Is Responded</th> -->
                    <th>Created At</th>
                    <th class="no-sort">Action</th>
                </tr>
            </thead>
        </table>


    </div>
    <div id="msgholder"></div>
</div>
@stop

@push('scripts')


<script type="text/javascript">
    jQuery(function ($) {
        var t = $('#vehicle_enquires-datatable').DataTable({
            processing: true,
            serverSide: true,
            order: [[0, "desc"]],
            language: {

                sLengthMenu: "_MENU_",
                search: "<i class='find icon'></i>",
                searchPlaceholder: "Search...",

            },
            ajax: {
                url: "{{ route('admin.vehicleenquires.ajax.list') }}",
                type: 'GET',
                data: function (d) {


                    d.slug = $('#searchslug').val();
                }
            },
            columns: [
                {data: 'id', name: 'id'},
                {data: 'name', name: 'name'},
                {data: 'email', name: 'email'},
                {data: 'phone', name: 'phone'},
                {data: 'postcode', name: 'postcode'},
                {data: 'details', name: 'details'},
                /*{data: 'status', name: 'status'},
                 {data: 'is_responded', name: 'is_responded'},*/
                {data: 'created_at', name: 'created_at'},
                {data: 'action', name: 'action'}
            ],
            "deferRender": true,
            "columnDefs": [
                {
                    "targets": 'no-sort',
                    "orderable": false,
                },
                {
                    "targets": 6,
                    "data": "created_at",
                    "render": function (data, type, full, meta) {
                        return moment(data).format('DD MMMM, YYYY ');
                    }
                },
                        /*{
                         
                         "targets": 7,
                         "data": "is_responded",
                         "render": function (data, type, full, meta) {
                         return '<input id="is_responded" class="switch-is_responded change-request" data-id="'+full.id+'" data-field="is_responded" data-size="mini" '+ ((data == true)?'checked':'') +' name="is_responded" type="checkbox">';
                         }
                         },
                         {
                         
                         "targets": 6,
                         "data": "status",
                         "render": function (data, type, full, meta) {
                         return '<input id="status" class="switch-status change-request" data-id="'+full.id+'" data-field="status" data-size="mini" '+ ((data == true)?'checked':'') +' name="status" type="checkbox">';
                         }
                         }*/
            ],
            "fnDrawCallback": function (settings) {

                $('input.switch-status').not('[data-switch-no-init]').bootstrapSwitch();
                $('[data-toggle="tooltip"]').tooltip();

                $('.switch-status.change-request').on('switchChange.bootstrapSwitch', function (e, state) {
                    var _this = $(this);
                    var _id = _this.data("id")
                    var table = _this.closest("table").data("table");
                    if (e.target.checked == true) {
                        var changedval = 1;
                    } else {
                        var changedval = 0;
                    }
                    changeStatus(table, _id, changedval, _this);
                });

                // Is responce
                $('input.switch-is_responded').not('[data-switch-no-init]').bootstrapSwitch();

                $('.switch-is_responded.change-request').on('switchChange.bootstrapSwitch', function (e, state) {
                    var _this = $(this);
                    var _id = _this.data("id")
                    var table = _this.closest("table").data("table");
                    if (e.target.checked == true) {
                        var changedval = 1;
                    } else {
                        var changedval = 0;
                    }
                    changeStatus(table, _id, changedval, _this);
                });
            }


        })
        t.on('order.dt search.dt', function () {
            t.column(0, {search: 'applied', order: 'applied'}).nodes().each(function (cell, i) {
                cell.innerHTML = i + 1;
            });
        });
        $('#statuss').on('change', function () {

            $('#vehicle_enquires-datatable').DataTable().draw(true);
        });

        var alphabet = $('<div class="alphabet"/>').append('Search: ');

        $('<span class="clear active"/>')
                .data('letter', '')
                .html('None')
                .appendTo(alphabet);

        for (var i = 0; i < 26; i++) {

            var letter = String.fromCharCode(65 + i);

            $('<span/>')
                    .data('letter', letter)
                    .html(letter)
                    .appendTo(alphabet);
        }

        alphabet.insertBefore(t.table().container());

        alphabet.on('click', 'span', function () {

            alphabet.find('.active').removeClass('active');
            $(this).addClass('active');
            _alphabetSearch = $(this).data('letter').toLowerCase();
            $("#searchslug").val(_alphabetSearch);

            t.draw();
        });
    })
</script>
@endpush