@extends('layouts.admin.app')
@section('title', !empty($vehiclebadge) ? 'Edit Vehicle Badge' : 'Add Vehicle Badge')
@section('content')
<div id="crumbs" class="clearfix"> 
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.vehiclebadgemanager.index'],['label' => !empty($vehiclebadge) ? 'Edit Vehicle Badge' : 'Add New Vehicle Badge' ]]]) }}
    </div>
</div>

<div class="wojo-grid">

    @if(session()->has('success'))
    <div class="alert alert-success">
        {{ session()->get('success') }}
    </div>
    @endif

    <div class="wojo form segment">
        <div class="wojo secondary icon message"> 
            <div class="content">
                <div class="header">  {{ !empty($vehiclebadge) ? 'Edit Vehicle Badge' : 'Add Vehicle Badge' }} </div>
                <!-- <p>Here you can edit your vehicle model </p> -->
            </div>
        </div>

        @if(isset($vehiclebadge))

        {{ Form::model($vehiclebadge, ['route' => ['admin.vehiclebadgemanager.update', $vehiclebadge->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}
        
        @else

        {{ Form::open(['route' => 'admin.vehiclebadgemanager.store','enctype'=>'multipart/form-data']) }}

        @endif

        @php

        $locales = config('app.locales');

        @endphp

        @include('layouts.flash.alert')

        <div class="wojo secondary message">

            <ul class="wojo tabs fixed clearfix">
                @foreach($locales as $key=>$val)
                <li class="{{ ($key=='en')?'active':'' }}">
                    <a data-tab="#{{ $key.'_tab' }}" class="{{ ($key=='en')?'active show':'' }}">
                        {{ $val }}
                    </a>
                </li>
                @endforeach
            </ul>



            <div class="container">

                <div class="two fields">
                    <div class="field required {{ $errors->has('status') ? 'has-error' : '' }}">

                        <label for="status">{{ __('Choose Make') }} </label>
                        {{ Form::select('makes_id', $make, old('makes_id') , ['id'=>'makes_id','class' => 'form-control', 'placeholder' => 'Choose Make']) }} 

                        @if($errors->has('makes_id'))
                        <span class="help-block">{{ $errors->first('makes_id') }}</span>
                        @endif

                    </div>


                    <div class="field required {{ $errors->has('models_id') ? 'has-error' : '' }}">

                        <label for="status">{{ __('Choose Model') }} </label>

                        {{ Form::select('models_id', [''=>'Choose Model'], isset($vehiclebadge)?$vehiclebadge->models_id:'', ['id'=>'models_id','class' => 'form-control']) }}

                        @if($errors->has('models_id'))
                        <span class="help-block">{{ $errors->first('models_id') }}</span>
                        @endif

                    </div>
                </div>

                <div class="two fields">
                    <div class="field required {{ $errors->has('status') ? 'has-error' : '' }}">

                        <label for="status">{{ __('Status') }} </label>
                        {{ Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control']) }}

                        @if($errors->has('status'))
                        <span class="help-block">{{ $errors->first('status') }}</span>
                        @endif

                    </div>

                    <div class="field {{ $errors->has('icon') ? 'has-error' : '' }}">
                        <label for="status">{{ __('Icon') }} </label>
                        @if($errors->has('icon'))
                        <span class="help-block">{{ $errors->first('icon') }}</span>
                        @endif
                    </div>

                    @php

                    $filepath = '/uploads/badge/';
                    @endphp

                    @if(!empty(@$vehiclebadge->icon) && file_exists(public_path() . $filepath . @$vehiclebadge->icon))

                    <?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url($filepath . @$vehiclebadge->icon), '150', '60', '100'); ?>
                    <?php $imageurl1 = $filepath . @$vehiclebadge->icon; ?>

                    @endif


                    @php

                    if(isset($vehiclebadge->icon) &&  $vehiclebadge->icon!='') {

                    $path=public_path('uploads/badge/'.$vehiclebadge->icon);

                    } else {

                    $path='';
                    }
                    @endphp

                    @if(file_exists($path))


                    <input type="file" name="image" data-type="image" data-exist="{{ URL::asset('/uploads/badge/'.@$vehiclebadge->icon) }}" accept="image/png, image/jpeg">

                    @else

                    <input type="file" name="icon" data-type="image" data-exist="{{ URL::asset('/images/migration/no-image.png') }}" accept="image/png, image/jpeg">
                    @endif
                </div>
            </div>


        </div>

        <div class="container">

            @foreach($locales as $key=>$val)
            <div id="{{ $key.'_tab' }}" class="wojo tab item " style="{{ ($key=='en')?'display: block;':'' }}">
                <div class="two fields">
                    <div class="field">

                        <div class="form-group required {{ $errors->has($key.'_name') ? 'has-error' : '' }}">
                            <label for="name">{{ __('Name') }} </label>

                            {{ Form::text($key.'_name',old($key.'_name', (isset($vehiclebadge))?$vehiclebadge->translate($key)['name']:""), ['class' => '','placeholder' => 'Name']) }}

                            @if($errors->has($key.'_name'))
                            <span class="help-block">{{ $errors->first($key.'_name') }}</span>
                            @endif
                        </div>
                    </div>

                </div>
            </div>
            @endforeach

        </div>

        <div class="wojo fitted divider"></div>
        <div class="wojo footer">
            <button type="submit" data-action="updateAccount" name="dosubmit" class="wojo positive button">Save</button>
            <a href="{{ route('admin.vehiclebadgemanager.index') }}" class="wojo negative button" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
        </div>
    </div>

    {{ Form::close() }}
</div>
</div>
@stop
@push('scripts')

<script>

    $(document).ready(function(){
        var makeId = $('#makes_id option:selected').val();
        var OldModal = '';
        @if (isset($vehiclebadge->models_id))
                var OldModal = "{{$vehiclebadge->models_id}}";
        @else
                var OldModal = "{{\Request::old('models_id')}}";
        @endif
        updateMakeModel(makeId,OldModal, 0, false);
        $('#makes_id').on('change', function () {
            updateMakeModel($(this).val(), 0, false);
        });
    })
    function updateMakeModel(make, model, isvin = false) {
        $.ajax({

            url: '{{route("admin.get-models","")}}/' + make+'/'+model,

            dataType: "json",
            success: function(json) {
                if (isvin) {
                    $('select[name=models_id]').html(json).selecter("update");
                    $('select[name=models_id] option').filter(function() {
                        return $(this).html() == model
                    }).prop("selected", "selected");
                    $('select[name=models_id]').selecter("update");
                    $('.selecter-options').scroller("destroy").scroller();
                } else {
                    $('select[name=models_id]').html(json).selecter("update");
                    $('.selecter-options').scroller("destroy").scroller();
                }
            }
        });
    }
</script>

@endpush
