<?php

namespace Modules\VehicleFeatureManager\Entities;

use Illuminate\Database\Eloquent\Model;

class VehicleFeatureTranslation extends Model {

    protected $fillable = ["name"];
    public $timestamps = false;


}
