<?php

namespace Modules\User\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreateUserRequest extends FormRequest {

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        $rules = [
            'secud_fname'  => 'required|max:200',
            'secud_sname'  => 'required|max:200',
            'meuser_name'  => 'required|string|unique:users|max:200',
            'email'        => 'required|email|unique:users',
            'secud_mobile' => 'max:50',
            'password'     => 'required|min:6|confirmed',
            'role_id'      => 'required',
              'status'   => '',
            'secud_cont' => '',
        ];
        return $rules;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Setting up custom messages for errors.
     *
     * @return array
     */
    /*public function messages(){

    }*/

    /**
     * Correcting attribute names.
     *
     * @return array
     */
    public function attributes(){
        $attributes = [
            'secud_fname'  => 'First Name',
            'secud_sname'  => 'Surname',
            'meuser_name'  => 'Username',
            'email'        => 'Email',
            'secud_mobile' => 'Mobile',
            'password'     => 'Password',
            'role_id'      => 'Role',
        ];
        return $attributes;
    }

}
