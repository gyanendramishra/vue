@extends('backpack::layout')
@section('header')
<style>
    .nodesign{ border: none; background: transparent; border-radius: none;  width: 100%}
    #example1_filter{ text-align: right !important;margin-bottom: 8px; }
    #example1_paginate { float: right; }
    .show_msg{ left: 220px;
               position: absolute;
               top: 17px;
               z-index: 9999;}
    </style>
    <section class="content-header">
    <h1>
        Product Enquiry Lead Reply Details
    </h1>

    <p class="show_msg"></p>
    @if(Session::has('success_message'))
    <p class="alert {{ Session::get('alert-class', 'alert-success') }}">{{ Session::get('success_message') }}</p>
    @endif
    @if(Session::has('error_message'))
    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error_message') }}</p>
    @endif 
    <ol class="breadcrumb">
        <li><a href="{{ url('user/dashboard') }}">{{ config('backpack.base.project_name') }}</a></li>
        <li class="active">{{ trans('backpack::base.dashboard') }} </li>
    </ol>
</section>

@endsection
@section('content')
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <!-- Default box -->
                    <a href="http://localhost/bdealer-site/public/admin/lead"><i class="fa fa-angle-double-left"></i> Back to all  <span>Product Enquiry</span></a><br><br>
        
        
          <form method="post" action="http://localhost/bdealer-site/public/admin/lead">
          <input type="hidden" name="_token" value="4ied6JKba1sfSwdpMiGREMt0tDGUabEUKVkuP6SU">
          <div class="box">

            <div class="box-header with-border">
              <h3 class="box-title">Add a new  Product Enquiry</h3>
            </div>
            <div class="box-body row">
              <!-- load the view from the application if it exists, otherwise load the one in the package -->
                            <!-- load the view from the application if it exists, otherwise load the one in the package -->
            <!-- select from array -->
<div class="form-group col-md-12">
    <label>Change Status</label>
        <select name="status" class="form-control">

        
                                                        <option value="0">New(Not Answered)</option>
                                                                <option value="1">In Progress(Not Answered)</option>
                                                                <option value="2">Response(Not Answered)</option>
                                                                <option value="3">Closed(If Answered)</option>
                                                                <option value="4">Rejected(If Answered)</option>
                                                                <option value="5">Convert to order(If Answered)</option>
                                        </select>

    
    </div>
        <!-- load the view from the application if it exists, otherwise load the one in the package -->
            <!-- select from array -->
<div class="form-group col-md-12">
    <label>Is Sample Sent</label>
        <select name="is_sample_sent" class="form-control">

        
                                                        <option value="0">Not Sent</option>
                                                                <option value="1">Sent</option>
                                        </select>

    
    </div>
        <!-- load the view from the application if it exists, otherwise load the one in the package -->
            <!-- select from array -->
<div class="form-group col-md-12">
    <label>Is Answered</label>
        <select name="is_answered" class="form-control">

        
                                                        <option value="0">No</option>
                                                                <option value="1">Yes</option>
                                        </select>

    
    </div>
    



                        </div><!-- /.box-body -->
            <div class="box-footer">

                <div id="saveActions" class="form-group">

    <input type="hidden" name="save_action" value="save_and_edit">

    <div class="btn-group">

        <button type="submit" class="btn btn-success">
            <span class="fa fa-save" role="presentation" aria-hidden="true"></span> &nbsp;
            <span data-value="save_and_edit">Save and edit this item</span>
        </button>

        <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aira-expanded="false">
            <span class="caret"></span>
            <span class="sr-only">▼</span>
        </button>

        <ul class="dropdown-menu">
                        <li><a href="javascript:void(0);" data-value="save_and_back">Save and back</a></li>
                        <li><a href="javascript:void(0);" data-value="save_and_new">Save and new item</a></li>
                    </ul>

    </div>

    <a href="http://localhost/bdealer-site/public/admin/lead" class="btn btn-default"><span class="fa fa-ban"></span> &nbsp;Cancel</a>
</div>
            </div><!-- /.box-footer-->

          </div><!-- /.box -->
          </form>
    </div>
</div>

    @endsection







