<?php

namespace Modules\VehicleFuelTypesManager\Entities;

use Illuminate\Database\Eloquent\Model;

class VehicleFuelTypesTranslation extends Model {

    protected $fillable = ["name"];
    public $timestamps = false;

   
}
