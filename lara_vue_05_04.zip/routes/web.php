<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

# Home route
Route::group(['middleware'=>'prevent-backhistory'], function(){

	Route::get('/', 'HomeController@index')->name('home');
	Route::get('/about-us', 'AboutUsController')->name('about.us');
	Route::get('/services', 'ServicesController')->name('services');
	Route::get('/frequently-asked-questions', 'FaqController')->name('faq');
	Route::get('/privacy-policy', 'PrivacyPolicyController')->name('privacy.policy');
	Route::get('/terms-and-conditions', 'TermsAndConditionController')->name('terms.and.conditions');

	Route::post('/near-by-data', 'HomeController@getNearByData')->name('near.by.data');

	# Service providers
	Route::group(['prefix'=> 'service-providers'], function(){
		# Get service providers
		Route::match(['GET', 'POST'], '/', 'ServiceProvidersController@index')->name('service.providers');
		# Get service providers
		Route::post('/filter', 'ServiceProvidersController@filterServiceProviders')->name('filter.service.providers');
		# Get categories
		Route::get('/categories', 'ServiceProvidersController@getCategories')->name('service.provider.categories');
	});
	Route::group(['prefix'=> 'service'], function(){
		# Get service detail
		Route::get('/{slug}', 'ServiceProvidersController@getServiceDetail')->name('service.detail');
		# Get service detail
		Route::post('/data', 'ServiceProvidersController@getServiceDetailData')->name('service.detail.data');
	});


	# Auth route group
	Route::group(['as'=>'user.', 'namespace'=>'Auth'], function(){
		# Login form route
		Route::get('/login', 'LoginController@index')
			->name('login.form');
		# Register form route
		Route::get('/register', 'RegisterController@index')
			->name('register.form');
		# Register route
		Route::post('/register', 'RegisterController@register')
			->name('register');
		# Login route
		Route::post('/login', 'LoginController@login')
			->name('login');
		# Logout route
		Route::get('logout', 'LoginController@logout')
			->name('logout');
		# Forgot password form route
		Route::get('/password/reset', 'ForgotPasswordController@index')
			->name('password.request');
		# Forgot password reset mail route
		Route::post('/password/email', 'ForgotPasswordController@sendResetPasswordEmail')
			->name('password.email');
		# Reset password route
		Route::post('/password/reset', 'ResetPasswordController@resetPassword')
			->name('password.update');
		# Verify email route
		Route::post('/email/verify', 'VerificationController@verify')
			->name('verify.email');
		# Verify email route
		Route::post('/resend/otp', 'RegisterController@resendOtp')
			->name('resend.otp');
		# Social login
		Route::get('/login/{provider}', 'SocialiteController@redirectToProvider');
		Route::get('/login/{provider}/callback', 'SocialiteController@handleProviderCallback');
	});

	# After Auth route group
	Route::group(['as'=>'user.', 'middleware'=>'auth'], function(){
		# Dashboard route
		Route::group(['prefix'=>'dashboard'], function(){
			# Show dashboard route
			Route::get('/', 'DashboardController@index')
			->name('dashboard');
			# Get dashboard route
			Route::post('/get', 'DashboardController@getDashboard')
			->name('dashboard.get');
		});

		# Switch account
		Route::get('/switch-account-to/{as}', 'DashboardController@switchAccountAs')
			->name('switch.account');

		# Change Password
		Route::get('/change-password', 'ChangePasswordController@index')
			->name('change.password');
		# Update Password
		Route::post('/update-password', 'ChangePasswordController@updatePassword')
			->name('update.password');
		# My Profile 
		Route::group(['prefix'=>'my-profile'], function(){
			# Show profile
			Route::get('/', 'MyProfileController@index')
			->name('profile');
			# Get profile
			Route::get('/get', 'MyProfileController@getProfile')
			->name('get.profile');
			# Update Profile
			Route::post('/update', 'MyProfileController@updateProfile')
				->name('update.profile');
		});

		# My Operational times

		Route::group(['prefix'=>'operational-times'], function(){
			# Show operational times 
			Route::get('/', 'OperationalTimesController@index')
				->name('operational.times');
			# Get operational times 
			Route::get('/get', 'OperationalTimesController@getOperationalTimes')
				->name('get.service');
			# Update operational times 
			Route::post('/update', 'OperationalTimesController@updateOperationalTimes')
				->name('save.update.service');
		});

		# My Service
		Route::group(['prefix'=>'my-service'], function(){
			# Show my Service 
			Route::get('/', 'MyServiceController@index')
				->name('service');
			# Get my Service 
			Route::get('/get', 'MyServiceController@getService')
				->name('get.service');
			# Save/Update Service
			Route::post('/add-update', 'MyServiceController@saveUpdateService')
				->name('save.update.service');
		});

		# Payment
		Route::group(['prefix'=>'payment'], function(){
			# My Payment 
			Route::get('/', 'PaymentController@index')
			->name('payment');
			# Add My Payment Account
			Route::post('/add/account', 'PaymentController@addPaymentAccount');
			# Update My Payment Account
			Route::post('/update/account', 'PaymentController@updatePaymentAccount');
		});

		# Booking
		Route::group(['prefix'=>'booking'], function(){
			# My booking 
			Route::get('/', 'BookingController@index')
			->name('booking');
			# Get my booking 
			Route::post('/get', 'BookingController@getBookings')
				->name('get.booking');
			# Book service
			Route::post('/book-service', 'BookingController@bookService')->name('service.book');

			# Get booking detail data
			Route::post('/get-detail-data', 'BookingDetailController@getBooking')
				->name('booking.detail.data');

			# Get booking detail
			Route::get('/{slug}', 'BookingDetailController@index')
				->name('booking.detail');
		});

	});

	# Get categories listing
	Route::get('/listing/get-categories', 'CategoryController@getParentCategories')
					->name('listing.categories');
	# Get sub categories listing
	Route::post('/listing/get-sub-categories', 'CategoryController@getSubCategories')
					->name('listing.sub.categories');

});

Route::get('/clear-cache', function() {
    $exitCode = Artisan::call('cache:clear');
    $exitCode = Artisan::call('view:clear');
    $exitCode = Artisan::call('route:clear');
    $exitCode = Artisan::call('config:clear');
});

/* Fallback route */

Route::fallback(function() {
    return view('errors.404');
});

