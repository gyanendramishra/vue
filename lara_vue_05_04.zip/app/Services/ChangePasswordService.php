<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class ChangePasswordService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/users/';

    /**
     * Update the user password.
     *
     * @param  array  $data
     * @return Illuminate\Http\Response
     */
    public function updatePasswordService(array $data) {
        $uri = $this->base_uri;
        $uri .= 'changePassword'; 
        return $this->postServiceRequest($uri, $data);
    }

    

}