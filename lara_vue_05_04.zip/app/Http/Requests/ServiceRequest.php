<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ServiceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title'       =>'bail|required|max:255',
            'parent_service_id' =>'bail|required|numeric',
            'category_id' =>'bail|required|numeric',
            'address'     => 'bail|required|max:255',
            'longitude'   => 'bail|required|max:255',
            'latitude'    => 'bail|required|max:255',
            'description' => 'bail|required|string',
            'price'       => 'bail|required|regex:/^\d+(\.\d{1,2})?$/|digits_between:1,8',
            'image_file'  => 'bail|required|image|mimes:jpg,png,jpeg'
        ];
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'parent_service_id.required' => 'The service field is required.',
            'parent_service_id.numeric' => 'The service field should be numeric.',
            'category_id.required' => 'The category field is required.',
            'category_id.numeric' => 'The category field should be numeric.',
            'image_file.required' => 'The file field is required.',
            'image_file.image' => 'The file must be an image. ',
            'image_file.mimes' => 'The file must be jpg,png,jpeg.',
        ];
    }
}
