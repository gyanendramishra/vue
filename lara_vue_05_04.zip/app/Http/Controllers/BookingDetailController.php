<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\BookingService;

class BookingDetailController extends Controller
{ 

    /**
     * Show the user bookings.
     *
     * @param Illuminate\Http\Request $request
     * @param string $slug
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request, $slug){
        $user = $request->session()->get('auth_user');
        $isServiceProvider = "false";
        if($user->isServiceProvider){
            $isServiceProvider = "true";
        }
        $slug_array = explode('-', $slug);
        $bookingId = last($slug_array);
        return view('booking.detail', compact('bookingId', 'isServiceProvider'));
    }

    /**
     * Get the user booking.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\BookingService $service
     * @return \Illuminate\Http\Response
     */
    public function getBooking(Request $request, BookingService $service){
        try{
            $response = $service->getBookingService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    
}
