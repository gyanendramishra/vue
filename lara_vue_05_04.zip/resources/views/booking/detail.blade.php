@extends('layouts.dashboard')
@section('page_header_title')
	Booking Detail
@endsection
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        booking detail
    </li>
@endsection

@section('dashboard_content')
  	<booking-detail-component :booking-id='{{ $bookingId }}' :is-service-provider="{{ $isServiceProvider }}"></booking-component>
@endsection

