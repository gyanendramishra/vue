<template>
    <div class="formBox editProfileForm">
        <div class="formBoxInner">
            <div class="dashbord-sec">     
                <div class="my-booking-sec">
                    <div class="booking-row">
                        <div class="form-group">
                            <label>Filter:</label>
                            <select v-model="filters.status" v-on:change="getBookings">
                                <option value="">All</option>
                                <option value="awaiting">Awaiting</option>
                                <option value="accepted">Accepted</option>
                                <option value="rejected">Rejected</option>
                                <option value="scheduled">Scheduled</option>
                                <option value="started">Started</option>
                                <option value="cancelled">Cancelled</option>
                                <option value="complained">Complained</option>
                                <option value="ended">Ended</option>
                                <option value="completed">Completed</option>
                            </select>
                        </div>
                    </div>
                    <div v-if="loading === false">
                        <div v-if="results.bookings.length > 0">
                            <div class="booking-row" v-for="booking in results.bookings">
                                <div class="booking-row-inner">
                                    <h4>
                                        <a :href="'/booking/'+ booking.title | prepareSlug(booking.id)">
                                            {{ booking.title }}
                                        </a>
                                    </h4>     
                                    <p>{{ booking.description }}</p>
                                    <div class="booking-bottom-date-sec">
                                        <span class="booking-date-col">
                                            {{ booking.service_date_time | formatDate }}
                                        </span>
                                        <span :class="'booking-status-label '+ booking.status">
                                            {{ booking.status }}
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="pro-pagination">
                                <div class="pager-result"> {{ results.total_count }} Items found</div>
                                <div class="pager" v-if="results.last_page > 1">
                                    <ul>
                                        <li class="pager-arrow" :disabled="filters.page === 1">
                                            <a href="javascript:;" v-on:click="paginate((filters.page - 1))">
                                                <i class="fa fa-angle-left"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:;" v-on:click="paginate(1)">
                                                1
                                            </a>
                                        </li>
                                        <li v-if="results.last_page >= 2">
                                            <a href="javascript:;" v-on:click="paginate(2)">
                                                2
                                            </a>
                                        </li>
                                        <li v-if="results.last_page >= 3">
                                            <a href="javascript:;" v-on:click="paginate(3)">
                                                3
                                            </a>
                                        </li>
                                        <li v-if="results.last_page >= 4">
                                            <a href="javascript:;" v-on:click="paginate(4)">
                                                4
                                            </a>
                                        </li>
                                        <li class="pager-arrow" :disabled="filters.page === results.last_page">
                                            <a href="javascript:;" v-on:click="paginate((filters.page + 1))">
                                                <i class="fa fa-angle-right"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div v-else>
                            <div class="booking-row">
                                <div class="booking-row-inner">
                                    <p>Sorry we have not found any {{ filters.status }} booking of you.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div v-else>
                        loading...
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import moment from "moment";
    export default {
        name: "booking-component",
        props:["isServiceProvider"],
        data: function () {
            return {
                loading: false,
                results: {},
                filters: {
                    page: 1,
                    account_type_id : 1,
                    status: ""
                }
            }
        },
        beforeCreate: function(){
            this.loading = true;
        },
        created: function(){
            this.getBookings();
        },
        mounted : function() {
            if(this.isServiceProvider === true){
                this.filters.account_type_id = 1;
            }else{
                this.filters.account_type_id = 2;
            }
        },
        filters: {
            formatDate : function(date){
                return moment(date, 'YYYY-MM-DD H:i:s').format('DD MMM YYYY h:mm a');
            },
            prepareSlug (str, id) {
                if(!str) return "";

                return str.toLowerCase().replace(/ /g, '-')+"-"+id;
            }
        },
        methods: {
            getBookings() {
                this.loading = true;
                axios.post('/booking/get', this.filters).then(response => {
                    if(response.data.status === true){
                        this.results = response.data.data;
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            paginate(page) {
                this.filters.page = page;
                this.getBookings();
            }
        },
    }
</script>

