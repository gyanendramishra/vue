<template>
    <div>
        <div class="formBox editProfileForm">
            <div class="formBoxInner">
                <div class="dashbord-sec">   
                    <div class="my-booking-sec my-booking-detail">
                        <a href="#" class="booking-cancel-btn">Complaint</a>
                        <h3>{{ booking.title }}</h3>
                        <div class="inner-page-sec-title">
                            <h4>Description</h4>
                        </div>
                        <p>{{ booking.description }}</p>
                        <div class="schedule-and-budget">
                            <div class="schedule-time">
                                <strong>
                                    Schedule Time:
                                </strong> 
                                <span>
                                    {{ booking.request_date_time | formatDate }}
                                </span>
                            </div>
                            <div class="booking-budget"> 
                                <strong>Budget:</strong> 
                                <span class="price-booking">${{ booking.budget }}</span> 
                                <small>(incl. all taxes)</small>
                            </div>
                        </div>
                        <div class="booking-provider-sec">
                            <div class="booking-provider-col">
                                <img :src="booking.provider_full_image_path" alt="" />
                                <h5>{{ booking.provider_name }}</h5>
                                <span>Lifestyle</span>
                            </div>
                            <a href="#" class="book-pro-arrow">
                                <img src="/images/booking_provider_arrow.png" alt="" />
                            </a>
                        </div>
                        <div class="book-pay-status-sec">
                            <ul>
                                <li>
                                    <div class="book-status-left">
                                        <strong>Booking Status</strong>
                                    </div>
                                    <div class="book-status-right">
                                        <span :class="'booking-status-label '+ booking.booking_status">{{ booking.booking_status }}</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="book-status-left">
                                        <strong>Payble Amount</strong>
                                    </div>
                                    <div class="book-status-right">
                                        <span class="price-booking">
                                            ${{ booking.payable_amount }}
                                        </span> 
                                        <small>(incl. all taxes)</small>
                                    </div>
                                </li>
                                <li>
                                    <div class="book-status-left">
                                        <strong>Payment Status</strong>
                                    </div>
                                    <div class="book-status-right">
                                        <div :class="booking.payment_status">
                                            {{ booking.payment_status }}
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <div class="chat-and-link-sec">
                                <a href="javascript:;" class="invoice-link" v-on:click="showInvoice">View Invoice</a>
                                <div class="chat-btn">
                                    <a href="booking-detail-chat.html">
                                        <img src="/images/top_category_img01.jpg" alt="" />
                                        <span>Chat</span>
                                    </a>
                                </div>
                            </div>
                            <div class="book-btn-sec">
                                <a href="#" class="btn-default">Cancel</a>
                                <a href="#" class="btn-default">Accept</a>
                            </div>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
        <!-- Booking Form modal -->
        <div class="modal fade my-popup" ref="invoice_modal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title">Invoice</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="booking-form-popup">
                            <object type="application/pdf" :data="booking.invoice_file_path" width="100%" height="300" style="height: 85vh;">No Support</object>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import moment from "moment";
    export default {
        name: "booking-detail-component",
        props:["bookingId"],
        data: function () {
            return {
                loading: false,
                booking: {}
            }
        },
        beforeCreate: function(){
            this.loading = true;
        },
        created: function(){
            this.getBooking();
        },
        filters: {
            formatDate : function(date){
                return moment(date, 'YYYY-MM-DD H:i:s').format('DD MMM YYYY h:mm a');
            }
        },
        methods: {
            getBooking() {
                this.loading = true;
                axios.post('/booking/get-detail-data', {
                    id: this.bookingId
                }).then(response => {
                    if(response.data.status === true){
                        this.booking = response.data.data;
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            showInvoice() {
                $(this.$refs.invoice_modal).modal();
            }
        },
    }
</script>

