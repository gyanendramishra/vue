<?php

return [
    'name' => 'VehicleBodyStyleManager'
];
