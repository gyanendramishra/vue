<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('admin')->middleware('auth:admin')->namespace('Admin')->as('admin.')->group(function() {
   
	Route::get('vehicleaudiocommunication/ajax/list', 'VehicleAudioCommunicationManagerController@ajaxList')->name('vehicleaudiocommunication.ajax.list');
	Route::get('vehicleaudiocommunication/delete/{id}', 'VehicleAudioCommunicationManagerController@destroy')->name('vehicleaudiocommunication.delete');
	Route::resources([
        'vehicleaudiocommunication' => 'VehicleAudioCommunicationManagerController',
    ]);
});
