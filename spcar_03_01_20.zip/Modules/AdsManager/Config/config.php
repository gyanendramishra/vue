<?php

return [
    'name' => 'AdsManager'
];
