@extends('layouts.admin.app')

@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            {{ __( 'Users Manager' ) }}            
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{url('/')}}"><i class="fa fa-dashboard"></i>  Dashboard </a></li>
            <li><a href="{{route('admin.users.index', ['roleSlug' => $role->slug ])}}"> {{ $role->name }}</a></li>
            <li class="active">{{ (@$row)?'Edit':'Add' }}</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
	  @include('layouts.flash.alert')
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Edit Personnel/User</h3>
                <div class="box-tools pull-right">
                    <a href="{{route('admin.users.index', ['roleSlug' => $role->slug ])}}" class="btn btn-primary">Back</a>

                </div>
            </div>
            <div class="box-body">
                @if(session()->has('success'))
                <div class="alert alert-success">
                    {{ session()->get('success') }}
                </div>
                @endif


                @if(@$row)
                    {!!  Form::model($row, ['url'=>route('admin.users.update', @$row->id), 'id'=>'form_data', 'method'=>'PUT', 'files' => true, ]) !!}
                @else
                    {!!  Form::open(['url'=>route('admin.users.store'), 'id'=>'form_data', 'method'=>'POST',  'files' => true, ])  !!}
                @endif

                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group @if($errors->has('name')) has-error @endif">
                            {{Form::label('name', 'Full Name')}}<span class="asterisk">*</span>
                            {{Form::text('name', old('name'), ['class' => 'form-control', 'placeholder'=>'Full Name', 'required'=>'required'])}}
                            @if($errors->has('name'))
                            <span class="help-block">{{$errors->first('name')}}</span>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group @if($errors->has('email')) has-error @endif">
                            {{Form::label('email', 'Email')}}<span class="asterisk">*</span>
                            {{Form::email('email', old('email'), ['class' => 'form-control', 'placeholder'=>'Email', 'required'=>'required'])}}
                            @if($errors->has('email'))
                            <span class="help-block">{{$errors->first('email')}}</span>
                            @endif
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group @if($errors->has('phone')) has-error @endif">
                            {{Form::label('phone', 'Contact No.')}}<span class="asterisk">*</span>
                            {{Form::text('phone', old('phone'), ['class' => "form-control", 'placeholder'=>'Contact No.', 'required'=>'required'] )}}
                            @if($errors->has('phone'))
                            <span class="help-block">{{$errors->first('phone')}}</span>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group @if($errors->has('location')) has-error @endif">
                            {{Form::label('location', 'Location')}}<span class="asterisk">*</span>
                            {{Form::text('location', old('location'), ['class' => "form-control", 'placeholder'=>'Location', 'required'=>'required'])}}
                            @if($errors->has('location'))
                            <span class="help-block">{{$errors->first('location')}}</span>
                            @endif
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group @if($errors->has('password')) has-error @endif">
                            {{Form::label('password', 'Password')}}
                            {{Form::password('password', [
                                    'class' => "form-control", ])}}
                            <span class="help-block">{{__( 'Min. 8 characters' )}}</span>

                            @if($errors->has('password'))
                            <span class="help-block">{{$errors->first('password')}}</span>
                            @endif
                        </div>
                    </div>


                    <div class="col-sm-6">
                        <div class="form-group @if($errors->has('password')) has-error @endif">
                            {{Form::label('password_confirmation', 'Confirm Password')}}
                            {{Form::password('password_confirmation', [
                                    'class' => "form-control", ])}}
                        </div>
                    </div>
                </div>



                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            {{Form::label('status', 'Status')}}
                            {!!Form::select('status', ['1'=>'Active','0'=>'InActive'], old('status'), ['class' => 'form-control'])!!}
                        </div>
                    </div>
                </div>

                <div class="col-sm-12">
                    <div class="form-group">
                        <input type="hidden" name="role_id" value="{{ $role->id }}">
                        {{Form::submit('Submit', [ 'class' => "btn btn-primary btn-flat" ])}}
                    </div>
                </div>
            </div>
            {{ Form::close() }}
        </div>
</div>
</section>
<!-- /.content -->
</div>

@endsection
@push('scripts')
<script type="text/javascript">
    jQuery(function ($) {

        // Preview Image
        function previewImage(input) {


            if (input.files && input.files[0]) {
                $('#profile_image-error').remove();
                __thisObj = input;
                var reader = new FileReader();
                var file_type = input.files[0].type;
                var file_size = input.files[0].size;

                reader.onload = function (e) {

                    var src = e.target.result;
                    var IsCorrupt = false;
                    var IsFileSize = true;
                    if (file_type == "image/png")
                    {
                        IsCorrupt = true;
                    } else if (file_type == "image/jpeg")
                    {
                        IsCorrupt = true;
                    }
                    if (file_size > 2000000)
                    {
                        IsFileSize = false;
                    }



                    if (IsCorrupt == false) {

                        var errorDiv = '<div id="' + $(__thisObj).attr('name') + '-error" class="error red">Uploaded file is not a valid image. Only JPG and PNG files are allowed.</div>';
                        // $(input).closest('.form-group').find('.preview').attr('src', "/images/user.png");

                        $(__thisObj).parents('.form-group').append(errorDiv);
                        $(__thisObj).val('');


                    } else if (IsFileSize == false) {


                        var errorDiv = '<div id="' + $(__thisObj).attr('name') + '-error" class="error red">Failed to upload an image. The image maximum size is 2MB.</div>';
                        // $(input).closest('.form-group').find('.preview').attr('src',  "/images/user.png");
                        $(__thisObj).parents('.form-group').append(errorDiv);
                        $(__thisObj).val('');

                    } else {
                        $(input).closest('.form-group').find('.preview').attr('src', e.target.result);
                    }


                }
                reader.readAsDataURL(input.files[0]);
            }


        }



        $("#profile_image").change(function () {
            previewImage(this);
        });

    });
</script>
@endpush
