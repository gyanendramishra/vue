@extends('layouts.admin.app')
@section('title', !empty($vehiclecomfortconvenience) ? 'Edit Vehicle Comfort & Convenience' : 'Add Vehicle Comfort & Convenience')
@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            {{ __( 'Manage Vehicle Comfort & Convenience' ) }}            
        </h1>
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.vehiclecomfortconveniencemanager.index'],['label' => !empty($vehiclecomfortconvenience) ? 'Edit Vehicle Comfort & Convenience' : 'Add New Vehicle Comfort & Convenience' ]]]) }}
    </section>
    <!-- Main content -->
    <section class="content">
         @include('layouts.flash.alert')
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">{{ !empty($vehiclecomfortconvenience) ? 'Edit Vehicle Comfort & Convenience' : 'Add Vehicle Comfort & Convenience' }}</h3>
                <div class="box-tools pull-right">
                    <a href="{{ route('admin.vehiclecomfortconveniencemanager.index') }}" class="btn btn-primary">Back</a>
                </div>
            </div>
            <div class="box-body">
                @if(session()->has('success'))
                <div class="alert alert-success">
                    {{ session()->get('success') }}
                </div>
                @endif

                @if(isset($vehiclecomfortconvenience))
                {{ Form::model($vehiclecomfortconvenience, ['route' => ['admin.vehiclecomfortconveniencemanager.update', $vehiclecomfortconvenience->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}
                @else
                {{ Form::open(['route' => 'admin.vehiclecomfortconveniencemanager.store','enctype'=>'multipart/form-data']) }}
                @endif
                <div class="nav-tabs-custom">          
                    
                     @php
                    $locales = config('app.locales');
                    @endphp
                    <ul class="nav nav-tabs">
                        @foreach($locales as $key=>$val)
                        <li class="{{ ($key=='en')?'active':'' }}"><a data-toggle="tab" href="#{{ $key.'_tab' }}" class="{{ ($key=='en')?'active show':'' }}">{{ $val }}</a></li>
                        @endforeach
                    </ul>
                    <div>&nbsp;</div>

                    <div class="tab-content">
                        @foreach($locales as $key=>$val)

                        <div id="{{ $key.'_tab' }}" class="tab-pane  {{ ($key=='en')?'fade in active':'' }}">



                            <div class="row">

                                <div class="col-xs-6">

                                    <div class="form-group required {{ $errors->has($key.'_name') ? 'has-error' : '' }}">
                                        <label for="title">Name <span class="asterisk">*</span></label>
                                        {{ Form::text($key.'_name',old($key.'_name', (isset($vehiclecomfortconvenience))?$vehiclecomfortconvenience->translate($key)['name']:"") , ['class' => 'form-control','placeholder' => 'Name']) }}
                                        @if($errors->has($key.'_name'))
                                        <span class="help-block">{{ $errors->first($key.'_name') }}</span>
                                        @endif
                                    </div>

                                </div>

                            </div>


                        </div>
                        @endforeach

                        <div class="row">
                            <div class="col-md-6">


                                <div class="form-group required {{ $errors->has('status') ? 'has-error' : '' }}">
                                    <label for="title">Status <span class="asterisk">*</span></label>
                                    {{ Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control']) }}
                                    @if($errors->has('status'))
                                    <span class="help-block">{{ $errors->first('status') }}</span>
                                    @endif
                                </div>

                               <!--  <div class="form-group {{ $errors->has('icon') ? 'has-error' : '' }}">
                                    <label for="title">Icon </label>
                                    {{Form::file('icon')}}
                                     @if($errors->has('icon'))
                                    <span class="help-block">{{ $errors->first('icon') }}</span>
                                    @endif
                                </div>
                                @php
                                $filepath = '/uploads/comfortConvience/';
                                @endphp
                                @if(!empty($vehiclecomfortconvenience->icon) && file_exists(public_path() . $filepath . $vehiclecomfortconvenience->icon))
                                <?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url($filepath . $vehiclecomfortconvenience->icon), '150', '60', '100'); ?>
                                <div class="form-group">
                                    <img src="{{$imageurl}}">
                                </div>
                                @endif -->
                            </div>

                        </div> <!-- /.row -->


                    </div>

                    
                </div>

                <div class="box-footer">
                    <button class="btn btn-primary btn-flat" title="Submit" type="submit"><i class="fa fa-fw fa-save"></i> Submit</button>
                    <a href="{{ route('admin.vehiclecomfortconveniencemanager.index') }}" class="btn btn-warning btn-flat" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
                </div>
                {{ Form::close() }}
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>

@stop