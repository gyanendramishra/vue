<?php

namespace Modules\EnquiresManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\EnquiresManager\Entities\Inquiry;
use Modules\EnquiresManager\Http\Requests\EnquiresRequest;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use Mail;

class EnquiresController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        $title = "Contact Enquiries";
        return view('enquires::Admin.enquires.index', compact('title'));
    }

    /**
     * Feeding list of enquires to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {

        $enquires = Inquiry::get();

        if ($request->status != '') {
            $enquires = $enquires->where('status', $request->status);
        }

        return datatables()->of($enquires)
                        
                        ->addColumn('action', function ($enquires) {
                            $actions = "";
                            $actions .= "<a title='view' href=\"" . route('admin.enquires.show', ['id' => $enquires->id]) . "\" class=\"\"><i class=\"rounded outline primary icon user profile link\"></i></a>";
                            return $actions;
                        })
                         ->addColumn('type', function ($enquires) {
                            $actions = "";
                            $actions = \Config('constants.INQUERY_FOR.'.$enquires->type);
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        $title = "Contact Enquiries";
        return view('enquires::Admin.enquires.createOrUpdate', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request) {
        //
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id) {
        $title = 'Contact Enquiries';
         $inquiry = Inquiry::where('id',  $id)->first();
       
        return view('enquires::Admin.enquires.show', compact( 'inquiry','title'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id) {
        //
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id) {
        Enquiry::where('id', $id)->delete();
        return redirect()->route('admin.enquires.index')->with('success', 'Enquiries deleted successfully.');
    }

    /**
     * List of Reply of enquires.
     * @param int $id
     * @return list of replies
     */
    public function reponses($id = NULL) {

        $title = '';
        $actions = ["On Hold" => 'On Hold', "In Progress" => 'In Progress', "Closed" => 'Closed'];
        $lead = Enquiry::findOrfail($id);
        $allresponces = EnquiryResponse::where('enquiry_id', $id)->get();
        return view('enquires::Admin.enquires.responses', compact('title', 'allresponces', 'id', 'actions', 'lead'));
    }

    /**
     * Feeding list of enquires to datatable.
     * @return Response
     */
    public function ajaxResponseList(DatatableRequest $request, $id = NULL) {

        $enquires = EnquiryResponse::where('enquiry_id', $id)->get();

        if ($request->action != '') {
            $enquires = $enquires->where('action', $request->action)->where('enquiry_id', $id);
        }

        return datatables()->of($enquires)->make(true);
    }

    /**
     * Reply of enquires, will sent in mail.
     * @param int $request
     * @return Response
     */
    public function enquiryReply(Request $request) {
        $data = $request->all();
        $lead = Enquiry::findOrfail($data['enquiry_id']);
        $lead->is_responded = 1;
        $lead->save();
        $data1['enquiry_id'] = $lead->id;
        $data1['email'] = $lead->email;
        $data1['details'] = $data['details'];
        $data1['action'] = $data['action'];
        $LeadAnswer = EnquiryResponse::create($data1);

        //send verification mail to user
        try {
            $hooksVars['NAME'] = $lead->name;
            $hooksVars['DETAIL'] = $lead->email;
            //$hooksVars['APPROVED_BY'] = $row->action_user->fullname();
            $emailData = ['template' => 'inquery', 'hooksVars' => $hooksVars];
            \Mail::to($lead->email)->send(new \App\Mail\ManuMailer($emailData));
        } catch (Exception $e) {
            $this->status = 'danger';
            $this->message = "Enquiry mail not sent. Somthing went wrong!";
        }

        return redirect()->route('admin.enquires.view-response', ['id' => $lead->id])->with('success', 'Enquiry response has been updated successfully!');
    }

}
