<?php

namespace Modules\VehicleEngineCapacityManager\Entities;

use Illuminate\Database\Eloquent\Model;

class VehicleEngineCapacityTranslation extends Model {

    public $timestamps = false;
    protected $fillable = ['name'];

    /**
     * Get the comments for the blog post.
     */
}
