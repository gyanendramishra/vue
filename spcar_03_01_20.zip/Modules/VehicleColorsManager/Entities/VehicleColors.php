<?php

namespace Modules\VehicleColorsManager\Entities;

use Illuminate\Database\Eloquent\Model;
use \Dimsav\Translatable\Translatable;

class VehicleColors extends Model {

    use Translatable;
    const ACTIVE = 1;
    const IN_ACTIVE = 0;

    protected $fillable = ["status"];

    public $translatedAttributes = ['name'];

    /**
     * Scope a query to only include active competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query) {
        return $query->where('status', self::ACTIVE);
    }

    /**
     * Scope a query to include given type of competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfActive($query, $type) {
        return $query->whereStatus($type);
    }

}
