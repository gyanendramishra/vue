<?php

namespace Modules\NewsManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Input;
use Modules\NewsManager\Entities\News;
use Modules\NewsManager\Http\Requests\NewsRequest;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use File;

class NewssController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        $title = "News";
        //return view('user::Admin.pages.index', ['title' => $title]);
        return view('newsmanager::Admin.news.index', compact('title'));
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {

        $newss = News::get();

        if ($request->status != '') {
            $newss = $newss->where('status', $request->status);
        }
        
        return datatables()->of($newss)
                        ->addColumn('action', function ($newss) {
                            $actions = "";
                            $actions .= "<a href=\"" . route('admin.news.show', ['id' => $newss->id]) . "\" class=\"\"><i class=\"rounded outline primary icon user profile link\"></i></a>";
                            $actions .= "&nbsp;<a href=\"" . route('admin.news.edit', ['id' => $newss->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";

                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        $title = "Add News";
        return view('newsmanager::Admin.news.createOrUpdate', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request) {

        $locales = config('app.locales');
        $valRule = [
            'publish_date' => 'required|date',
            'image' => 'required|mimes:jpeg,jpg,png|max:5000'
        ];
        $valMessage = [
            'publish_date.required' => 'The publish date field is required.',
            'publish_date.date' => 'Please enter the date.',
            'image.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
        'image.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
        ];

        foreach ($locales as $key => $value) {
            $valRule[$key . '_title'] = 'required|max:200|unique:news_translations,title|unique_space_check:news_translations,title';
            $valRule[$key . '_description'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_title.required'] = ' The title field is required in ' . $value . ' language.';
            $valMessage[$key . '_description.required'] = ' The description field is required in ' . $value . ' language.';
            $valMessage[$key . '_title.max'] = ' Sorry, you can\'t add the title more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_title.unique'] = ' Title must be unique in ' . $value . ' language.';
            $valMessage[$key . '_title.unique_space_check'] = ' Title must be unique in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $news_data = array();

            foreach ($locales as $key => $value) {
                $news_data[$key]['title'] = $request->input($key . '_title');
                $news_data[$key]['description'] = $request->input($key . '_description');
            }
            $news_data['status'] = $request->input('status');
            $news_data['publish_date'] = $request->input('publish_date');
            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $is_dest = "uploads/newsImages/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('image');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $news_data['image'] = $filenameOrig;
                }
            }

            $ad = News::create($news_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.news.index')->with('success', 'News has been saved Successfully');
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show($id) {
        $title = "News Detail";
        $news = News::findOrFail($id)->where('id', '=', $id)->first();
        return view('newsmanager::Admin.news.show', compact('title', 'news'));
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id) {
        $title = "Add News";
        $news = News::where('id', '=', $id)->first();
        return view('newsmanager::Admin.news.createOrUpdate', compact('title', 'news'));
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id) {

        $locales = config('app.locales');

        $valRule = [
            'publish_date' => 'required|date',
            'image' => 'sometimes|mimes:jpeg,jpg,png|max:5000'
        ];
        $valMessage = [
        'publish_date.required' => 'The publish date field is required.',
        'publish_date.date' => 'Publish date must be in date value.',
        'image.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
        'image.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
        ];



        foreach ($locales as $key => $value) {
            $valRule[$key . '_title'] = 'required|max:200|unique:news_translations,title,' . $request->segment(3) . ',news_id|unique_space_check:news_translations,title,' . $request->segment(3) . ',news_id';
            $valRule[$key . '_description'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_title.required'] = ' The title field is required in ' . $value . ' language.';
            $valMessage[$key . '_title.max'] = ' Sorry, you can\'t add the title more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_title.unique'] = ' Title must be unique in ' . $value . ' language.';
            $valMessage[$key . '_title.unique_space_check'] = ' Title must be unique in ' . $value . ' language.';
            $valMessage[$key . '_description.required'] = ' The description field is required in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);


        try {

            $news_data = array();

            foreach ($locales as $key => $value) {
                $news_data[$key]['title'] = $request->input($key . '_title');
                $news_data[$key]['description'] = $request->input($key . '_description');
            }
            $news_data['status'] = $request->input('status');
            $news_data['publish_date'] = $request->input('publish_date');
            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $is_dest = "uploads/newsImages/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('image');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;
                if ($image->move($directory, $filenameOrig)) {
                    $news_data['image'] = $filenameOrig;
                }
            }

            $News = News::find($id);

            $News->update($news_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.news.index')->with('success', 'News has been updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id) {
        News::where('id', $id)->delete();
        return redirect()->route('admin.news.index')->with('success', 'News deleted successfully.');
    }

}
