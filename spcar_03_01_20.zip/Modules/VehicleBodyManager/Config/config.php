<?php

return [
    'name' => 'VehicleBodyManager'
];
