<?php

namespace App\Mail\Frontend;

use App\EmailTemplate;
use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Modules\VehicleEnquiresManager\Entities\VehicleEnquiry;

class VehicleInquiryMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The Inquiry instance.
     *
     * @var Inquiry
     */

    public $vehicleEnquiry;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(VehicleEnquiry $vehicleEnquiry)
    {
        $this->vehicleEnquiry = $vehicleEnquiry;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $et = EmailTemplate::whereType('vehicle_inquiry_mail_to_admin')
            ->with('translations:id,email_template_id,locale,subject,template')
            ->first(['id']);
        if($et){
            $subject = $et->subject;
            $body = $et->template;
            $body = str_replace('##VEHICLE_TITLE##', $this->vehicleEnquiry->vehicle->title, $body);
            $body = str_replace('##VEHICLE_CODE##', $this->vehicleEnquiry->vehicle->id, $body);
            $body = str_replace('##NAME##', $this->vehicleEnquiry->name, $body);
            $body = str_replace('##EMAIL##', $this->vehicleEnquiry->email, $body);
            $body = str_replace('##PHONE##', $this->vehicleEnquiry->phone, $body);
            $body = str_replace('##POST_CODE##', $this->vehicleEnquiry->postcode, $body);
            $body = str_replace('##IS_TRADE_IN##', ($this->vehicleEnquiry->is_trade_in == 1) ? "Yes" : "No", $body);
            $body = str_replace('##IS_DEALER_RESPONSE##', ($this->vehicleEnquiry->is_dealer_response == 1) ? "Yes" : "No", $body);
            $body = str_replace('##MESSAGE##', $this->vehicleEnquiry->details, $body);

            $this->subject($subject)
                ->view('frontend.emails.template')
                ->with(['template'=>$body]);
        }
    }
}
