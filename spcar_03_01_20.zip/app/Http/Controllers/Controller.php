<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use View;
use Config;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Modules\VehicleModelManager\Entities\VehicleModel;
use Modules\VehicleBadgeManager\Entities\VehicleBadge;
use Modules\VehicleMakeManager\Entities\VehicleMake;
use Modules\VehicleTransmissionsManager\Entities\VehicleTransmissions;
use Modules\VehicleFuelTypesManager\Entities\VehicleFuelTypes;
use Modules\CategoryManager\Entities\Category;
use Modules\VehicleBodyStyleManager\Entities\VehicleBodyStyle;
use Modules\VehicleCylindersManager\Entities\VehicleCylinders;
use Modules\VehicleDriveTypesManager\Entities\VehicleDriveTypes;
use Modules\CmsManager\Entities\Page;
use App\State;

class Controller extends BaseController {

    use AuthorizesRequests,
        DispatchesJobs,
        ValidatesRequests;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {



//        $roles = \Modules\User\Entities\Role::select('name', 'id')->where('status', 1)->where('is_menu', 1)->get();
//        $make = VehicleMake::orderBy('name', 'ASC')->where(['status' => 1])
//                     ->Has('vehicles')
//                   ->pluck('name', 'id')->toArray();
//		
//		$make_all = VehicleMake::orderBy('name', 'ASC')->where(['status' => 1])->pluck('name', 'id')->toArray();
//
//        if (isset($_REQUEST['makes_id']) && $_REQUEST['makes_id'] != '') {
//            $makes_id = $_REQUEST['makes_id'];
//            $model = VehicleModel::where("makes_id", $makes_id)
//                            ->pluck("name", "id")->toArray();
//        } else {
//            $model = VehicleModel::orderBy('name', 'ASC')->where(['status' => 1])->pluck('name', 'id')->toArray();
//        }
//
//        if (isset($_REQUEST['models_id']) && $_REQUEST['models_id'] != '') {
//            $models_id = $_REQUEST['models_id'];
//            $badge = VehicleBadge::where("models_id", $models_id)->pluck("name", "id")->toArray();
//        } else {
//            $badge = VehicleBadge::orderBy('name', 'ASC')->where(['status' => 1])->pluck('name', 'id')->toArray();
//        }
//
//        $bodyStyle = VehicleBodyStyle::orderBy('name', 'ASC')->where(['status' => 1])->pluck('name', 'id')->toArray();
//        $category = Category::orderBy('name', 'ASC')->where(['status' => 1])->pluck('name', 'slug')->toArray();
//        $transmission = VehicleTransmissions::orderBy('name', 'ASC')->where(['status' => 1])->pluck('name', 'id')->toArray();
//        $fuleType = VehicleFuelTypes::orderBy('name', 'ASC')->where(['status' => 1])->pluck('name', 'id')->toArray();
//        $cylinder = VehicleCylinders::orderBy('name', 'ASC')->where(['status' => 1])->pluck('name', 'id')->toArray();
//        $driveType = VehicleDriveTypes::orderBy('name', 'ASC')->where(['status' => 1])->pluck('name', 'id')->toArray();
//        $priceRange = Config::get('constants.FilterPrice');
//        $turboId = Config::get('constants.turbosuperchargie');
//        $footercmsPages = Page::where(['status' => 1, 'position' => 2])->get();
//        $copywritecmsPages = Page::where(['status' => 1, 'position' => 1])->get();
//        $cetified = Config::get('constants.cetified');
//        $states = State::orderBy('name', 'ASC')->where(['status' => 1])->pluck('name', 'name')->toArray();
//        $role = \Modules\User\Entities\Role::orderBy('name', 'ASC')->where('status', 1)->where('is_menu', 1)->pluck('name', 'slug')->toArray();
//
//        view::share(['cmsPages' => $footercmsPages, 'copywritecmsPages' => $copywritecmsPages, 'roles' => $roles, 'model' => $model, 'make' => $make, 'bodyStyle' => $bodyStyle, 'category' => $category, 'priceRange' => $priceRange, 'transmission' => $transmission, 'fuleType' => $fuleType, 'cylinder' => $cylinder, 'driveType' => $driveType, 'turboId' => $turboId, 'badge' => $badge, 'cetified' => $cetified, 'states' => $states, 'role' => $role,'make_all'=>$make_all]);
    }

}
