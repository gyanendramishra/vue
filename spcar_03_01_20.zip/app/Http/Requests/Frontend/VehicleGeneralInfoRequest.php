<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class VehicleGeneralInfoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('user')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title'            =>'required|max:100',
            'type'             =>'required|integer|max:11',
            'make_id'          =>'required|integer|max:11',
            'model_id'         =>'required|integer|max:11',
            'badge_id'         =>'required|integer|max:11',
            'series_id'        =>'required|integer|max:11',
            'body_type_id'     =>'required|integer|max:11',
            'fuel_type_id'     =>'required|integer|max:11',
            'drive_type_id'    =>'required|integer|max:11',
            'transmission_id'  =>'required|integer|max:11',
            'doors'            =>'required|integer|max:11',
            'seats'            =>'required|integer|max:11',
            'gears'            =>'required|integer|max:11',
            'cylinders'        =>'required|integer|max:11',
            'year_built'       =>'required|max:11',
            'month_built'      =>'required|max:11',
            'year_complied'    =>'required|max:11',
            'turbo'            =>'required|max:11',
            'engine_capacity'  =>'required|max:10',
            'chassis_number'   =>'required|max:17'
        ];
    }
}
