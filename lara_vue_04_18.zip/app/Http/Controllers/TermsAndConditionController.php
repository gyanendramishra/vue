<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\CmsService;

class TermsAndConditionController extends Controller
{
    /**
     * Show the terms and conditions.
     *
     * @param Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request, CmsService $service) {
        try{
    		$page = $service->getTermsAndContition();
    		return view('terms-and-conditions', compact('page'));
    	}catch(\Exception $e){
    		$message = $e->getMessage();
    		return view('errors.500', compact('message'));
    	}
    }

    /**
     * Get terms and conditions data.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\CmsService $service
     * @return \Illuminate\Http\Response
     */
    public function getData(Request $request, CmsService $service){
        try{
            $response = $service->getTermsAndContition();
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
