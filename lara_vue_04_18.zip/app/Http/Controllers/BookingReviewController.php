<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\ReviewService;

class BookingReviewController extends Controller
{ 

    /**
     * Show the user booking review form.
     *
     * @param Illuminate\Http\Request $request
     * @param string $slug
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request, $slug){
        $slug_array = explode('-', $slug);
        $bookingId = last($slug_array);
        return view('booking.review', compact('bookingId'));
    }

    /**
     * Get the user booking.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\ReviewService $service
     * @return \Illuminate\Http\Response
     */
    public function addBookingReview(Request $request, ReviewService $service){
        try{
            $response = $service->addReviewService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
