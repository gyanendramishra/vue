@extends('layouts.dashboard')
@section('page_header_title', 'Dashboard')
@section('page_breadcrumb')
  	<li>
        <a href="{{ route('home') }}">
  	      	Home
  	    </a>
    </li>
    <li>
        Dashboard
    </li>
@endsection

@section('dashboard_content')
	   <dashboard-component :is-service-provider='{{ $isServiceProvider }}'></dashboard-component>
@endsection
