<template>
    <div>
        <loader-component :loading="loading"></loader-component>
        <div class="mainWpapContainer">
            <div class="login-sec">
                <div class="container">
                    <div class="login-title">
                        <h1>Log In</h1>
                    </div>
                    <div class="login-box">
                        <div class="row">
                            <div class="col-md-6 left-log-bar">
                                <div class="left-log">
                                    <h2>Login with</h2>
                                    <div class="or-icon">or</div>
                                    <div class="login-social-icons">
                                        <a href="login/facebook">
                                            <img src="/images/fb_icon.png" alt="" />
                                        </a>
                                        <a href="login/google">
                                            <img src="/images/google_plus_icon.png" alt="" />
                                        </a>
                                    </div>
                                    <div class="login-left-bg">
                                        <img src="/images/login_laft_pannel_bg.png" alt="" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 right-log-bar">
                                <div class="loginForm">
                                    <div v-if="isVerified === true">
                                        <form @submit.prevent="loginAccount">
                                            <div class="form-group">
                                                <label>
                                                    Email address 
                                                    <span class="red-color">*</span>
                                                </label>
                                                <div class="form-icon-col">
                                                    <i class="fa fa-envelope"></i> 
                                                    <input type="text" placeholder="Email address" name="email" v-model="login.email" v-validate="'required|email|max:255'" data-vv-as="email address" key="email">
                                                </div>
                                                <div v-if="errors.has('email')" class="text-danger">
                                                    {{ errors.first('email') }}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>
                                                    Password 
                                                    <span class="red-color">*</span>
                                                </label>
                                                <div class="form-icon-col">
                                                    <i class="fa fa-lock"></i> 
                                                    <input type="password" placeholder="Password" name="password" v-model="login.password" v-validate="'required|min:6|max:12'" data-vv-as="password" key="password">
                                                </div>
                                                <div v-if="errors.has('password')" class="text-danger">
                                                    {{ errors.first('password') }}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <input type="submit" value="Login" :disabled="errors.any()">
                                                <div class="forgotPassword">
                                                    <a href="/password/reset">Forgot Password?</a> 
                                                </div>
                                            </div>
                                            <div class="form-group margin-B-0">
                                                If you’re not an existing customer please <a href="/register">register</a>
                                            </div>
                                        </form>
                                    </div>
                                    <div v-else>
                                        <form @submit.prevent="verifyAccount">
                                            <div class="form-group">
                                                <label>
                                                    OTP 
                                                    <span class="red-color">*</span>
                                                </label>
                                                <div class="form-icon-col">
                                                    <i class="fa fa-envelope"></i> 
                                                    <input type="text" placeholder="OTP" name="verification_otp" v-model="verify.verification_otp" v-validate="'required|numeric|digits:4'" data-vv-as="OTP" key="verification_otp">
                                                </div>
                                                <div v-if="errors.has('verification_otp')" class="text-danger">
                                                    {{ errors.first('verification_otp') }}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div>
                                                    <input type="submit" value="Verify" :disabled="errors.any()">
                                                </div> 
                                                <div class="forgotPassword">
                                                    <a href="javascript:;" @click="resendOtp">Resend OTP</a>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="login-type-step" v-show="step === 2">
            <div class="login-type-step-inner">
                <h3>Switch account as</h3>
                <div class="login-type-btn-col">
                    <a href="/switch-account-to/service-provider">
                        Service Provider
                    </a>
                    <a href="/switch-account-to/user">
                        User
                    </a>
                </div>
            </div> 
        </div>
    </div>
</template>
<script>
    import VeeValidate from 'vee-validate';
    import LoaderComponent from "../LoaderComponent.vue";
    Vue.use(VeeValidate);
    export default {
        name: 'login-component',
        components:{
            LoaderComponent
        },
        data() {
            return {
                step : 1,
                isVerified: true,
                loading : false,
                login: {
                    email: "",
                    password: "",
                },
                verify: {
                    verification_otp: ""
                },
            }
        },
        methods: {
            loginAccount() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        axios.post('/login', {
                            email : this.login.email,
                            password : this.login.password
                        }).then(response => {
                            if(response.data.status === true){
                                this.step = 2;
                                flash(response.data.message, 'success');
                            }else{
                                if(response.data.code === 449){
                                    window.scrollTo(0, 0);
                                    this.isVerified = false;
                                }
                                if(response.data.error){
                                    var message =  response.data.error[0];
                                    flash(message.replace('_', ' '), 'error');
                                }else{
                                    flash(response.data.message, 'error');
                                }
                            }
                            this.loading = false;
                        }).catch(error => {
                            this.loading = false;
                            console.log(error);
                        });
                    }else{
                        this.loading = false;
                    }
                });
            },

            resendOtp() {
                this.loading = true;
                axios.post('/resend/otp', {
                    email : this.login.email
                }).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                    }else{
                        if(response.data.error){
                            var message =  response.data.error[0];
                            flash(message.replace('_', ' '), 'error');
                        }else{
                            flash(response.data.message, 'error');
                        }
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },

            verifyAccount() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        axios.post('/email/verify', {
                            email : this.login.email,
                            verification_otp : this.verify.verification_otp
                        }).then(response => {
                            if(response.data.status === true){
                                this.step = 2;
                                flash(response.data.message, 'success');
                            }else{
                                if(response.data.error){
                                    var message =  response.data.error[0];
                                    flash(message.replace('_', ' '), 'error');
                                }else{
                                    flash(response.data.message, 'error');
                                }
                            }
                            this.loading = false;
                        }).catch(error => {
                            this.loading = false;
                            console.log(error);
                        });
                    }else{
                        this.loading = false;
                    }
                });
            }
        },
    }
</script>
