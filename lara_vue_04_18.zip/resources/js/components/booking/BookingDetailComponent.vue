<template>
    <div>
        <loader-component :loading="loading"></loader-component>
        <div class="formBox editProfileForm">
            <div class="formBoxInner">
                <div class="dashbord-sec">   
                    <div class="my-booking-sec my-booking-detail">
                        <a class="booking-cancel-btn" href="javascript:;"  
                            v-if="
                                ((booking.booking_status === 'awaiting') && booking.is_customer) || 
                                (booking.booking_status === 'accepted') || 
                                (booking.booking_status === 'scheduled')
                            " 
                            v-on:click="cancelBooking">
                            Cancel
                        </a>
                        <a class="booking-cancel-btn" :href="'/booking/complaint/'+ booking.title | prepareSlug(booking.id)"  
                            v-if="
                                (booking.booking_status === 'started') || 
                                (booking.booking_status === 'ended') || 
                                (booking.booking_status === 'completed') || 
                                (booking.booking_status === 'complained')
                            " 
                            >
                            Complain
                        </a>
                        <h3>{{ booking.title }}</h3>
                        <div class="inner-page-sec-title">
                            <h4>Description</h4>
                        </div>
                        <p>{{ booking.description }}</p>
                        <div class="schedule-and-budget">
                            <div class="schedule-time">
                                <strong>
                                    Schedule Time:
                                </strong> 
                                <span>
                                    {{ booking.request_date_time | formatDate }}
                                </span>
                            </div>
                            <div class="booking-budget"> 
                                <strong>Budget:</strong> 
                                <span class="price-booking">${{ booking.budget | formatNumber }}</span> 
                                <small>(incl. all taxes)</small>
                            </div>
                        </div>
                        <div class="booking-provider-sec" v-if="booking.is_customer  === false">
                            <div class="booking-provider-col">
                                <img :src="booking.user_full_image_path" alt="" />
                                <h5>{{ booking.user_name }}</h5>
                                <span>{{ booking.category_title }}</span>
                            </div>
                            <a href="javascript:;" class="book-pro-arrow">
                                <img src="/images/booking_provider_arrow.png" alt="" />
                            </a>
                        </div>
                        <div class="booking-provider-sec" v-else>
                            <div class="booking-provider-col">
                                <img :src="booking.provider_full_image_path" alt="" />
                                <h5>{{ booking.provider_name }}</h5>
                                <span>{{ booking.category_title }}</span>
                            </div>
                            <a href="javascript:;" class="book-pro-arrow">
                                <img src="/images/booking_provider_arrow.png" alt="" />
                            </a>
                        </div>
                        <div class="book-pay-status-sec">
                            <ul>
                                <li>
                                    <div class="book-status-left">
                                        <strong>Booking Status</strong>
                                    </div>
                                    <div class="book-status-right">
                                        <span :class="'booking-status-label '+ booking.booking_status">
                                            {{ booking.booking_status }}
                                        </span>
                                    </div>
                                </li>
                                <div v-if="(booking.payable_amount > 0) && (booking.booking_status != 'complained')">
                                    <li>
                                        <div class="book-status-left">
                                            <strong>Payble Amount</strong>
                                        </div>
                                        <div class="book-status-right">
                                            <span class="price-booking">
                                                ${{ booking.payable_amount | formatNumber }}
                                            </span> 
                                            <small>(incl. all taxes)</small>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="book-status-left">
                                            <strong>Payment Status</strong>
                                        </div>
                                        <div class="book-status-right">
                                            <div :class="booking.payment_status">
                                                {{ booking.payment_status }}
                                            </div>
                                        </div>
                                    </li>
                                </div>
                            </ul>
                            <div class="chat-and-link-sec">
                                <a :href="booking.invoice_file_path" target="_blank" class="invoice-link" v-if="(booking.booking_status != 'complained') && (booking.payable_amount > 0)">View Invoice</a>
                                <div v-if="booking.booking_status != 'awaiting'">
                                    <div class="chat-btn" v-if="((booking.is_customer && (booking.payment_status == 'paid')) || (booking.is_customer && (isChatInitiated === true)) || ((booking.is_customer === false) || (isChatInitiated === true)))">
                                        <a :href="'/booking/chat/'+ booking.title | prepareSlug(booking.id)">
                                            <img src="/images/top_category_img01.jpg" alt="" />
                                            <span>Chat</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div v-if="booking.is_customer === false">
                                <div class="book-btn-sec" v-if="booking.booking_status === 'awaiting'">
                                    <a href="javascript:;" class="btn-default" v-on:click="rejectBooking">Reject</a>
                                    <a href="javascript:;" class="btn-default" v-on:click="acceptBooking">Accept</a>
                                </div>
                                <div class="book-btn-sec" v-if="booking.booking_status === 'accepted'">
                                    <a :href="'/booking/invoice/'+ booking.title | prepareSlug(booking.id)" class="btn-default">Generate Invoice</a>
                                </div>
                                <div class="book-btn-sec" v-if="booking.booking_status === 'scheduled'">
                                    <a href="javascript:;" class="btn-default" v-on:click="startBookingJob">Start Job</a>
                                </div>
                                <div class="book-btn-sec" v-if="booking.booking_status === 'started'">
                                    <a href="javascript:;" class="btn-default" v-on:click="endBookingJob">End Job</a>
                                </div>
                                <div class="book-btn-sec" v-if="booking.booking_status === 'ended'">
                                    <a href="javascript:;" class="btn-default">Waiting for Approval</a>
                                </div>
                            </div>
                            <div v-else>
                                <div class="book-btn-sec" v-if="(booking.payable_amount > 0) && (booking.payment_status === 'unpaid')">
                                    <a :href="'/booking/invoice/payment/'+ booking.title | prepareSlug(booking.id)" class="btn-default">Make Payment</a>
                                </div>
                                <div class="book-btn-sec" v-if="booking.booking_status === 'ended'">
                                    <a :href="'/booking/review/'+ booking.title | prepareSlug(booking.id)" class="btn-default">Approve & Review</a>
                                </div>
                            </div>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import moment from "moment";
    import fire from '../../firebase/init';
    import mixin from '../../mixin/mixin.js';
    import LoaderComponent from "../LoaderComponent.vue";
    export default {
        name: "booking-detail-component",
        components:{
            LoaderComponent
        },
        mixins: [mixin],
        props:["bookingId"],
        data: function () {
            return {
                loading: false,
                booking: {},
                isChatInitiated: false
            }
        },
        created: function(){
            this.loading = true;
            this.getBooking();
        },
        filters: {
            formatDate : function(date){
                return moment(date, 'YYYY-MM-DD H:i:s').format('DD MMM YYYY h:mm a');
            },
            formatNumber(value) {
                return (value/1).toFixed(2);
            },
            prepareSlug (str, id) {
                if(!str) return "";
                return str.toLowerCase().replace(/ /g, '-')+"-"+id;
            }
        },
        methods: {
            getBooking() {
                this.loading = true;
                axios.post('/booking/get/data', {
                    id: this.bookingId
                }).then(response => {
                    if(response.data.status === true){
                        this.booking = response.data.data;
                        let ref = fire.database().ref('conversation');
                        ref.child(this.booking.id).child('chat').on('value', snapshot => {
                            let data = snapshot.val();
                            if(data){
                                this.isChatInitiated = true;
                            }
                        });
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            acceptBooking(){
                let status = "accepted";
                this.changeBookingStatus(status);
            },
            rejectBooking(){
                let status = "rejected";
                this.changeBookingStatus(status);
            },
            cancelBooking(){
                let status = "cancelled";
                this.changeBookingStatus(status);
            },
            startBookingJob(){
                let status = "started";
                this.changeBookingStatus(status);
            },
            endBookingJob(){
                let status = "ended";
                this.changeBookingStatus(status);
            },
            changeBookingStatus(status) {
                this.loading = true;
                axios.post('/booking/change-booking-status', {
                    id: this.bookingId,
                    status: status,
                }).then(response => {
                    if(response.data.status === true){
                        this.getBooking();
                        flash(response.data.message, "success");
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            }
        },
    }
</script>
