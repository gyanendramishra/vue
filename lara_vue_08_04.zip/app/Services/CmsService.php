<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class CmsService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'pages/';

    /**
     * About us cms.
     *
     * @return Illuminate\Http\Response
     */
    public function getAboutUs() {
        $uri = $this->base_uri;
        $uri .= 'about-us';
        return $this->getServiceRequest($uri);
    }

    /**
     * FAQ cms.
     *
     * @return Illuminate\Http\Response
     */
    public function getFaq() {
        $uri = $this->base_uri;
        $uri .= 'faq';
        return $this->getServiceRequest($uri);
    }

    /**
     * Terms and condition cms.
     *
     * @return Illuminate\Http\Response
     */
    public function getTermsAndContition() {
        $uri = $this->base_uri;
        $uri .= 'terms-condition';
        return $this->getServiceRequest($uri);
    }

    /**
     * Privacy Policy cms.
     *
     * @return Illuminate\Http\Response
     */
    public function getPrivacyPolicy() {
        $uri = $this->base_uri;
        $uri .= 'privacy-policy';
        return $this->getServiceRequest($uri);
    }

    /**
     * Privacy Policy cms.
     *
     * @return Illuminate\Http\Response
     */
    public function getContactUs() {
        $uri = $this->base_uri;
        $uri .= 'contact-us';
        return $this->getServiceRequest($uri);
    }

    /**
     * Send Inquiry.
     *
     * @param  array  $data
     * @return Illuminate\Http\Response
     */
    public function sendInquiryService(array $data) {
        $uri = 'api/users/contactUs'; 
        return $this->postServiceRequest($uri, $data);
    }

}