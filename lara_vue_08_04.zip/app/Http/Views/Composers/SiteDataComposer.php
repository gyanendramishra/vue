<?php

namespace App\Http\Views\Composers;

use Illuminate\View\View;
use App\Services\CmsService;
use App\Services\MyProfileService;

class SiteDataComposer
{

    /**
     * The user.
     *
     * @var User
     */
    protected $cmsService;
    protected $profileService;

    /**
     * Create a new user composer.
     *
     * @return void
     */
    public function __construct(CmsService $cmsService, MyProfileService $profileService)
    {
        $this->cmsService = $cmsService;
        $this->profileService = $profileService;
    }
    /**
     * Bind data to the view.
     *
     * @param  View  $view
     * @return void
     */
    public function compose(View $view)
    {
        $viewData = [];

        $authUser = \Session::get('auth_user');
        $viewData['authUser'] = $authUser;
        
        try{
            $cms = $this->cmsService->getAboutUs();
            $user = $this->profileService->getProfileService();
            
            if($user->status === true){
                $user->data->token = $authUser->token;
                $user->data->isServiceProvider = false;
                if($authUser->isServiceProvider){
                    $user->data->isServiceProvider = true;
                }
                \Session::forget('auth_user');
                \Session::put('auth_user', $user->data);
                $viewData['authUser'] = $user->data;
            }
            if($cms->status == true){
                $data = $cms->ConfigSettings;
                $socialLinks = json_decode($data->SOCIAL_LINKS);
                $viewData['socialLinks'] = $socialLinks;
            }
        }catch(\Exception $e){}

        $view->with($viewData);
    }
}