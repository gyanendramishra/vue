<template>
    <div :class="alertType" role="alert" v-show="show">
        {{ body }}
    </div>
</template>
<script>
    export default {
        name: "app-flash",
        props: ["message"],
        data() {
            return {
            alertType: "flash flash-success",
            show: false,
            body: ""
            };
        },
        created() {
            if (this.message) {
                this.flash(this.message);
            }
            window.events.$on("flash", message => this.flash(message));
        },
        beforeDestroy() {
            window.events.$off("flash", message => this.flash(message));
        },
        methods: {
            flash(data) {
                this.alertType = "flash flash-" + data.variant;
                this.body = data.message;
                this.show = true;
                setTimeout(() => {
                    this.hide();
                }, 5000);
            },
            hide() {
                this.show = false;
            }
        }
    };
</script>

<style scoped>
    .flash {
        position: fixed;
        right: 5px;
        bottom: 0px;
        z-index: 1000;
        padding: 0.75rem 1.25rem;
        margin-bottom: 1rem;
        border: 1px solid transparent;
        border-top-color: transparent;
        border-right-color: transparent;
        border-bottom-color: transparent;
        border-left-color: transparent;
        border-radius: 0.25rem;
    }

    .flash-success {
        color: #155724;
        background-color: #d4edda;
        border-color: #c3e6cb;
    }
    .flash-error {
        color: #721c24;
        background-color: #f8d7da;
        border-color: #f5c6cb;
    }
    .flash-warning {
        color: #856404;
        background-color: #fff3cd;
        border-color: #ffeeba;
    }
    .flash-info {
        color: #0c5460;
        background-color: #d1ecf1;
        border-color: #bee5eb;
    }
</style>
