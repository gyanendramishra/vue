<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div class="my-booking-sec my-booking-detail">
                    <h3>{{ booking.title }}</h3>
                    <form @submit.prevent="addReview">
                        <div class="form-row full-input-box">
                            <div class="form-group">
                                <label>
                                    Rating
                                    <span class="red-color">*</span>
                                </label>
                                <select v-model="review.rate" v-validate="'required'" data-vv-name="rate" data-vv-as="rating">
                                    <option value="1">1</option>
                                    <option value="3">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                </select>
                                <div v-if="errors.has('rate')" class="text-danger">
                                    {{ errors.first('rate') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row full-input-box">
                            <div class="form-group">
                                <label>
                                    Write your review
                                    <span class="red-color">*</span>
                                </label>
                                <textarea placeholder="Write your review" v-model="review.comment" v-validate="'required'" data-vv-name="comment" data-vv-as="review"></textarea>
                                <div v-if="errors.has('comment')" class="text-danger">
                                    {{ errors.first('comment') }}
                                </div>
                            </div>
                        </div>
                        <div class="full-btn-col">
                            <input type="submit" value="Submit" :disabled="errors.any()">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import moment from "moment";
    import VeeValidate from 'vee-validate';
    import LoaderComponent from "../LoaderComponent.vue";
    Vue.use(VeeValidate);
    export default {
        name: "booking-review-component",
        components:{
            LoaderComponent
        },
        props:["bookingId"],
        data: function () {
            return {
                loading: false,
                booking: {},
                review: {
                    booking_id: "",
                    service_id: "",
                    rate: 5,
                    comment: ""
                }
            }
        },
        created: function(){
            this.loading = true;
            this.getBooking();
        },
        filters: {
            prepareSlug (str, id) {
                if(!str) return "";
                return str.toLowerCase().replace(/ /g, '-')+"-"+id;
            }
        },
        methods: {
            getBooking() {
                this.loading = true;
                axios.post('/booking/get/data', {
                    id: this.bookingId
                }).then(response => {
                    if(response.data.status === true){
                        this.booking = response.data.data;
                        this.review.booking_id = this.booking.id;
                        this.review.service_id = this.booking.service_id;
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            addReview() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        axios.post('/booking/review/add', this.review).then(response => {
                                if(response.data.status === true){
                                    flash(response.data.message, 'success');
                                    window.location = '/booking/detail/'+this.booking.title.toLowerCase().replace(/ /g, '-')+"-"+this.booking.id; 
                                }else{
                                    if(response.data.error){
                                        var message =  response.data.error[0];
                                        flash(message.replace('_', ' '), 'error');
                                    }else{
                                        flash(response.data.message, 'error');
                                    }
                                }
                                this.loading = false;
                            }).catch(error => {
                                this.loading = false;
                                console.log(error);
                            });
                    }else{
                        this.loading = false;
                    }
                });
            }
        }
    }
</script>
