<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div class="my-booking-sec my-booking-detail">
                    <h3>{{ booking.title }}</h3>
                    <div class="invoice-date">
                        <span>{{ booking.request_date_time | formatDate }}</span>
                    </div>
                    <div class="book-pay-status-sec invoice-status">
                        <ul>
                            <li>
                                <div class="book-status-left">
                                <strong>Payable Amount:</strong>
                                </div>
                                <div class="book-status-right">
                                    <span class="price-booking">
                                        <strong>$<span ref="payable_amount">{{ booking.payable_amount }}</span></strong>
                                    </span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <form @submit.prevent="makePayment">
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                Name on card
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="Name" name="name" v-model="card.name" v-validate="'required|max:255'" data-vv-as="name">
                            <div v-if="errors.has('name')" class="text-danger">
                                {{ errors.first('name') }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                Card number
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="Email" name="number" v-model="card.number" v-validate="'required|credit_card|max:16'" data-vv-as="card number" readonly>
                            <div v-if="errors.has('number')" class="text-danger">
                                {{ errors.first('number') }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                Expiry month
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="Mobile Number" name="exp_month" v-model="card.exp_month" v-validate="'required|numeric|digits:2'" data-vv-as="exp month">
                            <div v-if="errors.has('exp_month')" class="text-danger">
                                {{ errors.first('exp_month') }}
                            </div>
                        </div>
                        <div class="form-group">
                            <label>
                                Expiry year
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="Expiry year" name="exp_year" v-model="card.exp_year" v-validate="'required|numeric|digits:4'" data-vv-as="exp year">
                            <div v-if="errors.has('exp_year')" class="text-danger">
                                {{ errors.first('exp_year') }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                CVC
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="CVC" name="cvc" v-model="card.cvc" v-validate="'required|numeric|min:3|max:4'" data-vv-as="cvc">
                            <div v-if="errors.has('cvc')" class="text-danger">
                                {{ errors.first('cvc') }}
                            </div>
                        </div>
                    </div>
                    <div class="full-btn-col">
                        <input type="submit" value="Update" :disabled="errors.any()">
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
    import moment from "moment";
    import VeeValidate from 'vee-validate';
    import LoaderComponent from "../LoaderComponent.vue";
    Vue.use(VeeValidate);
    export default {
        name: "booking-invoice-payment-component",
        components:{
            LoaderComponent
        },
        props:["bookingId"],
        data: function () {
            return {
                loading: false,
                booking: {},
                card: {
                    number: '4242424242424242',
                    cvc: '123',
                    exp_month: '01',
                    exp_year: '19'
                }
            }
        },
        created: function(){
            this.loading = true;
            this.getBooking();
        },
        filters: {
            formatDate : function(date){
                return moment(date, 'YYYY-MM-DD H:i:s').format('DD MMM YYYY h:mm a');
            },
            formatNumber(value) {
                return (value/1).toFixed(2);
            },
            prepareSlug (str, id) {
                if(!str) return "";
                return str.toLowerCase().replace(/ /g, '-')+"-"+id;
            }
        },
        methods: {
            getBooking() {
                this.loading = true;
                axios.post('/booking/get/data', {
                    id: this.bookingId
                }).then(response => {
                    if(response.data.status === true){
                        this.booking = response.data.data;
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            makePayment() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        this.createToken();
                    }else{
                        this.loading = false;
                    }
                });
            },
            createToken() {
                Stripe.setPublishableKey(this.booking.stripe_public_key);
                //var stripe = Stripe(this.booking.stripe_public_key);
                Stripe.createToken(this.card, $.proxy(this.stripeResponseHandler, this));
            },
            stripeResponseHandler(status, response) {
                if (response.error) {
                    flash(response.error.message, 'error');
                    this.loading = false;
                } else {
                    // token to create charge  
                    var token = response.id;
                    axios.post('/booking/invoice/payment/make-payment', {
                        stripeToken: token,
                        booking_id: this.booking.id,
                    }).then(response => {
                        if(response.data.status === true){
                            flash(response.data.message, 'success');
                            window.location = '/booking/detail/'+this.booking.title.toLowerCase().replace(/ /g, '-')+"-"+this.booking.id; 
                        }else{
                            if(response.data.error){
                                var message =  response.data.error[0];
                                flash(message.replace('_', ' '), 'error');
                            }else{
                                flash(response.data.message, 'error');
                            }
                        }
                        this.loading = false;
                    }).catch(error => {
                        this.loading = false;
                        console.log(error);
                    });
                }
            }
        }
    }
</script>
