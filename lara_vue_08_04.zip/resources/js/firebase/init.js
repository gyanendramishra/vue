import firebase from 'firebase/app';
import firestore from 'firebase/firestore';
// Initialize Firebase
var config = {
    apiKey: "AIzaSyB6jf9xLG-pvv2v97Tl0CAlUtXjxSjO77s",
    authDomain: "ondemandchat-21014.firebaseapp.com",
    databaseURL: "https://ondemandchat-21014.firebaseio.com",
    projectId: "ondemandchat-21014",
    storageBucket: "ondemandchat-21014.appspot.com",
    messagingSenderId: "688147486482"
};
const firebaseApp = firebase.initializeApp(config);
firebaseApp.firestore().settings({ timestampsInSnapshots: true });
export default firebaseApp.firestore();
