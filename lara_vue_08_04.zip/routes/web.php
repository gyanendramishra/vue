<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

# Home route
Route::group(['middleware'=>'prevent-backhistory'], function(){

	Route::get('/', 'HomeController@index')->name('home');

	Route::post('/near-by-data', 'HomeController@getNearByData')->name('near.by.data');

	# Cms pages 

	Route::group(['prefix'=>'about-us'], function(){
		# Show contact us 
		Route::get('/', 'AboutUsController@index')->name('about.us');
		# Get contact us 
		Route::get('/get', 'AboutUsController@getAboutUs')->name('about.us.data');
	});

	Route::group(['prefix'=>'faq'], function(){
		# Show contact us 
		Route::get('/', 'FaqController@index')->name('faq');
		# Get contact us 
		Route::get('/get', 'FaqController@getFaq')->name('faq.data');
	});

	Route::group(['prefix'=>'privacy-policy'], function(){
		# Show contact us 
		Route::get('/', 'PrivacyPolicyController@index')->name('privacy.policy');
		# Get contact us 
		Route::get('/get', 'PrivacyPolicyController@getData')->name('faqdata');
	});

	Route::group(['prefix'=>'terms-and-conditions'], function(){
		# Show contact us 
		Route::get('/', 'TermsAndConditionController@index')->name('terms.and.conditions');
		# Get contact us 
		Route::get('/get', 'TermsAndConditionController@getData')->name('terms.and.conditions.data');
	});

	Route::group(['prefix'=>'contact-us'], function(){
		# Show contact us 
		Route::get('/', 'ContactUsController@index')->name('contact.us');
		# Get contact us 
		Route::get('/get', 'ContactUsController@getContactUs')->name('contact.us.data');
		# Inquire contact us 
		Route::post('/send', 'ContactUsController@inquire')->name('contact.us.inquire');
	});
	
	Route::get('/services', 'ServicesController')->name('services');


	# Service providers
	Route::group(['prefix'=> 'service-providers'], function(){
		# Get service providers
		Route::match(['GET', 'POST'], '/', 'ServiceProvidersController@index')->name('service.providers');
		# Get service providers
		Route::post('/filter', 'ServiceProvidersController@filterServiceProviders')->name('filter.service.providers');
		# Get categories
		Route::get('/categories', 'ServiceProvidersController@getCategories')->name('service.provider.categories');
	});
	Route::group(['prefix'=> 'service'], function(){
		# Get service detail
		Route::get('/{slug}', 'ServiceProvidersController@getServiceDetail')->name('service.detail');
		# Get service detail
		Route::post('/data', 'ServiceProvidersController@getServiceDetailData')->name('service.detail.data');
	});


	# Auth route group
	Route::group(['as'=>'user.', 'namespace'=>'Auth'], function(){
		# Login form route
		Route::get('/login', 'LoginController@index')
			->name('login.form');
		# Register form route
		Route::get('/register', 'RegisterController@index')
			->name('register.form');
		# Register route
		Route::post('/register', 'RegisterController@register')
			->name('register');
		# Login route
		Route::post('/login', 'LoginController@login')
			->name('login');
		# Logout route
		Route::get('logout', 'LoginController@logout')
			->name('logout');
		# Forgot password form route
		Route::get('/password/reset', 'ForgotPasswordController@index')
			->name('password.request');
		# Forgot password reset mail route
		Route::post('/password/email', 'ForgotPasswordController@sendResetPasswordEmail')
			->name('password.email');
		# Reset password route
		Route::post('/password/reset', 'ResetPasswordController@resetPassword')
			->name('password.update');
		# Verify email route
		Route::post('/email/verify', 'VerificationController@verify')
			->name('verify.email');
		# Verify email route
		Route::post('/resend/otp', 'RegisterController@resendOtp')
			->name('resend.otp');
		# Social login
		Route::get('/login/{provider}', 'SocialiteController@redirectToProvider');
		Route::get('/login/{provider}/callback', 'SocialiteController@handleProviderCallback');
	});

	# After Auth route group
	Route::group(['as'=>'user.', 'middleware'=>'auth'], function(){
		# Dashboard route
		Route::group(['prefix'=>'dashboard'], function(){
			# Show dashboard route
			Route::get('/', 'DashboardController@index')
			->name('dashboard');
			# Get dashboard route
			Route::post('/get', 'DashboardController@getDashboard')
			->name('dashboard.get');

			# Toggle availability
			Route::post('/toggle-availability', 'DashboardController@toggleAvailablity')
			->name('dashboard.toggle.availability');
		});

		# Switch account
		Route::get('/switch-account-to/{as}', 'DashboardController@switchAccountAs')
			->name('switch.account');

		# Change Password
		Route::get('/change-password', 'ChangePasswordController@index')
			->name('change.password');
		# Update Password
		Route::post('/update-password', 'ChangePasswordController@updatePassword')
			->name('update.password');
		# My Profile 
		Route::group(['prefix'=>'my-profile'], function(){
			# Show profile
			Route::get('/', 'MyProfileController@index')
			->name('profile');
			# Get profile
			Route::get('/get', 'MyProfileController@getProfile')
			->name('get.profile');
			# Update Profile
			Route::post('/update', 'MyProfileController@updateProfile')
				->name('update.profile');
		});

		# My earnings 
		Route::group(['prefix'=>'my-earnings'], function(){
			# Show earning
			Route::get('/', 'MyEarningController@index')
			->name('earnings');
			# Get earnings
			Route::post('/get', 'MyEarningController@getEarnings')
			->name('get.earnings');
		});

		# My reviews 
		Route::group(['prefix'=>'my-reviews'], function(){
			# Show earning
			Route::get('/', 'MyReviewsController@index')
			->name('reviews');
			# Get earnings
			Route::post('/get', 'MyReviewsController@getReviews')
			->name('get.reviews');
		});

		# My Operational times

		Route::group(['prefix'=>'operational-times'], function(){
			# Show operational times 
			Route::get('/', 'OperationalTimesController@index')
				->name('operational.times');
			# Get operational times 
			Route::get('/get', 'OperationalTimesController@getOperationalTimes')
				->name('get.service');
			# Update operational times 
			Route::post('/update', 'OperationalTimesController@updateOperationalTimes')
				->name('save.update.service');
		});

		# My Service
		Route::group(['prefix'=>'my-service'], function(){
			# Show my Service 
			Route::get('/', 'MyServiceController@index')
				->name('service');
			# Get my Service 
			Route::get('/get', 'MyServiceController@getService')
				->name('get.service');
			# Save/Update Service
			Route::post('/add-update', 'MyServiceController@saveUpdateService')
				->name('save.update.service');
		});

		# Payment
		Route::group(['prefix'=>'payment'], function(){
			# My Payment 
			Route::get('/', 'PaymentController@index')
					->name('payment');
			# Get my mayment account
			Route::get('/get/account', 'PaymentController@getPaymentAccount')
					->name('payment.get');
			# Update My Payment Account
			Route::post('/add-update/account', 'PaymentController@addUpdatePaymentAccount')
					->name('payment.add.update');
		});

		# Booking
		Route::group(['prefix'=>'booking'], function(){
			# My booking 
			Route::get('/', 'BookingController@index')
			->name('booking');
			# Get my booking 
			Route::post('/get', 'BookingController@getBookings')
				->name('get.booking');
			# Book service
			Route::post('/book-service', 'BookingController@bookService')->name('service.book');

			# Booking change status
			Route::post('/change-booking-status', 'BookingController@changeBookingStatus')->name('booking.change.status');

			# Get booking  data
			Route::post('/get/data', 'BookingController@getBooking')
				->name('booking.data');
		});

	});

	# Booking detail
	Route::group(['prefix'=>'booking/detail'], function(){
		# Get booking detail
		Route::get('/{slug}', 'BookingDetailController@index')
				->name('booking.detail');
	});

	# Booking invoice
	Route::group(['prefix'=>'booking/invoice'], function(){
		# Get booking invoice
		Route::get('/{slug}', 'BookingInvoiceController@index')
				->name('booking.invoice');
		# Send booking invoice
		Route::post('/send', 'BookingInvoiceController@sendBookingInvoice')
				->name('booking.send.invoice');
	});

	# Booking complain
	Route::group(['prefix'=>'booking/complaint'], function(){
		# Get booking complain
		Route::get('/{slug}', 'BookingComplaintController@index')
				->name('booking.complaint');
		# Add booking complain
		Route::post('/add', 'BookingComplaintController@addBookingComplaint')
				->name('booking.add.complaint');
	});

	# Booking approve/review
	Route::group(['prefix'=>'booking/review'], function(){
		# Get booking reviews
		Route::get('/{slug}', 'BookingReviewController@index')
				->name('booking.review');
		# Add booking reviews
		Route::post('/add', 'BookingReviewController@addBookingReview')
				->name('booking.add.review');
	});

	# Booking chat
	Route::group(['prefix'=>'booking/chat'], function(){
		# Get booking reviews
		Route::get('/{slug}', 'BookingChatController@index')
				->name('booking.chat');
	});

	# Booking invoice payemnt
	Route::group(['prefix'=>'booking/invoice/payment'], function(){
		# Make booking invoice payment
		Route::post('/make-payment', 'BookingInvoicePaymentController@makeInvoicePayment')
				->name('booking.invoice.make.payment');
		# Get booking invoice payment
		Route::get('/{slug}', 'BookingInvoicePaymentController@index')
				->name('booking.invoice');
	});

	# Get categories listing
	Route::get('/listing/get-categories', 'CategoryController@getParentCategories')
					->name('listing.categories');
	# Get sub categories listing
	Route::post('/listing/get-sub-categories', 'CategoryController@getSubCategories')
					->name('listing.sub.categories');

});

/* Fallback route */

Route::fallback(function() {
    return view('errors.404');
});

