<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\UserService;

class DashboardController extends Controller
{ 

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {}

    /**
     * Show the application user dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(){
    
        return view('users.dashboard');
    }

    /**
     * Show the application user profile.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function profile(Request $request){
        $user = $request->session()->get('auth_user');
        return view('users.profile', compact('user'));
    }
}
