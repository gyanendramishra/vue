<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\CmsService;

class AboutUsController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  CmsService $service
     * @return \Illuminate\Http\Response
     */
    public function __invoke(CmsService $service){
    	try{
    		$page = $service->getAboutUs();
        	return view('about-us', compact('page'));
    	}catch(\Exception $e){
    		$message = $e->getMessage();
            return view('errors.500', compact('message'));
    	}
    }
}
