<?php 
namespace App\Services\Traits;

use GuzzleHttp\Client;
use Illuminate\Http\Response;

trait ServiceTrait
{
    /**
     * The web service request url.
     */
    protected $url;

    /**
     * The web service request client.
     */
    protected $http;

    /**
     * The web service request headers.
     */
    protected $headers;

    /**
     * Create a new service instance.
     * @return void
     */
    public function __construct(Client $client) {

        $this->url = '192.168.4.164/ondemand/';
        //$this->url = 'http://ds15.projectstatus.co.uk/ondemand/api/';
        $this->http = $client;
        $this->headers = [
            'Cache-Control' => 'no-cache',
            'Accept' => 'application/json',
            //'Content-Type' => 'application/x-www-form-urlencoded',
            'Device-Type'=> 'iOS',
            'Version-Code'=> 1,
        ];
    }

    /**
     * Intract with the service and get data.
     * @param  string  $uri
     * @return Illuminate\Http\Response
     */
    private function getServiceRequest(string $uri = null) {
        $full_path = $this->url;
        $full_path .= $uri;

        $request = $this->http->get($full_path, [
            'headers'         => $this->headers,
            'timeout'         => 30,
            'connect_timeout' => true,
            'http_errors'     => true,
        ]);

        $response = $request ? $request->getBody()->getContents() : null;
        $status = $request ? $request->getStatusCode() : 500;

        if ($response && $status === 200 && $response !== 'null') {
            return (object) json_decode($response);
        }

        return null;
    }

    /**
     * Intract with the service and post data.
     * @param  string  $uri
     * @param  array  $post_params
     * @return Illuminate\Http\Response
     */
    private function postServiceRequest(string $uri = null, array $post_params = []) {
        $full_path = $this->url;
        $full_path .= $uri;

        
        $request = $this->http->post($full_path, [
            'headers'         => $this->headers,
            'timeout'         => 30,
            'connect_timeout' => true,
            'http_errors'     => true,
            'form_params'     => $post_params,
        ]);

        $response = $request ? $request->getBody()->getContents() : null;
        $status = $request ? $request->getStatusCode() : 500;
        
        if ($response && $status === 200 && $response !== 'null') {
            return (object) json_decode($response);
        }

        return null;
    }
}