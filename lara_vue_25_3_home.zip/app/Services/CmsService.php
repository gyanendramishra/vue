<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class CmsService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'pages/';

    /**
     * About us cms.
     *
     * @return Illuminate\Http\Response
     */
    public function getAboutUs() {

        $uri = $this->base_uri.'about-us';

        return $this->getServiceRequest($uri);
    }

    /**
     * FAQ cms.
     *
     * @return Illuminate\Http\Response
     */
    public function getFaq() {

        $uri = $this->base_uri.'faq';

        return $this->getServiceRequest($uri);
    }

    /**
     * Terms and condition cms.
     *
     * @return Illuminate\Http\Response
     */
    public function getTermsAndContition() {

        $uri = $this->base_uri.'terms-condition';

        return $this->getServiceRequest($uri);
    }

    /**
     * Privacy Policy cms.
     *
     * @return Illuminate\Http\Response
     */
    public function getPrivacyPolicy() {

        $uri = $this->base_uri.'privacy-policy';

        return $this->getServiceRequest($uri);
    }

    

}