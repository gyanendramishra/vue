@extends('layouts.app')

@section('content')

{{-- Main slider component --}}
<main-sliders-component></main-sliders-component>

{{-- How it work component --}}
<how-it-works-component></how-it-works-component>

{{-- Near service providers and to category slider component --}}
<near-service-providers-component></near-service-providers-component>

@endsection
