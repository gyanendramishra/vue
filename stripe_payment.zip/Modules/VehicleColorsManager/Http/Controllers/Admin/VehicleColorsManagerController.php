<?php

namespace Modules\VehicleColorsManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\VehicleColorsManager\Entities\VehicleColors;
use Yajra\DataTables\Utilities\Request as DatatableRequest;

class VehicleColorsManagerController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        $title = "Vehicle Colors";
        return view('vehiclecolorsmanager::Admin.vehiclecolorsmanager.index', compact('title'));
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $vehiclecolors = VehicleColors::query();
        if ($request->status != '') {
            $vehiclecolors = $vehiclecolors->where('status', $request->status);
        }
        if ($request->slug != '') {
            $slug = $request->slug;
            $vehiclecolors = $vehiclecolors->whereHas('vehicleColorTranslation', function($q) use($slug) {
                $q->where('name', 'LIKE', lcfirst($slug) . '%');
                $q->orWhere('name', 'LIKE', $slug . '%');
            });
        }
        $vehiclecolors = $vehiclecolors->get();
        return datatables()->of($vehiclecolors)
                        ->addColumn('action', function ($vehiclecolors) {
                            $actions = "";
                            $actions .= "<a href=\"" . route('admin.vehiclecolorsmanager.edit', ['id' => $vehiclecolors->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        $title = "Vehicle Colors";
        return view('vehiclecolorsmanager::Admin.vehiclecolorsmanager.createOrUpdate', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request) {

        $locales = config('app.locales');
        $valMessage = [
            'en_name.regex' => 'The name format is invalid In english language.'
        ];
        foreach ($locales as $key => $value) {
            $valRule[$key . '_name'] = 'required|max:200|unique:vehicle_colors_translations,name|unique_space_check:vehicle_colors_translations,name';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_name.required'] = ' The name field is required in ' . $value . ' language.';
            $valMessage[$key . '_name.max'] = ' Sorry, you can\'t add the name more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_name.unique'] = ' Name must be unique in ' . $value . ' language.';
            $valMessage[$key . '_name.unique_space_check'] = ' Name must be unique in ' . $value . ' language.';
        }
        $valRule['en_name'] = 'required|string|regex:/^[\pL\pN\s\-\_]+$/u|max:200|unique:vehicle_series_translations,name|unique_space_check:vehicle_series_translations,name';

        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['name'] = $request->input($key . '_name');
            }
            $article_data['status'] = $request->input('status');

            VehicleColors::create($article_data);
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->getMessage());
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.vehiclecolorsmanager.index')->with('success', 'Vehicle Colors has been saved Successfully');
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show(VehicleColors $vehiclecolors) {
        $title = "Vehicle Colors";
        return view('vehiclecolorsmanager::Admin.vehiclecolorsmanager.show', compact('vehiclecolors', 'title'));
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id) {
        $title = "Vehicle Colors";
        $vehiclecolors = VehicleColors::find($id);
        return view('vehiclecolorsmanager::Admin.vehiclecolorsmanager.createOrUpdate', compact('vehiclecolors', 'title'));
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id) {
        $locales = config('app.locales');
        $valMessage = [
            'en_name.regex' => 'The name format is invalid In english language.'
        ];
        foreach ($locales as $key => $value) {
            $valRule[$key . '_name'] = 'required|max:200|unique:vehicle_colors_translations,name,' . $request->segment(3) . ',vehicle_colors_id|unique_space_check:vehicle_colors_translations,name,' . $request->segment(3) . ',vehicle_colors_id';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_name.required'] = ' The name field is required in ' . $value . ' language.';
            $valMessage[$key . '_name.max'] = 'Sorry, you can\'t add the name more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_name.unique'] = ' Name must be unique in ' . $value . ' language.';
            $valMessage[$key . '_name.unique_space_check'] = ' Name must be unique in ' . $value . ' language.';
        }
        $valRule['en_name'] = 'required|string|regex:/^[\pL\pN\s\-\_]+$/u|max:200|unique:vehicle_series_translations,name|unique_space_check:vehicle_series_translations,name';

        $validatedData = $request->validate($valRule, $valMessage);


        try {

            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['name'] = $request->input($key . '_name');
            }
            $article_data['status'] = $request->input('status');

            $VehicleColors = VehicleColors::find($id);

            $VehicleColors->update($article_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.vehiclecolorsmanager.index')->with('success', 'Vehicle Colors has been updated Successfully');
    }

    
}
