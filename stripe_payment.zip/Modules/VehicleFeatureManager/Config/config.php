<?php

return [
    'name' => 'VehicleFeatureManager'
];
