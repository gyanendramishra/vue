@extends('backpack::layout')
@section('header')
<style>
    .nodesign{ border: none; background: transparent; border-radius: none;  width: 100%}
    #example1_filter{ text-align: right !important;margin-bottom: 8px; }
    #example1_paginate { float: right; }
    .show_msg{ left: 220px;
               position: absolute;
               top: 17px;
               z-index: 9999;}
    </style>
    <section class="content-header">
    <h1>
        Product Enquiry Lead Reply Details
    </h1>

    <p class="show_msg"></p>
    @if(Session::has('success_message'))
    <p class="alert {{ Session::get('alert-class', 'alert-success') }}">{{ Session::get('success_message') }}</p>
    @endif
    @if(Session::has('error_message'))
    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error_message') }}</p>
    @endif 
    <ol class="breadcrumb">
        <li><a href="{{ url('user/dashboard') }}">{{ config('backpack.base.project_name') }}</a></li>
        <li class="active">{{ trans('backpack::base.dashboard') }} </li>
    </ol>
</section>

@endsection
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="box box-default">

            <div class="box-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-ms-12">
                            <div class="pull-right"><a href="{{ url('')}}/admin/lead" class="btn btn-primary btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back </a></div>
                            <div class="clearfix"></div><br/>
                            <table id="example1" class="table table-bordered table-striped display dataTable no-footer" role="grid" aria-describedby="crudTable_info">
                               <thead>
                                    <tr>
                                      <th>S.N.</th>
                                      <th>Reply</th>
                                      <th>Dates</th>
                                    </tr>
                               </thead>
                               <tbody>
                                @if($LeadAnswer->count()>0)
                                @php $i=1; @endphp
                                @foreach($LeadAnswer as $k=> $product_view)
                                    <tr>
                                        <td>{{ $i++ }}</td>
                                        <td>{{ $product_view->answer }}</td>
                                        <td>{{ \Carbon\Carbon::parse($product_view->created_at)->format('d-m-Y')  }}</td>
                                    </tr>
                                @endforeach
                                @endif
                               </tbody>
                            </table> 
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
    @endsection







