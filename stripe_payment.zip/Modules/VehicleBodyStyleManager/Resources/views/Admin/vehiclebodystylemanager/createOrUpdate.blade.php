@extends('layouts.admin.app')
@section('title', !empty($vehiclebodystyle) ? 'Edit Vehicle Body Type' : 'Add Vehicle Body Type')
@section('content')
<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.vehiclebodystylemanager.index'],['label' => !empty($vehiclebodystyle) ? 'Edit Vehicle Body Type' : 'Add Vehicle Body Type' ]]]) }}
    </div>
</div>
<div class="wojo-grid">    
    @if(session()->has('success'))
    <div class="alert alert-success">
        {{ session()->get('success') }}
    </div>
    @endif

    <div class="wojo form segment">
        <div class="wojo secondary icon message"> 
            <div class="content">
                <div class="header">  {{ !empty($vehiclebodystyle) ? 'Edit Vehicle Body Type' : 'Add Vehicle Body Type' }}  </div>
            </div>
        </div>
        @if(isset($vehiclebodystyle))

        {{ Form::model($vehiclebodystyle, ['route' => ['admin.vehiclebodystylemanager.update', $vehiclebodystyle->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}

        @else

        {{ Form::open(['route' => 'admin.vehiclebodystylemanager.store','enctype'=>'multipart/form-data']) }}

        @endif

        @php

        $locales = config('app.locales');

        @endphp

        @include('layouts.flash.alert')

        <div class="wojo secondary message">

            <ul class="wojo tabs fixed clearfix">
                @foreach($locales as $key=>$val)
                <li class="{{ ($key=='en')?'active':'' }}">
                    <a data-tab="#{{ $key.'_tab' }}" class="{{ ($key=='en')?'active show':'' }}">
                        {{ $val }}
                    </a>
                </li>
                @endforeach
            </ul>

            <div class="container">

                @foreach($locales as $key=>$val)
                <div id="{{ $key.'_tab' }}" class="wojo tab item " style="{{ ($key=='en')?'display: block;':'' }}">
                    <div class="two fields">
                        <div class="field">

                            <div class="required {{ $errors->has($key.'_name') ? 'has-error' : '' }}">
                                <label for="name">{{ __('Name') }} </label>

                                {{ Form::text($key.'_name',old($key.'_name', (isset($vehiclebodystyle))?$vehiclebodystyle->translate($key)['name']:"") , ['class' => '','placeholder' => 'Name']) }}

                                @if($errors->has($key.'_name'))
                                <span class="help-block">{{ $errors->first($key.'_name') }}</span>
                                @endif
                            </div>
                        </div>

                    </div>
                </div>
                @endforeach

            </div>

            <div class="container">
                <div class="two fields">
                    <div class="field">
                        <div class="required {{ $errors->has('status') ? 'has-error' : '' }}">
                            <label for="status">{{ __('Status') }} </label>
                            {{ Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => '']) }}

                            @if($errors->has('status'))
                            <span class="help-block">{{ $errors->first('status') }}</span>
                            @endif
                        </div>
                    </div>
                </div>



                <div class="two fields">
                    <div class="field">

                        <div class="form-group {{ $errors->has('icon') ? 'has-error' : '' }}">
                            <label for="status">{{ __('Icon') }} </label>


                            @if($errors->has('icon'))
                            <span class="help-block">{{ $errors->first('icon') }}</span>
                            @endif
                        </div>
                        @if($errors->has('icon'))
                        <span class="help-block">{{ $errors->first('icon') }}</span>
                        @endif

                        @php

                        $filepath = '/uploads/bodyType/';
                        @endphp

                        @if(!empty($vehiclebodystyle->icon) && file_exists(public_path() . $filepath . $vehiclebodystyle->icon))

                        <?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url($filepath . $vehiclebodystyle->icon), '150', '60', '100'); ?>

                        @endif


                        @php

                        if(isset($vehiclebodystyle->icon) &&  $vehiclebodystyle->icon!='') {

                        $path=public_path('uploads/bodyType/'.$vehiclebodystyle->icon);

                        } else {

                        $path='';
                        }
                        @endphp

                        @if(file_exists($path))


                        <input type="file" name="image" data-type="image" data-exist="{{ URL::asset('/uploads/bodyType/'.$vehiclebodystyle->icon) }}" accept="image/png, image/jpeg">

                        @else

                        <input type="file" name="icon" data-type="image" data-exist="{{ URL::asset('/images/migration/no-image.png') }}" accept="image/png, image/jpeg">
                        @endif
                    </div>
                </div>

                <div class="wojo fitted divider"></div>
            </div>

            <div class="wojo fitted divider"></div>
            <div class="wojo footer">
                <button type="submit" data-action="updateAccount" name="dosubmit" class="wojo positive button">Save</button>
                <a href="{{ route('admin.vehiclebodystylemanager.index') }}" class="wojo negative button" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
            </div>
        </div>

        {{ Form::close() }}
    </div>
</div>
@stop