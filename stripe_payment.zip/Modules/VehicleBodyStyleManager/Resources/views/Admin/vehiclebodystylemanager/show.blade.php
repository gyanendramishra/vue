@extends('layouts.admin.master')
@section('content')
@include('layouts.admin.flash.alert')
<section class="content-header">
    <h1>
        Manage Vehicle Body Type        
    </h1>
    {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.vehiclebodystylemanager.index'],['label' => 'View Vehicle Body Type Detail']]]) }}
</section>

<section class="content" data-table="emailHooks">
    @include('layouts.flash.alert')
    <div class="box">
        <div class="box-header"><h3 class="box-title">{{ $vehiclebodystyle->name }}</h3>
            <a href="{{route('admin.vehiclebodystylemanager.index')}}" class="btn btn-default pull-right" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
        </div>
        <div class="box-body">
            <table class="table table-hover table-striped">
                <tr>
                    <th scope="row">{{ __('Name') }}</th>
                    <td>{{ $vehiclebodystyle->name }}</td>
                </tr>
                <tr>
                    <th scope="row"><?= __('Created') ?></th>
                    <td>{{ $vehiclebodystyle->created_at->toFormattedDateString() }}</td>
                </tr>
                <tr>
                    <th scope="row">{{ __('Modified') }}</th>
                    <td>{{ $vehiclebodystyle->updated_at->toFormattedDateString() }}</td>
                </tr>
                <tr>
                    <th scope="row">{{ __('Status') }}</th>
                    <td>{{ $vehiclebodystyle->status ? __('Active') : __('Inactive')  }}</td>
                </tr>
            </table>           
        </div>
        <div class="box-footer">
                <a href="{{route('admin.vehiclebodystylemanager.index')}}" class="btn btn-default pull-left" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
        </div>
    </div>
</section>

@endsection
