<?php

namespace Modules\AdsManager\Observers;

use Modules\AdsManager\Entities\AdImage;
use Illuminate\Support\Facades\Storage;

class AdImageObserver
{
    /**
     * Handle the product image "created" event.
     *
     * @param  \App\AdImage  $AdImage
     * @return void
     */
    public function created(AdImage $adImage)
    {
        $this->imageUploadAndUpdate($adImage);
    }

    /**
     * Handle the product image "updated" event.
     *
     * @param  \App\AdImage  $AdImage
     * @return void
     */
    public function updated(AdImage $adImage)
	{
        $this->imageUploadAndUpdate($adImage);
    }

public function imageUploadAndUpdate($adImage){
    if(!empty($adImage->getAttribute('image'))){        
            if($adImage->getAttribute('image') != $adImage->getOriginal('image')){
                $existNew = Storage::disk('public')->exists('temp/'.  $adImage->getAttribute('image'));
                if($existNew){
                    Storage::move('public/temp/' . $adImage->getAttribute('image'), 'public/pages/' . $adImage->getAttribute('image'));
                }

                $exists = Storage::disk('public')->exists('pages/'.  $adImage->getOriginal('image'));
                if($exists){
                    Storage::disk('public')->delete('pages/'. $adImage->getOriginal('image'));
                }
            }
        }
}

    /**
     * Handle the product image "deleted" event.
     *
     * @param  \App\AdImage  $AdImage
     * @return void
     */
    public function deleted(AdImage $adImage)
    {
        $exists = Storage::disk('public')->exists('pages/'.  $adImage->getAttribute('image'));
        if($exists){
            Storage::disk('public')->delete('pages/'. $adImage->getAttribute('image'));
        }
    }

    /**
     * Handle the product image "restored" event.
     *
     * @param  \App\AdImage  $AdImage
     * @return void
     */
    public function restored(AdImage $adImage)
    {
        //
    }

    /**
     * Handle the product image "force deleted" event.
     *
     * @param  \App\AdImage  $AdImage
     * @return void
     */
    public function forceDeleted(AdImage $adImage)
    {
        echo "force";
        //dd($AdImage);
    }
}
