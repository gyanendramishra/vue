<?php

namespace Modules\VehicleFuelTypesManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\VehicleFuelTypesManager\Entities\VehicleFuelTypes;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use Illuminate\Support\Facades\Input;

class VehicleFuelTypesManagerController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {

        $title = "Vehicle Fuel Types";
        return view('vehiclefueltypesmanager::Admin.vehiclefueltypesmanager.index', compact('title'));
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $vehiclefueltypes = vehiclefueltypes::query();
        if ($request->status != '') {
            $vehiclefueltypes = $vehiclefueltypes->where('status', $request->status);
        }
        if ($request->slug != '') {
            $slug = $request->slug;
            $vehiclefueltypes = $vehiclefueltypes->whereHas('vehiclesfueltype', function($q) use($slug) {
                $q->where('name', 'LIKE', lcfirst($slug) . '%');
                $q->orWhere('name', 'LIKE', $slug . '%');
            });
        }
        $vehiclefueltypes = $vehiclefueltypes->get();

        return datatables()->of($vehiclefueltypes)
                        ->addColumn('action', function ($vehiclefueltypes) {
                            $actions = "";
                            // $actions .= "<a href=\"" . route('admin.vehiclefueltypesmanager.show', ['id' => $vehiclefueltypes->id]) . "\" class=\"btn btn-xs btn-primary btn-flat info-btn\"><i class=\"glyphicon glyphicon-eye-open\"></i> View</a>";
                            $actions .= "<a href=\"" . route('admin.vehiclefueltypesmanager.edit', ['id' => $vehiclefueltypes->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i> </a>";
                            //$actions .= "<a onclick=\"return confirm('Are you sure want to delete this record?')\" href=\"" . route('admin.vehiclefueltypesmanager.delete', ['id' => $vehiclefueltypes->id]) . "\" class=\"btn btn-xs btn-danger btn-flat info-btn\"><i class=\"glyphicon glyphicon-remove\"></i> Delete</a>";
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        $title = "Vehicle Fuel Types";
        return view('vehiclefueltypesmanager::Admin.vehiclefueltypesmanager.createOrUpdate', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request) {

        $locales = config('app.locales');
        $valRule = [
            'icon' => 'sometimes|mimes:jpeg,jpg,png|max:5000'
        ];
        $valMessage = [
            'icon.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
            'icon.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
            'en_name.regex' => 'The name format is invalid In english language.'
        ];
        foreach ($locales as $key => $value) {
            $valRule[$key . '_name'] = 'required|max:200|unique:vehicle_fuel_types_translations,name|unique_space_check:vehicle_fuel_types_translations,name';
        }

        $valRule['en_name'] = 'required|string|regex:/^[\pL\pN\s\-\_]+$/u|max:200|unique:vehicle_fuel_types_translations,name|unique_space_check:vehicle_fuel_types_translations,name';

        foreach ($locales as $key => $value) {
            $valMessage[$key . '_name.required'] = ' The name field is required in ' . $value . ' language.';
            $valMessage[$key . '_name.max'] = ' Sorry, you can\'t add the name more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_name.unique'] = ' Name must be unique in ' . $value . ' language.';
            $valMessage[$key . '_name.unique_space_check'] = ' Name must be unique in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['name'] = $request->input($key . '_name');
            }
            $article_data['status'] = $request->input('status');

            if ($request->hasFile('icon')) {

                $image = $request->file('icon');
                $is_dest = "uploads/fueltype/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('icon');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $article_data['icon'] = $filenameOrig;
                }
            }

            VehicleFuelTypes::create($article_data);
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->getMessage());
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.vehiclefueltypesmanager.index')->with('success', 'Vehicle Fuel Types has been saved Successfully');
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show(VehicleFuelTypes $vehiclefueltypes) {
        $title = "Vehicle Fuel Types";
        return view('vehiclefueltypesmanager::Admin.vehiclefueltypesmanager.show', compact('vehiclefueltypes', 'title'));
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id) {
        $title = "Vehicle Fuel Types";
        $vehiclefueltypes = VehicleFuelTypes::find($id);
        return view('vehiclefueltypesmanager::Admin.vehiclefueltypesmanager.createOrUpdate', compact('vehiclefueltypes', 'title'));
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id) {
        $locales = config('app.locales');
        $valRule = [
            'icon' => 'sometimes|mimes:jpeg,jpg,png|max:5000'
        ];
        $valMessage = [
            'icon.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
            'icon.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
            'en_name.regex' => 'The name format is invalid In english language.'
        ];
        foreach ($locales as $key => $value) {
            $valRule[$key . '_name'] = 'required|max:200|unique:vehicle_fuel_types_translations,name,' . $request->segment(3) . ',vehicle_fuel_types_id|unique_space_check:vehicle_fuel_types_translations,name,' . $request->segment(3) . ',vehicle_fuel_types_id';
        }

        $valRule['en_name'] = 'required|string|regex:/^[\pL\pN\s\-\_]+$/u|max:200|unique:vehicle_fuel_types_translations,name,' . $request->segment(3) . ',vehicle_fuel_types_id|unique_space_check:vehicle_fuel_types_translations,name,' . $request->segment(3) . ',vehicle_fuel_types_id';

        foreach ($locales as $key => $value) {
            $valMessage[$key . '_name.required'] = ' The name field is required in ' . $value . ' language.';
            $valMessage[$key . '_name.max'] = 'Sorry, you can\'t add the name more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_name.unique'] = ' Name must be unique in ' . $value . ' language.';
            $valMessage[$key . '_name.unique_space_check'] = ' Name must be unique in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);


        try {

            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['name'] = $request->input($key . '_name');
            }
            $article_data['status'] = $request->input('status');


            if ($request->hasFile('icon')) {
                $image = $request->file('icon');
                $is_dest = "uploads/fueltype/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('icon');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $article_data['icon'] = $filenameOrig;
                }
            }
            $VehicleFuelTypes = VehicleFuelTypes::find($id);

            $VehicleFuelTypes->update($article_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.vehiclefueltypesmanager.index')->with('success', 'Vehicle Fuel Types has been updated Successfully');
    }

}
