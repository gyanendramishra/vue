@extends('layouts.admin.app')
@section('title', !empty($ads) ? 'Edit Ad' : 'Add Ad')

@push('styles')
    {!! Html::style('/css/migration/custom.css') !!}

@endpush
@section('content')

<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.pages.index'],['label' => !empty($pages) ? 'Edit CMS Page' : 'Add CMS Page' ]]]) }}
    </div>
  </div>

  <div class="wojo-grid">
    <div class="wojo form segment">
      <div class="wojo secondary icon message"> <!-- <i class="lock icon"></i> -->
        <div class="content">
          <div class="header">  {{ !empty($pages) ? 'Edit CMS Page' : 'Add CMS Page' }} </div>

        </div>
      </div>
     

        @if(isset($pages))

            {{ Form::model($pages, ['route' => ['admin.pages.update', $pages->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}
        @else

            {{ Form::open(['route' => 'admin.pages.store','enctype'=>'multipart/form-data']) }}
        @endif

         @php

            $locales = config('app.locales');

        @endphp
        
        @include('layouts.flash.alert')
        <div class="wojo secondary message">
             <ul class="wojo tabs fixed clearfix">
                @foreach($locales as $key=>$val)
                    <li class="{{ ($key=='en')?'active':'' }}">
                        <a data-tab="#{{ $key.'_tab' }}" class="{{ ($key=='en')?'active show':'' }}">
                            {{ $val }}
                        </a>
                    </li>
                @endforeach
            </ul>
             @foreach($locales as $key=>$val)
                
             
                <div id="{{ $key.'_tab' }}" class="wojo tab item " style="{{ ($key=='en')?'display: block;':'' }}">
                    <div class="two fields">
                        <div class="field required {{ $errors->has($key.'_title') ? 'has-error' : '' }}">

                             
                               <label for="title">{{ __('Title') }} </label>

                                 {{ Form::text($key.'_title', old($key.'_title', (isset($pages))?$pages->translate($key)['title']:"") , ['class' => '','placeholder' => 'Title']) }}

                                 @if($errors->has($key.'_title'))
                                    <span class="help-block">{{  $errors->first($key.'_title')  }}</span>
                                @endif
                             
                        </div>
                        <div class="field {{ $errors->has($key.'_meta_title') ? 'has-error' : '' }}">
                            <label for="title">{{ __('Meta Title') }} </label>
                            <div class="wojo labeled icon input">
                             {{ Form::text($key.'_meta_title',old($key.'_meta_title', (isset($pages))?$pages->translate($key)['meta_title']:""), ['class' => '','placeholder' => 'Meta Title']) }}

                             @if($errors->has($key.'_meta_title'))
                                <span class="help-block">{{ $errors->first($key.'_meta_title') }}</span>
                            @endif
                            </div>
                        </div>
                    </div>
                    <div class="two fields">
                        <div class="field {{ $errors->has($key.'_meta_keyword') ? 'has-error' : '' }}" >
                            <label for="title">{{ __('Meta Keyword') }} </label>
                            <div class="wojo labeled icon input">
                             {{ Form::text($key.'_meta_keyword',old($key.'_meta_keyword', (isset($pages))?$pages->translate($key)['meta_keyword']:"") , ['class' => '','placeholder' => 'Meta Keyword']) }}
                             
                            @if($errors->has($key.'_meta_keyword'))
                                <span class="help-block">{{ $errors->first($key.'_meta_keyword') }}</span>
                            @endif

                            </div>
                            
                        </div>
                    </div>
                    <div class="two fields {{ $errors->has($key.'_meta_description') ? 'has-error' : '' }}" >
                        
                            <label for="title">{{ __('Meta Description') }} </label>
                            <div class="wojo labeled icon input">
                                {{ Form::textarea($key.'_meta_description',old($key.'_meta_description', (isset($pages))?$pages->translate($key)['meta_description']:"") , ['class' => '','placeholder' => 'Meta Description', 'rows' => 8]) }}
                                 
                                 @if($errors->has($key.'_meta_description'))
                                    <span class="help-block">{{ $errors->first($key.'_meta_description') }}</span>
                                @endif

                            </div>
                            
                        
                    </div>
                    <div class="two fields {{ $errors->has($key.'_description') ? 'has-error' : '' }}" >
                        

                        
                            <label for="title">{{ __('Description') }} </label>
                            <div class="wojo labeled icon input">
                                  {{ Form::textarea($key.'_description',old($key.'_description',(isset($pages))?$pages->translate($key)['description']:""), ['class' => '','placeholder' => 'Description' , 'id'=>'editor1_'.$key, 'rows' => 8]) }}
                                 
                                @if($errors->has($key.'_description'))
                                    <span class="help-block">{{ $errors->first($key.'_description') }}</span>
                                @endif

                            </div>
                            
                        
                    </div>
                </div>
                   
             
            @endforeach
            <div class="two fields">
               
                <div class="field {{ $errors->has($key.'image_type') ? 'has-error' : '' }}">
                        <label for="title">{{ __('Status') }} </label>
                        <div class="wojo labeled icon input">
                            {{ Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => '']) }}
                            @if($errors->has('status'))
                                <span class="help-block">{{ $errors->first('status') }}</span>
                            @endif
                        </div>
                </div>
                
            </div>
        <div class="wojo fitted divider"></div>
        <div class="wojo footer">
          <button type="submit" data-action="updateAccount" name="dosubmit" class="wojo positive button">Save</button>
          <a href="{{ route('admin.pages.index') }}" class="wojo negative button" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
        </div>
      </form>
    </div>
  </div>

@stop
@section('per_page_style')
<!--<link href="{{ asset('plugins/select2-develop/dist/css/select2.min.css') }}" rel="stylesheet" />-->
<style>
    .ui-sortable-helper {
        display: table;
    }
</style>
@stop

@push('scripts')
<!--<script src="{{ asset('plugins/select2-develop/dist/js/select2.min.js') }}"></script>-->
<script src="{{asset('ckeditor/ckeditor.js')}}"></script>
<script>
$(function () {
    CKEDITOR.replace('editor1_en', {
        // Remove the redundant buttons from toolbar groups defined above.
        removeButtons: 'Font,Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Styles,Specialchar'
                // removeButtons: 'Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Specialchar'
    });

     CKEDITOR.replace('editor1_kh', {
        // Remove the redundant buttons from toolbar groups defined above.
        removeButtons: 'Font,Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Styles,Specialchar'
                // removeButtons: 'Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Specialchar'
    });


})
</script>
@endpush