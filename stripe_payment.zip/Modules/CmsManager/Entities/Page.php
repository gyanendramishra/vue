<?php

namespace Modules\CmsManager\Entities;

use Illuminate\Database\Eloquent\Model;
use \Dimsav\Translatable\Translatable;
use Cviebrock\EloquentSluggable\Sluggable;

class Page extends Model {

    use Translatable;
    use Sluggable;

    protected  $table = 'pages';

    public $translatedAttributes = ["title", "sub_title", "short_description", "description", "meta_title", "meta_keyword", "meta_description"];


    protected $fillable = ["slug", "position", "status"];

    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function sluggable() {
        return [
            'slug' => [
                'source' => 'title'
            ]
        ];
    }

}