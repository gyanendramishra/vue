<?php

namespace Modules\VehicleDriveTypesManager\Entities;

use Illuminate\Database\Eloquent\Model;


class VehicleDriveTypesTranslation extends Model
{
  

    public $timestamps = false;
    protected $fillable = ['name'];

    /**
     * Get the comments for the blog post.
     */
    public function vehicles() {

        return $this->hasMany(\Modules\VehicleManager\Entities\Vehicle::class, 'makes_id', 'id');
    }
    
   
   
}
