<?php

return [
    'name' => 'VehicleDriveTypesManager'
];
