<?php

namespace Modules\User\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\User\Entities\Role;
use Modules\User\Http\Requests\CreateRoleRequest as CreateRoleRequest;
use Yajra\DataTables\Utilities\Request as DatatableRequest;

class RolesController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        try {
            $title = "Roles";
            $roles = Role::select('id', 'name', 'status', 'created_at')->where('slug', '!=', 'admin')->paginate(10);
            return view('user::role.index', compact('roles', 'title'));
        } catch (Exception $ex) {
            
        }
    }

    /**
     * Feeding list of roles to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $roles = Role::select('id', 'name', 'status', 'created_at')->where('slug', '!=', 'admin');
        return datatables()->of($roles)
                        ->addColumn('action', function ($role) {
                            $actions = "";
                            $actions .= "<a href=\"" . route('user.roles.edit', $role->id) . "\" class=\"btn btn-xs btn-primary btn-flat info-btn\"><i class=\"glyphicon glyphicon-edit\"></i> Edit</a>";
                            $actions .= "<a onclick=\"return confirm('Are you sure want to delete this role?')\" href=\"" . route('user.roles.delete', $role->id) . "\" class=\"btn btn-xs btn-danger btn-flat info-btn\"><i class=\"fa fa-trash\"></i> Delete</a>";
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        $title = "Add Role";
        return view('user::role.create', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(CreateRoleRequest $request) {
        $role = new Role();
        $role->name = $request->name;
        $role->status = $request->status;
        if($request->is_menu)
            $role->is_menu = $request->is_menu;
        $role->save();
        return redirect()->route('roles')->with('message', 'Role added successfully.');
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id) {
        return view('user::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id) {
        $title = "Edit Role";
        $role = Role::where('id', $id)->first();
        return view('user::role.edit', compact('role', 'title'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(CreateRoleRequest $request, $id) {
        $role = Role::findOrFail($id);
        $role->name = $request->name;
        $role->status = $request->status;
        
        if($request->is_menu && $request->is_menu == 'on'){
            $role->is_menu = 1;
        }else {
            $role->is_menu = 0;
        }
        $role->save();
       
        return redirect()->route('roles')->with('message', 'Role updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id) {
        Role::where('id', $id)->delete();
        return redirect()->route('roles')->with('message', 'Role deleted successfully.');
    }

}
