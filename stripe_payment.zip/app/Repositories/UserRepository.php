<?php

namespace App\Repositories;

use Illuminate\Http\Request;
use App\Repositories\Interfaces\UserInterface;
use \Modules\VehicleManager\Entities\Vehicle;

class UserRepository implements UserInterface {
    
    /* Get user saved vehicles */
    public function getSavedVehicle() {
        $user = \Auth::guard('user')->user();
        return  $user->favouriteVehicles()
                    ->where('is_favourite', 1)
                    ->select(
                        'id', 
                        'category_id', 
                        'makes_id', 
                        'models_id', 
                        'badge_id', 
                        'body_styles_id',
                        'fuel_types_id',
                        'series_id',
                        'transmissions_id',
                        'title',
                        'role',
                        'odometer',
                        'price',
                        'address',
                        'slug'
                    )
                    ->with([
                        'main_image:id,vehicle_id,image,caption',
                        'transmissions:id',
                        'transmissions.translations:id,vehicle_transmissions_id,name,locale',
                        'bodystyle:id',
                        'bodystyle.translations:id,vehicle_body_style_id,locale,name',
                        'fuel_type:id',
                        'fuel_type.translations:id,vehicle_fuel_types_id,locale,name',
                    ])
                    ->approved()
                    ->orderBy('id', 'DESC')
                    ->paginate(10);
    }

    /* Get user vehicles */
    public function getMyVehicle() {
        $user = \Auth::guard('user')->user();
        return  $user->vehicles()
                    ->select(
                        'id', 
                        'category_id', 
                        'makes_id', 
                        'models_id', 
                        'badge_id', 
                        'body_styles_id',
                        'fuel_types_id',
                        'series_id',
                        'transmissions_id',
                        'title',
                        'role',
                        'odometer',
                        'price',
                        'address',
                        'is_approved',
                        'slug'
                    )
                    ->with([
                        'main_image:id,vehicle_id,image,caption',
                        'favouriteUsers:is_favourite',
                        'category:id',
                        'category.translations:id,category_id,name,locale',
                        'make:id',
                        'make.translations:id,vehicle_make_id,name,locale',
                        'model:id,makes_id',
                        'model.translations:id,vehicle_model_id,name,locale',
                        'badge:id,models_id',
                        'badge.translations:id,vehicle_badge_id,name,locale',
                        'series:id,badges_id',
                        'series.translations:id,vehicle_series_id,name,locale',
                        'transmissions:id',
                        'transmissions.translations:id,vehicle_transmissions_id,name,locale',
                        'bodystyle:id',
                        'bodystyle.translations:id,vehicle_body_style_id,locale,name',
                        'fuel_type:id',
                        'fuel_type.translations:id,vehicle_fuel_types_id,locale,name'
                    ])
                    ->orderBy('id', 'DESC')
                    ->paginate(10);
    }

    /**
     * @Desc : get logged in user total vehicle 
     * @return type
     */
    public function getTotalVehicle() {
        return \Auth::guard('user')->user()
                        ->vehicles()
                        ->approved()
                        ->count();
    }
    /**
     * 
     * @return type
     */
    public function getTotalFeaturedVehicle() {
        return \Auth::guard('user')->user()
                        ->vehicles()
                        ->where('is_featured', 1)
                        ->approved()
                        ->count();
    }

    /**
     * 
     * @return type
     */
    public function getTotalVehiclesInquiry() {
         return \Auth::guard('user')->user()
                 ->vehicleEnquiries()
                 ->count();
    }
    
    /**
     * 
     * @return type
     */
    public function getTotalFavouriteVehicles() {
         return \Auth::guard('user')->user()
                    ->favouriteVehicles()
                    ->approved()
                    ->count();
    }
    

}
