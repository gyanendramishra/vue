<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Collection\SeriesCollection as SeriesCollection;
use Modules\VehicleSeriesManager\Entities\VehicleSeries;

class BadgeResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'icon' => url('uploads/badge/' . $this->icon),
            'series' => new SeriesCollection(VehicleSeries::withTranslation()->where(['status' => 1, 'makes_id' => $this->makes_id,'models_id' => $this->models_id,'badges_id' => $this->id])->orderBy('name','asc')->get()),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
