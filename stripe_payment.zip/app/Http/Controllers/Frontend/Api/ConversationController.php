<?php

namespace App\Http\Controllers\Frontend\Api;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\ConversationRepository;

class ConversationController extends Controller {

    /**
     * Conversation repository.
     *
     * @var string
     */
    private $conversationRepository;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        ConversationRepository $conversationRepository
    ){
        $this->conversationRepository = $conversationRepository;
    }

    /**
     * Get conversation messages.
     *
     * @return \Illuminate\Http\Response
     */
    public function getMessagesByConversationId($id) {
        try {
            $messages = $this->conversationRepository->getConversationMessages($id);
            return response()->json([
                        "status" => "success",
                        "messages" => $messages
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function sendMessage(Request $request) {
        try {
            \DB::beginTransaction();
            $message = new \Modules\VehicleEnquiresManager\Entities\ConversationMessage($request->all());
            if ($message->save()) {
                // DB commit
                \DB::commit();

                $message = $this->conversationRepository->getMessageById($message->id);

                return response()->json([
                            "status" => "success",
                            "message" => $message
                        ], 200);
            }
            throw new Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get conversation messages.
     *
     * @return \Illuminate\Http\Response
     */
    public function getVehicleConversation($vehicleId) {
        try {
            $conversations = $this->conversationRepository->getVehicleConversations($vehicleId);
            $conversations->map(function ($conversation) {
                /* Load last message */
                $conversation['messages'] = $conversation->messages->last();
                /* Load participants */
                $conversation['participants'] = $conversation->participants->map(function ($participant){
                    if($participant->id == \Auth::guard('user')->id()){
                        $participant['type'] = 'sender';
                    }else{
                        $participant['type'] = 'receiver';
                    }
                    if($participant->roles->pluck('name')->contains('Guest')){
                        $participant['name'] = $participant->pivot->name;
                        $participant['email'] = $participant->pivot->email;
                        $participant['phone'] = $participant->pivot->phone;
                    }else{
                        $participant['name'] = $participant->name;
                        $participant['email'] = $participant->email;
                        $participant['phone'] = $participant->phone;
                    }
                    return $participant;
                });
                return $conversation;
            });
            return response()->json([
                        "status" => "success",
                        "conversations" => $conversations
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

}
