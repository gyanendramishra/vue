<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\AdRepository;
use App\Repositories\ReviewRepository;

class VehicleReviewsController extends Controller
{
    /**
     * Review repository.
     *
     * @var string
     */
    private $reviewRepository;

    /**
     * Ad repository.
     *
     * @var string
     */
    private $adRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        ReviewRepository $reviewRepository,
        AdRepository $adRepository
    ){
        $this->reviewRepository = $reviewRepository;
        $this->adRepository = $adRepository;
    }

    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        if($request->ajax()){
            try {
                $vehicles = $this->reviewRepository->getAllVehicles();
                return response()->json([
                        "status"=> "success",
                        "data"=> $vehicles
                    ], 200);
            } catch (\Exception $e) {
                return response()->json([
                    "status"=>"error",
                    "message"=>__('frontend.OOPS')
                ], 200);
            }
        }else{
            $vehicles = $this->reviewRepository->getAllVehicles();
            return view('frontend.reviews.index', compact('vehicles'));
        }
    }

}
