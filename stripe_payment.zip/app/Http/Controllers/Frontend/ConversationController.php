<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\VehicleRepository;
use App\Repositories\ConversationRepository;

class ConversationController extends Controller {

    /**
     * Conversation repository.
     *
     * @var string
     */
    private $conversationRepository;

    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        ConversationRepository $conversationRepository,
        VehicleRepository $vehicleRepository
    ){
        $this->conversationRepository = $conversationRepository;
        $this->vehicleRepository = $vehicleRepository;
    }
    
    
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request) {
        $userId = \Auth::guard('user')->id();
        $conversations = $this->conversationRepository->getUserAllConversations($userId);
        $conversations->map(function ($conversation) {
            /* Load last message */
            $conversation['messages'] = $conversation->messages->last();
            /* Load participants */
            $conversation['participants'] = $conversation->participants->map(function ($participant){
                if($participant->id == \Auth::guard('user')->id()){
                    $participant['type'] = 'sender';
                }else{
                    $participant['type'] = 'receiver';
                }
                if($participant->roles->pluck('name')->contains('Guest')){
                    $participant['name'] = $participant->pivot->name;
                    $participant['email'] = $participant->pivot->email;
                    $participant['phone'] = $participant->pivot->phone;
                }else{
                    $participant['name'] = $participant->name;
                    $participant['email'] = $participant->email;
                    $participant['phone'] = $participant->phone;
                }
                return $participant;
            });
            return $conversation;

        });
        $vehicles = $this->vehicleRepository->getUserVehiclesHasConversation($userId); 
        return view('frontend.user.conversations', compact('conversations', 'vehicles'));
    }

}
