<?php

namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use \Modules\VehicleManager\Entities\Vehicle;
use App\Http\Resources\Collection\VehicleReviewCollection;

class VehicleReviewController extends Controller {

    public $successStatus = 200;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request) {
        //$authInformation = $request->header();
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
    }

    /**
     *  get all news list
     * @param Request $request
     * @return type
     */
    public function index(Request $request) {
     
        try {
            $reviews = new VehicleReviewCollection(Vehicle::select(
                                    'id', 'title', 'slug'
                            )
                         //   ->active()
                            ->approved()
                            ->has('vehicleReviews')
                            ->with('main_image:id,vehicle_id,image,caption')
                            ->withCount(['vehicleReviews' => function($q) {
                                    $q->active()->with('user:id,name');
                                }])
                            ->orderBy('vehicle_reviews_count', 'DESC')
                            ->paginate(15)
            );
            $data['data'] = $reviews;
            $data['status'] = true;
            $data['message'] = "lists";
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {

            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

}
