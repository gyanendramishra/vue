<?php

namespace App\Mail;

use App\EmailTemplate;
use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class VehicleReviewApproveMailToSellerDealer extends Mailable {

    use Queueable,
        SerializesModels;

    public $vehicle;
    public $user;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($vehicle,$user) {
        $this->vehicle = $vehicle;
        $this->user = $user;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build() {


        $et = EmailTemplate::whereType('vehicle_review_approve_mail_to_selle/dealer')
                ->with('translations:id,email_template_id,locale,subject,template')
                ->first(['id']);

        if ($et) {

            $subject = $et->subject;

            $body = $et->template;
            $body = str_replace('##CARSELLER/DEALER##', $this->vehicle->user->name, $body);
            $body = str_replace('##USER##', $this->user->name, $body);
            $body = str_replace('##VEHICLE_TITLE##', $this->vehicle->title, $body);
            $body = str_replace('##VEHICLE_CODE##', $this->vehicle->id, $body);

            $this->subject($subject)
                    ->view('frontend.emails.template')
                    ->with(['template' => $body]);
        }
    }

}
