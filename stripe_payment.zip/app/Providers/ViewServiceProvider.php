<?php

namespace App\Providers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class ViewServiceProvider extends ServiceProvider
{
    /**
     * Register bindings in the container.
     *
     * @return void
     */
    public function boot()
    {
        // boot composer
        View::composer(
            'frontend*', 'App\Http\Views\Composers\LoggedInUserComposer'
        );
        View::composer(
            'frontend*', 'App\Http\Views\Composers\VehicleComposer'
        );
    }

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}