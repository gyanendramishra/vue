<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\CategoryService;

class CategoryController extends Controller
{ 

    /**
     * Get the parent categories.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\CategoryService $service
     * @return \Illuminate\Http\Response
     */
    public function getParentCategories(Request $request, CategoryService $service){
        try{
            $response = $service->getParentCategoryService();
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
    
    /**
     * Get the sub categories.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\CategoryService $service
     * @return \Illuminate\Http\Response
     */
    public function getSubCategories(Request $request, CategoryService $service){
        try{
            $response = $service->getSubCategoryService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
