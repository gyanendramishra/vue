@extends('layouts.dashboard')
@section('page_header_title', 'My Earnings')
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        My earnings
    </li>
@endsection
@section('dashboard_content')
  	<my-earning-component></my-earning-component>
@endsection

