<template>
    <ul class="nav-dropdown menu" v-if="categories.length > 0"> 
        <li class="menu-item has-dropdown" v-for="(category, index) in categories"> 
            <a href="javascript:;" class="menu-link">
                {{ category.title }}
            </a> 
            <ul class="nav-dropdown menu" v-if="category.subcategories.length > 0">
                <li class="menu-item" v-for="subcategory in category.subcategories"> 
                    <a :href="'/service-providers/'+subcategory.title | prepareSlug(subcategory.id)" class="menu-link">
                        {{ subcategory.title }}
                    </a> 
                </li>
            </ul>
        </li>
    </ul>
</template>
<script>
    export default {
        name: "service-category-component",
        data: function () {
            return {
                categories: {}
            }
        },
        created: function () {
            this.getCategories();
        },
        filters: {
            prepareSlug (str, id) {
                if(!str) return "";
                return str.toLowerCase().replace(/ /g, '-')+"-"+id;
            }
        },
        methods: {
            getCategories() {
                axios.get('/service-providers/categories').then(response => {
                    if(response.data.status === true){
                        this.categories = response.data.data;
                    }
                }).catch(error => {
                    console.log(error);
                });
            }
        }
    }
</script>

