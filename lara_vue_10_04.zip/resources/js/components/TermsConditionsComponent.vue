<template>
    <section class="default-contant-page content-grey-bg padding-T-B-30">
        <loader-component :loading="loading"></loader-component>
		<div class="container" v-html="page.description">
		</div>
	</section>
</template>
<script>
    import LoaderComponent from "./LoaderComponent.vue";
    export default {
        name: "terms-conditions-component",
        components:{
            LoaderComponent
        },
        data: function () {
            return {
                loading: false,
                page: {},
                settings:{}
            }
        },
        created(){
            this.loading = true;
            this.getPage();
        },
        methods: {
            getPage() {
                this.loading = true;
                axios.get('/terms-and-conditions/get').then(response => {
                    let data = response.data;
                    this.page = data.page_data;
                    this.settings = data.ConfigSettings;
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            }
        }
    }
</script>

