<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div class="my-booking-sec my-booking-detail">
                    <h3>{{ booking.title }}</h3>
                    <div class="invoice-date">
                        <span>{{ booking.request_date_time | formatDate }}</span>
                    </div>
                    <div class="book-pay-status-sec invoice-status">
                        <ul>
                            <li>
                                <div class="book-status-left">
                                    <strong class="Payable-amount-label">
                                       Service Amount $:
                                    </strong>
                                </div>
                                <div class="book-status-right">
                                    <span class="Payable-amount-input">
                                        <input type="text" v-model="invoice.service_amount" v-validate="'required|numeric|max:8'" data-vv-as="service amount" data-vv-name="service_amount" v-on:keyup="parepareInvoice" />
                                        <div v-if="errors.has('service_amount')" class="text-danger">
                                            {{ errors.first('service_amount') }}
                                        </div>
                                    </span>
                                </div>
                            </li>
                            <li>
                                <div class="book-status-left">
                                    <strong>GST (+):</strong>
                                </div>
                                <div class="book-status-right">
                                    $<span ref="gst_amount">{{ invoice.gst_amount }}</span>
                                </div>
                            </li>
                            <li>
                                <div class="book-status-left">
                                <strong>Payable Amount:</strong>
                                </div>
                                <div class="book-status-right">
                                    <span class="price-booking">
                                        <strong>$<span ref="payable_amount">{{ invoice.payable_amount }}</span></strong>
                                    </span>
                                </div>
                            </li>

                        </ul>
                        <div class="book-btn-sec">
                            <a href="javascript:;" class="btn-default"  v-on:click="sendInvoice">Send Invoice</a>
                        </div>
                        <ul>
                            <li>
                                <div class="book-status-left">
                                    <strong>Admin Commission (-):</strong>
                                </div>
                                <div class="book-status-right">
                                    $<span ref="commission">{{ invoice.commission }}</span>
                                </div>
                            </li>
                            <li>
                                <div class="book-status-left">
                                    <strong>Earning:</strong>
                                </div>
                                <div class="book-status-right">
                                    <span class="price-booking">
                                        <strong>$<span ref="earning_amount">{{ invoice.earning_amount }}</span></strong>
                                    </span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import moment from "moment";
    import VeeValidate from 'vee-validate';
    import mixin from '../../mixin/mixin.js';
    import LoaderComponent from "../LoaderComponent.vue";
    Vue.use(VeeValidate);
    export default {
        name: "booking-invoice-component",
        components:{
            LoaderComponent
        },
        mixins: [mixin],
        props:["bookingId"],
        data: function () {
            return {
                loading: false,
                booking: {},
                invoice: {
                    booking_id: "",
                    service_amount: 0,
                    payable_amount: 0,
                    earning_amount: 0,
                    gst_amount: 0,
                    commission: 0,
                }
            }
        },
        created: function(){
            this.loading = true;
            this.getBooking();
        },
        filters: {
            formatDate : function(date){
                return moment(date, 'YYYY-MM-DD H:i:s').format('DD MMM YYYY h:mm a');
            },
            formatNumber(value) {
                return (value/1).toFixed(2);
            },
            prepareSlug (str, id) {
                if(!str) return "";
                return str.toLowerCase().replace(/ /g, '-')+"-"+id;
            }
        },
        methods: {
            getBooking() {
                this.loading = true;
                axios.post('/booking/get/data', {
                    id: this.bookingId
                }).then(response => {
                    if(response.data.status === true){
                        this.booking = response.data.data;
                        this.invoice.booking_id = this.booking.id;
                        this.invoice.service_amount = this.booking.budget;
                        this.parepareInvoice();
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            sendInvoice() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        axios.post('/booking/invoice/send', this.invoice).then(response => {
                                if(response.data.status === true){
                                    flash(response.data.message, 'success');
                                    window.location = '/booking/detail/'+this.booking.title.toLowerCase().replace(/ /g, '-')+"-"+this.booking.id; 
                                }else{
                                    this.authorize(response);
                                }
                                this.loading = false;
                            }).catch(error => {
                                this.loading = false;
                                console.log(error);
                            });
                    }else{
                        this.loading = false;
                    }
                });
            },
            percentageAmount(amount, percentage) {
                return (amount*percentage)/100;
            },
            parepareInvoice() {
                this.invoice.gst_amount = this.percentageAmount(parseFloat(this.invoice.service_amount), parseFloat(this.booking.gst_percentage));
                this.invoice.payable_amount = (parseFloat(this.invoice.service_amount) + parseFloat(this.invoice.gst_amount));
                this.invoice.commission = this.percentageAmount(parseFloat(this.invoice.service_amount), parseFloat(this.booking.admin_commission_percentage));
                this.invoice.earning_amount = (parseFloat(this.invoice.service_amount) - parseFloat(this.invoice.commission));
                $(this.$refs.gst_amount).text(this.invoice.gst_amount);
                $(this.$refs.payable_amount).text(this.invoice.payable_amount);
                $(this.$refs.commission).text(this.invoice.commission);
                $(this.$refs.earning_amount).text(this.invoice.earning_amount);
            }
        },
    }
</script>
