<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class MyServiceService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/services/';


    /**
     * Get the  user service.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function getMyService() {
        $uri = $this->base_uri;
        $uri .= 'getService';
        return $this->getServiceRequest($uri);
    }

    /**
     * Save And Update Service.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function saveUpdateMyService($data) {
        $uri = $this->base_uri;
        $uri .= 'add';
        return $this->postFileRequest($uri, $data);
    }
}