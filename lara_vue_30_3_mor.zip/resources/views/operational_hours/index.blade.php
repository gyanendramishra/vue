@extends('layouts.dashboard')
@section('page_header_title')
	 Operational <strong>Hours</strong>
@endsection
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        Operational hours
    </li>
@endsection

@section('dashboard_content')
  	
@endsection

