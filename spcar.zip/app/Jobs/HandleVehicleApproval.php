<?php

namespace App\Jobs;

use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Modules\VehicleManager\Entities\Vehicle;
use Modules\AutoApproval\Entities\WorkingTime;
use Modules\AutoApproval\Entities\AutoApproval;
use Modules\AutoApproval\Entities\NonWorkingDay;

class HandleVehicleApproval implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $vehicle;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(Vehicle $vehicle)
    {
        $this->vehicle = $vehicle;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        if($this->vehicle){
            $vehicle = $this->vehicle->fresh();
            if($vehicle->is_reviewed === 0){
                $message = "";
                $today = Carbon::now();
                if($this->isHoliday($today) || $this->isWeekOff($today) || $this->isClosed($today)){
                    // schedule job for next working day
                    $tomorrow = $today->addDay(1);
                    $nextWorkingDay = $this->nextWorkingDay($tomorrow);

                    $autoApproval = AutoApproval::latest()->first();
                    $nextDayWorkingHours = WorkingTime::where('day', $nextWorkingDay->format('l'))->first();
                    
                    $nextScheduleDateTime = Carbon::parse($nextWorkingDay->format('Y-m-d').' '.$nextDayWorkingHours->opening_hours)->addHours($autoApproval->watch_hours);
                    if(Carbon::now()->addMinutes(10) < $nextScheduleDateTime){
                        HandleVehicleApproval::dispatch($vehicle)
                            ->delay($nextScheduleDateTime);
                        $message = "scheduled for later at ".$nextScheduleDateTime;
                    }else{
                        $message = "scheduled condition not meet run time is:".Carbon::now()."and scheduled time is:".$nextScheduleDateTime;
                    }
                }else{
                    $vehicle->is_approved = 0;
                    $vehicle->save();
                    $message = "marked as pending";
                }
                \Log::info('Vehicle approval: #'.$vehicle->id.' '.$message);
            }else{
                \Log::info('Vehicle approval: #'.$vehicle->id.' has been reviewed by admin.');
            }
        }else{
            \Log::info('Vehicle approval: Job unable to identify vehicle');
        }
    }

    /**
     * The job failed to process.
     *
     * @param  Exception  $exception
     * @return void
     */
    public function failed(\Exception $exception)
    {
        \Log::info('Vehicle approval failed: '.$exception->getMessage());
    }

    /**
     * Check that today is holiday or not
     */
    protected function isHoliday($date){
        $date = Carbon::parse($date);
        return NonWorkingDay::whereDate('non_working_date', $date->format('Y-m-d'))->exists();
    }

    /**
     * Check that today is week off or not
     */
    protected function isWeekOff($date){
        $date = Carbon::parse($date);
        return WorkingTime::where('day', $date->format('l'))->where('is_off', 1)->exists();
    }

    /**
     * Check that is closed
     */
    protected function isClosed($date){
        $date = Carbon::parse($date);
        $todayWorkingTimes = WorkingTime::where('day', $date->format('l'))->first();
        $closingDateTime = Carbon::parse($todayWorkingTimes->closing_hours);
        return $closingDateTime->isPast();
    }

    /**
     * Get the next working day
     */
    protected function nextWorkingDay($date){
        $date = Carbon::parse($date);
        if($this->isHoliday($date) || $this->isWeekOff($date)){
            $date = $date->addDay(1);
            $this->nextWorkingDay($date);
        }
        return $date;
    }

    
}
