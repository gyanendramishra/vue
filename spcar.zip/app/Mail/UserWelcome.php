<?php

namespace App\Mail;

use App\User;
use App\EmailTemplate;
use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class UserWelcome extends Mailable {

    use Queueable,
        SerializesModels;

    /**
     * The User instance.
     *
     * @var User
     */
    public $user;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(User $user) {
        $this->user = $user;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build() {
        
        $et = EmailTemplate::whereType('admin_mail_to_user')
                ->with('translations:id,email_template_id,locale,subject,template')
                ->first(['id']);
        if ($et) {
            $subject = $et->subject;
            $body = $et->template;
            $body = str_replace('##NAME##', $this->user->name, $body);
            $body = str_replace('##EMAIL##', $this->user->email, $body);
            $body = str_replace('##PHONE##', $this->user->phone, $body);
            $body = str_replace('##PASSWORD##', $this->user->password, $body);

            $this->subject($subject)
                    ->view('frontend.emails.template')
                    ->with(['template' => $body]);
        }
    }

}
