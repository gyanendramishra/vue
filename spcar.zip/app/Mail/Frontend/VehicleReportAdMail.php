<?php

namespace App\Mail\Frontend;

use App\EmailTemplate;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Modules\VehicleManager\Entities\Vehicle;

class VehicleReportAdMail extends Mailable {

    use Queueable,
        SerializesModels;
    
    /**
     * The Vehicle instance.
     *
     * @var Vehicle
     */
    public $vehicle;

    /**
     * The Request instance.
     *
     * @var Request
     */
    public $request;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Vehicle $vehicle, Request $request)
    {
        $this->vehicle = $vehicle;
        $this->request = $request;
    }
   
    /**
     * Build the message.
     *
     * @return $this
     */
    public function build() {
        $et = EmailTemplate::whereType('vehicle_report_ad_mail_to_admin')
                ->with('translations:id,email_template_id,locale,subject,template')
                ->first(['id']);
        if ($et) {
            $subject = $et->subject;
            $body = $et->template;
            $body = str_replace('##VEHICLE_TITLE##', $this->vehicle->title, $body);
            $body = str_replace('##VEHICLE_CODE##',$this->vehicle->id, $body);
            $body = str_replace('##NAME##', $this->request->name, $body);
            $body = str_replace('##EMAIL##', $this->request->email ? $this->request->email : 'N/A', $body);
            $body = str_replace('##PHONE##', $this->request->phone, $body);
            $body = str_replace('##TYPE##', __('vehicle.REPORT_AD.FORM.AS.OPTIONS')[$this->request->type], $body);
            $body = str_replace('##MESSAGE##', $this->request->message, $body);
            
            $this->subject($subject)
                    ->view('frontend.emails.template')
                    ->with(['template' => $body]);
        }
    }

}
