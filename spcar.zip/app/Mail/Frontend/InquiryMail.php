<?php

namespace App\Mail\Frontend;

use App\EmailTemplate;
use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Modules\EnquiresManager\Entities\Inquiry;

class InquiryMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The Inquiry instance.
     *
     * @var Inquiry
     */

    public $inquiry;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Inquiry $inquiry)
    {
        $this->inquiry = $inquiry;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $et = EmailTemplate::whereType('inquiry_mail')
            ->with('translations:id,email_template_id,locale,subject,template')
            ->first(['id']);
        if($et){
            $subject = $et->subject;
            $body = $et->template;
            $body = str_replace('##EMAIL##', $this->inquiry->email ? $this->inquiry->email : 'N/A', $body);
            $body = str_replace('##PHONE##', $this->inquiry->phone, $body);
            $body = str_replace('##ENQUIRY_RELATES_TO##', __('contactus.FORM.ENQUIRY_RELATESTO.OPTIONS')[$this->inquiry->type], $body);
            $body = str_replace('##SUBJECT##', $this->inquiry->subject, $body);
            $body = str_replace('##MESSAGE##', $this->inquiry->message, $body);

            $this->subject($subject)
                ->view('frontend.emails.template')
                ->with(['template'=>$body]);
        }
    }
}
