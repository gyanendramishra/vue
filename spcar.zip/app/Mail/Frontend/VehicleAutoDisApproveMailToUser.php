<?php

namespace App\Mail\Frontend;

use App\EmailTemplate;
use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class VehicleAutoDisApproveMailToUser extends Mailable {

    use Queueable,
        SerializesModels;

    public $vehicle;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($vehicle) {
        $this->vehicle = $vehicle;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build() {

       
        $et = EmailTemplate::whereType('vehicle_auto_disapprove_mail_to_user')
                ->with('translations:id,email_template_id,locale,subject,template')
                ->first(['id']);

        if ($et) {
         
            $subject = $et->subject;
            $subject = str_replace('##VEHICLE_TITLE##', $this->vehicle->title, $subject);
            $body = $et->template;
            $body = str_replace('##USER##', $this->vehicle->user->name, $body);
            $title = '<a href="'.route('admin.vehicle.show',$this->vehicle->id).'">'.$this->vehicle->title.'</a>' ;
            $body = str_replace('##VEHICLE_TITLE##', $title, $body);
            $body = str_replace('##VEHICLE_CODE##', $this->vehicle->id, $body);


            $this->subject($subject)
                    ->view('frontend.emails.template')
                    ->with(['template' => $body]);
        }
    }

}
