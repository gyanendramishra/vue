<?php

namespace App\Mail\Frontend;

use App\EmailTemplate;
use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Modules\VehicleEnquiresManager\Entities\Conversation;

class VehicleInquiryMailToAdmin extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The Inquiry instance.
     *
     * @var Inquiry
     */

    public $conversation;

    /**
     * The Inquiry data.
     *
     * @var Inquiry
     */

    public $inqData;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Conversation $conversation, $inqData)
    {
        $this->conversation = $conversation;
        $this->inqData = $inqData;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $et = EmailTemplate::whereType('vehicle_inquiry_mail_to_admin')
            ->with('translations:id,email_template_id,locale,subject,template')
            ->first(['id']);
        if($et){
            $subject = $et->subject;
            $body = $et->template;
            $body = str_replace('##VEHICLE_TITLE##', $this->conversation->vehicle->title, $body);
            $body = str_replace('##VEHICLE_CODE##', $this->conversation->vehicle->id, $body);
            $body = str_replace('##NAME##', $this->inqData['name'], $body);
            $body = str_replace('##EMAIL##', $this->inqData['email'] ?? 'N/A', $body);
            $body = str_replace('##PHONE##', $this->inqData['phone'], $body);
            $message = $this->conversation->messages->last();
            if($message){
                $body = str_replace('##MESSAGE##', $message->content, $body);
            }
            $this->subject($subject)
                ->view('frontend.emails.template')
                ->with(['template'=>$body]);
        }
    }
}
