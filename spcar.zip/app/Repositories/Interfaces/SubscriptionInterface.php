<?php
namespace App\Repositories\Interfaces;

use Illuminate\Http\Request;

interface SubscriptionInterface {
    
    public function getSubscriptionPlansByUser($user);

    public static function getSubscriptionPlanById($subscriptionPlanId);
    
}
