<?php
namespace App\Repositories\Interfaces;

interface ReviewInterface {
    
    public function getAllVehiclesReviewsOfUser();

    public function getAllVehiclesReviewsOfAdmin();

    public function getHomeReviewsOfAdmin();

    public function getVehicleReviews($vehicleId);

    public function getVehicleReviewOfAdminBySlug($slug);

}
