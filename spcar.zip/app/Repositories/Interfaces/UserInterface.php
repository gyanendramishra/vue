<?php
namespace App\Repositories\Interfaces;

use Illuminate\Http\Request;

interface UserInterface {
    
    public function savedVehicle($user);
    
    public function vehicles($user);

    public function hasActiveSubscription($user);

    public function subscription($user);
    
    public function listingCount($user);

    public function remaininglistingCount($user);
    
    public function featuredCount($user);

    public function remainingFeaturedCount($user);

    public function onSaleCount($user);

    public function remainingOnSaleCount($user);
    
    public function untilSoldCount($user);

    public function remainingUntilSoldCount($user);

    public function soldCount($user);

    public function favouriteCount($user);

    public function vehicleInquiriesCount($user);
}
