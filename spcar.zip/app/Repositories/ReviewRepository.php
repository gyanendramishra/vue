<?php
namespace App\Repositories;

use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Modules\VehicleManager\Entities\Vehicle;
use App\Repositories\Interfaces\ReviewInterface;
use Modules\VehicleReviewsManager\Entities\VehicleReview;
use Modules\AdminVehicleReviewManager\Entities\AdminVehicleReview;

class ReviewRepository implements ReviewInterface {
    

    /* Get vehicle user reviews ad's */
    public function getAllVehiclesReviewsOfUser(){
        return Vehicle::select(
                        'id',
                        'title',
                        'slug'
                    )
                    ->approved()
                    ->whereHas('vehicleReviews', function ($q) {
                        $q->active();
                    })
                    ->with('main_image:id,vehicle_id,image,caption')
                    ->withCount(['vehicleReviews'=> function($q){
                        $q->active()->with('user:id,name');
                    }])
                    ->orderBy('vehicle_reviews_count', 'DESC')
                    ->paginate(15);
    }

    /* Get vehicle admin reviews */
    public function getAllVehiclesReviewsOfAdmin(){
        return AdminVehicleReview::select('id', 'review_type', 'image', 'video', 'created_at', 'slug')
                    ->with('translations:id,admin_vehicle_review_id,locale,title,excerpt')
                    ->active()
                    ->orderBy('id', 'DESC')
                    ->paginate(15);
    }

    /* Get home reviews */
    public function getHomeReviewsOfAdmin(){
        return AdminVehicleReview::select('id', 'review_type', 'image', 'video', 'created_at', 'slug')
                    ->with('translations:id,admin_vehicle_review_id,locale,title,excerpt')
                    ->active()
                    ->orderBy('id', 'DESC')
                    ->take(20)
                    ->get();
    }

    /* Get vehicle admin reviews by slug */
    public function getVehicleReviewOfAdminBySlug($slug){
        return AdminVehicleReview::select('id', 'review_type', 'image', 'video', 'created_at')
                    ->with('translations:id,admin_vehicle_review_id,locale,title,description')
                    ->whereSlug($slug)
                    ->active()
                    ->first();
    }

    /* Get vehicle reviews */
    public function getVehicleReviews($vehicleId){
        return VehicleReview::select(
                'id',
                'user_id',
                'vehicle_id',
                'title',
                'rating',
                'review',
                'created_at'
            )
            ->active()
            ->where('vehicle_id', $vehicleId)
            ->with('user:id,name')
            ->orderBy('id', 'desc')
            ->paginate(10);
    }

}
