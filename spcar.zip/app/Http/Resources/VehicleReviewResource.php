<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class VehicleReviewResource extends JsonResource {

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request) {
       
        $data = [
            'id' => $this->id,
            'title' => $this->title,
            'slug' => $this->slug,
            'avg_rating' => ($this->average_rating == null)?0:$this->average_rating,
            'last_review' => $this->getLatestReviewTitleAttribute(),
            'image' => ($this->main_image)?url('storage/vehicle/') . "/" . $this->main_image->image:'',
            'video' => $this->video,
            'vehicle_reviews_count' => $this->vehicle_reviews_count,
            'url'=> url('vehicle/'.$this->slug)
          
        ];


        return $data;
    }

}
