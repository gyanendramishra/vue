<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ConversationMessagesResource extends JsonResource {

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request) {
      
        $data =  [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'date_time' => $this->date_time,
            'created_at' => $this->human_time,
            'content' => $this->content,
            'profile_image' => ($this->user) ? url('storage/' . $this->user->profile_image) : '',
        ];
        if ($this->user->roles->pluck('name')->contains('Guest')) {
            $participant = $this->conversation->participants()->where('user_id', $this->user->id)->first();
            $data['username'] = $participant->pivot->name;
        } else {
            $data['username'] = $this->user->name;
        }
       
        return $data;
    }

}
