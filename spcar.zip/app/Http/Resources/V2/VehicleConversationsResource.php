<?php

namespace App\Http\Resources\V2;

use Illuminate\Http\Resources\Json\JsonResource;

class VehicleConversationsResource extends JsonResource {

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request) {
        
        /* Load participants */
        $this->participants->map(function ($participant){
            if($participant->roles->pluck('name')->contains('Guest')){
                $participant['name'] = $participant->pivot->name;
                $participant['email'] = $participant->pivot->email;
                $participant['phone'] = $participant->pivot->phone;
            }else{
                $participant['name'] = $participant->name;
                $participant['email'] = $participant->email;
                $participant['phone'] = $participant->phone;
            }
            return $participant;
        });
     
        return [
            'id' => $this->id,
            'username' => isset($this->participants[0]) ? $this->participants[0]->name : '',
            'image' => isset($this->participants[0]) ? url('storage/' . $this->participants[0]->profile_image) : '',
            'message' => $this->messages->last(),
        ];
    }

}
