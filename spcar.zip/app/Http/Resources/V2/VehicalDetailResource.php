<?php

namespace App\Http\Resources\V2;

use Illuminate\Http\Resources\Json\JsonResource;
use Modules\VehicleFeatureManager\Entities\VehicleFeature;
use App\Http\Resources\V2\Collection\FeatureCollection as FeatureCollection;
use App\Http\Resources\V2\Collection\ImageCollection;
use App\Http\Resources\V2\Collection\ReviewCollection;

class VehicalDetailResource extends JsonResource {

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request) {

        $features = [];
        foreach ($this->vehicleFeatures as $vehicleFeatures) {
            $features[] = $vehicleFeatures->name;
        }

        if ($this->discount_price) {
            if ($this->is_masked_price == 1) {
                $discount_price = \App\Helpers\Helper::format_masked_currency($this->discount_price, $this->initial_masking_digits);
            }
        } else {
            if ($this->is_masked_price == 1) {
                $price = \App\Helpers\Helper::format_masked_currency($this->price, $this->initial_masking_digits);
            }
        }


        if ($request->header('language')) {
            $lang = $request->header('language');
        }

        $data = [
            'id' => $this->id,
            'code' => $this->id,
            'title' => $this->title,
            'year_build' => $this->year_build,
            'engine_size' => $this->engine_size,
            //'year_complied' => $this->year_complied,
            'doors' => $this->doors,
            'make' => ($this->make) ? $this->make->name : '',
            'model' => ($this->model) ? $this->model->name : '',
            'badge' => ($this->badge) ? $this->badge->name : '',
            'year' => $this->year,
            'price' => isset($price) ? $price : \App\Helpers\Helper::format_currency($this->price),
            'seats' => $this->seats,
            'chassis_number' => $this->chassis_numbe,
            'plate_number' => $this->plate_number,
            'gears' => $this->gears,
            'fuel_economy' => \Config::get('constants.FUEL_ECONOMY.') . $this->fuel_economy_id,
            'fuel_type' => $this->fuel_type->name,
            'transmissions' => ($this->transmissions) ? $this->transmissions->name : '',
            'turbo' => $this->turbo,
            'odometer' => \App\Helpers\Helper::format_number($this->odometer),
            'expiry_month' => $this->expiry_month,
            'expiry_year' => $this->expiry_year,
            'description' => $this->description,
            'phone' => $this->phone,
            'images' => $this->vehicle_images()->get(),
            'created_at' => $this->created_at,
            'owner_id' => ($this->user) ? $this->user->id : '',
            'is_masked_discounted_price' => $this->is_masked_price,
            'initial_masking_digits' => $this->initial_masking_digits,
            'discount_price' => isset($discount_price) ? $discount_price : '',
            'is_inspected' => $this->is_inspected,
            'is_featured' => $this->is_featured,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'shared_url' => url('vehicle/' . $this->slug)

                //'is_favourite ' => $this->created_at,
        ];
        $expiry_date = ($this->expiry_month && $this->expiry_year) ? \Config::get('constants.Month')[$this->expiry_month]."/".$this->expiry_year : 'N/A';
		
        $year_build = ($this->year_build && $this->month_build) ?\Config::get('constants.Month')[$this->month_build] ."/".$this->year_build : 'N/A';

        if ($lang == 'en') {
            $overview = [
                array('key' => 'Vehicle', 'value' => $this->title),
//            array('key' => 'Price', 'value' => \App\Helpers\Helper::format_currency( $this->price)),
                array('key' => 'Kilometers', 'value' => \App\Helpers\Helper::format_number($this->odometer) . " km"),
                array('key' => 'Engine Capacity', 'value' => \App\Helpers\Helper::format_number($this->engine_capacity) . " cc"),
                array('key' => 'Exterior Colour', 'value' => ($this->exteriorColor) ? $this->exteriorColor->name : ''),
                array('key' => 'Interior Colour', 'value' => ($this->interiorColor) ? $this->interiorColor->name : ''),
                array('key' => 'Transmission', 'value' => ($this->transmissions) ? $this->transmissions->name : ''),
                array('key' => 'Body', 'value' => ($this->bodystyle) ? $this->bodystyle->name : ''),
                array('key' => 'Registration Plate', 'value' => ($this->plate_number)?$this->plate_number:"N/A"),
                array('key' => 'Registration Expiry', 'value' => $expiry_date),
                array('key' => 'Build Date', 'value' => $year_build),
                array('key' => 'Model Year', 'value' => $this->year_build),
                array('key' => 'Car Code', 'value' => $this->id),
                array('key' => 'Location', 'value' => $this->address),
            ];
            $spec = [
                array('key' => 'Fuel Type', 'value' => ($this->fuel_type) ? $this->fuel_type->name : ''),
                array('key' => 'Drive Type', 'value' => ($this->drive_types) ? $this->drive_types->name : ''),
                array('key' => 'Lifestyle', 'value' => ($this->vehicleLifestyle) ? $this->vehicleLifestyle->name : ''),
                array('key' => 'Doors', 'value' => $this->doors),
                array('key' => 'Seats', 'value' => $this->seats),
                array('key' => 'Gears', 'value' => $this->gears),
                array('key' => 'Cylinders', 'value' => ($this->cylinders_id) ? $this->cylinders_id : ''),
                array('key' => 'Turbo/Supercharged', 'value' => ($this->turbo == 1) ? 'Yes' : 'No'),
                array('key' => 'Fuel Economy', 'value' => ($this->fuel_economy_id) ? \Config::get('constants.FUEL_ECONOMY')[$this->fuel_economy_id] : ''),
            ];
        }
        if ($lang == 'kh') {
			$overview = [
                array('key' => 'យានយន្ត', 'value' => $this->title),
	//          array('key' => 'តំលៃ', 'value' => \App\Helpers\Helper::format_currency( $this->price)),
				array('key' => 'កុងទ័រគីឡូម៉ែត្រ', 'value' => \App\Helpers\Helper::format_number($this->odometer) . " km"),
				array('key' => 'ម៉ាស៊ីន', 'value' => \App\Helpers\Helper::format_number($this->engine_capacity) . " cc"),
				array('key' => 'ពណ៌ផ្ទៃខាងក្រៅ', 'value' => ($this->exteriorColor) ? $this->exteriorColor->name : ''),
				array('key' => 'ពណ៌ផ្ទៃខាងក្នុង', 'value' => ($this->interiorColor) ? $this->interiorColor->name : ''),
				array('key' => 'ប្រអប់លេខ', 'value' => ($this->transmissions) ? $this->transmissions->name : ''),
				array('key' => 'ប្រភេទតួរថយន្ត', 'value' => ($this->bodystyle) ? $this->bodystyle->name : ''),
				array('key' => 'ស្លាកលេខរថយន្ត', 'value' => $this->plate_number),
				array('key' => 'ផុតកំណត់ពន្ធផ្លូវ', 'value' => $expiry_date),
				array('key' => 'ខែផលិត', 'value' => $year_build),
				array('key' => 'ឆ្នាំផលិត', 'value' => $this->year_build),
				array('key' => 'លេខកូដរថយន្ត', 'value' => $this->id),
				array('key' => 'ទីតាំង', 'value' => $this->address),
            ];
			
			
			$spec = [
            array('key' => 'ប្រភេទប្រេងឥន្ធនៈ', 'value' => ($this->fuel_type) ? $this->fuel_type->name : ''),
            array('key' => 'ប្រភេទប្រព័ន្ធនៃការរង្វិលកង់', 'value' => ($this->drive_types) ? $this->drive_types->name : ''),
            array('key' => 'គោលបំណងនៃការប្រើប្រាស់', 'value' => ($this->vehicleLifestyle) ? $this->vehicleLifestyle->name : ''),
            array('key' => 'ចំនូនទ្វារ', 'value' => $this->doors),
            array('key' => 'ចំនូនកៅអី', 'value' => $this->seats),
            array('key' => 'លេខប្រអប់លេខ', 'value' => $this->gears),
            array('key' => 'ស៊ីឡាំង', 'value' => ($this->cylinders_id) ? $this->cylinders_id : ''),
            array('key' => 'ទូប៊ូ/ស៊ុបពឺឆាច', 'value' => ($this->turbo == 1) ? 'Yes' : 'No'),
            array('key' => 'កំរិតប្រើប្រេងឥន្ធនៈ', 'value' => ($this->fuel_economy_id) ? \Config::get('constants.FUEL_ECONOMY')[$this->fuel_economy_id] : ''),
			];
        }
        
        $data['is_favourite'] = $this->is_favourite($this->id);
        $data['spec'] = $spec;
        $data['overview'] = $overview;
        $data['images'] = new ImageCollection($this->vehicle_images()->get());
        if ($this->vehicleReviews) {
            $data['reviews'] = new ReviewCollection($this->vehicleReviews()->where('status', 1)->orderBy('id','desc')->get());
        }

        $data['features'] = $features;
        $data['allFeatures'] = new FeatureCollection(VehicleFeature::withTranslation()->get());

        return $data;
    }

    protected function is_favourite($value) {
        if (\Auth::guard('api')->check()) {

            if (\Auth::guard('api')->user()->favouriteVehicles()->wherePivot('vehicle_id', $value)->first()) {
                $user = \Auth::guard('api')->user()->favouriteVehicles()->wherePivot('vehicle_id', $value)->first();
                return $user->pivot->is_favourite;
            }
        }
        return 0;
    }

}
