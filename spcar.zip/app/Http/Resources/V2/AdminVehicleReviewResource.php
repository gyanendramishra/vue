<?php

namespace App\Http\Resources\V2;

use Illuminate\Http\Resources\Json\JsonResource;

class AdminVehicleReviewResource extends JsonResource {

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request) {
        $data = [];

        if (!empty($this->id)) {
            $data = [
                'id' => $this->id,
                'review_type' => $this->review_type,
                'image' => url('uploads/vehicleAdminReviews/') . "/" . $this->image,
                'video' => $this->video,
                'created_at' => $this->published_at,
                'slug' => $this->slug,
                'status' => $this->status,
                'title' =>$this->title,
                'excerpt' => $this->app_description,
                'description' => $this->description,
                'url' => url('car-reviews/' . $this->slug)
            ];
        }




        return $data;
    }

}
