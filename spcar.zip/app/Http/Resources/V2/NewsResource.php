<?php

namespace App\Http\Resources\V2;

use Illuminate\Http\Resources\Json\JsonResource;

class NewsResource extends JsonResource {

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request) {
        $data = [];
     
        if (!empty($this->id)) {
            $data = [
                'id' => $this->id,
                'news_type' => $this->news_type,
                'image' => url('uploads/newsImages/') . "/" . $this->image,
                'video' => $this->video,
                'start_date' => $this->start_date,
                'description'=>$this->description,
                'excerpt' => $this->excerpt,
                'end_date' => $this->end_date,
                'slug' => $this->slug,
                'title' => $this->title,
                'url' => url('news/' . $this->slug)
            ];
        }




        return $data;
    }

}
