<?php

namespace App\Http\Resources\V2;

use Illuminate\Http\Resources\Json\JsonResource;

class UserVehiclesHasConversationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
    
         return [
          
            'id' => $this->id,
            'title' => $this->title,
            'image' => ($this->main_image)?url('storage/vehicle/'.$this->main_image->image):'',
             'conversations_count'=> $this->conversations_count
        ];
    }
}
