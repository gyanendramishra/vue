<?php

namespace App\Http\Resources\V2;

use Illuminate\Http\Resources\Json\JsonResource;

class SubscriptionResource extends JsonResource {

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request) {
        $data = [
            'id' => $this->id,
            'title' => $this->title,
            'duration' => $this->duration,
            'duration_type' => $this->duration_type,
            'price' => $this->price,
            'Listing' => $this->total_listing_count,
            'Featured' => $this->total_featured_count,
            'Sale' => $this->total_on_sale_count,
            'Image' => url('uploads/subscriptionImages/' . $this->image),
        ];

        return $data;
    }

}
