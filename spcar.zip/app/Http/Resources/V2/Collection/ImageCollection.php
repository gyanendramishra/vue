<?php

namespace App\Http\Resources\V2\Collection;

use Illuminate\Http\Resources\Json\ResourceCollection;
use App\Http\Resources\V2\ImageResource as ImageResource;

class ImageCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
      
        $this->collection = $this->collection->sortBy('image_type');
        return ImageResource::collection($this->collection);
    }
}
