<?php

namespace App\Http\Resources\V2\Collection;

use Illuminate\Http\Resources\Json\ResourceCollection;
use App\Http\Resources\V2\DriveTypeResource as DriveTypeResource;

class DriveTypeCollection extends ResourceCollection {

    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request) {

         return  DriveTypeResource::collection($this->collection);
           
        
        
    }

}
