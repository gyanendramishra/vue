<?php

namespace App\Http\Resources\V2\Collection;

use Illuminate\Http\Resources\Json\ResourceCollection;
use App\Http\Resources\ColorResource as ColorResource;

class ColorCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return ColorResource::collection($this->collection);
    }
}
