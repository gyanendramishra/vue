<?php

namespace App\Http\Resources\V2\Collection;

use Illuminate\Http\Resources\Json\ResourceCollection;
use App\Http\Resources\FeatureResource as FeatureResource;

class FeatureCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $this->collection = $this->collection->sortBy('name');
         return FeatureResource::collection($this->collection);
    }
}
