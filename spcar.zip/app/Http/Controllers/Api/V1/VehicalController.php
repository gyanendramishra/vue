<?php

namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Mail\Frontend\VehicleInquiryMailToAdmin;
use App\Mail\Frontend\VehicleInquiryMailToOwner;
use Validator;
use App\Http\Resources\Collection\FavouriteListCollection;
use Modules\VehicleBodyStyleManager\Entities\VehicleBodyStyle;
use Modules\VehicleManager\Entities\Vehicle;
use Modules\VehicleManager\Entities\VehicleImage;
use Modules\VehicleTransmissionsManager\Entities\VehicleTransmissions;
use Modules\VehicleFuelTypesManager\Entities\VehicleFuelTypes;
use Modules\VehicleFeatureManager\Entities\VehicleFeature;
use Modules\CategoryManager\Entities\Category;
use Modules\VehicleLifestyleManager\Entities\VehicleLifestyle;
use Modules\VehicleDriveTypesManager\Entities\VehicleDriveTypes;
use Modules\VehicleColorsManager\Entities\VehicleColors;
use App\Http\Resources\Collection\MakeCollection as MakeCollection;
use App\Http\Resources\Collection\TransmissionsCollection as TransmissionsCollection;
use App\Http\Resources\Collection\FuelTypesCollection as FuelTypesCollection;
use App\Http\Resources\Collection\BodyTypeCollection as BodyTypeCollection;
use App\Http\Resources\Collection\ColorCollection as ColorCollection;
use App\Http\Resources\Collection\DriveTypeCollection as DriveTypeCollection;
use App\Http\Resources\Collection\CategoryCollection as CategoryCollection;
use App\Http\Resources\Collection\FeatureCollection as FeatureCollection;
use App\Http\Resources\Collection\LifestyleCollection as LifestyleCollection;
use App\Http\Resources\Collection\UserVehicleListCollection as UserVehicleListCollection;
use App\Http\Resources\EditVehicleResource as EditVehicleResource;
use Modules\VehicleMakeManager\Entities\VehicleMake;
use Config;
use Image as Image;
use App\Mail\Frontend\VehicleReportAdMail;
use App\Repositories\UserRepository;
use App\Mail\Frontend\VehicleAddedMailToAdmin;
use App\Mail\Frontend\VehicleAddedMailToUser;
use Aloha\Twilio\Twilio;

class VehicalController extends Controller {

    public $successStatus = 200;
    private $userRepository;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request, UserRepository $userRepository) {
        //$authInformation = $request->header();
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
        $this->userRepository = $userRepository;
    }

    /**
     * Home api
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {
        
    }

    /**
     * @desc Save vehicle enquiry into db
     * @param Request $request
     */
    public function saveVehicalInquiry(Request $request) {

        try {
            // check validations
            $validator = Validator::make($request->all(), [
                        'vehicle_id' => 'bail|required',
                        'name' => 'bail|required|max:100',
                        'email' => 'nullable|email|max:100',
                        'phone' => 'bail|required|numeric|digits_between:9,15',
                        'post_code' => 'bail|required|min:4|max:10',
                        'message' => 'bail|required|max:500'
            ]);

            if ($validator->fails()) {
                $data['data'] = (object) [];
                $data['status'] = false;
                $data['message'] = implode(' ', $validator->errors()->all());
                $data['code'] = 200;
                return response()->json($data);
            }

            $vehicle = Vehicle::select('id', 'user_id')->find($request->vehicle_id);
            if ($vehicle) {
                if (\Auth::guard('api')->check()) {
                    $user = \Auth::guard('api')->user();
                    if ($user->id == $vehicle->user_id) {
                        $data['data'] = (object) [];
                        $data['status'] = false;
                        $data['message'] = __('frontend.VEHICLE_INQUIRY_SELF_VEHICLE');
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                } else {
                    $user = \App\User::where('phone', $request->phone)->first(['id']);

                    if ($user) {
                        if ($user->id == $vehicle->user_id) {
                            $data['data'] = (object) [];
                            $data['status'] = false;
                            $data['message'] = __('frontend.VEHICLE_INQUIRY_SELF_VEHICLE');
                            $data['code'] = 200;
                            return response()->json($data);
                        }
                    } else {
                        $user = \App\User::whereHas('roles', function($q) {
                                    $q->where('name', 'Guest');
                                })->first(['id', 'name', 'email', 'phone']);
                    }
                }
                \DB::beginTransaction();
                $conversation = new \Modules\VehicleEnquiresManager\Entities\Conversation();
                $conversation->vehicle_id = $vehicle->id;
                $conversation->title = $vehicle->title . '(' . $vehicle->user->name . '-' . $request->name . ')';
                /* Save conversaion */
                if ($conversation->save()) {
                    /* Save conversaion message */
                    $conversationMessage = new \Modules\VehicleEnquiresManager\Entities\ConversationMessage();
                    $conversationMessage->conversation_id = $conversation->id;
                    $conversationMessage->user_id = $user->id;
                    $conversationMessage->content = $request->message;
                    $conversationMessage->save();

                    /* Attach participants */
                    $conversation->participants()->attach([
                        $vehicle->user->id => [
                            'name' => $vehicle->user->name,
                            'email' => $vehicle->user->email,
                            'phone' => $vehicle->user->phone
                        ],
                        $user->id => [
                            'name' => $request->name,
                            'email' => $request->email,
                            'phone' => $request->phone
                        ]
                    ]);
                    // DB commit
                    \DB::commit();
                    // Send inquiry mail to admin


                    $settings = \Modules\SettingManager\Entities\Setting::select('id', 'slug')
                            ->with('translations:id,setting_id,locale,value')
                            ->where('slug', 'ADMIN_EMAIL')
                            ->get()
                            ->pluck('value', 'slug');
                    if ($settings->has('ADMIN_EMAIL')) {
                        try {
                            \Mail::to($settings['ADMIN_EMAIL'])->send(new VehicleInquiryMailToAdmin($conversation, $request->only(['name', 'email', 'phone'])));
                        } catch (\Exception $e) {
                            \Log::info('vehicle inquiry mail not sent to admin:' . $e->getMessage());
                        }
                    }
                    // send mail to owner
                    if (isset($vehicle->user->email)) {
                        try {
                            \Mail::to($vehicle->user->email)->send(new VehicleInquiryMailToOwner($conversation, $request->only(['name', 'email', 'phone'])));
                        } catch (\Exception $e) {
                            \Log::info('vehicle inquiry mail not sent to owner:' . $e->getMessage());
                        }
                    }

                    // send sms send to user
                    try {
                        $account_id = env('TWILIO_SID');
                        $auth_token = env('TWILIO_TOKEN');
                        $from_phone_number = env('TWILIO_FROM');
                        $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                        $message = 'Dear ' . $vehicle->user->name . ', a new enquiry receieved on your vehicle ' . $vehicle->title . '. Kindly login to app or website and check.';
                        $toNumber = '+855' . $vehicle->user->phone;
                        $twilio->message($toNumber, $message);
                    } catch (\Exception $e) {
                        \Log::info('new inquiry message not sent:' . $e->getMessage());
                    }
                    return response()->json([
                                'data' => (object) [],
                                "status" => true,
                                "message" => __('frontend.VEHICLE_INQUIRY_SAVED'),
                                "code" => 200,
                    ]);
                }
            }
            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        } catch (\Exception $e) {
            \DB::rollBack();
            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = $e->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * @desc Save/update favourite listing
     * @param Request $request
     */
    public function saveFavourite(Request $request) {
        try {
            \DB::beginTransaction();
            if (\Auth::guard('api')->check()) {

                $user = \Auth::guard('api')->user();
                $vehicle = Vehicle::find($request->vehicle_id);

                if ($user && $vehicle) {
                    if ($user->id == $vehicle->user_id) {
                        return response()->json([
                                    'data' => (object) [],
                                    "status" => false,
                                    "message" => __('frontend.VEHICLE_FAVOURITE_SELF_WARNING'),
                                    "code" => 200,
                        ]);
                    } else {
                        if ($user->favouriteVehicles()->where('vehicle_id', $request->vehicle_id)->exists()) {
                            if ($request->is_favourite == 0) {
                                $user->favouriteVehicles()->updateExistingPivot($request->vehicle_id, ['is_favourite' => 0]);
                                \DB::commit();
                                return response()->json([
                                            'data' => (object) [],
                                            "status" => true,
                                            "message" => __('frontend.VEHICLE_FAVOURITE_UNSAVED'),
                                            "code" => 200,
                                ]);
                            } else {
                                $user->favouriteVehicles()->updateExistingPivot($request->vehicle_id, ['is_favourite' => 1]);
                                \DB::commit();
                                return response()->json([
                                            'data' => (object) [],
                                            "status" => true,
                                            "message" => __('frontend.VEHICLE_FAVOURITE_SAVED'),
                                            "code" => 200,
                                ]);
                            }
                        } else {
                            $user->favouriteVehicles()->attach($request->vehicle_id, ['is_favourite' => 1]);
                            \DB::commit();
                            return response()->json([
                                        'data' => (object) [],
                                        "status" => true,
                                        "message" => __('frontend.VEHICLE_FAVOURITE_SAVED'),
                                        "code" => 200,
                            ]);
                        }
                    }
                }
            } else {
                return response()->json([
                            'data' => (object) [],
                            "status" => false,
                            "message" => __('frontend.VEHICLE_FAVOURITE_AUTH_WARNING'),
                            "code" => 200,
                ]);
            }
            throw new \Exception(__('frontend.OOPS'));

            return response()->json([
                        'data' => (object) [],
                        "status" => true,
                        "message" => __('frontend.VEHICLE_FAVOURITE'),
                        "code" => 200,
            ]);
        } catch (Exception $ex) {

            \DB::rollBack();
            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function listFavourite(Request $request) {
        try {
            if (\Auth::guard('api')->check()) {
                $user = new FavouriteListCollection(\Auth::guard('api')->user()->favouriteVehicles()->where('is_approved', 1)->wherePivot('is_favourite', 1)->withTranslation()->paginate(10));
                $data['data'] = [
                    'total_count' => $user->total(),
                    'list_items' => $user
                ];
                $data['status'] = true;
                $data['message'] = "lists";
                $data['code'] = 200;
                return response()->json($data);
            } else {

                $data['data'] = [];
                $data['status'] = false;
                $data['message'] = $ex->getMessage();
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {

            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @return type
     */
    public function addFormData() {
        try {
            $datas = [
                ["item" => "Make", "value" => new MakeCollection(VehicleMake::withTranslation()->get())],
                ["item" => "Postcode", "value" => []],
                ["item" => "Year", "value" => []],
                ["item" => "Price", "value" => []],
                ["item" => "Ad Type", "value" => new CategoryCollection(Category::withTranslation()->get())],
                ["item" => "Keywords", "value" => []],
                ["item" => "Transmissions", "value" => new TransmissionsCollection(VehicleTransmissions::withTranslation()->get())],
                ["item" => "Fuel Types", "value" => new FuelTypesCollection(VehicleFuelTypes::withTranslation()->get())],
                ["item" => "Fuel Economy", "value" => Config::get('constants.FUEL_ECONOMYS')],
                ["item" => "Cylinder", "value" => Config::get('constants.Cylinders')],
                ["item" => "Engine Size", "value" => []],
                ["item" => "Body Type", "value" => new BodyTypeCollection(VehicleBodyStyle::withTranslation()->get())],
                ["item" => "Color", "value" => new ColorCollection(VehicleColors::withTranslation()->get())],
                ["item" => "Drive Type", "value" => new DriveTypeCollection(VehicleDriveTypes::withTranslation()->get())],
                ["item" => "Seats", "value" => []],
                ["item" => "Doors", "value" => Config::get('constants.DOORS')],
                ["item" => "Features", "value" => new FeatureCollection(VehicleFeature::withTranslation()->get())],
                ["item" => "Lifestyle", "value" => new LifestyleCollection(VehicleLifestyle::withTranslation()->get())],
            ];
            $data['data'] = $datas;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            return response()->json([
                        'status' => FALSE,
                        'message' => $ex->getMessage(),
                        'data' => '',
                            ], 401);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function addCar(Request $request) {

        try {
            $user = $request->user('api');

            $validator = $this->validates($request);  // check validation
            if ($validator->fails()) {
                $data['status'] = false;
                $data['message'] = implode(' ', $validator->errors()->all());
                $data['code'] = 200;
                return response()->json($data);
            }

            $vehicalData = $this->prepareData($request);   // Prepare vehical data for savein db

            \DB::beginTransaction();

            if (!empty($request->id)) {
                $vehicle = Vehicle::with(['vehicle_images'])->find($request->id);

                if ($vehicle) {
                    $vehicle->update($vehicalData);
                } else {

                    $data['status'] = false;
                    $data['message'] = __('frontend.OOPS');
                    $data['code'] = 200;
                    return response()->json($data);
                }
            } else {
                $vehicle = Vehicle::create($vehicalData);
            }


            if ($request->steps == 2 && !empty($request->only(['features']))) {
                $vehicle->vehicleFeatures()->detach();
                $vehicle->vehicleFeatures()->attach(explode(',', $request->features));
            }
            $features = $vehicle->vehicleFeatures()->pluck('vehicle_feature_id');
            try {
                if ($request->steps == 4 && !empty($request->only(['vehicle_images']))) {

                    $items = $request->get('vehicle_images');
                    $files = $request->file('vehicle_images');
                    $imgs = [];
                    $sort = 0;
                    ;
                    VehicleImage::where('vehicle_id', $vehicle->id)->update(['image_type' => 'rear']);
                    foreach ($files as $key => $file) {

                        $destinationPath = public_path('storage/vehicle/');
                        $filename = time() . $key . '.' . $file['image']->getClientOriginalExtension();

                        $img = Image::make($file['image']);

                        $imageHeight = $img->height();
                        $imageWidth = $img->width();
                        $canvasHeight = 468;
                        $canvasWidth = 910;

                        $imgHeight = ($imageHeight > $canvasHeight) ? $canvasHeight : $imageHeight;
                        $imgWidth = ($imageWidth > $canvasWidth) ? $canvasWidth : $imageWidth;
                        $img->resize($imgWidth, $imgHeight, function ($constraint) use($imageHeight, $imageWidth, $canvasHeight, $canvasWidth) {
                            if (($imageHeight > $canvasHeight) && ($imageWidth > $canvasWidth)) {
                                $constraint->aspectRatio();
                            }
                            $constraint->upsize();
                        });
                        // insert a image watermark
                        if (($imageHeight >= $canvasHeight) && ($imageWidth >= $canvasWidth)) {
                            $img->insert(public_path('frontend/images/watermark-large.png'), 'bottom-right', 20, 20);
                        } else {
                            $img->insert(public_path('frontend/images/watermark-small.png'), 'bottom-right', 20, 20);
                        }
                        if ($user->hasRole('Dealer')) {
                            $imageHeight = $img->height();
                            $imageWidth = $img->width();
                            for ($i = ($imageWidth / 4), $j = $imageHeight / 4; $i < $imageWidth && $j < $imageHeight; $i += ($imageWidth / 4), $j += ($imageHeight / 4)) {
                                $img->text($user->company_name, $i, $j, function($font) use($imageHeight, $imageWidth, $canvasHeight, $canvasWidth) {
                                    $font->file(public_path('frontend/fonts/WojoSansDemi.ttf'));
                                    if (($imageHeight >= $canvasHeight) && ($imageWidth >= $canvasWidth)) {
                                        $font->size(30);
                                    } else {
                                        $font->size(25);
                                    }
                                    $font->color(array(255, 255, 255, 0.2));
                                    $font->align('center');
                                    $font->valign('top');
                                    $font->angle(45);
                                });
                            }
                        }
                        $img->resizeCanvas($canvasWidth, $canvasHeight, 'center', false, '#ffffff');
                        $img->save($destinationPath . $filename);
                       // $file['image']->move($destinationPath, $filename);


                        $pimage['sort_order'] = $sort++;
                        $pimage['image'] = $filename;
                        if (empty($request->cover_photo_id)) {
                            $pimage['image_type'] = ($key == 0) ? 'front' : 'rear';
                        } else {
                            $pimage['image_type'] = 'rear';

                            $vehicle->vehicle_images()->where('id', $request->cover_photo_id)->update(['image_type' => 'front']);
                        }

                        $pimage['caption'] = "Image";
                        $imgs[] = new VehicleImage($pimage);
                    }

                    $vehicle->vehicle_images()->saveMany($imgs);
                    $vehicle->steps = 4;
                    $vehicle->save();
                }
            } catch (Exception $ex) {
                \Log::info('image upload proceess:' . $e->getMessage());
            }

            if ($request->steps == 5) {
                if ($vehicle->steps == 4) {
                    $vehicle->steps = 5;
                    $vehicle->is_approved = 1;
                    $vehicle->save();
                    \DB::commit();
                    // Send mail to admin
                    $settings = \Modules\SettingManager\Entities\Setting::select('id', 'slug')
                            ->with('translations:id,setting_id,locale,value')
                            ->where('slug', 'ADMIN_EMAIL')
                            ->get()
                            ->pluck('value', 'slug');
                    if ($settings->has('ADMIN_EMAIL')) {
                        \Mail::to($settings['ADMIN_EMAIL'])->send(new VehicleAddedMailToAdmin($vehicle));
                    }
                    // Send vehicle added mail to user
                    if ($vehicle->user->email) {
                        \Mail::to($vehicle->user->email)->send(new VehicleAddedMailToUser($vehicle));
                    }
                    return response()->json([
                                'status' => true,
                                'message' => __('frontend.VEHICLE_SAVED_SUCCESS'),
                                'data' => $vehicle,
                                'code' => 200,
                    ]);
                } else {
                    return response()->json([
                                'status' => true,
                                'message' => __('frontend.VEHICLE_SAVED_SUCCESS'),
                                'data' => $vehicle,
                                'code' => 200,
                    ]);
                }
            }

            if (!empty($request->deleted_ids)) {
                $imagesId = explode(',', $request->deleted_ids);
                VehicleImage::destroy($imagesId);
            }
            if (!empty($request->cover_photo_id)) {

                VehicleImage::where('vehicle_id', $vehicle->id)->update(['image_type' => 'rear']);
                $vehicle->vehicle_images()->where('id', $request->cover_photo_id)->update(['image_type' => 'front']);
            }
            \DB::commit();
            $vehicle['features'] = $features;
            return response()->json([
                        'status' => true,
                        'message' => __('frontend.VEHICLE_SAVED_SUCCESS'),
                        'data' => $vehicle,
                        'code' => 200,
            ]);
        } catch (Exception $ex) {
            dd($ex->getMessage());
            \DB::rollBack();
            return response()->json([
                        'status' => FALSE,
                        'message' => __('frontend.OOPS'),
                        'data' => '',
                        'code' => 401,
            ]);
        }
    }

    /**
     * 
     * @param type $request
     * @return type
     */
    public function validates($request) {
        $validationArr = [];
        $validationArrMessage = [];
        switch ($request->steps) {
            case 1:
                $validationArr = [
                    'category_id' => 'required',
                    'makes_id' => 'required',
                    'models_id' => 'required',
                    //'badge_id' => 'required',
                    //'series_id' => 'required',
                    'body_styles_id' => 'required',
                    'fuel_types_id' => 'required',
                    'transmissions_id' => 'required',
                    'drive_types_id' => 'required',
                    'doors' => 'required|numeric',
                    'seats' => 'required|numeric',
                    'gears' => 'required|numeric',
                    'cylinders_id' => 'required',
                    'year_build' => 'required',
                    'month_build' => 'required',
                    'turbo' => 'required',
                    'engine_capacity' => 'required',
                ];
                $validationArrMessage = [
                    'category_id.required' => ' The category field is required.',
                    'makes_id.required' => ' The makes field is required.',
                    'models_id.required' => ' The models field is required.',
                    'badge_id.required' => ' The badge field is required.',
                    'series_id.required' => ' The series field is required.',
                    'body_styles_id.required' => ' The body style  field is required.',
                    'fuel_types_id.required' => ' The fuel types field is required.',
                    'drive_types_id.required' => ' The drive types field is required.',
                    'transmissions_id.required' => ' The transmissions field is required.',
                    'doors.required' => ' The doors field is required.',
                    'doors.numeric' => 'Doors must be in numeric value.',
                    'seats.required' => ' The seats field is required.',
                    'seats.numeric' => 'Seats must be in numeric value.',
                    'gears.required' => ' The gears field is required.',
                    'year_build.required' => ' The year build field is required.',
                    'month_build.required' => ' The build month field is required.',
                    // 'year_complied.required' => ' The year complied field is required.',
                    'turbo.required' => ' The turbo field is required.',
                    'engine_capacity.required' => ' The engine capacity field is required.',
                    'engine_capacity.required' => ' The engine capacity field is required.',
                    'chassis_number.required' => ' The chassis number field is required.',
                ];
                break;
            case 2:
                $validationArr = [];
                $validationArrMessage = [];
                break;
            case 3:
                $validationArr = [
                    'address' => 'required',
                    'odometer' => 'required',
                    'price' => 'required',
                    'exterior_colour_id' => 'required',
                    'interior_colour_id' => 'required',
                    // 'postcode' => 'required',
//                    'expiry_year' => 'required',
//                    'expiry_month' => 'required',
//                    'plate_number' => 'required',
                    'approved_certified' => 'required',
                    'phone' => 'required|digits_between:9,15|numeric',
                ];
                $validationArrMessage = [
                    'address.required' => ' The address field is required.',
                    'price.required' => ' The price field is required.',
                    'exterior_colour_id.required' => ' The exterior colour field is required.',
                    'interior_colour_id.required' => ' The interior colour field is required.',
                    'plate_number.required' => ' The plate number field is required.',
                    'odometer.required' => ' The odometer field is required.',
                    'odometer.numeric' => 'Odometer must be in numeric value.',
                    'expiry_year.required' => ' The expiry year field is required.',
                    'expiry_month.required' => ' The expiry month field is required.',
                    'approved_certified.required' => ' The approved certified field is required.',
                    'phone.required' => ' The phone field is required.',
                    'phone.digits_between' => 'Please use phone number between 9 to 15 digit only.',
                    'phone.numeric' => ' Phone must be in numeric value.',
                    'en_description.required' => ' The description field is required in english language.'
                ];
                break;
            case 4:
                $validationArr = [];
                $validationArrMessage = [];
                break;
            case 5:
                $validationArr = [];
                $validationArrMessage = [];
                break;
        }
        $validator = Validator::make($request->all(), $validationArr, $validationArrMessage);
        return $validator;
    }

    /**
     * 
     * @param type $request
     * @return type
     */
    public function prepareData($request) {

        $locales = config('app.locales');
        $vehicle_data = array();
        $user = \Auth::guard('api')->user();
        switch ($request->steps) {
            case 1:
                $vehicle_data['title'] = $request->input('year_build') . " " . $request->input('make') . " " . $request->input('model') . " " . $request->input('badge') . " " . $request->input('series');
                $vehicle_data['month_build'] = $request->input('month_build');
                $vehicle_data['user_id'] = $user->id;
                $vehicle_data['role'] = $user->roles->isNotEmpty() ? $user->roles->first()->name : '';
                $vehicle_data['makes_id'] = $request->input('makes_id');
                $vehicle_data['models_id'] = $request->input('models_id');
                $vehicle_data['badge_id'] = ($request->input('badge_id') != 0) ? $request->input('badge_id') : null;
                $vehicle_data['series_id'] = ($request->input('series_id') != 0) ? $request->input('series_id') : null;
                $vehicle_data['body_styles_id'] = $request->input('body_styles_id');
                $vehicle_data['fuel_types_id'] = $request->input('fuel_types_id');
                $vehicle_data['drive_types_id'] = $request->input('drive_types_id');
                $vehicle_data['transmissions_id'] = $request->input('transmissions_id');
                $vehicle_data['doors'] = $request->input('doors');
                $vehicle_data['seats'] = $request->input('seats');
                $vehicle_data['gears'] = $request->input('gears');
                $vehicle_data['cylinders_id'] = $request->input('cylinders_id');
                $vehicle_data['year_build'] = $request->input('year_build');
                //   $vehicle_data['year_complied'] = $request->input('year_complied');
                $vehicle_data['turbo'] = $request->input('turbo');
                $vehicle_data['engine_capacity'] = $request->input('engine_capacity');
                $vehicle_data['chassis_number'] = $request->input('chassis_number');
                $vehicle_data['category_id'] = $request->input('category_id');
                $vehicle_data['steps'] = $request->input('steps');
                break;
            case 3:

                $vehicle_data['address'] = $request->input('address');
                $vehicle_data['postcode'] = $request->input('postcode');
                $vehicle_data['latitude'] = $request->input('latitude');
                $vehicle_data['longitude'] = $request->input('longitude');
                $vehicle_data['country'] = $request->input('country');
                $vehicle_data['state'] = $request->input('state');
                $vehicle_data['city'] = $request->input('city');
                $vehicle_data['odometer'] = $request->input('odometer');
                $vehicle_data['price'] = $request->input('price');
                $vehicle_data['discount_price'] = $request->input('discount_price');
                $vehicle_data['exterior_colour_id'] = $request->input('exterior_colour_id');
                $vehicle_data['interior_colour_id'] = $request->input('interior_colour_id');
                $vehicle_data['expiry_month'] = $request->input('expiry_month');
                $vehicle_data['fuel_economy_id'] = $request->input('fuel_economy_id');
                $vehicle_data['expiry_year'] = $request->input('expiry_year');
                $vehicle_data['plate_number'] = $request->input('plate_number');
                $vehicle_data['written_off'] = $request->input('written_off');
                $vehicle_data['is_registered'] = $request->input('approved_certified');
                $vehicle_data['phone'] = $request->input('phone');
                $vehicle_data['is_masked_price'] = $request->input('is_masked_discounted_price');
                $vehicle_data['initial_masking_digits'] = $request->input('initial_masking_digits');
                $vehicle_data['lifestyle_id'] = $request->input('lifestyle_id');
                $vehicle_data['steps'] = $request->input('steps');


                foreach ($locales as $key => $value) {
                    $vehicle_data[$key]['description'] = $request->input($key . '_description');
                }
                break;
        }
        return $vehicle_data;
    }

    /**
     * @desc  List all user cars
     * @param Request $request
     * @return type
     */
    public function listUserVehicle(Request $request) {
        try {
            if (\Auth::guard('api')->check()) {
                $user = new UserVehicleListCollection(\Auth::guard('api')->user()->vehicles()->withTranslation()->paginate(10));

                $data['data'] = [
                    'total_count' => $user->total(),
                    'list_items' => $user
                ];
                $data['status'] = true;
                $data['message'] = "lists";
                $data['code'] = 200;
                return response()->json($data);
            } else {

                $data['data'] = [];
                $data['status'] = false;
                $data['message'] = __('frontend.OOPS');
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {

            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * Edit my vehicle
     * @param Request $request
     */
    public function editVehicle(Request $request) {
        try {
            if (!empty($request->id)) {
                $vehicle = new EditVehicleResource(Vehicle::with(['vehicleFeatures', 'translations'])->where('id', $request->id)->first());
                $data['data'] = $vehicle;
                $data['status'] = true;
                $data['message'] = "lists";
                $data['code'] = 200;
                return response()->json($data);
            } else {
                $data['data'] = [];
                $data['status'] = false;
                $data['message'] = __('frontend.OOPS');
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {
            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /*     * +
     * 
     */

    public function deleteVehicle(Request $request) {
        try {

            if ($request->id) {
                $res = Vehicle::where('id', $request->id)->delete();
                $data['data'] = (object) [];
                $data['status'] = true;
                $data['message'] = __('frontend.VEHICLE_DELETE_SUCCESS');
                $data['code'] = 200;
                return response()->json($data);
            } else {
                $data['data'] = [];
                $data['status'] = false;
                $data['message'] = __('frontend.OOPS');
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {
            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function reportVehicle(Request $request) {
        try {
            $vehicle = Vehicle::select('id', 'user_id', 'title')->find($request->vehicle_id);
            if ($vehicle) {
                if (\Auth::guard('api')->check()) {
                    $user = \Auth::guard('api')->user();
                    if ($user->id == $vehicle->user_id) {
                        $data['data'] = (object) [];
                        $data['status'] = false;
                        $data['message'] = __('frontend.REPORT_AD_SELF_VEHICLE');
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                } else {
                    $user = \App\User::where('phone', $request->phone)->first(['id']);
                    if ($user) {
                        if ($user->id == $vehicle->user_id) {
                            $data['data'] = (object) [];
                            $data['status'] = false;
                            $data['message'] = __('frontend.REPORT_AD_SELF_VEHICLE');
                            $data['code'] = 200;
                            return response()->json($data);
                        }
                    }
                }

                $settings = \Modules\SettingManager\Entities\Setting::select('id', 'slug')
                        ->with('translations:id,setting_id,locale,value')
                        ->where('slug', 'ADMIN_EMAIL')
                        ->get()
                        ->pluck('value', 'slug');
                if ($settings->has('ADMIN_EMAIL')) {
                    \Mail::to($settings['ADMIN_EMAIL'])->send(new VehicleReportAdMail($vehicle, $request));
                }
                $data['data'] = (object) [];
                $data['status'] = true;
                $data['message'] = __('frontend.REPORT_AD_LOGGED');
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     *  REPORT ADS FOR VEHICLE in storage.
     *
     * @param  App\Http\Requests\Frontend\VehicleReviewRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function saveReview(Request $request) {
        try {
            \DB::beginTransaction();
            $vehicle = Vehicle::select('id', 'user_id', 'title')->find($request->vehicle_id);
            if ($vehicle) {
                if (\Auth::guard('api')->check()) {
                    $user = \Auth::guard('api')->user();
                    if ($user->id == $vehicle->user_id) {
                        $data['data'] = (object) [];
                        $data['status'] = false;
                        $data['message'] = __('frontend.REVIEW_SELF_VEHICLE');
                        $data['code'] = 200;
                        return response()->json($data);
                    } else {
                        $review = new \Modules\VehicleReviewsManager\Entities\VehicleReview($request->all());
                        $review->user_id = $user->id;
                        // save vehicle review
                        if ($review->save()) {
                            // DB commit
                            \DB::commit();
                            $data['data'] = (object) [];
                            $data['status'] = true;
                            $data['message'] = __('frontend.VEHICLE_REVIEW_SAVED');
                            $data['code'] = 200;
                            return response()->json($data);
                        }
                    }
                } else {
                    $data['data'] = (object) [];
                    $data['status'] = false;
                    $data['message'] = __('frontend.REVIEW_AUTH_WARNING');
                    $data['code'] = 200;
                    return response()->json($data);
                }
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function toggleListing(Request $request) {
        try {
            switch ($request->get('type')) {
                case 'is_featured':
                    return $this->isToggleFeatured($request);
                    break;
                case 'is_on_sale':
                    return $this->isToggleOnSale($request);
                    break;
                case 'is_until_sold':
                    return $this->isToggleUntilSold($request);
                    break;
            }
        } catch (Exception $ex) {
            \DB::rollBack();
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * for vehicle toggle featured
     * @param type $request
     * @return type
     * @throws \Exception
     */
    public function isToggleFeatured($request) {
        try {
            \DB::beginTransaction();

            if ($user = $request->user('api')) {
                $vehicle = Vehicle::select('id', 'user_id', 'title', 'is_approved', 'is_featured')->find($request->vehicle_id);
                if ($vehicle) {
                    if ($vehicle->is_approved == 0) {
                        $data['status'] = false;
                        $data['message'] = __('frontend.VEHICLE_NOT_APPROVED', ["vehicle" => $vehicle->title]);
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                    if (!$user->can('update', $vehicle)) {
                        $data['status'] = FALSE;
                        $data['message'] = __('frontend.NOT_AUTHORISED_ACTION');
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                    $isSaved = 1;
                    if ($vehicle->is_featured == 1) {
                        $isSaved = 0;
                        $vehicle->is_featured = 0;
                    } else {
                        $isSaved = 1;
                        $vehicle->is_featured = 1;
                    }
                    $vehicle->save();
                    // DB commit
                    \DB::commit();
                    $data['data'] = $vehicle->is_featured;
                    $data['status'] = true;
                    $data['message'] = $isSaved ? __('frontend.VEHICLE_MARKED_FEATURED', ["vehicle" => $vehicle->title]) : __('frontend.VEHICLE_REMOVED_FEATURED', ["vehicle" => $vehicle->title]);
                    $data['code'] = 200;
                    return response()->json($data);
                }
            }
        } catch (\Exception $e) {
            \DB::rollBack();
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * for toggle vehicle is on sale
     * @param type $request
     * @return type
     * @throws \Exception
     */
    public function isToggleOnSale($request) {
        try {
            \DB::beginTransaction();
            if ($user = $request->user('api')) {
                $vehicle = Vehicle::select('id', 'user_id', 'title', 'is_approved', 'is_on_sale')->find($request->vehicle_id);
                if ($vehicle) {
                    if ($vehicle->is_approved == 0) {
                        $data['status'] = FALSE;
                        $data['message'] = __('frontend.VEHICLE_NOT_APPROVED', ["vehicle" => $vehicle->title]);
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                    if (!$user->can('update', $vehicle)) {
                        $data['status'] = FALSE;
                        $data['message'] = __('frontend.NOT_AUTHORISED_ACTION');
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                    $isSaved = 1;
                    if ($vehicle->is_on_sale == 1) {
                        $isSaved = 0;
                        $vehicle->is_on_sale = 0;
                    } else {
                        $isSaved = 1;
                        $vehicle->is_on_sale = 1;
                    }
                    $vehicle->save();
                    // DB commit
                    \DB::commit();
                    $data['data'] = $vehicle->is_on_sale;
                    $data['status'] = TRUE;
                    $data['message'] = $isSaved ? __('frontend.VEHICLE_MARKED_ONSALE', ["vehicle" => $vehicle->title]) : __('frontend.VEHICLE_REMOVED_ONSALE', ["vehicle" => $vehicle->title]);
                    $data['code'] = 200;
                    return response()->json($data);
                }
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    public function isToggleUntilSold($request) {
        try {
            \DB::beginTransaction();
            if ($user = $request->user('api')) {
                $vehicle = Vehicle::select('id', 'user_id', 'title', 'is_approved', 'is_until_sold')->find($request->vehicle_id);
                if ($vehicle) {
                    if ($vehicle->is_approved == 0) {
                        $data['status'] = FALSE;
                        $data['message'] = __('frontend.VEHICLE_NOT_APPROVED', ["vehicle" => $vehicle->title]);
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                    if (!$user->can('update', $vehicle)) {
                        $data['status'] = FALSE;
                        $data['message'] = __('frontend.NOT_AUTHORISED_ACTION');
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                    $isSaved = 1;
                    if ($vehicle->is_until_sold == 1) {
                        $isSaved = 0;
                        $vehicle->is_until_sold = 0;
                    } else {
                        $isSaved = 1;
                        $vehicle->is_until_sold = 1;
                    }
                    $vehicle->save();
                    // DB commit
                    \DB::commit();
                    $data['data'] = $vehicle->is_until_sold;
                    $data['status'] = TRUE;
                    $data['message'] = $isSaved ? __('frontend.VEHICLE_MARKED_UNTILSOLD', ["vehicle" => $vehicle->title]) : __('frontend.VEHICLE_REMOVED_UNTILSOLD', ["vehicle" => $vehicle->title]);
                    $data['code'] = 200;
                    return response()->json($data);
                }
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = $e->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

}
