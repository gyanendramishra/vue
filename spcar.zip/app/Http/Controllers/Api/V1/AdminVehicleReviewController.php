<?php

namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use \Modules\AdminVehicleReviewManager\Entities\AdminVehicleReview;
use App\Http\Resources\Collection\AdminVehicleReviewCollection;
use App\Http\Resources\AdminVehicleReviewResource as AdminVehicleReviewResource;

class AdminVehicleReviewController extends Controller {

    public $successStatus = 200;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request) {
        //$authInformation = $request->header();
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
    }

    /**
     *  get all news list
     * @param Request $request
     * @return type
     */
    public function index(Request $request) {

        try {

            $VehicleReview = new AdminVehicleReviewCollection(AdminVehicleReview::select('id', 'review_type', 'image', 'video', 'created_at', 'slug','status')
                            ->with('translations:id,admin_vehicle_review_id,locale,title,description,excerpt')
                            ->active()
                            ->orderBy('id', 'DESC')
                            ->paginate(10));
            $data['data'] = [
                'total_count' => $VehicleReview->total(),
                'list_items' => $VehicleReview
            ];
            $data['status'] = true;
            $data['message'] = "lists";
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {

            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

}
