<?php

namespace App\Http\Controllers\Api\V2;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\VehicleMakeManager\Entities\VehicleMake;
use Modules\AdsManager\Entities\Ad;
use App\PageLocation;
use Modules\VehicleBodyStyleManager\Entities\VehicleBodyStyle;
use Modules\VehicleManager\Entities\Vehicle;
use Modules\VehicleTransmissionsManager\Entities\VehicleTransmissions;
use Modules\VehicleFuelTypesManager\Entities\VehicleFuelTypes;
use Modules\VehicleFeatureManager\Entities\VehicleFeature;
use Modules\CategoryManager\Entities\Category;
use Modules\VehicleLifestyleManager\Entities\VehicleLifestyle;
use Modules\VehicleColorsManager\Entities\VehicleColors;
use App\Http\Resources\V2\Collection\MakeCollection as MakeCollection;
use App\Http\Resources\V2\Collection\AllMakeCollection as AllMakeCollection;
use App\Http\Resources\V2\Collection\TransmissionsCollection as TransmissionsCollection;
use App\Http\Resources\V2\Collection\FuelTypesCollection as FuelTypesCollection;
use App\Http\Resources\V2\Collection\BodyTypeCollection as BodyTypeCollection;
use App\Http\Resources\V2\Collection\AllBodyTypeCollection as AllBodyTypeCollection;
use App\Http\Resources\V2\Collection\ColorCollection as ColorCollection;
use App\Http\Resources\V2\Collection\CategoryCollection as CategoryCollection;
use App\Http\Resources\V2\Collection\CountryCollection as CountryCollection;
use App\Http\Resources\V2\Collection\FeatureCollection as FeatureCollection;
use App\Http\Resources\V2\Collection\LifestyleCollection as LifestyleCollection;
use Config;
use Modules\NewsManager\Entities\News;
use App\Http\Resources\V2\Collection\VehicleReviewCollection;
use App\Http\Resources\V2\Collection\AdminVehicleReviewCollection;
use App\Http\Resources\V2\AdminVehicleReviewResource as AdminVehicleReviewResource;
use \Modules\AdminVehicleReviewManager\Entities\AdminVehicleReview;

class HomeController extends Controller {

    public $successStatus = 200;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request) {
        //$authInformation = $request->header();
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
    }

    /**
     * Home api
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {

        $data = [];
        try {
            $page_location_id = PageLocation::where('slug', request()->segment(3))->first()->id;
         
            $datas['top_banner'] = url('images/bannerImg.jpg');
            $vahiclemakes = VehicleMake::withTranslation()->where('status', 1)->orderBy(\DB::raw('ISNULL(sort_order), sort_order'), 'ASC');
            $datas['makes_total'] = $vahiclemakes->count();
            $makeslist = $vahiclemakes->limit(6)->get();
            $makes = [];
            foreach ($makeslist AS $key => $row) {
                $makes[$key] = $row;
                if (!empty($row->icon)) {
                    $makes[$key]->icon = url('uploads/make/' . $row->icon);
                }
            }
            $datas['makes'] = $makes;
            $body_types = VehicleBodyStyle::withTranslation()->where('status', 1)->orderBy(\DB::raw('ISNULL(sort_order), sort_order'), 'ASC');
            ;
            $datas['body_type_total'] = $body_types->count();
            $typeslist = $body_types->limit(6)->get();
            $types = [];
            foreach ($typeslist AS $key => $row) {
                $types[$key] = $row;
                if (!empty($row->icon)) {
                    $types[$key]->icon = url('uploads/bodyStyle/' . $row->icon);
                }
            }
            $datas['body_types'] = $types;
            $datas['review'] = new VehicleReviewCollection(Vehicle::select(
                                    'id', 'title', 'slug'
                            )
                            // ->active()
                            ->approved()
                            ->has('vehicleReviews')
                            ->with('main_image:id,vehicle_id,image,caption')
                            ->withCount(['vehicleReviews' => function($q) {
                                    $q->active()->with('user:id,name');
                                }])
                            ->take(20)
                            ->orderBy('id', 'DESC')
                            ->get()->where('average_rating', '!=', null));
            $datas['adminReview'] = new AdminVehicleReviewCollection(AdminVehicleReview::select('id', 'review_type', 'image', 'video', 'created_at', 'slug', 'status')
                            ->with('translations:id,admin_vehicle_review_id,locale,title,description,excerpt')
                            ->active()
                            ->take(20)
                            ->orderBy('id', 'DESC')
                            ->get());
            $news = News::select('id', 'image', 'start_date', 'end_date', 'news_type', 'video', 'slug')
                    ->with('translations:id,news_id,locale,title,description,excerpt')
                    ->whereDate('start_date', '<=', \Carbon\Carbon::now())
                    ->whereDate('end_date', '>=', \Carbon\Carbon::now())
                    ->active()
                    ->take(10)
                    ->orderBy('id', 'DESC')
                    ->get();
            $newss = [];
            foreach ($news as $k => $news) {
                $newss[$k]['image'] = url('uploads/newsImages/' . $news->image);
                $newss[$k]['video'] = $news->video;
                $newss[$k]['title'] = $news->title;
                $newss[$k]['slug'] = $news->slug;
                $newss[$k]['description'] = $news->description;
                $newss[$k]['start_date'] = $news->start_date;
                $newss[$k]['end_date'] = $news->end_date;
                $newss[$k]['news_type'] = $news->news_type;
                $newss[$k]['description'] = $news->description;
                $newss[$k]['excerpt'] = $news->excerpt;
                $newss[$k]['url'] = url('news/' . $news->slug);
            }

            $datas['news'] = $newss;
            $caroftheweek['image'] = "";
            $caroftheweek = [];
            $caroftheweeks = Vehicle::withTranslation()->with('vehicle_images')->where('is_approved', 1)->where('is_car_of_the_week', 1)->first();
            if ($caroftheweeks) {
                if ($caroftheweeks->vehicle_images->isNotEmpty()) {
                    $caroftheweek['image'] = url('storage/vehicle/' . @$caroftheweeks->vehicle_images()->first()->image);
                }
                $caroftheweek['web_url'] = "https://carmarket.projectstatus.in/vehicle/" . $caroftheweeks->slug;
                $caroftheweek['slug'] = $caroftheweeks->slug;
                $caroftheweek['title'] = $caroftheweeks->title;
                $caroftheweek['description'] = "Car of the Year is a common abbreviation for numerous awards";
                $datas['caroftheweek'] = $caroftheweek;
            }

            $advertisement = [];
            $ads = [];
            if (Ad::withTranslation()->where(['status' => 1, 'page_location_id' => $page_location_id])->exists()) {
                $ads[] = Ad::withTranslation()->where(['status' => 1, 'page_location_id' => $page_location_id])->inRandomOrder()->first('id', 'title', 'image_type', 'image', 'image_scripts', 'url')->setAttribute("type", "home")->setAppends(['image_full_path']);
            }
            if (Ad::withTranslation()->where(['status' => 1, 'page_location_id' => 4])->exists()) {
                $ads[] = Ad::withTranslation()->where(['status' => 1, 'page_location_id' => 4])->inRandomOrder()->first('id', 'title', 'image_type', 'image', 'image_scripts', 'url')->setAppends(['image_full_path'])->setAttribute("type", "filter");
            }

            $datas['advertisement'] = $ads;
            $data['data'] = $datas;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {

            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 401;
            return response()->json($data);
        }
    }

    /* Get vehicle makes */

    public function getAllMake() {
        try {
            $allMakes = new AllMakeCollection(VehicleMake::select('id', 'icon', 'slug')
                            ->with('translations:id,vehicle_make_id,locale,name')
                            ->active()
                            ->orderBy(\DB::raw('ISNULL(sort_order), sort_order'), 'ASC')
                            ->get());
            $data['data'] = $allMakes;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 401;
            return response()->json($data);
        }
    }

    /* Get vehicle body styles */

    public function getAllBodyType() {
        try {
            $allBodyTypes = new AllBodyTypeCollection(VehicleBodyStyle::select('id', 'icon', 'slug','sort_order')
                            ->with('translations:id,vehicle_body_style_id,locale,name')
                            ->active()
                            ->orderBy(\DB::raw('ISNULL(sort_order), sort_order'), 'ASC')
                            ->get());
            $data['data'] = $allBodyTypes;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 401;
            return response()->json($data);
        }
    }

    /**
     * Master api
     *
     * @return \Illuminate\Http\Response
     */
    public function masters(Request $request) {

        try {
            $datas = [
                ["item" => "Make", "value" => new MakeCollection(VehicleMake::withTranslation()->active()->get())],
                ["item" => "Any Distance", "value" => []],
                ["item" => "Year", "value" => []],
                ["item" => "Price", "value" => []],
                ["item" => "Ad Type", "value" => new CategoryCollection(Category::withTranslation()->active()->get())],
                ["item" => "Keywords", "value" => []],
                ["item" => "Transmissions", "value" => new TransmissionsCollection(VehicleTransmissions::withTranslation()->active()->get())],
                ["item" => "Fuel Types", "value" => new FuelTypesCollection(VehicleFuelTypes::withTranslation()->active()->get())],
                ["item" => "Fuel Economy", "value" => Config::get('constants.FUEL_ECONOMYS')],
                ["item" => "Cylinder", "value" => Config::get('constants.Cylinders')],
                ["item" => "Engine Size", "value" => []],
                ["item" => "Body Type", "value" => new BodyTypeCollection(VehicleBodyStyle::withTranslation()->active()->get())],
                ["item" => "Color", "value" => new ColorCollection(VehicleColors::withTranslation()->active()->get())],
                ["item" => "Seats", "value" => []],
                ["item" => "Doors", "value" => Config::get('constants.DOORS')],
                ["item" => "Features", "value" => new FeatureCollection(VehicleFeature::withTranslation()->active()->get())],
                ["item" => "Lifestyle", "value" => new LifestyleCollection(VehicleLifestyle::withTranslation()->active()->get())],
            ];
            $data['data'] = $datas;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            return response()->json([
                        'status' => FALSE,
                        'message' => __('frontend.OOPS'),
                        'data' => '',
                            ], 401);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function location(Request $request) {
        try {
            $datas = [
                ["item" => "Location", "value" => new CountryCollection(\App\Country::whereIn('id', [12])->get())],
            ];
            $data['data'] = $datas;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            return response()->json([
                        'status' => FALSE,
                        'message' => __('frontend.OOPS'),
                        'data' => '',
                            ], 401);
        }
    }

}
