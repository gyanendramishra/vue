<?php

namespace App\Http\Controllers\Api\V2;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\VehicleInspectionsManager\Entities\VehicleInspection;
use Validator;
use App\Mail\Frontend\VehicleInspectionMailToOwner;
use App\Mail\Frontend\VehicleInspectionMailToAdmin;

class InspectionController extends Controller {

    public $successStatus = 200;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request) {
        //$authInformation = $request->header();
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Backend\InquiryRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function inspection(Request $request) {
        try {

            // check validations
            $validator = Validator::make($request->all(), [
                        'name' => 'bail|required|max:100',
                        'email' => 'nullable|email|max:100',
                        'phone' => 'bail|required|string|max:100',
                        'message' => 'bail|required|string'
            ]);

            if ($validator->fails()) {
                $data['data'] = (object) [];
                $data['status'] = false;
                $data['message'] = implode(' ', $validator->errors()->all());
                $data['code'] = 200;
                return response()->json($data);
            }


            \DB::beginTransaction();
            $inspection = new VehicleInspection($request->all());
            $inspection->user_id = \Auth::guard('api')->id();
            if ($inspection->save()) {
                // DB commit
                \DB::commit();

                /* Send mail to admin */
                $settings = \Modules\SettingManager\Entities\Setting::select('id', 'slug')
                        ->with('translations:id,setting_id,locale,value')
                        ->where('slug', 'ADMIN_EMAIL')
                        ->get()
                        ->pluck('value', 'slug');

                if ($settings->has('ADMIN_EMAIL')) {
                    \Mail::to($settings['ADMIN_EMAIL'])->send(new VehicleInspectionMailToAdmin($inspection));
                }
                /* Send mail to owner */
                if ($inspection->user->email) {
                    \Mail::to($inspection->user->email)->send(new VehicleInspectionMailToOwner($inspection));
                }

                return response()->json([
                            'data' => (object) [],
                            "status" => true,
                            "message" => __('frontend.VEHICLE_INSPECTION_REQUEST_RAISED'),
                            "code" => 200,
                ]);
            }

            \DB::rollBack();
            return response()->json([
                        'data' => (object) [],
                        "status" => false,
                        "message" => __('frontend.OOPS'),
                        "code" => 200,
            ]);
        } catch (\Exception $e) {
            dd($e->getMessage());
            \DB::rollBack();
            return response()->json([
                        'data' => (object) [],
                        "status" => false,
                        "message" => __('frontend.OOPS'),
                        "code" => 200,
            ]);
        }
    }

}
