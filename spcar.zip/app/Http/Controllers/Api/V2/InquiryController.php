<?php

namespace App\Http\Controllers\Api\V2;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Mail\Frontend\InquiryMail;
use Modules\EnquiresManager\Entities\Inquiry;
use Validator;

class InquiryController extends Controller {

    public $successStatus = 200;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request) {
        //$authInformation = $request->header();
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Backend\InquiryRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function saveInquiry(Request $request) {
        try {

            // check validations
            $validator = Validator::make($request->all(), [
                        'type' => 'bail|required|integer|max:100',
                        'email' => 'bail|required|email|max:100',
                        'subject' => 'bail|required|string|max:100',
                        'message' => 'bail|required|string|min:100|max:500'
            ]);

            if ($validator->fails()) {
                $data['data'] = (object) [];
                $data['status'] = false;
                $data['message'] = implode(' ', $validator->errors()->all());
                $data['code'] = 200;
                return response()->json($data);
            }


            \DB::beginTransaction();
            $inquiry = new Inquiry($request->all());
            if ($inquiry->save()) {
                // DB commit
                \DB::commit();

                // Send inquiry mail to admin
                $settings = \Modules\SettingManager\Entities\Setting::select('id', 'slug')
                        ->with('translations:id,setting_id,locale,value')
                        ->where('slug', 'ADMIN_EMAIL')
                        ->get()
                        ->pluck('value', 'slug');
                if ($settings->has('ADMIN_EMAIL')) {
                    \Mail::to($settings['ADMIN_EMAIL'])->send(new InquiryMail($inquiry));
                }


                return response()->json([
                            'data' => (object) [],
                            "status" => true,
                            "message" => __('frontend.ENQUIRED'),
                            "code" => 200,
                ]);
            }

            \DB::rollBack();
            return response()->json([
                        'data' => (object) [],
                        "status" => false,
                        "message" => __('frontend.NOT_ENQUIRED'),
                        "code" => 200,
            ]);
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        'data' => (object) [],
                        "status" => false,
                        "message" => __('frontend.OOPS'),
                        "code" => 200,
            ]);
        }
    }

}
