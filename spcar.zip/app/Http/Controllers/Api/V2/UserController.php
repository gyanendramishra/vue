<?php

namespace App\Http\Controllers\Api\V2;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Support\Facades\Auth;
use Validator;
use Aloha\Twilio\Twilio;

class UserController extends Controller {

    public $successStatus = 200;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request) {
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
    }

    /**
     * @desc For check cred is email or phone
     * @param Request $request
     * @return type
     */
    protected function credentials(Request $request) {
        if (is_numeric($request->get('email'))) {
            return ['phone' => $request->get('email'), 'password' => $request->get('password')];
        }
        return $request->only('email', 'password');
    }

    /**
     * @desc Create condition for check fields
     * @param Request $request
     * @return type
     */
    protected function chkusername(Request $request) {
        if (is_numeric($request->get('email'))) {
            return $cred = ['phone' => $request->email];
        } else {
            return $cred = ['email' => $request->email];
        }
    }

    /**
     * @desc login api 
     * @param Request $request
     * @return type
     */
    public function login(Request $request) {
        try {
            if (Auth::attempt([
                        (is_numeric($request->get('email'))) ? 'phone' : 'email' => $request->get('email'),
                        'password' => $request->password
                    ])) {
                $user = \Auth::user();
                $error = 0;
                // Check if user is active
                if ($user->is_otp_verified == 0) {
                    $error = 1;
                }
                // Check if user is verified
                if ($user->status == 0) {
                    $error = 2;
                }

                if ($error != 0) {
                    \Auth::logout();
                    if ($error == 1) {
                        $randomNumber = rand(100000, 999999);

                        \App\UserVerification::where('user_id', $user->id)->where('otp_type', 1)->delete();
                        \App\UserVerification::create([
                            'user_id' => $user->id,
                            'otp' => $randomNumber,
                            'otp_type' => 1,
                        ]);

                        try {
                            $account_id = env('TWILIO_SID');
                            $auth_token = env('TWILIO_TOKEN');
                            $from_phone_number = env('TWILIO_FROM');
                            $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                            $message = 'Warm Greeting From S.P Car Market! Please use OTP ' . $randomNumber . ' for phone verification. Thanks.';
                            $toNumber = $user->country_code . $user->phone;
                            $twilio->message($toNumber, $message);
                        } catch (\Exception $e) {
                            \Log::info('verify OTP message not sent:' . $e->getMessage());
                        }

                        $data['data'] = $user;
                        $data['status'] = true;
                        $data['message'] = 'Your account not verified yet.';
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                    if ($error == 2) {

                        $data['data'] = (object) [];
                        $data['status'] = FALSE;
                        $data['message'] = __('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_ACTIVATION');
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                }
                $tokenResult = $user->createToken('Personal Access Token');
                $user->api_token = $tokenResult->accessToken;
                $user->last_seen_at = date('Y-m-d H:i:s');
                $user->save();
                $user->profile_image = url('storage/' . $user->profile_image);
                $user->phone = (string) $user->phone;
                $datas = $user;
                $datas['access_token'] = $tokenResult->accessToken;
                $datas['role_id'] = $user->roles()->first()->id;
                $datas['token_type'] = 'Bearer';
                $data['data'] = $datas;
                $data['status'] = TRUE;
                $data['message'] = __('frontend.LOGIN_SUCCESS');
                $data['code'] = 200;
                return response()->json($data);
            } else {
                // Failed login
                $data['data'] = (object) [];
                $data['status'] = FALSE;
                $data['message'] = __('frontend.LOGIN_FAILED');
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {
            return response()->json([
                        'status' => FALSE,
                        'message' => __('frontend.OOPS'),
                        'data' => (object) [],
                            ], 401);
        }
    }

    /**
     * Register api 
     * 
     * @return \Illuminate\Http\Response 
     */
    public function register(Request $request) {

        $validator = Validator::make($request->all(), [
                    'name' => 'required',
                    'email' => 'nullable|email|max:50|unique:users,email',
                    'password' => 'required',
                    'phone' => 'required|unique:users',
                    'company_name' => 'nullable|required_if:role_id,3',
                    'address' => 'nullable|required_if:role_id,3',
        ]);
        if ($validator->fails()) {


            $data['status'] = false;
            $data['message'] = implode(' ', $validator->errors()->all());
            $data['code'] = 200;
            return response()->json($data);
        }
        try {
            $randomNumber = rand(100000, 999999);

            $input = $request->all();

            $input['password'] = bcrypt($input['password']);
            $input['otp'] = $randomNumber;
            if ($request->role_id == 3) {
                $input['company_name'] = $request->company_name;
                $input['address'] = $request->address;
                $input['latitude'] = $request->latitude;
                $input['longitude'] = $request->longitude;
            }
            $user = User::create($input);

            $data1['token'] = $user->createToken('MyApp')->accessToken;
            $data1 = $user;

            if ($user) {
                $user->roles()->sync($input['role_id']);

                $conversations = \Modules\VehicleEnquiresManager\Entities\Conversation::whereHas('participants', function($q) use($user) {
                            $q->where('conversation_participants.phone', $user->phone);
                            $q->orWhere('conversation_participants.email', $user->email);
                        });

                $conversations->each(function($conversation) use($user) {

                    $conversation->participants()->detach(2);

                    $conversation->participants()->attach([
                        $user->id => [
                            'name' => $user->name,
                            'email' => $user->email,
                            'phone' => $user->phone
                        ]
                    ]);
                    $messages = $conversation->messages->where('user_id', '!=', $conversation->vehicle->user->id);

                    $conversation->messages->each(function($message) use($conversation, $user) {
                        if ($message->user_id !== $conversation->vehicle->user->id) {

                            $message->user_id = $user->id;
                            $message->save();
                        }
                    });
                });

                $userVerification = new \App\UserVerification();
                $userVerification->otp = $input['otp'];
                $userVerification->otp_type = 1;
                $user->userVerification()->save($userVerification);

                try {
                    $account_id = env('TWILIO_SID');
                    $auth_token = env('TWILIO_TOKEN');
                    $from_phone_number = env('TWILIO_FROM');
                    $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                    $message =  'Warm Greeting From S.P Car Market! Please use OTP ' . $randomNumber . ' for phone verification. Thanks.';
                    $toNumber = $request->country_code . $user->phone;
                    $twilio->message($toNumber, $message);
                } catch (\Exception $e) {
                    \Log::info('Registration OTP message not sent:' . $e->getMessage());
                }
               
            }
            $data['status'] = true;
            $data['message'] = __('frontend.REGISTERED');
            $data['code'] = 200;
            $data['data'] = $data1;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * @desc For verify otp for mobile verification
     * @param Request $request
     * @return type
     */
    public function verify(Request $request) {
        try {
            if ($request->otp) {
                $userOtp = \App\User::whereHas('userVerification', function($q) use($request) {
                            $q->where('otp', $request->otp)->where('phone', $request->phone)->where('otp_type', $request->otp_type);
                        })->first();

                if ($userOtp) {

                    $to = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $userOtp->userVerification->created_at);
                    $from = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', date('Y-m-d H:i:s'));


                    $diff_in_minutes = $to->diffInMinutes($from);

                    if ($diff_in_minutes > 120) {
                        $data['data'] = (object) [];
                        $data['status'] = true;
                        $data['message'] = __('frontend.OTP_EXPIRED');
                        $data['code'] = 200;
                        return response()->json($data);
                    }


                    $userOtp->userVerification()->where('otp_type', $request->otp_type)->delete();
                    if ($request->otp_type == 1) {
                        $userOtp->update(['is_otp_verified' => 1]);

                        Auth::login($userOtp);
                        $user = Auth::user();

                        $tokenResult = $user->createToken('Personal Access Token');
                        $user->api_token = $tokenResult->accessToken;
                        $user->save();
                        $user->phone = (string) $user->phone;
                        $datas = $user;
                        $datas['access_token'] = $tokenResult->accessToken;
                        $datas['role_id'] = $user->roles()->first()->id;
                        $datas['token_type'] = 'Bearer';
                        $data['data'] = $datas;
                        $data['status'] = TRUE;
                        $data['message'] = __('frontend.LOGIN_SUCCESS');
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                    $userOtp->profile_image = url('storage/' . $userOtp->profile_image);
                    $userOtp->phone = (string) $userOtp->phone;
                    $data['data'] = $userOtp;
                    $data['status'] = true;
                    $data['message'] = __('frontend.VERIFIED');
                    $data['code'] = 200;
                    return response()->json($data);
                } else {
                    $data['data'] = (object) [];
                    $data['status'] = false;
                    $data['message'] = __('frontend.INCORRECT_OTP');
                    $data['code'] = 200;
                    return response()->json($data);
                }
            } else {
                $data['data'] = (object) [];
                $data['status'] = false;
                $data['message'] = __('frontend.INCORRECT_OTP');
                $data['code'] = 200;
                return response()->json($data);
            }
            
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function resendOtp(Request $request) {
        try {
            if ($request->phone) {
                $user = User::where('phone', $request->phone)->first();
                if ($user) {
                    $randomNumber = rand(100000, 999999);
                
                    \App\UserVerification::where('user_id', $user->id)->where('otp_type', $request->otp_type)->delete();

                    \App\UserVerification::updateOrCreate(
                            [
                        'user_id' => $user->id,
                        'otp_type' => $request->otp_type
                            ], [
                        'user_id' => $user->id,
                        'otp' => $randomNumber,
                        'otp_type' => $request->otp_type,
                            ]
                    );

                    try {
                        $account_id = env('TWILIO_SID');
                        $auth_token = env('TWILIO_TOKEN');
                        $from_phone_number = env('TWILIO_FROM');
                        $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                        $message =  'Warm Greeting From S.P Car Market! Please use OTP ' . $randomNumber . ' for phone verification. Thanks.';
                        $toNumber = $user->country_code . $user->phone;
                        $twilio->message($toNumber, $message);
                    } catch (\Exception $e) {
                        \Log::info('Rsend OTP message not sent:' . $e->getMessage());
                    }
                    $data['data'] = (object) [];
                    $data['status'] = true;
                    $data['message'] = __('frontend.RESEND_OTP');
                    $data['code'] = 200;
                    return response()->json($data);
                } else {
                    $data['data'] = (object) [];
                    $data['status'] = false;
                    $data['message'] = __('frontend.FORGOT_PASSWORD_EMAIL_NOT_EXISTS');
                    $data['code'] = 200;
                    return response()->json($data);
                }
            }
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * @desc For forgot password send otp
     * @param Request $request
     */
    public function forgot(Request $request) {
        try {
            if ($request->phone) {
                $user = User::where('phone', $request->phone)->first();
                if ($user) {
                    if ($user->is_otp_verified == 0) {
                        $user->phone = (string) $user->phone;
                        $data['data'] = $user;
                        $data['status'] = TRUE;
                        $data['message'] = __('frontend.FORGOT_PASSWORD_FAILED_DUE_TO_ACCOUNT_VERIFICATION');
                        $data['code'] = 105;
                        return response()->json($data);
                    }
                    // Check if user is verified
                    if ($user->status == 0) {
                        $data['data'] = (object) [];
                        $data['status'] = FALSE;
                        $data['message'] = __('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_ACTIVATION');
                        $data['code'] = 200;
                        return response()->json($data);
                    }

                    $randomNumber = rand(100000, 999999);
                   
                    \App\UserVerification::where('user_id', $user->id)->delete();
                    \App\UserVerification::updateOrCreate(
                            [
                        'user_id' => $user->id,
                        'otp_type' => 2
                            ], [
                        'user_id' => $user->id,
                        'otp' => $randomNumber,
                        'otp_type' => 2,
                            ]
                    );
                    
                    try {
                        $account_id = env('TWILIO_SID');
                        $auth_token = env('TWILIO_TOKEN');
                        $from_phone_number = env('TWILIO_FROM');
                        $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                        $message =  'Warm Greeting From S.P Car Market! Please use OTP ' . $randomNumber . ' for phone verification. Thanks.';
                        $toNumber = $user->country_code . $user->phone;
                        $twilio->message($toNumber, $message);
                    } catch (\Exception $e) {
                        \Log::info('Registration OTP message not sent:' . $e->getMessage());
                    }
                    
                    $data['data'] = (object) [];
                    $data['status'] = true;
                    $data['message'] = __('frontend.FORGOT_PASSWORD_SUCCESS');
                    $data['code'] = 200;
                    return response()->json($data);
                } else {
                    $data['data'] = (object) [];
                    $data['status'] = false;
                    $data['message'] = __('frontend.FORGOT_PASSWORD_EMAIL_NOT_EXISTS');
                    $data['code'] = 200;
                    return response()->json($data);
                }
            }
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * @desc for change password
     * @param Request $request
     * @return type
     */
    public function resetPassword(Request $request) {
        try {
            if ($request->id) {
                $user = \App\User::where('id', $request->id)->first();
                if ($user) {
                    $user->update(['password' => bcrypt($request->password)]);
                    $data['data'] = (object) [];
                    $data['status'] = true;
                    $data['message'] = __('frontend.RESET_PASSWORD_SUCCESS');
                    $data['code'] = 200;
                    return response()->json($data);
                } else {
                    $data['data'] = (object) [];
                    $data['status'] = false;
                    $data['message'] = __('frontend.OOPS');
                    $data['code'] = 200;
                    return response()->json($data);
                }
            } else {
                $data['data'] = (object) [];
                $data['status'] = false;
                $data['message'] = __('frontend.OOPS');
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * Social login via app
     * @param Request $request
     * @return type
     */
    public function socialLogin(Request $request) {
        try {
            \DB::beginTransaction();

            if ($request->token) {

                $user = User::where($request->provider . '_id', $request->token)->first();

                if ($user) {  // if user exists
                    // Check if user is active
                    if ($user->status == 0) {
                        $data['data'] = (object) [];
                        $data['status'] = FALSE;
                        $data['message'] = __('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_ACTIVATION');
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                    if ($user->is_otp_verified == 0) {
                        $user->phone = (string) $user->phone;
                        $data['data'] = $user;
                        $data['status'] = FALSE;
                        $data['message'] = __('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_VERIFICATION');
                        $data['code'] = 105;
                        return response()->json($data);
                    }

                    // login the user
                    $tokenResult = $user->createToken('Personal Access Token');
                    $data = $user;
                    $user->api_token = $tokenResult->accessToken;
                    $user->save();
                    // Commit db
                    \DB::commit();
                    $data['access_token'] = $tokenResult->accessToken;
                    $data['role_id'] = $user->roles()->first()->id;
                    $data['token_type'] = 'Bearer';
                    $data['message'] = __('frontend.LOGIN_SUCCESS');
                    return response()->json([
                                'status' => TRUE,
                                'data' => $data,
                                'code' => 200,
                    ]);
                } else {   // not exits user
                    if (isset($request->phone)) {  // check phone or email has 
                        $user = User::where('phone', $request->phone)->first();
                        if ($user) {  // if user exists
                            // Check if user is active
                            if ($user->status == 0) {
                                $data['data'] = (object) [];
                                $data['status'] = FALSE;
                                $data['message'] = __('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_ACTIVATION');
                                $data['code'] = 200;
                                return response()->json($data);
                            }
                            if ($user->is_otp_verified == 0) {
                                $user->phone = (string) $user->phone;
                                $data['data'] = $user;
                                $data['status'] = FALSE;
                                $data['message'] = __('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_VERIFICATION');
                                $data['code'] = 105;
                                return response()->json($data);
                            }
                            // login the user
                            $tokenResult = $user->createToken('Personal Access Token');
                            $data = $user;
                            $user->api_token = $tokenResult->accessToken;
                            $user->save();
                            // Commit db
                            \DB::commit();
                            $data['access_token'] = $tokenResult->accessToken;
                            $data['role_id'] = $user->roles()->first()->id;
                            $data['token_type'] = 'Bearer';
                            $data['message'] = __('frontend.LOGIN_SUCCESS');
                            return response()->json([
                                        'status' => TRUE,
                                        'data' => $data,
                                        'code' => 200,
                            ]);
                        } else {

                            $user->name = $request->name ?? '';
                            $user->email = $request->email ?? '';
                            $user->phone = $request->phone ?? '';
                            if ($request->provider == 'google') {
                                $user->google_id = $request->token;  // cgeck user behalf on token
                            } else {
                                $user->facebook_id = $request->token;
                            }
                            $user->status = 1;
                            $user->is_otp_verified = 1;
                            $user->save();

                            // Commit db
                            \DB::commit();

                            // login the user
                            $tokenResult = $user->createToken('Personal Access Token');
                            $data = $user;
                            $user->api_token = $tokenResult->accessToken;
                            $user->save();
                            $data['access_token'] = $tokenResult->accessToken;
                            $data['role_id'] = $user->roles()->first()->id;
                            $data['token_type'] = 'Bearer';
                            $data['message'] = __('frontend.LOGIN_SUCCESS');
                            return response()->json([
                                        'status' => TRUE,
                                        'data' => $data,
                                        'code' => 200,
                            ]);
                        }
                    } else {
                        $data['data'] = $request->all();
                        $data['status'] = FALSE;
                        $data['code'] = 106;
                        return response()->json($data);
                    }
                }
            }
            \DB::rollBack();
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            \DB::rollBack();
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * For phone social; login
     * @param Request $request
     */
    public function handleAppPhoneLogin(Request $request) {
        $randomNumber = rand(100000, 999999);
        try {
            \DB::beginTransaction();
            $user = User::where('phone', $request->phone)->first();
            if (!$user) {
                $user = new User;
                $user->password = null;
            }

            $user->name = $request->name;
            $user->phone = $request->phone;
            if(!User::whereEmail($request->email)->exists()){
                $user->email = $request->email;
            }
            $user->country_code = $request->countryCode;

            if ($request->provider == 'facebook') {
                $user->facebook_id = $request->token;
            }
            if ($request->provider == 'google') {
                $user->google_id = $request->token;
            }

            $user->status = 1;

            if ($user->save()) {
                // attach user role to user

                $conversations = \Modules\VehicleEnquiresManager\Entities\Conversation::whereHas('participants', function($q) use($user) {
                            $q->where('conversation_participants.phone', $user->phone);
                            $q->orWhere('conversation_participants.email', $user->email);
                        });

                $conversations->each(function($conversation) use($user) {

                    $conversation->participants()->detach(2);

                    $conversation->participants()->attach([
                        $user->id => [
                            'name' => $user->name,
                            'email' => $user->email,
                            'phone' => $user->phone
                        ]
                    ]);
                    $messages = $conversation->messages->where('user_id', '!=', $conversation->vehicle->user->id);

                    $conversation->messages->each(function($message) use($conversation, $user) {
                        if ($message->user_id !== $conversation->vehicle->user->id) {

                            $message->user_id = $user->id;
                            $message->save();
                        }
                    });
                });
               

                if ($user->is_otp_verified == 0) {
                    $userVerification = new \App\UserVerification();
                    $userVerification->otp = $randomNumber;
                    $userVerification->otp_type = 1;
                    $user->userVerification()->save($userVerification);
                    try {
                        $account_id = env('TWILIO_SID');
                        $auth_token = env('TWILIO_TOKEN');
                        $from_phone_number = env('TWILIO_FROM');
                        $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                        $message = 'Warm Greeting From S.P Car Market! Please use OTP ' . $randomNumber . ' for phone verification. Thanks.';
                        $toNumber = $request->countryCode . $user->phone;
                        $twilio->message($toNumber, $message);
                    } catch (\Exception $e) {
                        \Log::info('Registration OTP message not sent:' . $e->getMessage());
                    }
                    \DB::commit();
                    $user->phone = (string) $user->phone;
                    $data['status'] = true;
                    $data['message'] = __('frontend.REGISTERED');
                    $data['code'] = 105;
                    $data['data'] = $user;
                        \Log::info('otp sent success' );
                    return response()->json($data);
                 
                } else {
                    $tokenResult = $user->createToken('Personal Access Token');

                    $user->api_token = $tokenResult->accessToken;
                    $user->save();
                    \DB::commit();
                    $data = $user;
                    $data['access_token'] = $tokenResult->accessToken;
                    $data['role_id'] = $user->roles()->first()->id;
                    $data['token_type'] = 'Bearer';
                    $data['message'] = __('frontend.LOGIN_SUCCESS');
                     \Log::info('login success');
                    return response()->json([
                                'status' => TRUE,
                                'data' => $data,
                                'code' => 200,
                    ]);
                }
                
            } else {
                 \Log::info('login success');
                \DB::rollBack();
                $data['data'] = (object) [];
                $data['status'] = false;
                $data['message'] = __('frontend.OOPS');
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {
            \DB::rollBack();
             \Log::info('new inquiry message not sent:' . $e->getMessage());
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function socialVerifyOtp(Request $request) {

        try {
            if ($request->otp) {
                $userOtp = \App\User::whereHas('userVerification', function($q) use($request) {
                            $q->where('otp', $request->otp)->where('phone', $request->phone)->where('otp_type', $request->otp_type);
                        })->first();

                if ($userOtp) {

                    $to = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $userOtp->userVerification->created_at);
                    $from = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', date('Y-m-d H:i:s'));


                    $diff_in_minutes = $to->diffInMinutes($from);

                    if ($diff_in_minutes > 120) {
                        $data['data'] = (object) [];
                        $data['status'] = true;
                        $data['message'] = __('frontend.OTP_EXPIRED');
                        $data['code'] = 200;
                        return response()->json($data);
                    }


                    $userOtp->userVerification()->where('otp_type', $request->otp_type)->delete();
                    if ($request->otp_type == 1) {
                        $userOtp->is_otp_verified = 1;
                        if ($request->role_id == 3) {
                            $userOtp->company_name = $request->company_name;
                            $userOtp->address = $request->address;
                            $userOtp->city = $request->city;
                            $userOtp->state = $request->state;
                            $userOtp->country = $request->country;
                            $userOtp->latitude = $request->latitude;
                            $userOtp->longitude = $request->longitude;
                        }
                        $userOtp->save();

                        Auth::login($userOtp);
                        $user = Auth::user();


                        $tokenResult = $user->createToken('Personal Access Token');
                        $user->api_token = $tokenResult->accessToken;
                        $user->save();

                        $user->phone = (string) $user->phone;
                        $user->roles()->attach($request->role_id);
                        $datas = $user;
                        $datas['access_token'] = $tokenResult->accessToken;
                        $datas['role_id'] = $user->roles()->first()->id;
                        $datas['token_type'] = 'Bearer';
                        $data['data'] = $datas;
                        $data['status'] = TRUE;
                        $data['message'] = __('frontend.LOGIN_SUCCESS');
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                    $userOtp->profile_image = url('storage/' . $userOtp->profile_image);
                    $userOtp->phone = (string) $userOtp->phone;
                    $data['data'] = $userOtp;
                    $data['status'] = true;
                    $data['message'] = __('frontend.VERIFIED');
                    $data['code'] = 200;
                    return response()->json($data);
                } else {
                    $data['data'] = (object) [];
                    $data['status'] = false;
                    $data['message'] = __('frontend.INCORRECT_OTP');
                    $data['code'] = 200;
                    return response()->json($data);
                }
            } else {
                $data['data'] = (object) [];
                $data['status'] = false;
                $data['message'] = __('frontend.INCORRECT_OTP');
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

}
