<?php

namespace App\Http\Controllers\Api\V2;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Support\Facades\Auth;
use Validator;
use App\Repositories\UserRepository;

class DashboardController extends Controller {

    public $successStatus = 200;
    private $userRepository;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request, UserRepository $userRepository) {
        $this->userRepository = $userRepository;
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
    }

    public function index() {
        try {
            $datas = [];
            $user = \Auth::guard('api')->user();

            //$subscription = $this->userRepository->subscription($user);
            //  $datas['subscription'] = !empty($subscription) ? $this->userRepository->subscription($user) : (object) [];

            $datas['totalVehicle'] = $this->userRepository->listingCount($user);

            $datas['totalIsFeatured'] = $this->userRepository->featuredCount($user);

            $datas['favouriteVehicles'] = $this->userRepository->favouriteCount($user);

            $datas['totalIsConversations'] = $this->userRepository->vehicleInquiriesCount($user);
            $datas['onSaleCount'] = $this->userRepository->onSaleCount($user);
            $datas['untilSoldCount'] = $this->userRepository->onSaleCount($user);


            $data['data'] = $datas;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function changePassword(Request $request) {

        $validator = Validator::make($request->all(), [
                    'old_password' => 'required',
                    'new_password' => 'required',
        ]);
        if ($validator->fails()) {
            $data['status'] = false;
            $data['message'] = implode(' ', $validator->errors()->all());
            $data['code'] = 200;
            return response()->json($data);
        }

        try {
            \DB::beginTransaction();

            $user = \Auth::guard('api')->user();
            if (!\Hash::check($request->old_password, $user->password)) {
                $data['status'] = false;
                $data['message'] = __('frontend.OLD_PASSWORD_NOT_MATCHED');
                $data['code'] = 200;
                return response()->json($data);
            }

            $user->password = bcrypt($request->new_password);
            if ($user->save()) {
                \DB::commit();
                $data['status'] = true;
                $data['message'] = __('frontend.CHANGE_PASSWORD_SUCCESS');
                $data['code'] = 200;
                return response()->json($data);
            } else {
                $data['status'] = true;
                $data['message'] = __('frontend.CHANGE_PASSWORD_FAILED');
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (\Exception $e) {
            \DB::rollBack();
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @return type
     */
    public function profile() {
        try {
            $user = \Auth::guard('api')->user();
            $user->profile_image = url('storage/' . $user->profile_image);
            $user->phone = (string) $user->phone;
            $data['data'] = $user;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    public function updateProfile(Request $request) {

        try {
            $user = \Auth::guard('api')->user();
            
            if ($user->hasRole('Dealer')) {
                $validator = Validator::make($request->all(), [
                            'name' => 'required',
                            'email' => 'nullable|email|unique:users,email,' . $user->id . ',id',
                            'phone' => 'required|unique:users,phone,' . $user->id . ',id',
                            'address' => 'bail|required|max:150',
                            'company_name' => 'bail|required|max:100',
                            'profile_image' => 'nullable|mimes:jpeg,jpg,png| max:2000',
                ]);
            } else {
                $validator = Validator::make($request->all(), [
                            'name' => 'required',
                            'email' => 'nullable|email|unique:users,email,' . $user->id . ',id',
                            'phone' => 'required|unique:users,phone,' . $user->id . ',id',
                            'profile_image' => 'nullable|mimes:jpeg,jpg,png| max:2000',
                ]);
            }
            if ($validator->fails()) {
                $data['status'] = false;
                $data['message'] = implode(' ', $validator->errors()->all());
                $data['code'] = 200;
                return response()->json($data);
            }

            $user->name = $request->name;
            $user->email = $request->email;
            $user->phone = $request->phone;
            $user->address = $request->address;
            $user->company_name = $request->company_name;
            if (!empty($request->latitude) && !empty($request->longitude)) {
                $user->latitude = $request->latitude;
                $user->longitude = $request->longitude;
                $user->city = $request->city;
                $user->state = $request->state;
                $user->country = $request->country;
            }
            if ($request->profile_image) {
                if (\Storage::disk('public')->delete($user->profile_image)) {
                    $user->profile_image = "";
                    $user->save();
                }
                $avatar = $request->file('profile_image')->store('avatars', 'public');
                $user->profile_image = $avatar;
            }
            $user->save();
            $user->profile_image = url('storage/' . $user->profile_image);

            $datas = $user;

            $datas['access_token'] = $user->api_token;
            $datas['role_id'] = $user->roles()->first()->id;
            $datas['token_type'] = 'Bearer';
            $data['data'] = $datas;
            $data['status'] = TRUE;
            $data['message'] = __('frontend.PROFILE_UPDATE_SUCCESS');
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

}
