<?php

namespace App\Http\Controllers\Api\V2;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\VehicleEnquiresManager\Entities\Conversation;
use Modules\VehicleEnquiresManager\Entities\ConversationMessage;
use Modules\VehicleManager\Entities\Vehicle;
use App\Http\Resources\V2\Collection\UserVehiclesHasConversationCollection;
use App\Http\Resources\V2\Collection\VehicleConversationsCollection;
use App\Http\Resources\V2\Collection\ConversationMessagesCollection;
use App\Repositories\ConversationRepository;
use App\Mail\Frontend\MessageMail;
use Aloha\Twilio\Twilio;

class ConversationController extends Controller {

    public $successStatus = 200;
    private $conversationRepository;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request, ConversationRepository $conversationRepository) {
        //$authInformation = $request->header();
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
        $this->conversationRepository = $conversationRepository;
    }

    /**
     * Get all vehicle they has conversation
     * @return type
     */
    public function getVehicleHasConversation(Request $request) {
        try {
            $userId = \Auth::guard('api')->id();

            $allVehicles = new UserVehiclesHasConversationCollection(Vehicle::select('id as id', 'title')
                            ->withCount('conversations')
                            ->with([
                                'main_image:id,vehicle_id,image,caption',
                            ])
                            ->whereHas('conversations', function($q) use($userId) {
                                $q->whereHas('participants', function($q) use($userId) {
                                    $q->where('user_id', $userId);
                                });
                            })->paginate(10));
            $data['data'] = [
                'total_count' => $allVehicles->total(),
                'list_items' => $allVehicles
            ];
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function getVehicleConversations(Request $request) {
      
        try {
            $userId = \Auth::guard('api')->id();

            $allVehicles = new VehicleConversationsCollection(
                    Conversation::select('id', 'vehicle_id', 'title')
                            ->where('vehicle_id', $request->vehicle_id)
                            ->with([
                                'vehicle:id,title,price',
                                'participants' => function($q) use($userId) {
                                    $q->select('users.id', 'users.name', 'users.email', 'users.phone', 'users.profile_image')
                                    ->where('user_id', '!=', $userId);
                                }
                            ])
                            ->selectRaw("conversations.*, (SELECT MAX(created_at) from conversation_messages WHERE conversation_messages.conversation_id=conversations.id) as latest_message_on")
                            ->orderBy("latest_message_on", "DESC")
                            ->paginate(10));
            $data['data'] = [
                'total_count' => $allVehicles->total(),
                'list_items' => $allVehicles
            ];
          
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function getConversationMessages(Request $request) {
        try {

            $allMessages = new ConversationMessagesCollection(
                    ConversationMessage::select('id', 'conversation_id', 'user_id', 'content', 'created_at')
                            ->where('conversation_id', $request->conversation_id)
                            ->with('user:id,name,profile_image')
                            ->orderBy('id', 'DESC')
                            ->get());
            $data['data'] = $allMessages;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function sendMessages(Request $request) {
        try {
            \DB::beginTransaction();
            $conversation = \Modules\VehicleEnquiresManager\Entities\Conversation::find($request->conversation_id);
            if ($conversation) {
                if ($conversation->vehicle->is_approved == 0) {

                    $data['data'] = (object) [];
                    $data['status'] = FALSE;
                    $data['message'] = __('frontend.CONVERSATION_VEHICLE_UNAPPROVED');
                    $data['code'] = 200;
                    return response()->json($data);
                }
                if ($conversation->vehicle->is_sold == 1) {
                    $data['data'] = (object) [];
                    $data['status'] = FALSE;
                    $data['message'] = __('frontend.CONVERSATION_VEHICLE_SOLD');
                    $data['code'] = 200;
                    return response()->json($data);
                }
                $message = new \Modules\VehicleEnquiresManager\Entities\ConversationMessage($request->all());
                $message->user_id = \Auth::guard('api')->id();
                if ($message->save()) {
                    // DB commit
                    \DB::commit();
                    $mailData = [
                        'vehicle_title' => $message->conversation->vehicle->title,
                        'message' => $message->content
                    ];
                    $allMessages = new \App\Http\Resources\V2\ConversationMessagesResource($message);
                    $receiver = $message->conversation->participants()->where('user_id', '!=', $message->user->id)->first();
                    if($receiver){
                        if ($receiver->hasRole('Guest')) {
                            $mailData['name'] = $receiver->pivot->name;
                            $mailData['email'] = $receiver->pivot->email;
                            $mailData['phone'] = $receiver->phone;
                            \Log::info('Mail sent to guest users conversation email:'.$receiver->pivot->email);
                        } else {
                            $receiverUser = \App\User::find($receiver->pivot->user_id);
                            if($receiverUser){
                                $mailData['name'] = $receiverUser->name;
                                $mailData['email'] = $receiverUser->email;
                                $mailData['phone'] = $receiverUser->phone;
                                \Log::info('Mail sent to conversation receiver email:'.$receiverUser->email);
                            }else{
                                \Log::info('Mail not sent to conversation receiver email');
                            }
                        }
                    }else{
                        \Log::info('Message receiver not found');
                    }
                    
                    // Send mail
                    if (isset($mailData['email'])) {
                        try {
                            \Mail::to($mailData['email'])->send(new MessageMail($mailData));
                        }catch (\Exception $e) {
                            \Log::info('conversation mail not sent:' . $e->getMessage());
                        }
                    }

                    if(isset($mailData['phone'])){
                        // send sms send to user
                        try {
                            $account_id = env('TWILIO_SID');
                            $auth_token = env('TWILIO_TOKEN');
                            $from_phone_number = env('TWILIO_FROM');
                            $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                            $message = 'Dear ' . $mailData['name'] . ', a new enquiry receieved on your vehicle ' . $message->conversation->vehicle->title . '. Kindly login to app or website and check.';
                            $toNumber = '+855' .$mailData['phone'];
                            $twilio->message($toNumber, $message);
                        } catch (\Exception $e) {
                            \Log::info('conversation message not sent:' . $e->getMessage());
                        }
                    }
                    
                    $data['data'] = $allMessages;
                    $data['status'] = TRUE;
                    $data['message'] = __('frontend.MESSAGE_SENT');
                    $data['code'] = 200;
                    return response()->json($data);
                }
            }
            //throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = __('frontend.OOPS');
            $data['code'] = 200;
            return response()->json($data);
        }
    }

}
