<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\VehicleManager\Entities\Vehicle;
use Illuminate\Support\Facades\Auth;
use App\Mail\Frontend\VehicleApproveMailToUser;
use App\Mail\Frontend\VehicleDisApproveMailToUser;
use Hash;
use App\Charts\VehicleEnquiryChart;
use App\Charts\UserChart;
use App\Charts\VehicleChart;
use Modules\StaffManager\Entities\AdminUser;
use Aloha\Twilio\Twilio;

class HomeController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {

        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     * @parameter: null
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index() {

        $title = 'Dashboard';

        //Total Active Buyers
        $buyer = \App\User::where(['status' => 1])->whereHas('roles', function($query) {
                    $query->where('roles.id', '=', 2);
                })->get()->count();
        //Total Active Dealers
        $dealers = \App\User::where(['status' => 1])->whereHas('roles', function($query) {
                    $query->where('roles.id', '=', 3);
                })->get()->count();
        //Total Active Sellers
        $sellers = \App\User::where(['status' => 1])->whereHas('roles', function($query) {
                    $query->where('roles.id', '=', 4);
                })->get()->count();
		// Total count of staff
		$staffmanager = AdminUser::get()->count();
	

        $year = date('Y');
        $enq = array();

        for ($i = 1; $i <= 12; $i++) {
            $enq[$i] = \Modules\VehicleEnquiresManager\Entities\Conversation::whereMonth('created_at', '=', $i)->count();
        }
//        $enq = \Modules\VehicleEnquiresManager\Entities\Conversation::select(\DB::raw("COUNT(*) as count"))
//                ->whereYear('created_at', $year)
//                ->groupBy(\DB::raw("Month(created_at)"))
//                ->pluck('count');
        $vehicleEnquiriesChart = new VehicleEnquiryChart;
        $vehicleEnquiriesChart->labels(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']);
        $vehicleEnquiriesChart->dataset('Vehicle Enquiries (' . $year . ')', 'line', array_values($enq))->options([
            'fill' => true,
            'borderColor' => '#51C1C0',
            'backgroundColor' => '#51C1C0',
        ]);
        $users = array();

        for ($i = 1; $i <= 12; $i++) {
            $users[$i] = \App\User::whereMonth('created_at', '=', $i)->count();
        }
//        $users = \App\User::select(\DB::raw("COUNT(*) as count"))
//                ->whereYear('created_at', $year)
//                ->groupBy(\DB::raw("Month(created_at)"))
//                ->pluck('count');

        $userChart = new UserChart;
        $userChart->labels(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']);

        $userChart->dataset('Registered Users (' . $year . ')', 'line', array_values($users))->options([
            'fill' => true,
            'borderColor' => '#a5543c',
            'backgroundColor' => '#a5543c',
        ]);
        for ($i = 1; $i <= 12; $i++) {
            $vehicles[$i] = Vehicle::whereMonth('created_at', '=', $i)->count();
        }
        $vehicleChart = new VehicleChart;
//        $vehicles = Vehicle::select(\DB::raw("COUNT(*) as count"))
//                ->whereYear('created_at', $year)
//                ->groupBy(\DB::raw("Month(created_at)"))
//                ->pluck('count');
        
        $vehicleChart->labels(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']);

        $vehicleChart->dataset('Vehicle Listing (' . $year . ')', 'line', array_values($vehicles))->options([
            'fill' => true,
            'borderColor' => '#a5543c',
            'backgroundColor' => '#1CA8DD',
        ]);

        $totalVehicles = Vehicle::count();
        $pendingVehicles = Vehicle::where('is_approved', 0)->count();
        $approvedVehicles = Vehicle::where('is_approved', 1)->count();
        $totalVehicleEnquiries = \Modules\VehicleEnquiresManager\Entities\Conversation::count();
        $isFeatured = Vehicle::where('is_featured', 1)->count();
        $isOnSale = Vehicle::where('is_on_sale', 1)->count();
        $isUntilSold = Vehicle::where('is_until_sold', 1)->count();
        return view('Admin.dashboard', compact('title', 'isFeatured', 'vehicleChart', 'isOnSale', 'isUntilSold', 'vehicleEnquiriesChart', 'buyer', 'userChart', 'dealers', 'sellers', 'totalVehicles', 'pendingVehicles', 'approvedVehicles', 'totalVehicleEnquiries','staffmanager'));
    }

    /**
     * 
     * @return boolean
     */
    public function userGeoChart() {
        $users = \App\User::select(\DB::raw("COUNT(*) as count"), 'country')
                        ->whereNotNull('country')
                        ->groupBy('country')
                        ->pluck('count', 'country')->prepend('Popularity', 'Country')->toArray();


        $responce = ['status' => true, 'data' => $users];
        return $responce;
    }

    /** Show profile form   
     * @ param type $id
     * @ REturn: form of profile with autofill value
     */
    public function profile() {
        $id = Auth::user()->id;

        try {
            if ($id) {
                $title = 'Profile';
                $user = AdminUser::where('id', $id)->first();
                //dd($user);
                return view('Admin.profile', compact('title', 'user'));
            }
        } catch (Exception $ex) {
            
        }
    }

    /** Save modified update value in database
     * Request $requestId
     * @param type $id
     */
    public function profileUpdate(Request $request, $id) {



        $val = [
            'name' => 'required|max:200',
            'email' => 'required|email|unique:admin_users,email,' . $id,
            'phone' => 'required|numeric',
            'profile_image' => 'mimes:jpeg,jpg,png| max:2000',
        ];

        $customMessage = [
            'phone.required' => 'The Contact No. field is required.',
            'phone.numeric' => 'The Contact No. must be a number.',
        ];


        $validatedData = $request->validate($val, $customMessage);
        $user = AdminUser::findOrFail($id);
        try {
            $updated = $user->update($request->all());
            if ($updated) {

                // Saving headshot image.
                if ($request->profile_image) {
                    $headshotName = $user->id . '_' . time() . '.' . $request->profile_image->getClientOriginalExtension();
                    $file = $request->profile_image->move(public_path('uploads/user-images'), $headshotName);

                    if ($user->profile_image && \File::exists(public_path('uploads/user-images/' . $user->profile_image))) { // unlink or remove previous image from folder
                        unlink(public_path('uploads/user-images/' . $user->profile_image));
                    }
                    $user->profile_image = $headshotName;
                }

                $user->save();
            }
        } catch (Exception $e) {
            // Todo: Exception handleing.
        }
        return redirect()->back()->with('success', 'Your profile has been updated successfully.');
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function changeFlag(Request $request, $table, $id) {
        try {
            if ($request->status == 1) {
                $msg = 'Record has been Active Successfully!';
                $status = true;
                $type = "approved";
            } else {
                $msg = 'Record has been Inactive Successfully!';
                $status = true;
                $type = "disapproved";
            }
            $update = \DB::table($table)->where('id', $id)->limit(1)->update([$request->field => $request->status]);



            if ($request->is_mail == 'true') {

                $vehicle = \Modules\VehicleManager\Entities\Vehicle::find($id);
                // Send vehicle added mail to user
                if ($vehicle->user->email) {
                    if ($type == 'approved') {
                        \Mail::to($vehicle->user->email)->send(new VehicleApproveMailToUser($vehicle));
                    } else {
                        \Mail::to($vehicle->user->email)->send(new VehicleDisApproveMailToUser($vehicle, $request->reason));
                    }
                }
            }
            $responce = ['status' => $status, 'message' => $msg, 'data' => ''];
        } catch (\Exception $e) {
            //DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function changeVehicleApprove(Request $request, $id) {
        try {

            if ($request->status == 1) {
                $msg = 'Vehicle has been Approved Successfully!';

                $type = "approved";
            } else {
                $msg = 'Vehicle has been Disapproved Successfully!';

                $type = "disapproved";
            }
            $update = \DB::table('vehicles')->where('id', $id)->limit(1)->update(['is_approved' => $request->status]);

            $vehicle = \Modules\VehicleManager\Entities\Vehicle::find($id);
            // Send vehicle added mail to user
            if ($vehicle->user->email) {
                if ($type == 'approved') {
                    \Mail::to($vehicle->user->email)->send(new VehicleApproveMailToUser($vehicle));
                    if ($vehicle->user->phone) {
                        try {
                            $account_id = env('TWILIO_SID');
                            $auth_token = env('TWILIO_TOKEN');
                            $from_phone_number = env('TWILIO_FROM');
                            $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                            $message = 'Dear ' . $vehicle->user->name . ', your vehicle ' . $vehicle->title . ' has been approved by SPCarMarket team. Kindly login to app or website and check.';
                            $toNumber = $vehicle->user->country_code . $vehicle->user->phone;
                            $twilio->message($toNumber, $message);
                        } catch (\Exception $e) {
                            \Log::info('Vehicle approve disapprove message not sent:' . $e->getMessage());
                        }
                    }
                } else {
                    \Mail::to($vehicle->user->email)->send(new VehicleDisApproveMailToUser($vehicle,$request->reason));
                    if ($vehicle->user->phone) {
                        try {
                            $account_id = env('TWILIO_SID');
                            $auth_token = env('TWILIO_TOKEN');
                            $from_phone_number = env('TWILIO_FROM');
                            $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                            $message = 'Dear ' . $vehicle->user->name . ', your vehicle ' . $vehicle->title . ' has been disapproved by SPCarMarket team. Kindly login to app or website and check.';
                            $toNumber = $vehicle->user->country_code . $vehicle->user->phone;
                            $twilio->message($toNumber, $message);
                        } catch (\Exception $e) {
                            \Log::info('Vehicle approve disapprove message not sent:' . $e->getMessage());
                        }
                    }
                }
            }

            $responce = ['status' => true, 'message' => $msg, 'data' => ''];
        } catch (\Exception $e) {
            //DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function showChangePasswordForm() {
        $title = 'Change Password';
        return view('Admin.changepassword', compact('title'));
    }

    public function changePassword(Request $request) {
        $validatedData = $request->validate([
            'current-password' => 'required',
            'new-password_confirmation' => 'required',
            'new-password' => 'required|string|min:8|max:50|confirmed',
                ], [
            'current-password.required' => 'Current password field is required',
            'new-password_confirmation.required' => 'Confirm new password field is required',
            'new-password.required' => 'New password field is required',
            'new-password.min' => 'New password field should be atleast 8 characters long',
            'new-password.max' => 'New password field must not be longer than 50 characters',
            'new-password.confirmed' => 'Your new password and Confirm New Password do not match',
        ]);
        if (!(Hash::check($request->get('current-password'), Auth::user()->password))) {
            // The passwords matches
            return redirect()->back()->withInput()->with("error", "Your current password does not matches with the password you provided. Please try again.");
        }
        if (strcmp($request->get('current-password'), $request->get('new-password')) == 0) {
            //Current password and new password are same
            return redirect()->back()->withInput()->with("error", "New Password cannot be same as your current password. Please choose a different password.");
        }

        //Change Password
        $user = Auth::user();
        $user->password = bcrypt($request->get('new-password'));
        $user->save();
        return redirect()->back()->with("success", "Password changed successfully !");
    }

    public function getstates($id, $region_id = null) {
        $resions = \App\Region::where('country_id', $id)->pluck('name', 'id');
        $options = [];
        $options[] = '<option value="">State/Province</option>';
        if ($resions) {

            foreach ($resions as $key => $val) {

                if ($region_id == null) {
                    $options[] = '<option value="' . $key . '" >' . $val . '</option>';
                } else {
                    $seleted = '';

                    if (($key == $region_id)) {
                        $seleted = "selected";
                    }
                    $options[] = '<option value="' . $key . '" ' . $seleted . '>' . $val . '</option>';
                }
            }
        }

        return $options;
    }

    public function getCities($id) {
        $resions = \App\City::where('region_id', $id)->pluck('name', 'id');
        $options = [];
        $options[] = '<option value="">City</option>';
        if ($resions) {

            foreach ($resions as $key => $val) {

                $options[] = '<option value="' . $key . '" >' . $val . '</option>';
            }
        }

        return $options;
    }

}
