<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Http\Controllers\Controller;
use \Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\ResetsPasswords;

class ResetPasswordController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Password Reset Controller
      |--------------------------------------------------------------------------
      |
      | This controller is responsible for handling password reset requests
      | and uses a simple trait to include this behavior. You're free to
      | explore this trait and override any methods you wish to tweak.
      |
     */

use ResetsPasswords;

    /**
     * Where to redirect users after resetting their password.
     *
     * @var string
     */
    protected $redirectTo = '/admin/dashboard';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest:admin');
    }

    /**
     * Get the password reset validation rules.
     *
     * @return array
     */
    protected function rules() {
        return [
            'token' => 'required',
            'email' => 'required|email',
            'password' => 'required|confirmed|min:8|max:50',
            'password_confirmation' => 'required'
        ];
    }

    protected function validationErrorMessages() {
        return [
            'email.required' => 'The email-addrtess field is required.',
            'password.confirmed' => 'The password and confirm password are not matching.',
        ];
    }

    protected function guard() {
        return Auth::guard('admin');
    }

    /**
     * Get the broker to be used during password reset.
     *
     * @return PasswordBroker
     */
    protected function broker() {
        return Password::broker('admins');
    }

    /**
     * Display the password reset view for the given token.
     *
     * If no token is present, display the link request form.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string|null  $token
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function showResetForm(Request $request, $token = null) {
        $tokens = \DB::table('admin_password_resets')->get();
        $i = 0;
        foreach ($tokens as $tokenpass) {
            if (\Hash::check($token, $tokenpass->token)) {
                $i++;
            }
        }
        if ($i == 0) {
            return redirect()->route('admin.login')->with('error', 'The password reset link has been expired. Please try again with the new forgot password request.');
        }
        $title = 'Reset Password';
         return view('Admin.auth.passwords.reset')->with(
                        ['token' => $token, 'email' => $request->email]
        );
    }

}
