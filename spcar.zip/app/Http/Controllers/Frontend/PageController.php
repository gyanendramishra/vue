<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Modules\CmsManager\Entities\Page;
use Illuminate\Routing\Controller;

class PageController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request, $slug)
    {
        if(!empty($slug)){
            $query = Page::whereSlug($slug);
            if($query->exists()){
                $page = $query->withTranslation()->first();
                return view('frontend.page', compact('page'));
            }
        }
        abort(404);
    }
}
