<?php

namespace App\Http\Controllers\Frontend\Auth;

use Socialite;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Aloha\Twilio\Twilio;

class SocialiteController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Login Controller
      |--------------------------------------------------------------------------
      |
      | This controller handles authenticating users for the application and
      | redirecting them to your home screen. The controller uses a trait
      | to conveniently provide its functionality to your applications.
      |
     */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest:user');
    }

    /**
     * Redirect the user to the GitHub authentication page.
     *
     * @return \Illuminate\Http\Response
     */
    public function redirectToProvider($provider) {
        return Socialite::driver($provider)->redirect();
    }

    /**
     * Obtain the user information from GitHub.
     *
     * @return \Illuminate\Http\Response
     */
    public function handleProviderCallback(Request $request, $provider) {


        try {
            \DB::beginTransaction();
            $s_user = Socialite::driver($provider)->user();

            if ($s_user) {

                $user = User::where($provider . '_id', $s_user->id)->first();

                if ($user) {  // if user exists
                    // Check if user is active
                    if ($user->status == 0) {
                        return redirect()
                                        ->route('frontend.login')
                                        ->withFlashError(__('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_ACTIVATION'));
                    }
                    if ($user->is_otp_verified == 0) {
                        $user->step = 2;
                        $s_user = $user;
                        return view('frontend.auth.social_auth', compact('s_user'))
                                        ->withFlashError(__('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_VERIFICATION'));
                    }
                    // login the user
                    Auth::guard('user')->login($user);

                    return redirect()
                                    ->intended('/')
                                    ->withFlashSuccess(__('frontend.LOGIN SUCCESS'));
                } else {   // not exits user
                    if (isset($s_user->phone)) {  // check phone or email has 
                        $user = User::where('phone', $s_user->phone)->first();
                        if ($user) {  // if user exists
                            // Check if user is active
                            if ($user->status == 0) {
                                return redirect()
                                                ->route('frontend.login')
                                                ->withFlashError(__('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_ACTIVATION'));
                            }
                            if ($user->is_otp_verified == 0) {
                                $user->step = 2;
                                $s_user = $user;
                                return view('frontend.auth.social_auth', compact('s_user'))
                                                ->withFlashError(__('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_VERIFICATION'));
                            }
                            // login the user
                            Auth::guard('user')->login($user);

                            return redirect()
                                            ->intended('/')
                                            ->withFlashSuccess(__('frontend.LOGIN SUCCESS'));
                        } else {

                            $user->name = $s_user->name ?? '';
                            $user->email = $s_user->email ?? '';
                            $user->phone = $s_user->phone ?? '';
                            if ($provider == 'google') {
                                $user->google_id = $s_user->id;  // cgeck user behalf on token
                            } else {
                                $user->facebook_id = $s_user->id;
                            }
                            $user->status = 1;
                            $user->is_otp_verified = 1;
                            $user->save();

                            // Commit db
                            \DB::commit();

                            // login the user
                            Auth::guard('user')->login($user);

                            return redirect()
                                            ->intended('/')
                                            ->withFlashSuccess(__('frontend.LOGIN SUCCESS'));
                        }
                    } else {
                        $s_user->provider = $provider;

                        return view('frontend.auth.social_auth', compact('s_user'));
                    }
                }
            }
            return redirect()
                            ->route('frontend.login')
                            ->withFlashError(__('frontend.OOPS'));
        } catch (\Exception $e) {

            \DB::rollBack();
            return redirect()
                            ->route('frontend.login')
                            ->withFlashError(__('frontend.OOPS'));
        }
    }

    /**
     * For phone social; login
     * @param Request $request
     */
    public function handlePhoneLogin(Request $request) {
        $randomNumber = rand(100000, 999999);

        try {

            \DB::beginTransaction();

            $user = User::where('phone', $request->phone)->first();
            if (!$user) {
                $user = new User;
                $user->password = null;
            }


            $user->name = $request->user['name'];
            $user->phone = $request->phone;
            if(!User::whereEmail($request->user['email'])->exists()){
                $user->email = $request->user['email'];
            }
            
            $user->country_code = $request->countryCode;

            if ($request->user['provider'] == 'facebook') {
                $user->facebook_id = $request->user['id'];
            }
            if ($request->user['provider'] == 'google') {
                $user->google_id = $request->user['id'];
            }
            
            $user->status = 1;
           
            if ($user->save()) {
                // attach user role to user
//                $user->roles()->detach();
//                $user->roles()->attach($request->role_id);
                $conversations = \Modules\VehicleEnquiresManager\Entities\Conversation::whereHas('participants', function($q) use($user) {
                            $q->where('conversation_participants.phone', $user->phone);
                            $q->orWhere('conversation_participants.email', $user->email);
                        });

                $conversations->each(function($conversation) use($user) {

                    $conversation->participants()->detach(2);

                    $conversation->participants()->attach([
                        $user->id => [
                            'name' => $user->name,
                            'email' => $user->email,
                            'phone' => $user->phone
                        ]
                    ]);
                    $messages = $conversation->messages->where('user_id', '!=', $conversation->vehicle->user->id);

                    $conversation->messages->each(function($message) use($conversation, $user) {
                        if ($message->user_id !== $conversation->vehicle->user->id) {

                            $message->user_id = $user->id;
                            $message->save();
                        }
                    });
                });
                if ($user->is_otp_verified == 0) {
                    $userVerification = new \App\UserVerification();
                    $userVerification->otp = $randomNumber;
                    $userVerification->otp_type = 1;
                    $user->userVerification()->save($userVerification);
                   
                } else {
                    \Auth::guard('user')->login($user);
                    $target_url = \Redirect::intended('dashboard')->getTargetUrl();
                    \DB::commit();

                    return response()->json([
                                "status" => "login",
                                "url" => $target_url,
                                "message" => __('frontend.REGISTERED')
                                    ], 200);
                }
                // Attach verification otp with user
                // Commit db
                try {
                    $account_id = env('TWILIO_SID');
                    $auth_token = env('TWILIO_TOKEN');
                    $from_phone_number = env('TWILIO_FROM');
                    $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                    $message = 'Warm Greeting From S.P Car Market! Please use OTP ' . $randomNumber . ' for phone verification. Thanks.';
                    $toNumber = $request->countryCode . $user->phone;
                    $twilio->message($toNumber, $message);
                } catch (\Exception $e) {
                    \Log::info('Registration OTP message not sent:' . $e->getMessage());
                }
                \DB::commit();

                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.REGISTERED')
                                ], 200);
            } else {
                \DB::rollBack();
                return response()->json([
                            "status" => "error",
                            "message" => __('frontend.OOPS')
                                ], 200);
            }
        } catch (Exception $ex) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function socialVerifyOtp(Request $request) {
        try {

            if ($request->otp) {
                $userOtp = \App\User::whereHas('userVerification', function($q) use($request) {
                            $q->where('otp', $request->otp)->where('otp_type', $request->otpType);
                        })->where('phone', $request->phone)->first();

                if ($userOtp) {

                    $to = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $userOtp->userVerification->created_at);
                    $from = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', date('Y-m-d H:i:s'));
                    $diff_in_minutes = $to->diffInMinutes($from);
                    if ($diff_in_minutes > 120) {
                        return response()->json([
                                    "status" => "error",
                                    "message" => __('frontend.OTP_EXPIRED')
                                        ], 200);
                    }
                    if ($request->otpType == 1) {
                        $userOtp->is_otp_verified = 1;
                    }
                    if ($request->role_id == 3) {
                        $userOtp->company_name = $request->company_name;
                        $userOtp->address = $request->address;
                        $userOtp->city = $request->city;
                        $userOtp->state = $request->state;
                        $userOtp->country = $request->country;
                        $userOtp->latitude = $request->latitude;
                        $userOtp->longitude = $request->longitude;
                    }
                    $userOtp->save();
                    $userOtp->roles()->attach($request->role_id);
                    $userOtp->userVerification()->where('otp_type', $request->otpType)->delete();
                    if ($request->is_social == 1) {
                        $user = User::where('phone', $request->phone)->first();
                        // login the user
                        \Auth::guard('user')->login($user);
                        $target_url = \Redirect::intended('dashboard')->getTargetUrl();


                        return response()->json([
                                    "status" => "success",
                                    "url" => $target_url,
                                    "message" => __('frontend.VERIFIED')
                                        ], 200);
                    } else {
                        return response()->json([
                                    "status" => "success",
                                    "message" => __('frontend.VERIFIED')
                                        ], 200);
                    }
                } else {
                    return response()->json([
                                "status" => "error",
                                "message" => __('frontend.INCORRECT_OTP')
                                    ], 200);
                }
            } else {
                return response()->json([
                            "status" => "error",
                            "message" => __('frontend.OOPS')
                                ], 200);
            }
        } catch (Exception $ex) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

}
