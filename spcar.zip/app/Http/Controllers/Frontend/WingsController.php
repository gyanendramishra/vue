<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class WingsController extends Controller {

    /**
     * News repository.
     *
     * @var string
     */
    private $newsRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        
    }

    /**
     * Display news view.
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {

        
        try {
            $endpoint = "https://stageonline.wingmoney.com/wingonlinesdk/";
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $endpoint,
                CURLOPT_REFERER => 'https://demo.carmarketkh.com/wings',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_AUTOREFERER => true,
                CURLOPT_FAILONERROR => false,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => "sandbox=1&amount=12&username=online.carmarketusd&rest_api_key=a91824b2d9537dde1da21c59078144f824e9f6b73590f4cfd7287f6f970a4912&return_url=https://demo.carmarketkh.com/wings/callback/success&bill_till_rbtn=0&bill_till_number=5209&default_wing=1",
                CURLOPT_HTTPHEADER => array(
                    "cache-control: no-cache",
                    "content-type: application/x-www-form-urlencoded"
                ),
            ));
            $response = curl_exec($curl);

            $err = curl_error($curl);
            curl_close($curl);
            if ($err) {
                echo "cURL Error #:" . $err;
            } else {
                echo $response;
            }
        } catch (\Exception $ex) {
            dd($ex->getMessage());
        }
    }

    public function callback(Request $request){
        
        dd($request);
    }
}
