<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\UserRepository;
use App\Repositories\VehicleRepository;
use Modules\VehicleManager\Entities\Vehicle;
use App\Mail\Frontend\VehicleAddedMailToUser;
use App\Mail\Frontend\VehicleAddedMailToAdmin;
use Modules\SubscriptionManager\Entities\SubscriptionPlan;
use App\Services\Cashier\Subscription;

class ManageVehicleController extends Controller {

    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;

    /**
     * User repository.
     *
     * @var string
     */
    private $userRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        VehicleRepository $vehicleRepository,
        UserRepository $userRepository
    ) {
        $this->vehicleRepository = $vehicleRepository;
        $this->userRepository = $userRepository;
    }

    /**
     * Display a listing of user ad's.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {
        if($request->ajax()){
            try {
                $user = $request->user('user');
                $vehicles = $this->userRepository->vehicles($user);
                return response()->json([
                        "status"=> "success",
                        "data"=> $vehicles
                    ], 200);
            } catch (\Exception $e) {
                return response()->json([
                    "status"=>"error",
                    "message"=>__('frontend.OOPS')
                ], 200);
            }
        }else{
            $user = $request->user('user');
            if ($user->can('manageAd', Vehicle::class)) {
                $vehicles = $this->userRepository->vehicles($user);
                return view('frontend.user.manage-ad.ads', compact('vehicles'));
            }else{
                abort(401);
            }
        }
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function createVehicle(Request $request, $slug = null) {
        $user = $request->user('user');
        if ($user->can('create', Vehicle::class) && $user->can('manageAd', Vehicle::class)) {
            
            if(!$this->userRepository->hasActiveSubscription($user) && empty($slug)){
                return redirect()->route('frontend.subscription.plans');
            }else{
                $plan = SubscriptionPlan::where('slug', $slug)->first(['id', 'provider_plan_title']);
                if($plan){
                    
                    if($user->subscriptions->where('status', 'initiated')->isNotEmpty()){
                        $subscription = $user->subscriptions->where('status', 'initiated')->first();
                    }else{
                        $subscription = new Subscription();
                    }
                    $subscription->user_id              = $user->id;
                    $subscription->subscription_plan_id = $plan->id;
                    $subscription->provider_plan_name   = $plan->provider_plan_title;
                    $subscription->provider_status      = 'initiated';
                    $subscription->save();
                }
            }
            $fuelTypes = $this->vehicleRepository->getAllFuelType();
            $transmissions = $this->vehicleRepository->getAllTransmissions();
            $driveTypes = $this->vehicleRepository->getDriveTypes();
            return view('frontend.user.manage-ad.general_info', compact( 
                'fuelTypes', 
                'transmissions', 
                'driveTypes'
            ));
        }else{
            abort(401);
        }
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function handleVehicleGeneral(Request $request, $slug) {
        $user = $request->user('user');
        $vehicle = $this->vehicleRepository->getUserVehicleWithGeneralBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        if ($user->can('update', $vehicle)) {
            $fuelTypes = $this->vehicleRepository->getAllFuelType();
            $transmissions = $this->vehicleRepository->getAllTransmissions();
            $driveTypes = $this->vehicleRepository->getDriveTypes();
            $models = $this->vehicleRepository->getMakeModelById($vehicle->makes_id);
            $badges = $this->vehicleRepository->getModelBadgeById($vehicle->models_id);
            $series = $this->vehicleRepository->getBadgeSeriesById($vehicle->badge_id);
            return view('frontend.user.manage-ad.general_info', compact(
                'fuelTypes', 
                'transmissions', 
                'driveTypes',
                'models',
                'badges',
                'series',
                'vehicle'
            ));
        }else{
            abort(401);
        }
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function handleVehicleFeatures(Request $request, $slug) {
        $user = $request->user('user');
        $vehicle = $this->vehicleRepository->getUserVehicleWithFeaturesBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        if ($user->can('update', $vehicle)) {
            $features = $this->vehicleRepository->getAllFeatures();
            return view('frontend.user.manage-ad.features', compact('features', 'vehicle'));
        }else{
            abort(401);
        }
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function handleVehicleDetails(Request $request, $slug) {
        $user = $request->user('user');
        $vehicle = $this->vehicleRepository->getUserVehicleWithDetailsBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        if ($user->can('update', $vehicle)) {
            $colors = $this->vehicleRepository->getAllColors();
            $lifestyles = $this->vehicleRepository->getAllLifestyles();
            return view('frontend.user.manage-ad.details', compact('vehicle', 'colors', 'lifestyles'));
        }else{
            abort(401);
        }
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function handleVehiclePhotos(Request $request, $slug) {
        $user = $request->user('user');
        $vehicle = $this->vehicleRepository->getUserVehicleWithPhotosBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        if ($user->can('update', $vehicle)) {
            return view('frontend.user.manage-ad.photos', compact('vehicle'));
        }else{
            abort(401);
        }
    }

    /**
     * Show the preview page of ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function handleVehiclePreview(Request $request, $slug) {
        $user = $request->user('user');
        $vehicle = $this->vehicleRepository->getUserVehicleWithPreviewBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        if ($user->can('update', $vehicle)) {
            return view('frontend.user.manage-ad.preview', compact('vehicle'));
        }else{
            abort(401);
        }
    }

    /**
     * Show the thank you page of the ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function handleVehicleThankYou(Request $request, $slug) {
        try {
            \DB::beginTransaction();
            $user = $request->user('user');
            $vehicle = Vehicle::select('id', 'user_id', 'title', 'steps', 'status', 'slug')
                    ->where('user_id', $user->id)
                    ->where('slug', $slug)
                    ->first();
            if (!$vehicle) {
                abort(404);
            }
            if ($user->can('update', $vehicle)) {
                return view('frontend.user.manage-ad.thank_you', compact('vehicle'));
            }else{
                abort(401);
            }
        } catch (\Exception $ex) {
            \DB::rollBack();
            abort(500);
        }
    }

}
