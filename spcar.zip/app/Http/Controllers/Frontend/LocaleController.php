<?php

namespace App\Http\Controllers\Frontend;

use Session;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class LocaleController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request, $locale = 'en')
    {  
        if (!in_array($locale, ['en','kh']))
        {
            $locale = 'en';
        }
        //Cookie::queue('locale', $locale);
        Session::put('locale', $locale);
        return redirect()->back();
    }
}
