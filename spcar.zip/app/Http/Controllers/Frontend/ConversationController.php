<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\ConversationRepository;

class ConversationController extends Controller {

    /**
     * Conversation repository.
     *
     * @var string
     */
    private $conversationRepository;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        ConversationRepository $conversationRepository
    ){
        $this->conversationRepository = $conversationRepository;
    }
    
    
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request) {
        $user = $request->user('user');
        $conversations = $this->conversationRepository->getUserAllConversations($user->id);
        
        $conversations->map(function ($conversation) {
            /* Load last message */
            $conversation['messages'] = $conversation->messages->last();
            /* Load participants */
            $conversation['participants'] = $conversation->participants->map(function ($participant){
                if($participant->roles->pluck('name')->contains('Guest')){
                    $participant['name'] = $participant->pivot->name;
                    $participant['email'] = $participant->pivot->email;
                    $participant['phone'] = $participant->pivot->phone;
                }else{
                    $participant['name'] = $participant->name;
                    $participant['email'] = $participant->email;
                    $participant['phone'] = $participant->phone;
                }
                return $participant;
            });
            return $conversation;

        });
        $vehicles = $this->conversationRepository->getConversationParticipantionVehicles($user); 
        return view('frontend.user.conversations', compact('conversations', 'vehicles'));
    }

}
