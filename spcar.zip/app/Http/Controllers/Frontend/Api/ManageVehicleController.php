<?php

namespace App\Http\Controllers\Frontend\Api;

use Aloha\Twilio\Twilio;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\UserRepository;
use App\Repositories\VehicleRepository;
use App\Mail\Frontend\VehicleReportAdMail;
use Modules\VehicleManager\Entities\Vehicle;
use App\Mail\Frontend\VehicleAddedMailToUser;
use App\Mail\Frontend\VehicleAddedMailToAdmin;
use Modules\VehicleManager\Entities\VehicleImage;
use App\Mail\Frontend\VehicleInspectionMailToOwner;
use App\Mail\Frontend\VehicleInspectionMailToAdmin;
use App\Http\Requests\Frontend\VehicleReviewRequest;
use App\Http\Requests\Frontend\VehiclePhotosRequest;
use App\Http\Requests\Frontend\VehicleReportRequest;
use App\Http\Requests\Frontend\VehicleDetailsRequest;
use App\Http\Requests\Frontend\VehicleFeaturesRequest;
use App\Http\Requests\Frontend\VehicleInspectionRequest;
use App\Http\Requests\Frontend\VehicleGeneralInfoRequest;

class ManageVehicleController extends Controller {

    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;

    /**
     * User repository.
     *
     * @var string
     */
    private $userRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
    VehicleRepository $vehicleRepository, UserRepository $userRepository
    ) {
        $this->vehicleRepository = $vehicleRepository;
        $this->userRepository = $userRepository;
    }

    /**
     * Store or update resource in storage.
     *
     * @param  \App\Http\Requests\Frontend\VehicleGeneralInfoRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function storeGeneralInfoStep(VehicleGeneralInfoRequest $request) {
        try {
            \DB::beginTransaction();
            $user = $request->user('user');
            if ($request->has('vehicle_slug')) {
                $vehicle = Vehicle::where('user_id', $user->id)
                        ->whereSlug($request->vehicle_slug)
                        ->first();
            } else {
                $vehicle = new Vehicle();
                $vehicle->user_id = $user->id;
                $vehicle->role = $user->roles->isNotEmpty() ? $user->roles->first()->name : '';
                $vehicle->is_approved = 0;
            }
            $vehicle->title = $request->title;
            $vehicle->category_id = $request->type;
            $vehicle->makes_id = $request->make_id;
            $vehicle->models_id = $request->model_id;
            $vehicle->badge_id = $request->badge_id;
            $vehicle->series_id = $request->series_id;
            $vehicle->body_styles_id = $request->body_type_id;
            $vehicle->fuel_types_id = $request->fuel_type_id;
            $vehicle->drive_types_id = $request->drive_type_id;
            $vehicle->transmissions_id = $request->transmission_id;
            $vehicle->doors = $request->doors;
            $vehicle->seats = $request->seats;
            $vehicle->gears = $request->gears;
            $vehicle->cylinders_id = $request->cylinders;
            $vehicle->month_build = $request->month_built;
            $vehicle->year_build = $request->year_built;
            $vehicle->turbo = $request->turbo;
            $vehicle->engine_capacity = $request->engine_capacity;
            $vehicle->chassis_number = $request->chassis_number;
            if ($vehicle->steps < 1) {
                $vehicle->steps = 1;
            }
            // save vehicle
            if ($vehicle->save()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "slug" => $vehicle->slug,
                            "message" => __('frontend.VEHICLE_GENERAL_INFO_SAVED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Store or update resource in storage.
     *
     * @param  \App\Http\Requests\Frontend\VehicleFeaturesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function storeFeaturesStep(VehicleFeaturesRequest $request) {
        try {
            \DB::beginTransaction();
            $vehicle = Vehicle::where('user_id', \Auth::guard('user')->id())
                    ->whereSlug($request->vehicle_slug)
                    ->first();
            $vehicle->vehicleFeatures()->sync($request->features);
            if ($vehicle->steps < 2) {
                $vehicle->steps = 2;
            }
            // save vehicle
            if ($vehicle->save()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "slug" => $vehicle->slug,
                            "message" => __('frontend.VEHICLE_FEATURES_SAVED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Store or update resource in storage.
     *
     * @param  \App\Http\Requests\Frontend\VehicleDetailsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function storeDetailsStep(VehicleDetailsRequest $request) {
        try {
            \DB::beginTransaction();
            $user = $request->user('user');
            $vehicle = Vehicle::where('user_id', $user->id)
                    ->whereSlug($request->vehicle_slug)
                    ->first();
            // save detail
            $vehicle->address = $request->address;
            $vehicle->country = $request->country;
            $vehicle->state = $request->state;
            $vehicle->city = $request->city;
            $vehicle->postcode = $request->postcode;
            $vehicle->latitude = $request->latitude;
            $vehicle->longitude = $request->longitude;
            $vehicle->odometer = $request->odometer;
            $vehicle->price = $request->sale_price;
            if ($user->hasRole('Dealer')) {
                $vehicle->discount_price = $request->discounted_price;
            } else {
                $vehicle->discount_price = null;
            }
            $vehicle->is_masked_price = $request->is_masked_price;
            $vehicle->initial_masking_digits = $vehicle->is_masked_price ? $request->initial_masking_digits : null;
            $vehicle->interior_colour_id = $request->interior_color_id;
            $vehicle->exterior_colour_id = $request->exterior_color_id;
            $vehicle->lifestyle_id = $request->lifestyle_id;
            $vehicle->plate_number = $request->registration_plate_number;
            $vehicle->expiry_month = $request->registration_expiry_month;
            $vehicle->expiry_year = $request->registration_expiry_year;
            $vehicle->fuel_economy_id = $request->fuel_economy_id;
            $vehicle->phone = $request->contact_phone_number;
            $vehicle->written_off = $request->is_written_off;
            $vehicle->is_registered = $request->is_car_registered;
            // delete locales
            $vehicle->translations()->delete();
            // save locales
            $vehicle->translations()->saveMany([
                new \Modules\VehicleManager\Entities\VehicleTranslation([
                    "locale" => 'en',
                    "description" => $request->english_comment
                        ]),
                new \Modules\VehicleManager\Entities\VehicleTranslation([
                    "locale" => 'kh',
                    "description" => $request->khmer_comment
                        ])
            ]);
            if ($vehicle->steps < 3) {
                $vehicle->steps = 3;
            }
            // save vehicle
            if ($vehicle->save()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "slug" => $vehicle->slug,
                            "message" => __('frontend.VEHICLE_DETAILS_SAVED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Store or update resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function storePhotosStep(Request $request) {
        try {
            \DB::beginTransaction();
            $vehicle = Vehicle::where('user_id', \Auth::guard('user')->id())
                    ->whereSlug($request->vehicle_slug)
                    ->first();
            // save detail
            if ($vehicle->steps < 4) {
                $vehicle->steps = 4;
            }
            // save vehicle
            if ($vehicle->save()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "slug" => $vehicle->slug,
                            "message" => __('frontend.VEHICLE_PHOTOS_SAVED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Store or update resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function storePreviewStep(Request $request) {
        try {
            $user = $request->user('user');
            $vehicle = Vehicle::whereSlug($request->vehicle_slug)->first();
            if ($vehicle->steps == 4) {
                $vehicle->steps = 5;
                $vehicle->is_approved = 1;
                $vehicle->save();
                // DB commit
                \DB::commit();
                // Send mail to admin
                $settings = \Modules\SettingManager\Entities\Setting::select('id', 'slug')
                ->with('translations:id,setting_id,locale,value')
                ->where('slug', 'ADMIN_EMAIL')
                ->get()
                ->pluck('value', 'slug');
                if ($settings->has('ADMIN_EMAIL')) {
                    try {
                        \Mail::to($settings['ADMIN_EMAIL'])->send(new VehicleAddedMailToAdmin($vehicle));
                    }catch (\Exception $e) {
                        \Log::info('vehicle added mail not sent to admin:' . $e->getMessage());
                    }
                }
                // Send vehicle added mail to user
                if ($vehicle->user->email) {
                    try {
                        \Mail::to($vehicle->user->email)->send(new VehicleAddedMailToUser($vehicle));
                    }catch (\Exception $e) {
                        \Log::info('vehicle added mail not sent to user:' . $e->getMessage());
                    }
                }
            }
            if($this->userRepository->hasActiveSubscription($user)){
                // Handle auto approval
                \App\Helpers\Helper::registerAutoApproval($vehicle);
                $redirect = route('frontend.vehicle.handle.thank.you', $vehicle->slug);
            }else{
                $redirect = route('frontend.subscription.payment');
            }
            return response()->json([
                "status" => "success",
                "redirect"=> $redirect,
                "message" => __('frontend.VEHICLE_UPDATED')
                    ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Save photos in storage.
     *
     * @param  \App\Http\Requests\Frontend\VehiclePhotosRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function savePhotos(VehiclePhotosRequest $request) {
        try {
            \DB::beginTransaction();
            $user = $request->user('user');
            $vehicle = Vehicle::where('user_id', $user->id)
                    ->whereSlug($request->vehicle_slug)
                    ->first();
            if ($request->has('image_id')) {
                $image = VehicleImage::find($request->image_id);
                // delete old image
                \Storage::disk('public')->delete('vehicle/' . $image->image);
            } else {
                $image = new VehicleImage();
            }
            $file = $request->file('file');
            // create image
            $img = \Image::make($file);

            $imageHeight = $img->height();
            $imageWidth = $img->width();
            $canvasHeight = 468;
            $canvasWidth = 910;
            
            $imgHeight = ($imageHeight > $canvasHeight) ? $canvasHeight : $imageHeight;
            $imgWidth = ($imageWidth > $canvasWidth) ? $canvasWidth : $imageWidth;
            $img->resize($imgWidth, $imgHeight, function ($constraint) use($imageHeight, $imageWidth, $canvasHeight, $canvasWidth) {
                if(($imageHeight > $canvasHeight) && ($imageWidth > $canvasWidth)){
                    $constraint->aspectRatio();
                }
                $constraint->upsize();
            });
            // insert a image watermark
            if(($imageHeight >= $canvasHeight) && ($imageWidth >= $canvasWidth)){
                $img->insert(public_path('frontend/images/watermark-large.png'), 'bottom-right', 20, 20);
            }else{
                $img->insert(public_path('frontend/images/watermark-small.png'), 'bottom-right', 20, 20);
            }

            if ($user->hasRole('Dealer')) {
                /* Add the text watermark to image */
                $imageHeight = $img->height();
                $imageWidth = $img->width();
                for ($i = ($imageWidth / 4), $j = $imageHeight / 4; $i < $imageWidth && $j < $imageHeight; $i += ($imageWidth / 4), $j += ($imageHeight / 4)) {
                    $img->text($user->company_name, $i, $j, function($font) use($imageHeight, $imageWidth, $canvasHeight, $canvasWidth) {
                        $font->file(public_path('frontend/fonts/WojoSansDemi.ttf'));
                        if(($imageHeight >= $canvasHeight) && ($imageWidth >= $canvasWidth)){
                            $font->size(30);
                        }else{
                            $font->size(25);
                        }
                        $font->color(array(223, 223, 223, 0.2));
                        $font->align('center');
                        $font->valign('top');
                        $font->angle(45);
                    });
                }
            }
            // Resize canvas
            $img->resizeCanvas($canvasWidth, $canvasHeight, 'center', false, '#ffffff');

            // Store img
            $fileName = ($vehicle->vehicle_images->count() + 1) . '_' . $file->getClientOriginalName();
            $img->save(public_path('storage/vehicle/') . $fileName);
            $image->vehicle_id = $vehicle->id;
            $image->image = $fileName;
            if ($vehicle->vehicle_images->count() === 0) {
                $image->image_type = 'front';
            } else {
                $image->image_type = 'rear';
            }
            $image->sort_order = ($vehicle->vehicle_images->count() + 1);
            $image->caption = "image";
            // save vehicle image
            if ($image->save()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "image"=> [
                                "id" => $image->id,
                                "default"=> ($image->image_type === 'front') ? 1 : 0,
                                "highlight"=> ($image->image_type === 'front') ? 1 : 0,
                                "caption"=> $image->caption,
                                "name"=>$image->image,
                                "path"=> url("/")."/timthumb.php?src=".url("/")."/storage/vehicle/".$image->image."&w=434&h=261&zc=0",
                            ],
                            "message" => __('frontend.VEHICLE_PHOTOS_SAVED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Delete resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function deletePhotos(Request $request, VehicleImage $vehicleImage) {
        try {
            \DB::beginTransaction();
            // delete old image
            \Storage::disk('public')->delete('vehicle/' . $vehicleImage->image);
            // delete vehicle image
            if ($vehicleImage->delete()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.VEHICLE_PHOTOS_DELETED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Mark as cover photo in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function markAsCoverPhotos(Request $request) {
        try {
            \DB::beginTransaction();
            $vehicle = Vehicle::where('user_id', \Auth::guard('user')->id())
                    ->whereSlug($request->vehicle_slug)
                    ->first();
            $image = VehicleImage::find($request->image_id);

            if ($vehicle && $image) {
                if ($vehicle->vehicle_images->isNotEmpty()) {
                    foreach ($vehicle->vehicle_images as $vehicleImage) {
                        $vehicleImage->image_type = ($vehicleImage->id == $image->id) ? 'front' : 'rear';
                        $vehicleImage->save();
                    }

                    // DB commit
                    \DB::commit();
                }

                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.VEHICLE_PHOTO_MARKED_AS_COVER')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * 
     * @param  \Illuminate\Http\Request  $request
     * @param string  $slug
     * @return \Illuminate\Http\Response
     */
    public function deleteVehicle(Request $request, $slug) {
        try {
            \DB::beginTransaction();
            if (Vehicle::where('user_id', \Auth::guard('user')->id())
                            ->where('slug', $slug)
                            ->delete()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.VEHICLE_DELETE_SUCCESS')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $ex) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Toggle favourite cars in storage.
     *
     * @param  vehicalid  $id
     * @return \Illuminate\Http\Response
     */
    public function toogleFavourite($id) {
        try {
            \DB::beginTransaction();
            if (\Auth::guard('user')->check()) {
                $user = \Auth::guard('user')->user();
                $vehicle = Vehicle::find($id);

                if ($user && $vehicle) {
                    if ($user->id == $vehicle->user_id) {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.VEHICLE_FAVOURITE_SELF_WARNING')
                                        ], 200);
                    } else {
                        if ($user->favouriteVehicles()->where('vehicle_id', $id)->exists()) {
                            if ($vehicle->is_my_favourite) {
                                $user->favouriteVehicles()->updateExistingPivot($id, ['is_favourite' => 0]);
                                \DB::commit();
                                return response()->json([
                                            "status" => "success",
                                            "is_favourite" => false,
                                            "message" => __('frontend.VEHICLE_FAVOURITE_UNSAVED')
                                                ], 200);
                            } else {
                                $user->favouriteVehicles()->updateExistingPivot($id, ['is_favourite' => 1]);
                                \DB::commit();
                                return response()->json([
                                            "status" => "success",
                                            "is_favourite" => true,
                                            "message" => __('frontend.VEHICLE_FAVOURITE_SAVED')
                                                ], 200);
                            }
                        } else {
                            $user->favouriteVehicles()->attach($id, ['is_favourite' => 1]);
                            \DB::commit();
                            return response()->json([
                                        "status" => "success",
                                        "is_favourite" => true,
                                        "message" => __('frontend.VEHICLE_FAVOURITE_SAVED')
                                            ], 200);
                        }
                    }
                }
            } else {
                return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.VEHICLE_FAVOURITE_AUTH_WARNING')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     *  REPORT ADS FOR VEHICLE in storage.
     *
     * @param  App\Http\Requests\Frontend\VehicleReportRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function reportAd(VehicleReportRequest $request) {
        try {
            $vehicle = Vehicle::select('id', 'user_id', 'title')->find($request->vehicle_id);
            if ($vehicle) {
                if (\Auth::guard('user')->check()) {
                    $user = \Auth::guard('user')->user();
                    if ($user->id == $vehicle->user_id) {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.REPORT_AD_SELF_VEHICLE')
                                        ], 200);
                    }
                } else {
                    $user = \App\User::where('phone', $request->phone)->first(['id']);
                    if ($user) {
                        if ($user->id == $vehicle->user_id) {
                            return response()->json([
                                        "status" => "warning",
                                        "message" => __('frontend.REPORT_AD_SELF_VEHICLE')
                                            ], 200);
                        }
                    }
                }

                // Send mail to admin
                $settings = \Modules\SettingManager\Entities\Setting::select('id', 'slug')
                        ->with('translations:id,setting_id,locale,value')
                        ->where('slug', 'ADMIN_EMAIL')
                        ->get()
                        ->pluck('value', 'slug');
                if ($settings->has('ADMIN_EMAIL')) {
                    try {
                        \Mail::to($settings['ADMIN_EMAIL'])->send(new VehicleReportAdMail($vehicle, $request));
                    }catch (\Exception $e) {
                        \Log::info('vehicle report ad mail not sent to admin:' . $e->getMessage());
                    }
                }
                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.REPORT_AD_LOGGED')
                                ], 200);
            }

            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $ex) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     *  Inspect vehicle in storage.
     *
     * @param  App\Http\Requests\Frontend\VehicleInspectionRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function inspectVehicle(VehicleInspectionRequest $request) {
        try {
            \DB::beginTransaction();
            if (\Modules\VehicleInspectionsManager\Entities\VehicleInspection::where('vehicle_id', $request->vehicle_id)->where('user_id', $request->user_id)->exists()) {
                return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.ALREADY_RECEIVED_VEHICLE_INSPECTION_REQUEST')
                                ], 200);
            }
            $inspection = new \Modules\VehicleInspectionsManager\Entities\VehicleInspection($request->all());
            // save vehicle inspection
            if ($inspection->save()) {
                // DB commit
                \DB::commit();

                // Send mail to admin
                $settings = \Modules\SettingManager\Entities\Setting::select('id', 'slug')
                        ->with('translations:id,setting_id,locale,value')
                        ->where('slug', 'ADMIN_EMAIL')
                        ->get()
                        ->pluck('value', 'slug');
                /* Send mail to admin */
                if ($settings->has('ADMIN_EMAIL')) {
                    try {
                        \Mail::to($settings['ADMIN_EMAIL'])->send(new VehicleInspectionMailToAdmin($inspection));
                    }catch (\Exception $e) {
                        \Log::info('vehicle inspection mail not sent to admin:' . $e->getMessage());
                    }
                }
                /* Send mail to owner */
                if ($inspection->user->email) {
                    try {
                        \Mail::to($inspection->user->email)->send(new VehicleInspectionMailToOwner($inspection));
                    }catch (\Exception $e) {
                        \Log::info('vehicle inspection mail not sent to user:' . $e->getMessage());
                    }
                }
                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.VEHICLE_INSPECTION_REQUEST_RAISED')
                                ], 200);
            }
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     *  Save reviews of vehicle in storage.
     *
     * @param  App\Http\Requests\Frontend\VehicleReviewRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function saveReview(VehicleReviewRequest $request) {
        try {
            \DB::beginTransaction();
            $vehicle = Vehicle::select('id', 'user_id', 'title')->find($request->vehicle_id);
            if ($vehicle) {
                if (\Auth::guard('user')->check()) {
                    $user = \Auth::guard('user')->user();
                    if ($user->id == $vehicle->user_id) {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.REVIEW_SELF_VEHICLE')
                                        ], 200);
                    } else {
                        if ($vehicle->vehicleReviews->contains('user_id', $user->id)) {
                            return response()->json([
                                        "status" => "warning",
                                        "message" => __('frontend.ALREADY_REVIEWED')
                                            ], 200);
                        }
                        $review = new \Modules\VehicleReviewsManager\Entities\VehicleReview($request->all());
                        $review->user_id = $user->id;
                        // save vehicle review
                        if ($review->save()) {
                            // DB commit
                            \DB::commit();
                            // Send SMS
                            try {
                                $account_id = env('TWILIO_SID');
                                $auth_token = env('TWILIO_TOKEN');
                                $from_phone_number = env('TWILIO_FROM');
                                $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                                $message =  'Dear ' . $vehicle->user->name . ', A new review posted at your vehicle ' . $vehicle->title . '. Kindly login to app or website and check.';
                                $toNumber = $vehicle->user->country_code . $vehicle->user->phone;
                                $twilio->message($toNumber, $message);
                            } catch (\Exception $e) {
                                \Log::info('save review message not sent:' . $e->getMessage());
                            }
                            return response()->json([
                                        "status" => "success",
                                        "message" => __('frontend.VEHICLE_REVIEW_SAVED')
                                            ], 200);
                        }
                    }
                } else {
                    return response()->json([
                                "status" => "warning",
                                "message" => __('frontend.REVIEW_AUTH_WARNING')
                                    ], 200);
                }
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * MARK USER VEHICLES AS FEATURED
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function markVehiclesFeatured(Request $request) {
        try {
            \DB::beginTransaction();
            if ($user = $request->user('user')) {
                if ($count = count($request->vehicleIds)) {
                    $remainingFeaturedCount = $this->userRepository->remainingFeaturedCount($user);
                    if($remainingFeaturedCount >= $count){
                        foreach ($request->vehicleIds as $vehicleId) {
                            $vehicle = $vehicle = Vehicle::select('id', 'user_id', 'title', 'is_approved', 'is_featured')->find($vehicleId);
                            if ($vehicle) {
                                if ($user->can('update', $vehicle)) {
                                    if ($vehicle->is_approved != 1) {
                                        return response()->json([
                                                    "status" => "warning",
                                                    "message" => __('frontend.VEHICLE_NOT_APPROVED', ["vehicle" => $vehicle->title])
                                                        ], 200);
                                    }
                                    $vehicle->is_featured = 1;
                                    $vehicle->save();
                                    // DB commit
                                    \DB::commit();
                                }
                            }
                        }
                        return response()->json([
                                    "status" => "success",
                                    "message" => __('frontend.VEHICLES_MARKED_FEATURED')
                                        ], 200);
                    }else{
                        return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.VEHICLES_MARKED_FEATURED_LIMIT_EXCEDED', ["limit"=>$remainingFeaturedCount])
                                ], 200);
                    }
                } else {
                    return response()->json([
                                "status" => "warning",
                                "message" => __('frontend.SELECT_VEHICLES_TO_MARK_FEATURED')
                                    ], 200);
                }
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * MARK USER VEHICLES AS ONSALE
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function markVehiclesOnsale(Request $request) {
        try {
            \DB::beginTransaction();
            if ($user = $request->user('user')) {
                if ($count = count($request->vehicleIds)) {
                    $remainingOnSaleCount = $this->userRepository->remainingOnSaleCount($user);
                    if($remainingOnSaleCount >= $count){
                        foreach ($request->vehicleIds as $vehicleId) {
                            $vehicle = $vehicle = Vehicle::select('id', 'user_id', 'title', 'is_approved', 'is_on_sale')->find($vehicleId);
                            if ($vehicle) {
                                if ($user->can('update', $vehicle)) {
                                    if ($vehicle->is_approved != 1) {
                                        return response()->json([
                                                    "status" => "warning",
                                                    "message" => __('frontend.VEHICLE_NOT_APPROVED', ["vehicle" => $vehicle->title])
                                                        ], 200);
                                    }
                                    $vehicle->is_on_sale = 1;
                                    $vehicle->save();
                                    // DB commit
                                    \DB::commit();
                                }
                            }
                        }
                        return response()->json([
                                    "status" => "success",
                                    "message" => __('frontend.VEHICLES_MARKED_ONSALE')
                                        ], 200);
                    }else{
                        return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.VEHICLES_MARKED_ONSALE_LIMIT_EXCEDED', ["limit"=>$remainingOnSaleCount])
                                ], 200);
                    }
                } else {
                    return response()->json([
                                "status" => "warning",
                                "message" => __('frontend.SELECT_VEHICLES_TO_MARK_ON_SALE')
                                    ], 200);
                }
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * MARK USER VEHICLES AS UntilSold
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function markVehiclesUntilSold(Request $request) {
        try {
            \DB::beginTransaction();
            if ($user = $request->user('user')) {
                if ($count = count($request->vehicleIds)) {
                    $remainingUntilSoldCount = $this->userRepository->remainingUntilSoldCount($user);
                    if($remainingUntilSoldCount >= $count){
                        foreach ($request->vehicleIds as $vehicleId) {
                            $vehicle = $vehicle = Vehicle::select('id', 'user_id', 'title', 'is_approved', 'is_until_sold')->find($vehicleId);
                            if ($vehicle) {
                                if ($user->can('update', $vehicle)) {
                                    if ($vehicle->is_approved != 1) {
                                        return response()->json([
                                                    "status" => "warning",
                                                    "message" => __('frontend.VEHICLE_NOT_APPROVED', ["vehicle" => $vehicle->title])
                                                        ], 200);
                                    }
                                    $vehicle->is_until_sold = 1;
                                    $vehicle->save();
                                    // DB commit
                                    \DB::commit();
                                }
                            }
                        }
                        return response()->json([
                                    "status" => "success",
                                    "message" => __('frontend.VEHICLES_MARKED_UNTILSOLD')
                                        ], 200);
                    }else{
                        return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.VEHICLES_MARKED_UNTILSOLD_LIMIT_EXCEDED', ["limit"=>$remainingUntilSoldCount])
                                ], 200);
                    }
                } else {
                    return response()->json([
                                "status" => "warning",
                                "message" => __('frontend.SELECT_VEHICLES_TO_MARK_UNTIL_SOLD')
                                    ], 200);
                }
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * USER VEHICLE TOGGLE FEATURED
     * @param Request $request
     * @param (int) $vehicleId 
     * @return \Illuminate\Http\Response
     */
    public function toggleVehicleFeatured(Request $request, $vehicleId) {
        try {
            \DB::beginTransaction();
            if ($user = $request->user('user')) {
                $vehicle = Vehicle::select('id', 'user_id', 'title', 'is_approved', 'is_featured')->find($vehicleId);
                if ($vehicle) {
                    if ($vehicle->is_approved != 1) {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.VEHICLE_NOT_APPROVED', ["vehicle" => $vehicle->title])
                                        ], 200);
                    }
                    if (!$user->can('update', $vehicle)) {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.NOT_AUTHORISED_ACTION')
                                        ], 200);
                    }
                    $isSaved = 1;
                    if ($vehicle->is_featured == 1) {
                        $isSaved = 0;
                        $vehicle->is_featured = 0;
                    } else {
                        $remainingFeaturedCount = $this->userRepository->remainingFeaturedCount($user);
                        if($remainingFeaturedCount == 0){
                            return response()->json([
                                "status" => "warning",
                                "message" => __('frontend.VEHICLE_MARKED_FEATURED_LIMIT_EXCEDED')
                                    ], 200);
                        }else{
                            $isSaved = 1;
                            $vehicle->is_featured = 1;
                        }
                        
                    }
                    $vehicle->save();
                    // DB commit
                    \DB::commit();
                    return response()->json([
                                "status" => "success",
                                "is_featured" => $vehicle->is_featured,
                                "message" => $isSaved ? __('frontend.VEHICLE_MARKED_FEATURED', ["vehicle" => $vehicle->title]) : __('frontend.VEHICLE_REMOVED_FEATURED', ["vehicle" => $vehicle->title])
                                    ], 200);
                }
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * USER VEHICLE TOGGLE ON SALE
     * @param Request $request
     * @param (int) $vehicleId 
     * @return \Illuminate\Http\Response
     */
    public function toggleVehicleOnSale(Request $request, $vehicleId) {
        try {
            \DB::beginTransaction();
            if ($user = $request->user('user')) {
                $vehicle = Vehicle::select('id', 'user_id', 'title', 'is_approved', 'is_on_sale')->find($vehicleId);
                if ($vehicle) {
                    if ($vehicle->is_approved != 1) {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.VEHICLE_NOT_APPROVED', ["vehicle" => $vehicle->title])
                                        ], 200);
                    }
                    if (!$user->can('update', $vehicle)) {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.NOT_AUTHORISED_ACTION')
                                        ], 200);
                    }
                    $isSaved = 1;
                    if ($vehicle->is_on_sale == 1) {
                        $isSaved = 0;
                        $vehicle->is_on_sale = 0;
                    } else {
                        $remainingOnSaleCount = $this->userRepository->remainingOnSaleCount($user);
                        if($remainingOnSaleCount == 0){
                            return response()->json([
                                "status" => "warning",
                                "message" => __('frontend.VEHICLE_MARKED_ONSALE_LIMIT_EXCEDED')
                                    ], 200);
                        }else{
                            $isSaved = 1;
                            $vehicle->is_on_sale = 1;
                        }
                    }
                    $vehicle->save();
                    // DB commit
                    \DB::commit();
                    return response()->json([
                                "status" => "success",
                                "is_on_sale" => $vehicle->is_on_sale,
                                "message" => $isSaved ? __('frontend.VEHICLE_MARKED_ONSALE', ["vehicle" => $vehicle->title]) : __('frontend.VEHICLE_REMOVED_ONSALE', ["vehicle" => $vehicle->title])
                                    ], 200);
                }
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * USER VEHICLE TOGGLE UNTIL SOLD
     * @param Request $request
     * @param (int) $vehicleId 
     * @return \Illuminate\Http\Response
     */
    public function toggleVehicleUntilSold(Request $request, $vehicleId) {
        try {
            \DB::beginTransaction();
            if ($user = $request->user('user')) {
                $vehicle = Vehicle::select('id', 'user_id', 'title', 'is_approved', 'is_until_sold')->find($vehicleId);
                if ($vehicle) {
                    if ($vehicle->is_approved != 1) {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.VEHICLE_NOT_APPROVED', ["vehicle" => $vehicle->title])
                                        ], 200);
                    }
                    if (!$user->can('update', $vehicle)) {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.NOT_AUTHORISED_ACTION')
                                        ], 200);
                    }
                    $isSaved = 1;
                    if ($vehicle->is_until_sold == 1) {
                        $isSaved = 0;
                        $vehicle->is_until_sold = 0;
                    } else {
                        $remainingUntilSoldCount = $this->userRepository->remainingUntilSoldCount($user);
                        if($remainingUntilSoldCount == 0){
                            return response()->json([
                                "status" => "warning",
                                "message" => __('frontend.VEHICLE_MARKED_UNTILSOLD_LIMIT_EXCEDED')
                                    ], 200);
                        }else{
                            $isSaved = 1;
                            $vehicle->is_until_sold = 1;
                        }
                    }
                    $vehicle->save();
                    // DB commit
                    \DB::commit();
                    return response()->json([
                                "status" => "success",
                                "is_until_sold" => $vehicle->is_until_sold,
                                "message" => $isSaved ? __('frontend.VEHICLE_MARKED_UNTILSOLD', ["vehicle" => $vehicle->title]) : __('frontend.VEHICLE_REMOVED_UNTILSOLD', ["vehicle" => $vehicle->title])
                                    ], 200);
                }
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * MARK USER VEHICLE  SOLD
     * @param Request $request
     * @param (int) $vehicleId 
     * @return \Illuminate\Http\Response
     */
    public function markVehicleSold(Request $request, $vehicleId) {
        try {
            \DB::beginTransaction();
            if ($user = $request->user('user')) {
                $vehicle = Vehicle::select('id', 'user_id', 'title', 'is_approved', 'is_sold')->find($vehicleId);
                if ($vehicle) {
                    if ($vehicle->is_approved != 1) {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.VEHICLE_NOT_APPROVED', ["vehicle" => $vehicle->title])
                                        ], 200);
                    }
                    if (!$user->can('update', $vehicle)) {
                        return response()->json([
                                    "status" => "warning",
                                    "message" => __('frontend.NOT_AUTHORISED_ACTION')
                                        ], 200);
                    }
                    $isSaved = 1;
                    if ($vehicle->is_sold == 1) {
                        $isSaved = 0;
                        $vehicle->is_sold = 0;
                    } else {
                        $isSaved = 1;
                        $vehicle->is_sold = 1;
                    }
                    $vehicle->save();
                    // DB commit
                    \DB::commit();
                    return response()->json([
                                "status" => "success",
                                "is_sold" => $vehicle->is_sold,
                                "message" => $isSaved ? __('frontend.VEHICLE_MARKED_SOLD', ["vehicle" => $vehicle->title]) : __('frontend.VEHICLE_REMOVED_SOLD', ["vehicle" => $vehicle->title])
                                    ], 200);
                }
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

}
