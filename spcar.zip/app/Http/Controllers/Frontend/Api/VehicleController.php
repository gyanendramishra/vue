<?php

namespace App\Http\Controllers\Frontend\Api;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\VehicleRepository;

class VehicleController extends Controller {

    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(VehicleRepository $vehicleRepository) {
        $this->vehicleRepository = $vehicleRepository;
    }

    /**
     * Get vehicle types.
     *
     * @return \Illuminate\Http\Response
     */
    public function getTypes() {
        try {
            $types = $this->vehicleRepository->getAllType();
            return response()->json([
                        "status" => "success",
                        "data" => $types
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get makes.
     *
     * @return \Illuminate\Http\Response
     */
    public function getMakes() {
        try {
            $makes = $this->vehicleRepository->getAllMake();
            return response()->json([
                        "status" => "success",
                        "data" => $makes->sortBy("name")->values()
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get body types.
     *
     * @return \Illuminate\Http\Response
     */
    public function getBodyTypes() {
        try {
            $bodyTypes = $this->vehicleRepository->getAllBodyType();
            return response()->json([
                        "status" => "success",
                        "data" => $bodyTypes->sortBy("name")->values()
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get fuel types.
     *
     * @return \Illuminate\Http\Response
     */
    public function getFuelTypes() {
        try {
            $fuelTypes = $this->vehicleRepository->getAllFuelType();
            return response()->json([
                        "status" => "success",
                        "data" => $fuelTypes->sortBy("name")->values()
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get models by make slug.
     *
     * @param  (int) $slug
     * @return \Illuminate\Http\Response
     */
    public function getModelsByMakeSlug($slug) {
        try {
            $models = $this->vehicleRepository->getMakeModelBySlug($slug);
            return response()->json([
                        "status" => "success",
                        "data" => $models->sortBy("name")->values()
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get models by make id.
     *
     * @param  (int) $id
     * @return \Illuminate\Http\Response
     */
    public function getModelsByMakeId($id) {
        try {
            $models = $this->vehicleRepository->getMakeModelById($id);
            return response()->json([
                        "status" => "success",
                        "data" => $models->sortBy("name")->values()
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get badges by model slug.
     *
     * @param  (int) $slug
     * @return \Illuminate\Http\Response
     */
    public function getBadgesByModelSlug($slug) {
        try {
            $badges = $this->vehicleRepository->getModelBadgeBySlug($slug);
            return response()->json([
                        "status" => "success",
                        "data" => $badges->sortBy("name")->values()
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get badges by id.
     *
     * @param  (int) $id
     * @return \Illuminate\Http\Response
     */
    public function getBadgesByModelId($id) {
        try {
            $badges = $this->vehicleRepository->getModelBadgeById($id);
            return response()->json([
                        "status" => "success",
                        "data" => $badges->sortBy("name")->values()
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get series by badge.
     *
     * @param  (int) $badgeId
     * @return \Illuminate\Http\Response
     */
    public function getSeriesByBadgeId($badgeId) {
        try {
            $series = $this->vehicleRepository->getBadgeSeriesById($badgeId);
            return response()->json([
                        "status" => "success",
                        "data" => $series->sortBy("name")->values()
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get cities by state.
     *
     * @param  (int) $stateId
     * @return \Illuminate\Http\Response
     */
    public function getCitiesByStateId($stateId) {
        try {
            $cities = $this->vehicleRepository->getStateCitiesById($stateId);
            return response()->json([
                        "status" => "success",
                        "data" => $cities
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __($e->getMessage())
                            ], 200);
        }
    }

}
