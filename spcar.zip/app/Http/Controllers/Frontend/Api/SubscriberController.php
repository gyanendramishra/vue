<?php

namespace App\Http\Controllers\Frontend\Api;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\SubscriptionRepository;
use App\Services\Cashier\Exceptions\IncompletePayment;

class SubscriberController extends Controller {

    /**
     * Subscription repository.
     *
     * @var string
     */
    private $subscriptionRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        SubscriptionRepository $subscriptionRepository
    ) {
        $this->subscriptionRepository = $subscriptionRepository;
    }

    /**
     * Charge user for plan using stripe.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function chargeThrowStripe(Request  $request){
        try {
            $user = $request->user('user');
            $plan = $this->subscriptionRepository->getSubscriptionPlanById($request->plan_id);
            if(!$user->subscribed($plan->provider_plan_title) ){
                try{
                    $payment = $user->stripeCharge(100, $request->payment_method_id, $plan);
                    return response()->json([
                        "status" => "success",
                        "message" => __('frontend.SUBSCRIBED')
                    ], 200); 
                }catch(IncompletePayment $exception){
                    return response()->json([
                        "status" => "incomplete",
                        "url" => route('frontend.subscription.show.payment', [$exception->payment->id, 'redirect' => route('frontend.subscription.thank.you')]),
                        "message" => __('Subscribe to plan.')
                    ], 200);
                }
            }else{
                return response()->json([
                    "status" => "warning",
                    "message" => __('frontend.ALREADY_SUBSCRIBED')
                ], 200);
            }
        }catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Subscribe user for plan using stripe.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function subscribeThrowStripe(Request  $request){
        try {
            $user = $request->user('user');
            $plan = $this->subscriptionRepository->getSubscriptionPlanById($request->plan_id);
            if(!$user->subscribed($plan->provider_plan_title) ){
                try{
                    $user->newStripeSubscription($plan)->create($request->payment_method_id);
                    return response()->json([
                        "status" => "success",
                        "message" => __('frontend.SUBSCRIBED')
                    ], 200);
                }catch(IncompletePayment $exception){
                    return response()->json([
                        "status" => "incomplete",
                        "url" => route('frontend.subscription.show.payment', [$exception->payment->id, 'redirect' => route('frontend.subscription.thank.you')]),
                        "message" => __('Subscribe to plan.')
                    ], 200);
                }
            }else{
                return response()->json([
                    "status" => "warning",
                    "message" => __('frontend.ALREADY_SUBSCRIBED')
                ], 200);
            }
        }catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Upgrade user subscription from stripe.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  (int)  $subscriptionId
     * @return \Illuminate\Http\Response
     */
    public function upgradeSubscriptionFromStripe(Request  $request, $subscriptionId){
        try {
            $user = $request->user('user');
            $subscription = $user->subscriptions->where('id', $subscriptionId)->first();
            if($user->subscribed($subscription->provider_plan_name) ){
                $user->subscription($subscription->provider_plan_name)->cancel();
                return response()->json([
                    "status" => "success",
                    "message" => __('frontend.SUBSCRIPTION_CANCELLED')
                ], 200);
            }else{
                return response()->json([
                    "status" => "warning",
                    "message" => __('frontend.NOT_SUBSCRIBED_IN_SUBSCRIPTION_PLAN')
                        ], 200);
            }
        }catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Downgrade user subscription from stripe.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  (int)  $subscriptionId
     * @return \Illuminate\Http\Response
     */
    public function downgradeSubscriptionFromStripe(Request  $request, $subscriptionId){
        try {
            $user = $request->user('user');
            $subscription = $user->subscriptions->where('id', $subscriptionId)->first();
            if($user->subscribed($subscription->provider_plan_name) ){
                $user->subscription($subscription->provider_plan_name)->cancel();
                return response()->json([
                    "status" => "success",
                    "message" => __('frontend.SUBSCRIPTION_CANCELLED')
                ], 200);
            }else{
                return response()->json([
                    "status" => "warning",
                    "message" => __('frontend.NOT_SUBSCRIBED_IN_SUBSCRIPTION_PLAN')
                        ], 200);
            }
        }catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Cancel user subscription from stripe.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  (int)  $subscriptionId
     * @return \Illuminate\Http\Response
     */
    public function cancelSubscriptionFromStripe(Request  $request, $subscriptionId){
        try {
            $user = $request->user('user');
            $subscription = $user->subscriptions->where('id', $subscriptionId)->first();
            if($user->subscribed($subscription->provider_plan_name) ){
                $user->subscription($subscription->provider_plan_name)->cancel();
                return response()->json([
                    "status" => "success",
                    "message" => __('frontend.SUBSCRIPTION_CANCELLED')
                ], 200);
            }else{
                return response()->json([
                    "status" => "warning",
                    "message" => __('frontend.NOT_SUBSCRIBED_IN_SUBSCRIPTION_PLAN')
                        ], 200);
            }
        }catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * resume user subscription from stripe.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  (int)  $subscriptionId
     * @return \Illuminate\Http\Response
     */
    public function resumeSubscriptionFromStripe(Request  $request, $subscriptionId){
        try {
            $user = $request->user('user');
            $subscription = $user->subscriptions->where('id', $subscriptionId)->first();
            if($user->subscribed($subscription->provider_plan_name) ){
                if ($user->subscription($subscription->provider_plan_name)->onGracePeriod()) {
                    $user->subscription($subscription->provider_plan_name)->resume();
                    return response()->json([
                        "status" => "success",
                        "message" => __('frontend.SUBSCRIPTION_RESUMED')
                            ], 200);
                }else{
                    return response()->json([
                        "status" => "warning",
                        "message" => __('frontend.SUBSCRIPTION_NOT_IN_GRACE_PERIOD')
                            ], 200);
                }
            }else{
                return response()->json([
                    "status" => "warning",
                    "message" => __('frontend.NOT_SUBSCRIBED_IN_SUBSCRIPTION_PLAN')
                        ], 200);
            }
        }catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Creates an intent for payment so we can capture the payment
     * method for the user. 
     * 
     * @param Request $request The request data from the user.
     */
    public function getStripeSetupIntent(Request $request){
        try {
            $user = $request->user('user');
            if($user){
                $setupIntent =  $user->createStripeSetupIntent();
                return response()->json([
                    "status" => "success",
                    "setup_intent" => $setupIntent
                    ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        }catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

}
