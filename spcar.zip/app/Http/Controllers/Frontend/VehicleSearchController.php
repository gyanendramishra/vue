<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\VehicleRepository;
use App\Repositories\AdRepository;

class VehicleSearchController extends Controller
{
    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;
    
    private $adRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(VehicleRepository $vehicleRepository ,  AdRepository $adRepository)
    {
        $this->vehicleRepository = $vehicleRepository;
         $this->adRepository = $adRepository;
    }

    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(
        Request $request, 
        $first = null, 
        $second = null,
        $third = null, 
        $fourth = null,
        $fifth = null,
        $sixth = null,
        $seventh = null,
        $eighth = null,
        $ninth = null,
        $tenth = null
    ){
        if($request->ajax()){
            try {
                $searchResults = $this->vehicleRepository->search($request);
                $vehicles = $searchResults['results'];
                $filtes = $searchResults['filters'];
                return response()->json([
                        "status"=> "success",
                        "data"=> $vehicles
                    ], 200);
            } catch (\Exception $e) {
                return response()->json([
                    "status"=>"error",
                    "message"=>__('frontend.OOPS')
                ], 200);
            }
        }else{
            try {
                
                $types = $this->vehicleRepository->getAllType(); 
                $fuelTypes = $this->vehicleRepository->getAllFuelType(); 
                $transmissions = $this->vehicleRepository->getAllTransmissions();
                $colors = $this->vehicleRepository->getAllColors();
                $driveTypes = $this->vehicleRepository->getDriveTypes();
                $features = $this->vehicleRepository->getAllFeatures();
                $lifestyles = $this->vehicleRepository->getAllLifestyles();
                $searchResults = $this->vehicleRepository->search($request);
                $vehicles = $searchResults['results'];
                $filtes = $searchResults['filters'];
                $ads = $this->adRepository->getListingPageAds();
                return view('frontend.vehicle.index', compact(
                    'vehicles', 
                    'filtes', 
                    'types', 
                    'fuelTypes',
                    'transmissions',
                    'colors',
                    'driveTypes',
                    'features',
                    'lifestyles',
                    'ads'
                ));
            } catch (\Exception $e) {
                dd($e);
                abort(500);
            }
        }
    }
}
