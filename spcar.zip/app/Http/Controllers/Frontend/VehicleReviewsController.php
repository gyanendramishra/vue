<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\ReviewRepository;

class VehicleReviewsController extends Controller
{
    /**
     * Review repository.
     *
     * @var string
     */
    private $reviewRepository;


    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        ReviewRepository $reviewRepository
    ){
        $this->reviewRepository = $reviewRepository;
    }


    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function userReviews(Request $request){
        if($request->ajax()){
            try {
                $vehicles = $this->reviewRepository->getAllVehiclesReviewsOfUser();
                return response()->json([
                        "status"=> "success",
                        "data"=> $vehicles
                    ], 200);
            } catch (\Exception $e) {
                return response()->json([
                    "status"=>"error",
                    "message"=>__('frontend.OOPS')
                ], 200);
            }
        }else{
            $vehicles = $this->reviewRepository->getAllVehiclesReviewsOfUser();
            return view('frontend.reviews.user', compact('vehicles'));
        }
    }

    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function adminReviews(Request $request){
        if($request->ajax()){
            try {
                $reviews = $this->reviewRepository->getAllVehiclesReviewsOfAdmin();
                return response()->json([
                        "status"=> "success",
                        "data"=> $reviews
                    ], 200);
            } catch (\Exception $e) {
                return response()->json([
                    "status"=>"error",
                    "message"=>__('frontend.OOPS')
                ], 200);
            }
        }else{
            $reviews = $this->reviewRepository->getAllVehiclesReviewsOfAdmin();
            return view('frontend.reviews.admin', compact('reviews'));
        }
    }

    /**
     * Display reviews detail view.
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function vehicleReviewInfo(Request $request, $slug)
    {
        $review = $this->reviewRepository->getVehicleReviewOfAdminBySlug($slug);
        if($review){
            return view('frontend.reviews.info', compact('review'));
        }
        abort(404);
    }

}
