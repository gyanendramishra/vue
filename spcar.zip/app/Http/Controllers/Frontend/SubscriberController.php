<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Services\Cashier\Cashier;
use App\Services\Cashier\Payment;
use Illuminate\Routing\Controller;
use App\Repositories\UserRepository;
use App\Repositories\SubscriptionRepository;
use Modules\VehicleManager\Entities\Vehicle;
use Stripe\PaymentIntent as StripePaymentIntent;

class SubscriberController extends Controller
{

    /**
     * User repository.
     *
     * @var string
     */
    private $userRepository;
    /**
     * Subscription repository.
     *
     * @var string
     */
    private $subscriptionRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        SubscriptionRepository $subscriptionRepository,
        UserRepository $userRepository
    ){
        $this->subscriptionRepository = $subscriptionRepository;
        $this->userRepository = $userRepository;
    }
    
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function payment(Request $request, $slug = null){
        try{
            $user = $request->user('user');
            $selectedPlan = "";
            $subscriptions = $this->subscriptionRepository->getSubscriptionPlansByUser($user);
            $selectedSubscription = $user->subscriptions()
                                ->select('subscription_plan_id')
                                ->where('provider_status', 'initiated')
                                ->first();
            if($selectedSubscription){
                $selectedPlan = $this->subscriptionRepository->getSubscriptionPlanById($selectedSubscription->subscription_plan_id);
            }
            return view('frontend.subscription.payment', compact('subscriptions', 'selectedPlan'));
        }catch(\Exception $e){
            abort(500);
        }
    }
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function show($id){
        return view('frontend.subscription.cashier.payment', [
            'stripeKey' => config('cashier.key'),
            'payment' => new Payment(
                StripePaymentIntent::retrieve($id, Cashier::stripeOptions())
            ),
            'redirect' => request('redirect'),
        ]);
    }

    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function thankYou(){
        return view('frontend.subscription.thank_you');
    }
}
