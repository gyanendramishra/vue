<?php

namespace App\Http\Controllers\Frontend;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Http\Requests\Frontend\AvatarRequest;
use App\Http\Requests\Frontend\ProfileRequest;

class ProfileController extends Controller
{
    /**
     * Display profile view.
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $user = \Auth::guard('user')->user();
        $profile =  $user->fresh();
        return view('frontend.user.profile', compact('profile'));
    }

    /**
     * Handle profile update.
     *
     * @param  App\Http\Request\Frontend\ProfileRequest  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response
     */
    public function updateProfile(ProfileRequest $request)
    {
        try{
            \DB::beginTransaction();
            $user = \Auth::guard('user')->user();
            
            if($user->update($request->except('phone'))){
                \DB::commit();
                return response()->json([
                    "status"=>"success",
                    "message"=>__('frontend.PROFILE_UPDATE_SUCCESS')
                ], 200);
            }
            return response()->json([
                    "status"=>"error",
                    "message"=>__('frontend.PROFILE_UPDATE_FAILED')
                ], 200);
        }catch(\Exception $e){
            \DB::rollBack();
            return response()->json([
                "status"=>"error",
                "message"=>__('frontend.OOPS')
            ], 200);
        }
    }

    /**
     * Handle avatar update.
     *
     * @param  App\Http\Request\AvatarRequest  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response
     */
    public function updateAvatar(AvatarRequest $request)
    {
        try{
            \DB::beginTransaction();
            $user = \Auth::guard('user')->user();
            if($request->hasFile('avatar')){
                // Remove old avatar
                if(\Storage::disk('public')->delete($user->avatar)){
                    $user->profile_image = "";
                    $user->save();
                }
                $avatar = $request->file('avatar')->store('avatars', 'public');
                $user->profile_image = $avatar;
                $user->save();
                \DB::commit();
                return response()->json([
                    "avatar"=> $user->profile_image,
                    "status"=>"success",
                    "message"=>__('frontend.PROFILE_PICTURE_UPDATE_SUCCESS')
                ], 200);
            }
            return response()->json([
                    "status"=>"error",
                    "message"=>__('frontend.PROFILE_PICTURE_UPDATE_FAILED')
                ], 200);

        }catch(\Exception $e){
            \DB::rollBack();
            return response()->json([
                "status"=>"error",
                "message"=>__('frontend.OOPS')
            ], 200);
        }
    }
}
