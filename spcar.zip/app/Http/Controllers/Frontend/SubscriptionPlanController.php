<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\UserRepository;
use App\Repositories\SubscriptionRepository;

class SubscriptionPlanController extends Controller
{

    /**
     * User repository.
     *
     * @var string
     */
    private $userRepository;
    /**
     * Subscription repository.
     *
     * @var string
     */
    private $subscriptionRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        SubscriptionRepository $subscriptionRepository,
        UserRepository $userRepository
    ){
        $this->subscriptionRepository = $subscriptionRepository;
        $this->userRepository = $userRepository;
    }
    
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request){
        try{
            $user = $request->user('user');
            $plans = $this->subscriptionRepository->getSubscriptionPlansByUser($user); 
            return view('frontend.subscription.plans', compact('plans'));
        }catch(\Exception $e){
            abort(500);
        }
    }

    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function upgradeNDowngrade(Request $request){
        try{
            $user = $request->user('user');
            $plans = $this->subscriptionRepository->getSubscriptionPlansByUser($user);
            $activePlan = $this->userRepository->subscription($request->user('user'));
            $plans = $plans->where('id', '!=', $activePlan->subscription_plan_id);
            return view('frontend.subscription.upgrade_downgrade_plans', compact('plans', 'activePlan'));
        }catch(\Exception $e){
            abort(500);
        }
    }
}
