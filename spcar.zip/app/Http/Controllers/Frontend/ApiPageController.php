<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Modules\CmsManager\Entities\Page;
use Illuminate\Routing\Controller;

class ApiPageController extends Controller
{
    
    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request) {
        //$authInformation = $request->header();
        if ($request->segment(2)) {
            \App::setLocale($request->segment(2));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale',$request->segment(2));
    }

    
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request,$lang, $slug)
    {
        if(!empty($slug)){
            $query = Page::whereSlug($slug);
            if($query->exists()){
                $page = $query->withTranslation()->first();
                return view('frontend.api_page', compact('page'));
            }
        }
        abort(404);
    }
}
