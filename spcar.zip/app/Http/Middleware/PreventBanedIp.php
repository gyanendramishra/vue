<?php

namespace App\Http\Middleware;

use Closure;

class PreventBanedIp
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $banedIps = \Modules\BanList\Entities\BanList::all()->pluck('ban_item');
        if($banedIps->isNotEmpty()){
            if (in_array($request->ip(), $banedIps->toArray())) {
                if($request->ajax()){
                    return response()->json([
                        "status"=> "warning",
                        "message"=> __('frontend.BANNED')
                    ], 200);
                }else{
                    return response(__('frontend.BANNED'));
                }
            }
        }   
        return $next($request);
    }
}
