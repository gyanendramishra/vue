<?php

namespace App\Http\Views\Composers;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Modules\SettingManager\Entities\Setting;

class SettingsComposer
{

    /**
     * Create a new user composer.
     *
     * @return void
     */
    public function __construct(Request $request){}
    /**
     * Bind data to the view.
     *
     * @param  View  $view
     * @return void
     */
    public function compose(View $view)
    {
        $settings = Setting::select('id', 'slug')
        ->with('translations:id,setting_id,locale,value')
        ->get()
        ->pluck('value', 'slug');
        if($settings){
            if(isset($settings['site_name'])){
                \Config::set('app.name', $settings['site_name']);
            }
        }
        //dd($settings);
        $view->with('appSettings', $settings);
    }
}