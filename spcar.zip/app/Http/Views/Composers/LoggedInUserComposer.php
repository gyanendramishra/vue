<?php

namespace App\Http\Views\Composers;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoggedInUserComposer
{

    /**
     * The user.
     *
     * @var User
     */
    protected $user;

    /**
     * Create a new user composer.
     *
     * @return void
     */
    public function __construct(Request $request)
    {
        $this->user = Auth::guard('user')->user();
    }
    /**
     * Bind data to the view.
     *
     * @param  View  $view
     * @return void
     */
    public function compose(View $view)
    {
        $view->with('loggedinUser', $this->user);
    }
}