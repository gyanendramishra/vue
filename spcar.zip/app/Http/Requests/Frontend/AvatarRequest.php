<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class AvatarRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('user')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'avatar'                =>'bail|required|image'
        ];
    }

    /**
     * Configure the validator instance.
     *
     * @param \Illuminate\Validation\Validator $validator
     *
     * @return void
     */
    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            if($this->hasFile('avatar')){
                if ($this->file('avatar')->getClientSize() > '5242880') {
                    if(app()->getLocale() === 'kh'){
                        $validator->errors()->add('avatar', 'រូបភាពប្រូហ្វាល់មិនអាចមានទំហំធំជាង5 MB។ សូមជ្រើសយកឯកសារផ្សេងទៀត');
                    }else{
                        $validator->errors()->add('avatar', 'Profile picture shouldn\'t be greater than 5 MB. Please select another file');
                    }
                }
            }
        });
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        if(app()->getLocale() === 'kh'){
            return [
                'avatar.required'=>'តំរូវអោយដាក់រូបភាពប្រូហ្វាល់',
                'avatar.image'=>'ប្រូហ្វាល់ត្រូវជារូបភាព'
            ];
        }else{
            return [
                'avatar.required'=>'The profile picture field is required.',
                'avatar.image'=>'The profile picture must be an image.'
            ];
        }
    }

}
