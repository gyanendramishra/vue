<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class VehicleInquiryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'vehicle_id'            =>'bail|required',
            'name'                  =>'bail|required|max:50',
            'email'                 =>'bail|nullable|email|max:100',
            'phone'                 =>'bail|required|numeric|digits_between:9,15',
            'message'               =>'bail|required|max:500'
        ];
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        if(app()->getLocale() === 'kh'){
            return [
                'vehicle_id.required'=> 'តំរូវអោយបំពេញព័ត៌មានរថយន្ត',
                'name.required'=> 'តំរូវអោយបំពេញឈ្មោះពេញ',
                'name.max'=> 'បំពេញឈ្មោះពេញមិនអាចលើសពី50តួអក្សរ',
                'email.email'=>  'ត្រូវបំពេញអ៊ីម៉ែលអោយបានត្រឹមត្រូវ',
                'email.max'=> 'បំពេញអ៊ីម៉ែលមិនអាចលើសពី100តួអក្សរ',
                'phone.required'=> 'តំរូវអោយបំពេញលេខទូរស័ព្ទ',
                'phone.numeric'=> 'បំពេញលេខទូរស័ព្ទអាចជាតួលេខប៉ុណ្ណោះ',
                'phone.digits_between'=> 'បំពេញលេខទូរស័ព្ទត្រូវនៅចន្លោះពី9ទៅ15តួលេខ',
                'message.required'=> 'តំរូវអោយបំពេញសារ',
                'message.max'=> 'បំពេញសារមិនអាចលើសពី500តួអក្សរ',
            ];
        }else{
            return [
                'vehicle_id.required'=> 'The vehicle field is required',
                'name.required'=> 'The full name field is required',
                'name.max'=> 'The full name field may not be greater than 50 characters',
                'email.email'=>  'The email field must be a valid email',
                'email.max'=> 'The email field may not be greater than 100 characters',
                'phone.required'=> 'The phone field is required',
                'phone.numeric'=> 'The phone field may only contain numeric characters',
                'phone.digits_between'=> 'The phone field must be at between 9 to 15 characters',
                'message.required'=> 'The message field is required',
                'message.max'=> 'The message field may not be greater than 500 characters',
            ];
        }
    }
}
