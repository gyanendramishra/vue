<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class NewsLetterRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
         return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'email' =>'bail|required|email|unique:newsletters,email',
        ];
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        if(app()->getLocale() === 'kh'){
            return [
                'email.required'=> 'តំរូវអោយបំពេញអ៊ីម៉ែល',
                'email.email'=>  'ត្រូវបំពេញអ៊ីម៉ែលអោយបានត្រឹមត្រូវ',
                'email.max'=> 'បំពេញអ៊ីម៉ែលមិនអាចលើសពី100តួអក្សរ',
                'email.unique'=>'អ្នកនឹងទទួលបានព្រឹតិ្តការណ៍ព័ត៌មានរបស់ពួកយើង'
            ];
        }else{
            return [
                'email.required'=> 'The email field is required',
                'email.email'=>  'The email field must be a valid email',
                'email.max'=> 'The email field may not be greater than 100 characters',
                'email.unique'=>'You have already subscribed to our news letter'
            ];
        }
    }

}
