<?php namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class ProfileRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('user')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $user = \Auth::guard('user')->user();
        $rules = [];
        $rules['name'] = 'bail|required|max:50';
        $rules['email'] = 'bail|nullable|email|max:100|unique:users,email,'.$user->id;
        $rules['phone'] = 'bail|required|numeric|digits_between:9,15|unique:users,phone,'.$user->id;
        if($user->hasRole('Dealer')){
            $rules['company_name'] = 'bail|required|max:100';
            $rules['address'] = 'bail|required|max:150';
        }
        return $rules;
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        if(app()->getLocale() === 'kh'){
            return [
                'name.required'=>'តំរូវអោយបំពេញឈ្មោះ',
                'name.max'=>'បំពេញឈ្មោះមិនអាចលើសពី50តួអក្សរ',
                'email.email'=>'ត្រូវបំពេញអ៊ីម៉ែលអោយបានត្រឹមត្រូវ',
                'email.max'=>'បំពេញអ៊ីម៉ែលមិនអាចលើសពី100តួអក្សរ',
                'email.unique'=> 'អ៊ីម៉ែលត្រូវបានប្រើប្រាស់រួចហើយ',
                'phone.required'=>'តំរូវអោយបំពេញលេខទូរស័ព្ទ',
                'phone.numeric'=>'បំពេញលេខទូរស័ព្ទអាចជាតួលេខប៉ុណ្ណោះ',
                'phone.digits_between'=>'បំពេញលេខទូរស័ព្ទត្រូវនៅចន្លោះពី9ទៅ15តួលេខ',
                'phone.unique'=> 'លេខទូរស័ព្ទត្រូវបានប្រើប្រាស់រួចហើយ',
                'company_name.required'=>'តំរូវអោយបំពេញឈ្មោះក្រុមហ៊ុន',
                'company_name.max'=>'ឈ្មោះក្រុមហ៊ុនមិនអាចលើសពី100តួអក្សរ',
                'address.required'=>'តំរូវអោយបំពេញអាសយដ្ឋាន',
                'address.max'=>'បំពេញអាសយដ្ឋានមិនអាចលើសពី100តួអក្សរ',
            ];
        }else{
            return [
                'name.required'=>'The name field is required',
                'name.max'=>'The name field may not be greater than 50 characters',
                'email.email'=>'The email field must be a valid email',
                'email.max'=>'The email field may not be greater than 100 characters',
                'email.unique'=> 'The email has already been taken',
                'phone.required'=>'The phone field is required',
                'phone.numeric'=>'The phone field may only contain numeric characters',
                'phone.digits_between'=>'The phone field must be between 9 to 15 characters',
                'phone.unique'=> 'The phone has already been taken',
                'company_name.required'=>'The company name field is required',
                'company_name.max'=>'The company name may not be greater than 100 characters',
                'address.required'=>'The address field is required',
                'address.max'=>'The address field may not be greater than 100 characters',
            ];
        }
    }

}
