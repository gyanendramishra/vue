<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class VehicleReviewRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'vehicle_id'            =>'bail|required',
            'title'                 =>'bail|required|max:100',
            'rating'                =>'bail|required',
            'review'                =>'bail|required|max:500'
        ];
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        if(app()->getLocale() === 'kh'){
            return [
                'vehicle_id.required'=> 'តំរូវអោយបំពេញព័ត៌មានរថយន្ត',
                'title.required'=> 'តំរូវអោយបំពេញចំណងជើងមតិ',
                'title.max'=> 'បំពេញចំណងជើងមតិមិនអាចលើស100តួអក្សរ',
                'rating.required'=> 'តំរូវអោយដាក់ចំណាត់ថ្នាក់មតិ',
                'review.required'=> 'តំរូវអោយបំពេញការពិពណ៌នាមតិ',
                'review.max'=> 'បំពេញការពិពណ៌នាមតិមិនអាចលើសពី500តួអក្សរ',
            ];
        }else{
            return [
                'vehicle_id.required'=> 'The vehicle field is required',
                'title.required'=> 'The review title field is required',
                'title.max'=> 'The review title field may not be greater than 100 characters',
                'rating.required'=> 'The review rating field is required',
                'review.required'=> 'The review description field is required',
                'review.max'=> 'The review description field may not be greater than 500 characters',
            ];
        }
    }
}
