<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Hash;

class PasswordRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('user')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'old_password'     => 'bail|required|min:8|max:12',
            'new_password'     => 'bail|required|confirmed|min:8|max:12',
        ];
    }

    /**
     * Configure the validator instance.
     *
     * @param \Illuminate\Validation\Validator $validator
     *
     * @return void
     */
    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            if(strcmp($this->old_password, $this->new_password) == 0){
                if(app()->getLocale() === 'kh'){
                    $validator->errors()->add('new_password', 'លេខសំងាត់ថ្មីមិនអាចដូចលេខសំងាត់ចាស់');
                }else{
                    $validator->errors()->add('new_password', 'New Password cannot be same as your old password');
                }
            }
            $user = \Auth::guard('user')->user();
            if(!Hash::check($this->old_password, $user->password)){
                if(app()->getLocale() === 'kh'){
                    $validator->errors()->add('old_password', 'លេខសំងាត់ចាស់គឺមិនត្រឹមត្រូវ');
                }else{
                    $validator->errors()->add('old_password', 'The old password is incorrect');
                }
            }
        });
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        if(app()->getLocale() === 'kh'){
            return [
                'old_password.required'=> 'តំរូវអោយបំពេញលេខសំងាត់',
                'old_password.min'=> 'បំពេញលេខសំងាត់យ៉ាងតិចមាន8តួលេខ',
                'old_password.max'=>'បំពេញលេខសំងាត់មិនអាចលើសពី12តួលេខ',
                'new_password.required'=> 'តំរូវអោយបំពេញលេខសំងាត់ថ្មី',
                'new_password.min'=>  'បំពេញលេខសំងាត់ថ្មីយ៉ាងតិចមាន8តួលេខ',
                'new_password.max'=> 'បំពេញលេខសំងាត់ថ្មីមិនអាចលើសពី12តួលេខ',
                'new_password_confirmation.required'=> 'តំរូវអោយបញ្ជាក់លេខសំងាត់ថ្មី',
                'new_password_confirmation.confirmed'=> 'ការបញ្ជាក់លេខសំងាត់គឺមិនត្រឹមត្រូវ',
            ];
        }else{
            return [
                'old_password.required'=> 'The old password field is required',
                'old_password.min'=> 'The old password field must be at least 8 characters',
                'old_password.max'=>'The old password field may not be greater than 12 characters',
                'new_password.required'=> 'The new password field is required',
                'new_password.min'=>  'The new password field must be at least 8 characters',
                'new_password.max'=> 'The new password field may not be greater than 12 characters',
                'new_password.confirmed'=> 'The confirm password confirmation does not match',
            ];
        }
    }
    

}
