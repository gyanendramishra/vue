<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Support\Facades\Hash;
use Illuminate\Foundation\Http\FormRequest;

class ResetPasswordRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'password' => 'bail|required|min:8|max:12'
        ];
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages() {
        if (app()->getLocale() === 'kh') {
            return [
                'password.required' => 'តំរូវអោយបំពេញលេខសំងាត់',
                'password.min' => 'បំពេញលេខសំងាត់យ៉ាងតិចមាន8តួលេខ',
                'password.max' => 'បំពេញលេខសំងាត់មិនអាចលើសពី12តួលេខ',
            ];
        } else {
            return [
                'password.required' => 'The password field is required',
                'password.min' => 'The password field must be at least 8 characters',
                'password.max' => 'The password field may not be greater than 12 characters',
            ];
        }
    }

}
