<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class VehicleDetailsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('user')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules =   [
            'vehicle_slug'              =>'required',
            'address'                   =>'required|max:100',
            'odometer'                  =>'required|numeric|digits_between:1,10',
            'interior_color_id'         =>'required',
            'exterior_color_id'         =>'required',
            'lifestyle_id'              =>'required',
            'registration_plate_number' =>'nullable|max:9',
            'fuel_economy_id'           =>'required',
            'contact_phone_number'      =>'required|numeric|digits_between:9,15',
            'english_comment'           =>'nullable|max:500',
            'khmer_comment'             =>'nullable|max:500',
            'initial_masking_digits'    =>'required_if:is_masked_price,1'
        ];
        if(is_numeric($this->discounted_price) && \Auth::guard('user')->user()->hasRole('Dealer')){
            $rules['sale_price'] = 'required|numeric|min:3,digits_between:1,7';
            $rules['discounted_price'] = 'nullable|numeric|min:3,digits_between:1,7';
        }else{
            $rules['sale_price'] = 'required|numeric|min:3,digits_between:1,7';
            $rules['discounted_price'] = 'nullable|numeric|min:3,digits_between:1,7';
        }

        return $rules;
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        if(app()->getLocale() === 'kh'){
            return [
                'address.required'=> 'តំរូវអោយបំពេញអាសយដ្ឋាន',
                'address.max'=>'បំពេញអាសយដ្ឋានមិនអាចលើសពី100តួអក្សរ',
                'odometer.required'=> 'តំរូវអោយបំពេញកុងទ័រគីឡូម៉ែត្រ',
                'odometer.digits_between'=>'បំពេញកុងទ័រគីឡូម៉ែត្រមិនអាចលើសពី10តួអក្សរ',
                'interior_color_id.required'=> 'តំរូវអោយបំពេញពណ៌ផ្ទៃខាងក្នុង',
                'exterior_color_id.required'=> 'តំរូវអោយបំពេញពណ៌ផ្ទៃខាងក្រៅ',
                'lifestyle_id.required'=> 'តំរូវអោយបំពេញសំរាប់គោលបំណង',
                'registration_plate_number.max'=>'បំពេញស្លាកលេខរថយន្តមិនអាចលើសពី9តួអក្សរ',
                'fuel_economy_id.required'=> 'តំរូវអោយបំពេញកំរិតប្រើប្រេងឥន្ធនៈ',
                'contact_phone_number.required'=> 'តំរូវអោយបំពេញលេខទូរស័ព្ទ',
                'contact_phone_number.numeric'=>'បំពេញលេខទូរស័ព្ទអាចជាតួលេខប៉ុណ្ណោះ',
                'contact_phone_number.digits_between'=>'បំពេញលេខទូរស័ព្ទត្រូវនៅចន្លោះពី9ទៅ15តួលេខ',
                'english_comment.max'=>'បំពេញមតិជាសាភាអង់គ្លេសមិនអាចលើសពី500តួអក្សរ',
                'khmer_comment.max'=>'បំពេញមតិជាសាភាខ្មែរមិនអាចលើសពី500តួអក្សរ',
                'sale_price.required'=> 'តំរូវអោយបំពេញតំលៃដាក់លក់',
                'sale_price.numeric'=>'បំពេញតំលៃដាក់លក់អាចជាតួលេខប៉ុណ្ណោះ',
                'sale_price.min'=> 'បំពេញតំលៃដាក់លក់យ៉ាងតិចមាន3តួលេខ',
                'sale_price.digits_between'=>'បំពេញតំលៃដាក់លក់ត្រូវនៅចន្លោះពី1ទៅ7តួលេខ',
                'sale_price.gt'=> 'បំពេញតំលៃដាក់លក់ត្រូវលើសពីតំលៃដែលបញ្ចុះ',
                'discounted_price.numeric'=>'បំពេញតំលៃដែលបញ្ចុះអាចជាតួលេខប៉ុណ្ណោះ',
                'discounted_price.min'=> 'បំពេញតំលៃដែលបញ្ចុះយ៉ាងតិចមាន3តួលេខ',
                'discounted_price.digits_between'=>'បំពេញតំលៃដែលបញ្ចុះត្រូវនៅចន្លោះពី1ទៅ7តួលេខ',
                'discounted_price.lt'=> 'បំពេញតំលៃដែលបញ្ចុះមិនត្រូវលើសតំលៃដាក់លក់',
                'initial_masking_digits.required_if'=> 'តំរូវអោយជ្រើសរើសចំនួនតួលេខខាងមុខដែលគ្មានការបិទបាំង នៅពេលដែលជ្រើសយកការបិទបាំងតំលៃ',
            ];
        }else{
            return [
                'address.required'=> 'The address field is required',
                'address.max'=>'The address field may not be greater than 100 characters',
                'odometer.required'=> 'The odometer field is required',
                'odometer.digits_between'=>'The odometer field may not be greater than 10 characters',
                'interior_color_id.required'=> 'The interior colour field is required',
                'exterior_color_id.required'=> 'The exterior colour field is required',
                'lifestyle_id.required'=> 'The lifestyle field is required',
                'registration_plate_number.max'=>'The registration plate number field may not be greater than 9 characters',
                'fuel_economy_id.required'=> 'The fuel economy field is required',
                'contact_phone_number.required'=> 'The contact phone number field is required',
                'contact_phone_number.numeric'=>'The contact phone number field may only contain numeric characters',
                'contact_phone_number.digits_between'=>'The contact phone number field must be between 9 to 15 characters',
                'english_comment.max'=>'The english comment field may not be greater than 500 characters',
                'khmer_comment.max'=>'The khmer comment field may not be greater than 500 characters',
                'sale_price.required'=> 'The sale price field is required',
                'sale_price.numeric'=>'The sale price field may only contain numeric characters',
                'sale_price.min'=> 'The sale price field must be at least 3 characters',
                'sale_price.digits_between'=>'The sale price field must be between 1 to 7 characters',
                'sale_price.gt'=> 'The sale price field must be greater than discounted price',
                'discounted_price.numeric'=>'The discounted price field may only contain numeric characters',
                'discounted_price.min'=> 'The discounted price field must be at least 3 characters',
                'discounted_price.digits_between'=>'The discounted price field must be between 1 to 7 characters',
                'discounted_price.lt'=> 'The discounted price field must be less than sale price',
                'initial_masking_digits.required_if'=> 'The initial digits without masking field is required when masking enabled',
            ];
        }
    }
}
