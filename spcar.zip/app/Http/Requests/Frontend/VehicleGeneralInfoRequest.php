<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class VehicleGeneralInfoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('user')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title'            =>'required|max:100',
            'make_id'          =>'required',
            'model_id'         =>'required',
            'badge_id'         =>'nullable',
            'series_id'        =>'nullable',
            'body_type_id'     =>'required',
            'fuel_type_id'     =>'required',
            'drive_type_id'    =>'required',
            'transmission_id'  =>'required',
            'doors'            =>'required',
            'seats'            =>'required',
            'gears'            =>'required',
            'cylinders'        =>'required',
            'year_built'       =>'required',
            'month_built'      =>'required',
            'turbo'            =>'required',
            'engine_capacity'  =>'required|max:4',
            'chassis_number'   =>'nullable|max:17'
        ];
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        if(app()->getLocale() === 'kh'){
            return [
                'title.required'=> 'តំរូវអោយបំពេញព័ត៌មានរថយន្ត',
                'make_id.required'=> 'តំរូវអោយបំពេញម៉ាក',
                'model_id.required'=> 'តំរូវអោយបំពេញម៉ូដែល',
                'body_type_id.required'=> 'តំរូវអោយបំពេញតួរថយន្ត',
                'fuel_type_id.required'=> 'តំរូវអោយបំពេញប្រភេទឥន្ធនៈ',
                'drive_type_id.required'=> 'តំរូវអោយបំពេញប្រភេទរង្វិលកង់',
                'transmission_id.required'=> 'តំរូវអោយបំពេញប្រអប់លេខ',
                'doors.required'=> 'តំរូវអោយបំពេញចំនួនទ្វារ',
                'seats.required'=> 'តំរូវអោយបំពេញចំនួនកៅអី',
                'gears.required'=> 'តំរូវអោយបំពេញចំនួនលេខប្រអប់លេខ',
                'cylinders.required'=> 'តំរូវអោយបំពេញចំនួនស៊ីឡាំង',
                'year_built.required'=> 'តំរូវអោយបំពេញឆ្នាំផលិត',
                'month_built.required'=> 'តំរូវអោយបំពេញខែផលិត',
                'turbo.required'=> 'តំរូវអោយបំពេញទូប៊ូ',
                'engine_capacity.required'=> 'តំរូវអោយបំពេញទំហំម៉ាស៊ីន',
                'engine_capacity.max'=>'បំពេញទំហំម៉ាស៊ីនមិនអាចលើសពី4តួអក្សរ',
                'chassis_number.max'=> 'បំពេញលេខ VIN មិនអាចលើសពី17តួលេខ'
            ];
        }else{
            return [
                'title.required'=> 'The vehicle title field is required',
                'make_id.required'=> 'The make field is required',
                'model_id.required'=> 'The model field is required',
                'body_type_id.required'=> 'The body type field is required',
                'fuel_type_id.required'=> 'The fuel type field is required',
                'drive_type_id.required'=> 'The drive type field is required',
                'transmission_id.required'=> 'The transmission field is required',
                'doors.required'=> 'The doors field is required',
                'seats.required'=> 'The seats field is required',
                'gears.required'=> 'The gears field is required',
                'cylinders.required'=> 'The cylinders field is required',
                'year_built.required'=> 'The year built field is required',
                'month_built.required'=> 'The month built field is required',
                'turbo.required'=> 'The turbo field is required',
                'engine_capacity.required'=> 'The engine capacity field is required',
                'engine_capacity.max'=>'The engine capacity field may not be greater than 4 characters',
                'chassis_number.max'=> 'The VIN/chassis number field may not be greater than 17 characters'
            ];
        }
    }
}
