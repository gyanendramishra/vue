<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class ForgotPasswordRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'phone' => 'bail|required|digits_between:9,15',
        ];
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages() {
        if (app()->getLocale() === 'kh') {
            return [
                'phone.required' => 'The phone field is required',
                'phone.digits_between' => 'The phone field must be between 9 to 15 characters',
            ];
        } else {
            return [
                'phone.required' => 'The phone field is required',
                'phone.digits_between' => 'The phone field must be between 9 to 15 characters',
            ];
        }
    }

}
