<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class RegisterRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'name' => 'bail|required|max:50',
            'phone' => 'bail|required|digits_between:9,15|unique:users,phone',
            'email' => 'nullable|email|max:100|unique:users,email',
            'password' => 'bail|required|confirmed|min:8|max:12',
            'company_name' => 'nullable|required_if:role_id,3|max:100',
            'address' => 'nullable|required_if:role_id,3|max:100',
        ];
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages() {
        if (app()->getLocale() === 'kh') {
            return [
                'name.required' => 'តំរូវអោយបំពេញឈ្មោះ',
                'name.max' => 'បំពេញឈ្មោះមិនអាចលើសពី50តួអក្សរ',
                'phone.required' => 'តំរូវអោយបំពេញលេខទូរស័ព្ទ',
                'phone.digits_between' => 'បំពេញលេខទូរស័ព្ទត្រូវនៅចន្លោះពី9ទៅ15តួលេខ',
                'phone.unique' => 'លេខទូរស័ព្ទត្រូវបានប្រើប្រាស់រួចហើយ',
                'email.email' => 'ត្រូវបំពេញអ៊ីម៉ែលអោយបានត្រឹមត្រូវ',
                'email.max' => 'បំពេញអ៊ីម៉ែលមិនអាចលើសពី100តួអក្សរ',
                'email.unique' => 'អ៊ីម៉ែលត្រូវបានប្រើប្រាស់រួចហើយ',
                'password.required' => 'តំរូវអោយបំពេញលេខសំងាត់',
                'password.min' => 'បំពេញលេខសំងាត់យ៉ាងតិចមាន8តួលេខ',
                'password.max' => 'បំពេញលេខសំងាត់មិនអាចលើសពី12តួលេខ',
                'company_name.required_if' => 'តំរូវអោយបំពេញឈ្មោះក្រុមហ៊ុន',
                'company_name.max' => 'ឈ្មោះក្រុមហ៊ុនមិនអាចលើសពី100តួអក្សរ',
                'address.required_if' => 'តំរូវអោយបំពេញអាសយដ្ឋាន',
                'address.max' => 'បំពេញអាសយដ្ឋានមិនអាចលើសពី100តួអក្សរ',
            ];
        } else {
            return [
                'name.required' => 'The name field is required',
                'name.max' => 'The name field may not be greater than 50 characters',
                'phone.required' => 'The phone field is required',
                'phone.digits_between' => 'The phone field must be between 9 to 15 characters',
                'phone.unique' => 'The phone has already been taken',
                'email.email' => 'The email address field must be a valid email',
                'email.max' => 'The email field may not be greater than 100 characters',
                'email.unique' => 'The email has already been taken',
                'password.required' => 'The password field is required',
                'password.min' => 'The password field must be at least 8 characters',
                'password.max' => 'The password field may not be greater than 12 characters',
                'company_name.required_if' => 'The company name field is required',
                'company_name.max' => 'The company name field may not be greater than 100 characters',
                'address.required_if' => 'The address field is required',
                'address.max' => 'The address field may not be greater than 100 characters',
            ];
        }
    }

   

}
