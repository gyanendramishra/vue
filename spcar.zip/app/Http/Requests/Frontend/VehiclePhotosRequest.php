<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class VehiclePhotosRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('user')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'vehicle_slug'              =>'required',
            'file'                      =>'bail|required|image'
        ];
    }
    /**
     * Configure the validator instance.
     *
     * @param \Illuminate\Validation\Validator $validator
     *
     * @return void
     */
    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            if($this->hasFile('file')){
                if ($this->file('file')->getClientSize() > '5242880') {
                    if(app()->getLocale() === 'kh'){
                        $validator->errors()->add('file', 'ទំហំឯកសារមិនអាចធំជាង5 MB។ សូមជ្រើសយកឯកសារផ្សេងទៀត');
                    }else{
                        $validator->errors()->add('file', 'File shouldn\'t be greater than 5 MB. Please select another file');
                    } 
                }
            }
        });
    }
    
    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        if(app()->getLocale() === 'kh'){
            return [
                'file.required'=>'តំរូវអោយបំពេញឯកសារ',
                'file.image'=>'ឯកសារត្រូវជារូបភាព'
            ];
        }else{
            return [
                'file.required'=>'The file field is required',
                'file.image'=>'The file must be an image'
            ];
        }
    }
}
