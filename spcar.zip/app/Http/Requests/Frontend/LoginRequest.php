<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class LoginRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'email' => 'bail|required|max:100',
            'password' => 'bail|required|min:8|max:12',
        ];
    }

    /**
     * Configure the validator instance.
     *
     * @param \Illuminate\Validation\Validator $validator
     *
     * @return void
     */
    public function withValidator($validator) {
        $validator->after(function ($validator) {
            if ($this->has('email')) {
                if (is_numeric($this->email)) {
                    if (!preg_match('/^[0-9]{4,16}+$/', $this->email)) {
                        if(app()->getLocale() === 'kh'){
                            $validator->errors()->add('email', 'សូមបំពេញលេខទូរស័ព្ទអោយបានត្រឹមត្រូវ');
                        }else{
                            $validator->errors()->add('email', 'Please enter a valid phone number');
                        }
                    }
                } else {
                    if (!filter_var($this->email, FILTER_VALIDATE_EMAIL)) {
                        if(app()->getLocale() === 'kh'){
                            $validator->errors()->add('email', 'សូមបំពេញអ៊ីម៉ែលអោយបានត្រឹមត្រូវ');
                        }else{
                            $validator->errors()->add('email', 'Please enter a valid email address');
                        }
                    }
                }
            }
        });
    }
    
     /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        if(app()->getLocale() === 'kh'){
            return [
                'email.required'=> 'តំរូវអោយបំពេញអ៊ីម៉ែល ឫ លេខទូរស័ព្ទ',
                'email.max'=> 'បំពេញអ៊ីម៉ែល ឫ លេខទូរស័ព្ទមិនអាចលើសពី100តួអក្សរ',
                'password.required' => 'តំរូវអោយបំពេញលេខសំងាត់',
                'password.min' => 'បំពេញលេខសំងាត់យ៉ាងតិចមាន8តួលេខ',
                'password.max' => 'បំពេញលេខសំងាត់មិនអាចលើសពី12តួលេខ',
            ];
        }else{
            return [
                'email.required'=> 'The email/phone field is required',
                'email.max'=> 'The email/phone field may not be greater than 50 characters',
                'password.required'=> 'The password field is required',
                'password.min'=> 'The password field must be at least 8 characters',
                'password.max'=> 'The password field may not be greater than 12 characters',
            ];
        }
    }

}
