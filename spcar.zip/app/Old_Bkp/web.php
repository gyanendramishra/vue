<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */



/* Front Route */

Route::get('/preview-e-template', function() {
    return view('frontend.emails.template');
});
Route::group(['namespace' => 'Frontend', 'as' => 'frontend.'], function () {
    /* Home route */
    Route::get('/', 'HomeController')->name('home');
    /* Auth route */
    Route::get('/login', 'Auth\LoginController@index')->name('login');

    Route::post('/login', 'Auth\LoginController@login')->name('dologin');
    Route::post('/logout', 'Auth\LoginController@logout')->name('logout');
    Route::get('/register', 'Auth\RegisterController@index')->name('register');
    Route::post('/register', 'Auth\RegisterController@register')->name('doregister');
    Route::post('/verify-otp', 'Auth\RegisterController@verifyOtp')->name('verifyotp');
    Route::post('/reset-password', 'Auth\ResetPasswordController@resetPassword')->name('reset.password');
    Route::get('/verify/{token}', 'Auth\VerificationController@index')->name('verify');
    Route::post('/resend-otp', 'Auth\RegisterController@resendOtp')->name('resendOtp');
    # Forgot password
    Route::get('/password/email', 'Auth\ForgotPasswordController@index')->name('forgot.password');
    Route::post('/password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('send.reset.link.email');

    # Social login
    Route::get('/login/{provider}', 'Auth\SocialiteController@redirectToProvider')->name('social.login');
    Route::get('/auth/{provider}/callback', 'Auth\SocialiteController@handleProviderCallback')->name('social.login.callback');

    # Contact us
    Route::group(['prefix' => 'contact-us'], function() {
        Route::get('/', 'InquiryController@index')->name('inquiry');
        Route::post('inquire', 'InquiryController@sendInquiry')->name('inquire');
    });

    # Vehicle search
    Route::group(['prefix' => 'vehicles'], function() {
        Route::get('/{first?}/{second?}/{third?}/{fourth?}/{fifth?}/{sixth?}/{seventh?}/{eighth?}', 'VehicleSearchController')->name('vehicles');
    });

    # Vehicle compare
    Route::get('/compare/{slug}', 'VehicleCompareController')->name('vehicles.compare');

    # Vehicle
    Route::group(['prefix' => 'vehicle'], function() {
        Route::get('/{slug}', 'VehicleController')->name('vehicle');
    });

    # News
    Route::group(['prefix' => 'news'], function() {
        Route::get('/', 'NewsController@index')->name('news');
        Route::get('/{slug}', 'NewsController@info')->name('info');
    });

    # Reviews
    Route::group(['prefix' => 'reviews'], function() {
        Route::get('/', 'VehicleReviewsController')->name('reviews');
    });

    ## Auth route group 
    Route::group(['middleware' => ['auth:user']], function() {
        # Dashboard
        Route::get('/dashboard', 'DashboardController')->name('dashboard');

        # Profile
        Route::group(['prefix' => 'profile'], function() {
            Route::get('/', 'ProfileController@index')->name('profile');
            Route::post('/', 'ProfileController@updateProfile')->name('update.profile');
            Route::post('/change-avatar', 'ProfileController@updateAvatar')->name('update.profile.avatar');
        });

        # Change password
        Route::group(['prefix' => 'change'], function() {
            Route::get('/password', 'PasswordController@index')->name('change.password');
            Route::post('/password', 'PasswordController@updatePassword')->name('update.password');
        });

        # Saved vehicles
        Route::get('/saved-vehicles', 'SavedVehicleController')->name('saved.vehicles');

        # Conversations
        Route::get('/messages', 'ConversationController')->name('my.messages');

        # My ad's
        Route::get('/manage-ads', 'ManageVehicleController@index')->name('my.vehicles');

        # Sell my car
        Route::get('/sell-my-car', 'VehiclePlanController')->name('sell.my.car');
        # Manage ad's
        Route::group(['prefix' => 'vehicle', 'as' => 'vehicle.'], function() {
            Route::get('/create/new/{plan?}', 'ManageVehicleController@createVehicle')->name('create');
            Route::get('/{vehicle}/general', 'ManageVehicleController@saveVehicleGeneral')->name('save.general');
            Route::get('/{vehicle}/features', 'ManageVehicleController@saveVehicleFeatures')->name('save.features');
            Route::get('/{vehicle}/details', 'ManageVehicleController@saveVehicleDetails')->name('save.details');
            Route::get('/{vehicle}/photos', 'ManageVehicleController@saveVehiclePhotos')->name('save.photos');
            Route::get('/{vehicle}/preview', 'ManageVehicleController@vehiclePreview')->name('preview');
            Route::get('/{vehicle}/complete', 'ManageVehicleController@vehicleComplete')->name('completed');
            Route::get('/{vehicle}/subscribe-and-pay', 'ManageVehicleController@subscribe')->name('subscribe.n.pay');
            Route::get('/{vehicle}/thank-you', 'ManageVehicleController@vehicleThankYou')->name('thank.you');
        });
    });
    # Api
    Route::group(['prefix' => 'api', 'namespace' => 'Api', 'as' => 'api.'], function() {
        # NewsLetter
        Route::post('subscribe-to-news-letter', 'NewsletterController@subscribeToNewsletter')->name('subscribe.newsletter');
        
        Route::group(['prefix' => 'subscription'], function() {
            Route::get('/stripe/setup-intent', 'ManageStripeSubscriptionController@getSetupIntent');
            Route::post('/stripe/subscribe-to-plan', 'ManageStripeSubscriptionController@subscribeToPlan');
        });
        
        # Vehicle
        Route::group(['prefix' => 'vehicle', 'as' => 'vehicle.'], function() {
            Route::group(['prefix' => 'manage', 'as' => 'manage.'], function() {
                # Save vehicle general info
                Route::post('/general-info', 'ManageVehicleController@manageGeneralInfo')->name('general.info');
                # Save vehicle features
                Route::post('/features', 'ManageVehicleController@manageFeatures')->name('general.features');
                # Save vehicle details
                Route::post('/details', 'ManageVehicleController@manageDetails')->name('general.details');
                # Save vehicle photos
                Route::group(['prefix' => 'photos', 'as' => 'photo.'], function() {
                    Route::post('/', 'ManageVehicleController@managePhotos');
                    Route::post('/save', 'ManageVehicleController@savePhotos')->name('save');
                    Route::delete('/{vehicle_image}/delete', 'ManageVehicleController@deletePhotos')->name('delete');
                    Route::post('/update-cover', 'ManageVehicleController@markAsCoverPhotos')->name('mark.cover.photo');
                });
                # Save inspection
                Route::post('/inspect', 'ManageVehicleController@inspectVehicle')->name('inspect');
                # Delete ad
                Route::get('/{slug}/delete', 'ManageVehicleController@deleteVehicle')->name('delete.vehicle');
                # Toogle favourite ad
                Route::get('/{id}/toogle-favourite', 'ManageVehicleController@toogleFavourite')->name('toogle.favourite');

                # Save ad review
                Route::post('/save-review', 'ManageVehicleController@saveReview')->name('save.ad.review');
                
                Route::post('/mark-vehicles-as-featured', 'ManageVehicleController@markVehiclesFeatured');
                Route::post('/mark-vehicles-as-on-sale', 'ManageVehicleController@markVehiclesOnsale');
                Route::post('/mark-vehicles-as-until-sold', 'ManageVehicleController@markVehiclesUntilSold');
                Route::get('/{id}/toggle-vehicle-featured', 'ManageVehicleController@toggleVehicleFeatured');
                Route::get('/{id}/toggle-vehicle-on-sale', 'ManageVehicleController@toggleVehicleOnSale');
                Route::get('/{id}/toggle-vehicle-until-sold', 'ManageVehicleController@toggleVehicleUntilSold');
                Route::get('/{id}/mark-vehicle-as-sold', 'ManageVehicleController@markVehicleSold');
                
            });
            # Get models by make slug
            Route::get('/make/{slug}/models-by-slug', 'VehicleController@getModelsByMakeSlug')->name('make.model');
            # Get models by make id
            Route::get('/make/{id}/models-by-id', 'VehicleController@getModelsByMakeId')->name('make.model.by.id');
            # Get badges by model slug
            Route::get('model/{slug}/badges-by-slug', 'VehicleController@getBadgesByModelSlug')->name('model.badge');
            # Get badges by model id
            Route::get('/model/{id}/badges-by-id', 'VehicleController@getBadgesByModelId')->name('model.badge.by.id');
            # Get series by badge id
            Route::get('/badge/{id}/series-by-id', 'VehicleController@getSeriesByBadgeId')->name('badge.series');
            # Get cities by state id
            Route::get('/state/{id}/cities-by-id', 'VehicleController@getCitiesByStateId')->name('state.cities');
            
        });

        # Conversation
        Route::group(['prefix' => 'conversation', 'as' => 'conversation.'], function() {
            # Save vehicle inquiry as conversation
            Route::post('/save/inquiry', 'ConversationController@saveVehicleQuery')->name('save.query');
            # Send conversation message
            Route::post('/send-message', 'ConversationController@sendMessage')->name('send.message');
            # Get all vehcile conversations
            Route::get('/all-conversations/{page?}', 'ConversationController@getAllVehiclesConversations')->name('all.vehicles');
            # Get vehcile conversations
            Route::get('/{id}/conversations/{page?}', 'ConversationController@getVehicleConversations')->name('vehicle');
            # Get conversation messages
            Route::get('/{id}/messages/{page?}', 'ConversationController@getMessagesByConversationId')->name('messages');
        });
    });
});


/* Admin Routes */

Route::group(['namespace' => 'Admin', 'prefix' => 'admin', 'as' => 'admin.'], function () {

    Route::get('/', function() {
        return redirect()->route('admin.login');
    });

    Auth::routes(['register' => false]);

    Route::get('/get-resion/{id}/{region_id?}', 'HomeController@getstates')->name('get-resion');
    Route::get('/get-cities/{id}', 'HomeController@getCities')->name('get-cities');
    Route::get('/get-models/{id}/{model_id?}', '\Modules\VehicleManager\Http\Controllers\Admin\VehicleManagerController@getModels')->name('get-models');
    Route::get('/get-badges/{id}/{model_id?}/{badge_id?}', '\Modules\VehicleManager\Http\Controllers\Admin\VehicleManagerController@getBadge')->name('get-badges');
    Route::get('/get-model-badge/{make_id?}/{model_id?}/{badge_id?}', '\Modules\VehicleManager\Http\Controllers\Admin\VehicleManagerController@getBadge')->name('get-model-badge');
    Route::get('/get-badgess/{id}/{model_id}', '\Modules\VehicleManager\Http\Controllers\Admin\VehicleManagerController@getBadge')->name('get-badgess');
    Route::get('/get-series/{id}/{model_id}/{badge_id}/{series_id?}', '\Modules\VehicleManager\Http\Controllers\Admin\VehicleManagerController@getSeries')->name('get-series');
    Route::get('/get-badge-series/{id}/{model_id?}/{badge_id?}/{series_id?}', '\Modules\VehicleManager\Http\Controllers\Admin\VehicleManagerController@getSeries')->name('get-badge-series');

    /* Auth route group */
    Route::group(['middleware' => 'auth:admin'], function() {
        Route::post('/change-flag/{table}/{id}', 'HomeController@changeFlag')->name('changeflag');
        Route::post('/change-vehicle-status/{id?}', 'HomeController@changeVehicleApprove')->name('changeVehicleApprove');
        /* Dashboard */
        Route::get('/dashboard', 'HomeController@index')->name('dashboard');
        Route::get('/profile', 'HomeController@profile')->name('profile');
        Route::post('/profile/update/{id}', 'HomeController@profileUpdate')->name('profile.update');
        Route::get('/change-password', 'HomeController@showChangePasswordForm')->name('changepassword');
        Route::post('/update-password', 'HomeController@changePassword')->name('updatepassword');
        Route::resources(['emailtemplates' => 'EmailTemplatesController',]);
        Route::get('emailtemplates/ajax/list', 'EmailTemplatesController@ajaxList')->name('emailtemplates.ajax.list');
        Route::get('get-geo-chart', 'HomeController@userGeoChart')->name('get-geo-chart');
    });
});

Route::get('/generate-thumb/{width?}/{height?}/{quality?}/{crop?}', function(\Illuminate\Http\Request $request, $width = null, $height = null, $quality = null, $crop = null) {
    return \App\Helpers\Helper::imageUrl($request->query('path'), $width, $height, $quality, $crop);
});

# Cms pages routes
Route::get('/{slug}', 'Frontend\PageController')->name('cms.pages');




