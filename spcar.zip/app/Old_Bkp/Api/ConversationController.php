<?php

namespace App\Http\Controllers\Frontend\Api;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Mail\Frontend\MessageMail;
use App\Mail\Frontend\VehicleInquiryMail;
use App\Repositories\ConversationRepository;
use Modules\VehicleManager\Entities\Vehicle;
use App\Http\Requests\Frontend\VehicleInquiryRequest;
use Modules\VehicleEnquiresManager\Entities\Conversation;
use Modules\VehicleEnquiresManager\Entities\ConversationMessage;

class ConversationController extends Controller {

    /**
     * Conversation repository.
     *
     * @var string
     */
    private $conversationRepository;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        ConversationRepository $conversationRepository
    ){
        $this->conversationRepository = $conversationRepository;
    }

    /**
     * Get conversation messages.
     *
     * @return \Illuminate\Http\Response
     */
    public function getMessagesByConversationId($conversationId, $page = null) {
        try {
            $messages = $this->conversationRepository->getConversationMessages($conversationId, $page);
            $messages->map(function ($message) {
                $message['user']['id'] = $message->user->id;
                $message['user']['profile_image'] = $message->user->profile_image;
                if($message->user->roles->pluck('name')->contains('Guest')){
                    $participant = $message->conversation->participants()->where('user_id', $message->user->id)->first();
                    $message['user']['name'] = $participant->pivot->name;
                    $message['user']['email'] = $participant->pivot->email;
                    $message['user']['phone'] = $participant->pivot->phone;
                }else{
                    $message['user']['name'] = $message->user->name;
                    $message['user']['email'] = $message->user->email;
                    $message['user']['phone'] = $message->user->phone;
                }
                return $message;

            });
            return response()->json([
                        "status" => "success",
                        "messages" => $messages
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()//__('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get all vehicles conversations.
     *
     * @return \Illuminate\Http\Response
     */
    public function getAllVehiclesConversations(Request $request, $page = null) {
        try {
            $user = $request->user('user');
            $conversations = $this->conversationRepository->getUserAllConversations($user->id, $page);
            $conversations->map(function ($conversation) {
                /* Load last message */
                $conversation['messages'] = $conversation->messages->last();
                /* Load participants */
                $conversation['participants'] = $conversation->participants->map(function ($participant){
                    if($participant->roles->pluck('name')->contains('Guest')){
                        $participant['name'] = $participant->pivot->name;
                        $participant['email'] = $participant->pivot->email;
                        $participant['phone'] = $participant->pivot->phone;
                    }else{
                        $participant['name'] = $participant->name;
                        $participant['email'] = $participant->email;
                        $participant['phone'] = $participant->phone;
                    }
                    return $participant;
                });
                return $conversation;
            });
            return response()->json([
                        "status" => "success",
                        "conversations" => $conversations
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get vehicle conversations.
     *
     * @return \Illuminate\Http\Response
     */
    public function getVehicleConversations(Request $request, $vehicleId, $page = null) {
        try {
            $user = $request->user('user');
            $conversations = $this->conversationRepository->getVehicleConversations($vehicleId, $user->id, $page);
            $conversations->map(function ($conversation) {
                /* Load last message */
                $conversation['messages'] = $conversation->messages->last();
                /* Load participants */
                $conversation['participants'] = $conversation->participants->map(function ($participant){
                    if($participant->roles->pluck('name')->contains('Guest')){
                        $participant['name'] = $participant->pivot->name;
                        $participant['email'] = $participant->pivot->email;
                        $participant['phone'] = $participant->pivot->phone;
                    }else{
                        $participant['name'] = $participant->name;
                        $participant['email'] = $participant->email;
                        $participant['phone'] = $participant->phone;
                    }
                    return $participant;
                });
                return $conversation;
            });
            return response()->json([
                        "status" => "success",
                        "conversations" => $conversations
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function sendMessage(Request $request) {
        try {
            \DB::beginTransaction();
            $conversation = \Modules\VehicleEnquiresManager\Entities\Conversation::find($request->conversation_id);
            if($conversation){
                if($conversation->vehicle->is_approved == 0){
                    return response()->json([
                        "status" => "warning",
                        "message" => __('frontend.CONVERSATION_VEHICLE_UNAPPROVED')
                    ], 200);
                }
                if($conversation->vehicle->is_sold == 1){
                    return response()->json([
                        "status" => "warning",
                        "message" => __('frontend.CONVERSATION_VEHICLE_SOLD')
                    ], 200);
                }
                $message = new \Modules\VehicleEnquiresManager\Entities\ConversationMessage($request->all());
                if ($message->save()) {
                    // DB commit
                    \DB::commit();
                    /* Send mail to receiver */
                    $mailData = [
                        'vehicle_title' => $message->conversation->vehicle->title,
                        'message' => $message->content
                    ];
                    $receiver = $message->conversation->participants()->where('user_id', '!=', $message->user->id)->first();
                    if($receiver->hasRole('Guest')){
                        $mailData['name'] = $receiver->pivot->name;
                        $mailData['email'] = $receiver->pivot->email;
                    }else{
                        $mailData['name'] = $message->user->name;
                        $mailData['email'] = $message->user->email;
                    }
                    // Send mail
                    if(isset($mailData['email'])){
                        \Mail::to($mailData['email'])->send(new MessageMail($mailData));
                    }
                    /* Get the sent message */
                    $message = $this->conversationRepository->getMessageById($message->id);
                    /* Modify message */
                    $messageUser = new \Illuminate\Support\Collection;
                    $messageUser->id = $message->user->id;
                    $messageUser->profile_image = $message->user->profile_image;
                    if($message->user->hasRole('Guest')){
                        $sender = $message->conversation->participants()->where('user_id', $message->user->id)->first();
                        $messageUser->name = $sender->pivot->name;
                        $messageUser->email = $sender->pivot->email;
                        $messageUser->phone = $sender->pivot->phone;
                    }else{
                        $messageUser->name = $message->user->name;
                        $messageUser->email = $message->user->email;
                        $messageUser->phone = $message->user->phone;
                    }
                    $message->user = $messageUser;
                    return response()->json([
                                "status" => "success",
                                "message" => $message
                            ], 200);
                }
            }
            throw new Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Frontend\VehicleInquiryRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function saveVehicleQuery(VehicleInquiryRequest $request) {
        try {
            \DB::beginTransaction();
            $vehicle = Vehicle::select('id', 'user_id', 'title')->find($request->vehicle_id);
            if($vehicle){
                if(\Auth::guard('user')->check()){
                    $user = \Auth::guard('user')->user();
                }else{
                    $user = \App\User::where('phone', $request->phone)
                        ->orWhere('email', $request->email)
                        ->first(['id', 'name', 'email', 'phone']);
                }
                if($user){
                    if($user->id == $vehicle->user_id){
                        return response()->json([
                            "status" => "warning",
                            "message" => __('frontend.VEHICLE_INQUIRY_SELF_VEHICLE')
                                ], 200);
                    }
                }else{
                    $user = \App\User::whereHas('roles', function($q){
                        $q->where('name', 'Guest');
                    })->first(['id', 'name', 'email', 'phone']);
                }

                $conversation = $this->conversationRepository->conversationForVehicleAndUser($vehicle->id, $user->id, [
                    'email'=> $request->email,
                    'phone'=> $request->phone,
                ]);
                
                if(!$conversation){
                    $conversation = new Conversation();
                    $conversation->vehicle_id = $vehicle->id;
                    $conversation->title = $vehicle->title.'('.$vehicle->user->name.'-'.$request->name.')';
                    $conversation->save();
                    /* Attach participants */
                    $conversation->participants()->attach([
                        $vehicle->user->id => [
                            'name'=> $vehicle->user->name,
                            'email'=> $vehicle->user->email,
                            'phone'=> $vehicle->user->phone
                        ], 
                        $user->id => [
                            'name'=> $request->name,
                            'email'=> $request->email,
                            'phone'=> $request->phone
                        ]
                    ]); 
                }else{
                    $conversation->participants()->updateExistingPivot($user->id, [
                        'name'=> $request->name,
                        'email'=> $request->email,
                        'phone'=> $request->phone
                    ]);
                }  
                /* Save conversaion message */
                $conversationMessage = new ConversationMessage();
                $conversationMessage->conversation_id = $conversation->id;
                $conversationMessage->user_id = $user->id;
                $conversationMessage->content = $request->message;
                $conversationMessage->save();
                // DB commit
                \DB::commit();
                // Send inquiry mail to admin
                if (!empty(config('get.ADMIN_EMAIL'))) {
                    \Mail::to(config('get.ADMIN_EMAIL'))->send(new VehicleInquiryMail($conversation));
                }
                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.VEHICLE_INQUIRY_SAVED')
                                ], 200);
            }
            throw new Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

}
