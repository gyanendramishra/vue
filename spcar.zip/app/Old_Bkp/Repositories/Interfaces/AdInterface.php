<?php
namespace App\Repositories\Interfaces;

interface AdInterface {
    
    public function getHomeAds();
    public function getListingPageAds();
    public function getDetailPageAds();
    public function getLisitngPageLeftAd();
    public function getLisitngPageTopAd();
    public function getLisitngPageBottomAd();
    public function getDetailPageLeftAd();
    public function getDetailPageTopAd();
    public function getDetailPageBottomAd();

}
