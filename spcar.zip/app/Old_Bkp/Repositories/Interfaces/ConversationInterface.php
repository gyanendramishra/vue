<?php
namespace App\Repositories\Interfaces;

interface ConversationInterface {
    
    public function getAllConversations();
    
    public function getUserAllConversations($userId, $page);

    public function getConversationMessages($conversationId, $page);

    public function getMessageById($messageId);

    public function getVehicleConversations($vehicleId, $userId, $page);

    public function getConversationParticipantionVehicles($user);

    public function conversationForVehicleAndUser($vehicleId, $userId, $options);
}
