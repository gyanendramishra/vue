<?php

namespace App\Policies\Admin;

use App\User;
use Modules\StaffManager\Entities\AdminUser;
use Illuminate\Auth\Access\HandlesAuthorization;

class AdminUserPolicy {

    use HandlesAuthorization;

    public function before($user, $ability) {
        if (\Auth::user('admin')->adminRoleUsers()->first()->slug == 'admin') {
            return true;
        }
    }

    /**
     * Determine whether the user can view any admin users.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function viewAny(AdminUser $adminUser) {
        //
    }

    /**
     * Determine whether the user can view any admin users.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function listing(AdminUser $adminUser) {
        $hasPermission = \Auth::user('admin')->adminRoleUsers()->whereHas('adminRolePermissions', function($q) {
                    $q->where('module', 'User');
                    $q->where('name', 'Listing');
                })->exists();

        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can view the admin user.
     *
     * @param  \App\User  $user
     * @param  \App\AdminUser  $adminUser
     * @return mixed
     */
    public function view(AdminUser $adminUser) {

        $hasPermission = \Auth::user('admin')->adminRoleUsers()->whereHas('adminRolePermissions', function($q) {
                    $q->where('module', 'User');
                    $q->where('name', 'View');
                })->exists();
        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can create admin users.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function create(AdminUser $adminUser) {

        $hasPermission = \Auth::user('admin')->adminRoleUsers()->whereHas('adminRolePermissions', function($q) {
                    $q->where('module', 'User');
                    $q->where('name', 'Add');
                })->exists();
        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can update the admin user.
     *
     * @param  \App\User  $user
     * @param  \App\AdminUser  $adminUser
     * @return mixed
     */
    public function update(AdminUser $adminUser) {

        $hasPermission = \Auth::user('admin')->adminRoleUsers()->whereHas('adminRolePermissions', function($q) {
                    $q->where('module', 'User');
                    $q->where('name', 'Edit');
                })->exists();
        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can delete the admin user.
     *
     * @param  \App\User  $user
     * @param  \App\AdminUser  $adminUser
     * @return mixed
     */
    public function delete(AdminUser $adminUser) {

        $hasPermission = \Auth::user('admin')->adminRoleUsers()->whereHas('adminRolePermissions', function($q) {
                    $q->where('module', 'User');
                    $q->where('name', 'Delete');
                })->exists();
        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can restore the admin user.
     *
     * @param  \App\User  $user
     * @param  \App\AdminUser  $adminUser
     * @return mixed
     */
    public function restore(User $user, AdminUser $adminUser) {
        //
    }

    /**
     * Determine whether the user can permanently delete the admin user.
     *
     * @param  \App\User  $user
     * @param  \App\AdminUser  $adminUser
     * @return mixed
     */
    public function forceDelete(User $user, AdminUser $adminUser) {
        //
    }

}
