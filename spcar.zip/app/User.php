<?php

namespace App;

use App\Traits\Billable;
use Modules\User\Entities\Role;
use Laravel\Passport\HasApiTokens;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable {

    use HasApiTokens,
        Notifiable,
        Billable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'facebook_id', 
        'google_id',
        'name', 
        'email', 
        'password',    
        'phone', 
        'company_name',
        'address', 
        'country',
        'country_code', 
        'state', 
        'city', 
        'latitude', 
        'longitude', 
        'postcode', 
        'profile_image', 
        'api_token',
        'remember_token',
        'is_otp_verified',
        'status',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should have default values.
     *
     * @var array
     */
    protected $attributes = [
        'status' => 1,
    ];

    /**
     * Defining date fields.
     *
     * @var array
     */
    protected $dates = [
        'last_seen_at'
    ];

    /**
     * Get the roles that associated with the user.
     */
    public function roles() {
        return $this->belongsToMany('Modules\User\Entities\Role');
    }

    /**
     * CHECK IF USER HAS GIVEN ROLE.
     */
    public function hasRole($role) {

        return $this->roles()->where('name', $role)->exists();
    }

    /**
     * CHECK IF USER HAS GIVEN ROLE.
     */
    public function isRole($roleName) {
        foreach ($this->roles()->get() as $role) {
            if ($role->slug == $roleName) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get the role of user.
     */
    public function role() {
        if (isset($this->roles->first()->slug)) {
            return $this->roles->first()->slug;
        } else {
            return '';
        }
    }

    /**
     * Get the user verification that belongs to user.
     */
    public function userVerification() {
        return $this->hasOne('\App\UserVerification');
    }

    /**
     * Get the favourite vehciles that belongs to user.
     */
    public function favouriteVehicles() {
        return $this->belongsToMany('Modules\VehicleManager\Entities\Vehicle', 'user_vehicle', 'user_id', 'vehicle_id')->withPivot('is_favourite');
    }

    /**
     * Get the vehicles that belongs to user.
     */
    public function vehicles() {
        return $this->hasMany('Modules\VehicleManager\Entities\Vehicle');
    }

    /**
     * Get the participants that belongs to conversation.
     */
    public function conversations() {
        return $this->belongsToMany(\Modules\VehicleEnquiresManager\Entities\Conversation::class, 'conversation_participants', 'user_id', 'conversation_id')
                        ->withPivot('name', 'email', 'phone');
    }

}
