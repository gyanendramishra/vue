<?php

namespace Modules\AdminVehicleReviewManager\Entities;

use Illuminate\Database\Eloquent\Model;

class AdminVehicleReviewTranslation extends Model {

    public $timestamps = false;
    protected $fillable = ["title", "excerpt","app_description",  "description"];

}
