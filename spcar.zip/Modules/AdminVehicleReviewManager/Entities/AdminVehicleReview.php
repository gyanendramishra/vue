<?php

namespace Modules\AdminVehicleReviewManager\Entities;

use Illuminate\Database\Eloquent\Model;
use \Dimsav\Translatable\Translatable;
use Cviebrock\EloquentSluggable\Sluggable;

class AdminVehicleReview extends Model {

    use Translatable;
    use Sluggable;

    const ACTIVE = 1;
    const IN_ACTIVE = 0;

    protected $fillable = ["vehicle_id", "review_type", 'slug', 'image', 'video', "status"];
    
    public $translatedAttributes = ["title", "excerpt", "description"];

    /**
     * Scope a query to only include active competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query) {
        return $query->where('status', self::ACTIVE);
    }

    /**
     * Scope a query to include given type of competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfActive($query, $type) {
        return $query->whereStatus($type);
    }

    /* 07-01 */

    public function AdminVehicleReviewTranslation() {

        return $this->hasMany(\Modules\AdminVehicleReviewManager\Entities\AdminVehicleReviewTranslation::class, 'admin_vehicle_review_id', 'id');
    }
	
	
    /*
     * make dynamic attribute for human readable time
     *
     * @return string
     * 
     */
    public function getPublishedAtAttribute() {
        return \Carbon\Carbon::parse($this->created_at)->format('d M Y');
    }

    /**
     * Get the sluggable.
     */
    public function sluggable() {
        return [
            'slug' => [
                'source' => 'title'
            ]
        ];
    }

}
