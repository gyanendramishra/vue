<?php

namespace Modules\AdminVehicleReviewManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Input;
use Modules\AdminVehicleReviewManager\Entities\AdminVehicleReview;
use Yajra\DataTables\Utilities\Request as DatatableRequest;

class AdminVehicleReviewsController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {

        if (\Auth::user('admin')->can('listing', \Modules\AdminVehicleReviewManager\Entities\AdminVehicleReview::class)) {
            $title = "Admin Vehicle Review";
            return view('adminvehiclereviewmanager::Admin.adminvehiclereview.index', compact('title'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $adminVehicleReview = AdminVehicleReview::query();

        if ($request->status != '') {
            $adminVehicleReview = $adminVehicleReview->where('status', $request->status);
        }
        if ($request->slug != '') {
            $slug = $request->slug;
            $adminVehicleReview = $adminVehicleReview->whereHas('AdminVehicleReviewTranslation', function($q) use($slug) {
                $q->where('title', 'LIKE', ucfirst($slug) . '%');
                $q->orWhere('title', 'LIKE', $slug . '%');
            });
        }
        $adminVehicleReview = $adminVehicleReview->get();

        return datatables()->of($adminVehicleReview)
                        ->addColumn('action', function ($adminVehicleReview) {
                            $actions = "";
                            if (\Auth::user('admin')->can('view', \Modules\AdminVehicleReviewManager\Entities\AdminVehicleReview::class)) {
                                $actions .= "<a title='View' href=\"" . route('admin.adminvehiclereview.show', ['id' => $adminVehicleReview->id]) . "\" class=\"\"><i class=\"rounded outline primary icon user profile link\"></i></a>";
                            }
                            if (\Auth::user('admin')->can('update', \Modules\AdminVehicleReviewManager\Entities\AdminVehicleReview::class)) {
                                $actions .= "&nbsp;<a title='Edit' href=\"" . route('admin.adminvehiclereview.edit', ['id' => $adminVehicleReview->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                            }
                            if (\Auth::user('admin')->can('delete', \Modules\AdminVehicleReviewManager\Entities\AdminVehicleReview::class)) {
                                $actions .= "&nbsp;<a title='Delete' data-id='" . $adminVehicleReview->id . "' class='Delete' data-set='{&quot;title&quot;: &quot;Delete Listing&quot;, &quot;parent&quot;: &quot;tr&quot;, &quot;option&quot;: &quot;deleteListing&quot;, &quot;id&quot;: 17, &quot;name&quot;: &quot;Infiniti Coupe Concept&quot;}''><i class='rounded outline icon negative trash link'></i></a>";
                            }
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        if (\Auth::user('admin')->can('create', \Modules\AdminVehicleReviewManager\Entities\AdminVehicleReview::class)) {
            $title = "Add Vehicle Review";
            return view('adminvehiclereviewmanager::Admin.adminvehiclereview.createOrUpdate', compact('title'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request) {
        $locales = config('app.locales');

        $valRule = [
            'review_type' => 'required',
            'image' => 'required_if:review_type,==,0|mimes:jpeg,jpg,png|max:5000',
            'video' => 'required_if:review_type,==,1',
        ];
        if ($request->review_type == 1) {
            $valRule = [
                'video' => 'url',
            ];
        }
        $valMessage = [
            'review_type.required' => 'The review type field is required.',
            'image.required_if' => 'The image field is required.',
            'image.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
            'image.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
            'video.required_if' => 'The video field is required.',
            'video.url' => 'The video field must be a valid URL.',
        ];

        foreach ($locales as $key => $value) {
            $valRule[$key . '_title'] = 'required|max:200|unique:admin_vehicle_review_translations,title|unique_space_check:admin_vehicle_review_translations,title';
            $valRule[$key . '_excerpt'] = 'required|max:200|unique:admin_vehicle_review_translations,excerpt|unique_space_check:admin_vehicle_review_translations,excerpt';
             $valRule[$key . '_app_description'] = 'required|max:2000';
            $valRule[$key . '_description'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_title.required'] = ' The title field is required in ' . $value . ' language.';
            $valMessage[$key . '_excerpt.required'] = ' The short description field is required in ' . $value . ' language.';
            $valMessage[$key . '_app_description.required'] = ' The App description field is required in ' . $value . ' language.';
            $valMessage[$key . '_app_description.max'] = ' Sorry, you can\'t add the app description more than the 2000 characters in ' . $value . ' language.';
            $valMessage[$key . '_description.required'] = ' The description field is required in ' . $value . ' language.';
            $valMessage[$key . '_title.max'] = ' Sorry, you can\'t add the title more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_title.unique'] = ' Title must be unique in ' . $value . ' language.';
            $valMessage[$key . '_title.unique_space_check'] = ' Title must be unique in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $review_data = array();

            foreach ($locales as $key => $value) {
                $review_data[$key]['title'] = $request->input($key . '_title');
                $review_data[$key]['description'] = $request->input($key . '_description');
                $review_data[$key]['excerpt'] = $request->input($key . '_excerpt');
                $review_data[$key]['app_description'] = $request->input($key.'_app_description');
            }
            $review_data['status'] = $request->input('status');
            $review_data['review_type'] = $request->input('review_type');


            if ($request->hasFile('image')) {
                $image = $request->file('image');

                $is_dest = "uploads/vehicleAdminReviews/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('image');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $review_data['image'] = $filenameOrig;
                }
            } else {
                $review_data['video'] = $request->input('video');
            }

            $ad = AdminVehicleReview::create($review_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.adminvehiclereview.index')->with('success', 'Admin Vehicle Review has been saved Successfully');
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show($id) {
        if (\Auth::user('admin')->can('view', \Modules\AdminVehicleReviewManager\Entities\AdminVehicleReview::class)) {
            $title = "Admin Vehicle Review Detail";
            $data = AdminVehicleReview::find($id);

            return view('adminvehiclereviewmanager::Admin.adminvehiclereview.show', compact('title', 'data'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id) {
        if (\Auth::user('admin')->can('update', \Modules\AdminVehicleReviewManager\Entities\AdminVehicleReview::class)) {
            $title = "Add Admin Vehicle Review";
            $data = AdminVehicleReview::where('id', '=', $id)->first();
            return view('adminvehiclereviewmanager::Admin.adminvehiclereview.createOrUpdate', compact('title', 'data'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id) {

        $locales = config('app.locales');
        if ($request->input('old_image') == '') {
            $valRule = ['image' => 'required_if:review_type,==,0|mimes:jpeg,jpg,png|max:5000'];
        }

        $valRule = [
            'review_type' => 'required',
            'video' => 'required_if:review_type,==,1',
        ];
       
        if($request->review_type==1) {
            $valRule = ['video' => 'url'];
        }
        $valMessage = [
            'review_type.required' => 'The review type field is required.',
            'image.required_if' => 'The image field is required.',
            'image.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
            'image.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
            'video.required_if' => 'The video field is required.',
            'video.url' => 'The video field must be a valid URL.',
        ];

        foreach ($locales as $key => $value) {
            $valRule[$key . '_title'] = 'required|max:200|unique:admin_vehicle_review_translations,title,' . $request->segment(3) . ',admin_vehicle_review_id|unique_space_check:admin_vehicle_review_translations,title,' . $request->segment(3) . ',admin_vehicle_review_id';
            $valRule[$key . '_excerpt'] = 'required|max:200';
            $valRule[$key . '_app_description'] = 'required|max:2000';
            $valRule[$key . '_description'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_title.required'] = ' The title field is required in ' . $value . ' language.';
            $valMessage[$key . '_excerpt.required'] = ' The short description field is required in ' . $value . ' language.';
            $valMessage[$key . '_app_description.required'] = ' The App description field is required in ' . $value . ' language.';
            $valMessage[$key . '_app_description.max'] = ' Sorry, you can\'t add the app description more than the 2000 characters in ' . $value . ' language.';
            $valMessage[$key . '_description.required'] = ' The description field is required in ' . $value . ' language.';
            $valMessage[$key . '_title.max'] = ' Sorry, you can\'t add the title more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_title.unique'] = ' Title must be unique in ' . $value . ' language.';
            $valMessage[$key . '_title.unique_space_check'] = ' Title must be unique in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {

            $adminvehiclereview_data = array();

            foreach ($locales as $key => $value) {
                $adminvehiclereview_data[$key]['title'] = $request->input($key . '_title');
                $adminvehiclereview_data[$key]['description'] = $request->input($key . '_description');
                $adminvehiclereview_data[$key]['excerpt'] = $request->input($key . '_excerpt');
                $adminvehiclereview_data[$key]['app_description'] = $request->input($key.'_app_description');
            }
            $adminvehiclereview_data['status'] = $request->input('status');
            $adminvehiclereview_data['review_type'] = $request->input('review_type');


            if ($request->hasFile('image')) {
                $image = $request->file('image');

                $is_dest = "uploads/vehicleAdminReviews/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('image');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $adminvehiclereview_data['image'] = $filenameOrig;
                }
            } else {
                $adminvehiclereview_data['video'] = $request->input('video');
            }

            $adminVehicleReview = AdminVehicleReview::find($id);

            $adminVehicleReview->update($adminvehiclereview_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.adminvehiclereview.index')->with('success', 'Vehicle Review has been updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id) {

        try {
            if (\Auth::user('admin')->can('delete', \Modules\AdminVehicleReviewManager\Entities\AdminVehicleReview::class)) {
                AdminVehicleReview::where('id', $id)->delete();

                $responce = ['status' => true, 'message' => 'This Vehicle Review has been deleted Successfully!'];
            } else {
                return view('Admin.not-authorised');
            }
        } catch (\Exception $e) {
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

}
