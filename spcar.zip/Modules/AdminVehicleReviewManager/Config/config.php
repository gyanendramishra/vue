<?php

return [
    'name' => 'AdminVehicleReviewManager'
];
