@extends('layouts.admin.app')


@section('content')
<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> 'Admin Vehicle Review','route'=> 'admin.adminvehiclereview.index'],['label' => 'View Admin Vehicle Review']]]) }}
    </div>
</div>
<div class="wojo-grid">
    <div class="wojo form segment">
        <table class="wojo two column table">
            <thead>
                <tr class="viewheading">
                    <td colspan="2"> <span><strong> {{ __('Manage Admin Vehicle Review ')}} </strong></span></td>
                    <td> <a style="float:right;" href="{{route('admin.adminvehiclereview.index')}}" class="btn btn-primary"><span>Back</span></a></td>
                </tr>

            </thead>
            @php $locales = config('app.locales');@endphp
            @foreach($locales as $key=>$val)
            <table class="wojo two column table">
                <thead>
                    <tr>
                        <th  colspan="2">{{  $val }} </th>

                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{{ __('Title') }}</td>
                        <td>{{ $data->translate($key)['title'] }}</td>
                    </tr>
                    <tr>
                        <td>{{ __('Short Description') }}</td>
                        <td>{!! $data->translate($key)['excerpt'] !!}</td>
                    </tr>
                    <tr>
                        <td>{{ __('Description') }}</td>
                        <td>{!! $data->translate($key)['description'] !!}</td>
                    </tr>
                </tbody>
            </table>
            @endforeach
            <table class="wojo two column table">
                <thead>
                    <tr>
                        <td  colspan="2"> <strong> {{ __( 'General Details' ) }} </strong> </th>

                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td><?= __('Created') ?></td>
                        <td>{{ $data->created_at->toFormattedDateString() }}</td>
                    </tr>

                    <tr>
                        <td>{{ __('Status') }}</td>
                        <td>{{ $data->status ? __('Active') : __('Inactive')  }}</td>
                    </tr>

                    <tr>
                        @if($data->review_type == 0)
                        <td>{{ __('Image') }}</td>
                        @php
                        $filepath = '/uploads/vehicleAdminReviews/';
                        @endphp

                        @if(!empty($data->image) && file_exists(public_path() . $filepath . $data->image))

                        <?php $imageurl = \App\Helpers\Helper::imageUrl(url($filepath . $data->image), '500', '200', '100'); ?>

                        @else
                        <?php $imageurl = ''; ?>
                        @endif

                        <td>


                            @if($imageurl!='')


                            <img height="200" width="200" src="{{ URL::asset('/uploads/vehicleAdminReviews/'.$data->image) }}">

                            @else
                            <img src="{{ URL::asset('/images/migration/no-image.png') }}">
                        </td>
                        @endif
                        @else
                        <td>{{ __('Video') }}</td>
                        <td><iframe width="560" height="315" src="{{$data->video}}"></iframe></td>
                        @endif
                    </tr>


                </tbody>
            </table>




    </div>
</div>


@stop