@extends('layouts.admin.app')

@section('title', !empty($category) ? 'Edit Category' : 'Add Category')
@push('styles')
{!! Html::style('css/wickedpicker.min.css') !!}
<link href="{{ asset('/css/migration/jquery-ui.css') }}" rel="stylesheet" />

@endpush
@section('content')

<div class="wojo-grid">
    <div class="wojo form segment">
        <div class="wojo secondary icon message"> 
            <h3>Auto Approval Settings</h3>
        </div>
        <div class="wojo secondary message">
            @if(isset($autoApproval)) 
            {{ Form::model($autoApproval, ['route' => ['admin.autoapproval.update', $autoApproval->id], 'method' => 'patch','files' => true,'id'=>'wojo_form','name'=>'wojo_form']) }}
            @else
            {{ Form::open(['route' => 'admin.autoapproval.store','files' => true,'id'=>'wojo_form','name'=>'wojo_form']) }}
            @endif

            <div class="container">
                @include('layouts.flash.alert')
                <div class="field">
                    <h3>Working Hours</h3>
                </div>
                <div class="three fields">


                    @for ($i = 0; $i < 7; $i++)

                    @php 
                    if($i==0)
                    $day='Monday';
                    else if($i==1)
                    $day='Tuesday';
                    else if($i==2)
                    $day='Wednesday';
                    else if($i==3)
                    $day='Thursday';
                    else if($i==4)
                    $day='Friday';
                    else if($i==5)
                    $day='Saturday';
                    else	
                    $day='Sunday';
                    @endphp
                    {{ Form::hidden("vehicleOffArr[$i][days]",$day)}}

                    <div class="field" >
                        <label class="checkbox">
                            {{ Form::checkbox("vehicleOffArr[$i][is_off]",1,(isset($autoApproval->workingTimes[$i]->is_off) && $autoApproval->workingTimes[$i]->is_off == 1)?false:true, array('id'=>'is_off_'.$i,'class'=>'is_off')) }}
                            <i></i>{{$day}}
                            
                        </label>
                        <span class="day-open-close-{{$i}}">{{(isset($autoApproval->workingTimes[$i]->is_off) && $autoApproval->workingTimes[$i]->is_off == 1)?'Closed':'Opened'}}</span>


                    </div>
                    <div class="field opening">
                        <label for="opening_hours"><strong>( {{ $day }}) </strong> {{ __('Opening Hours') }} </label>
                        {{ Form::text("vehicleOffArr[$i][opening_hours]",isset($autoApproval->workingTimes[$i]['opening_hours']) ? $autoApproval->workingTimes[$i]['opening_hours'] : '' , ['data-val'=>isset($autoApproval->workingTimes[$i]['opening_hours']) ? $autoApproval->workingTimes[$i]['opening_hours'] : '','class' => 'openingHours','id'=>'opening_hours_'.$i,'placeholder' => 'Opening Hours']) }}

                        @if($errors->has('opening_hours'))
                        <span class="help-block">{{ $errors->first('opening_hours') }}</span>
                        @endif

                    </div>

                    <div class="field closing">
                        <label for="name"><strong>( {{ $day }})</strong> {{ __('Closing Hours') }}</label>
                        {{ Form::text("vehicleOffArr[$i][closing_hours]",isset($autoApproval->workingTimes[$i]['closing_hours']) ? $autoApproval->workingTimes[$i]['closing_hours'] : '' , ['data-val'=>isset($autoApproval->workingTimes[$i]['closing_hours']) ? $autoApproval->workingTimes[$i]['closing_hours'] : '','class' => 'closingHours','id'=>'closing_hours_'.$i,'placeholder' => 'Closing Hours']) }}
                        @if($errors->has('closing_hours'))
                        <span class="help-block">{{ $errors->first('closing_hours') }}</span>
                        @endif

                    </div>
                    @endfor 
                </div>
                <div class="field">
                    <h3>Vehicle Working Hours</h3>
                </div>
                <div class="two fields">
                    <div class="field col-sm-3">

                        {{ Form::select('watch_hours', $workingHours,null, ['class'=>'watchHours','id'=>'watchHours','placeholder'=>'Select']) }}

                        @if($errors->has('watch_hours'))
                        <span class="help-block">{{ $errors->first('watch_hours') }}</span>
                        @endif

                    </div>
                </div>

                <div class="field">
                    <h3>Set Holidays</h3>
                </div>
                <div class="fields">
                 
                        @if(@$autoApproval->nonworkingDays)
                            @php $dates =  implode(',',@$autoApproval->nonworkingDays()->pluck('non_working_date','non_working_date')->toArray()); @endphp
                        @else
                            @php $dates = ''; @endphp
                        @endif
                   
                        {{ Form::text('non_working','' , ['class' => 'nonworkingDay date','id'=>'nonworkingDay','placeholder' => 'Working Day']) }}  
                      
                </div>

<!--                <div class="field">
                    <h3>Set Holidays</h3>
                </div>
                <div class="two fields">
                    <div class="field col-sm-3">

                        @if(@$autoApproval->nonworkingDays)
                        @php $dates =  implode(',',@$autoApproval->nonworkingDays()->pluck('non_working_date','non_working_date')->toArray()); @endphp
                        @else
                        @php $dates = ''; @endphp
                        @endif
                        {{ Form::text('non_working[]',$dates , ['class' => 'nonworkingDay hide','id'=>'nonworkingDay','placeholder' => 'Working Day']) }}  
                        {{ Form ::hidden('non_working_days',$dates,array('id'=>'non_working_days')) }}

                        @if($errors->has('non_working_days'))
                        <span class="help-block">{{ $errors->first('non_working_days') }}</span>
                        @endif

                    </div>
                </div>-->

            </div>

            <div class="container">


                <div class="wojo fitted divider"></div>
                <div class="wojo footer">
                    <button type="submit" data-action="updateAccount1" name="dosubmit1" class="wojo positive button">Save</button>


                </div>
            </div>
            {{ Form::close() }}
        </div>
    </div>
</div>
@stop
@push('scripts')
<script src="{{ asset('js/migration/jquery-ui.js') }}"></script>
<script src="https://cdn.rawgit.com/dubrox/Multiple-Dates-Picker-for-jQuery-UI/master/jquery-ui.multidatespicker.js"></script>

<script type="text/javascript">
    
$(document).ready(function () {

    
    var date = new Date();
    @if(@$autoApproval->nonworkingDays)
        var dates = "{{implode(',',@$autoApproval->nonworkingDays()->pluck('non_working_date','non_working_date')->toArray())}}" ;
    @else
         var dates = '';
    @endif
    var allDates =  dates.split( "," );

    $('.date').multiDatesPicker({
        dateFormat: "yy-mm-dd",
        addDates:allDates,
        beforeShowDay: function( date ) {
            var highlight = allDates;
            if( highlight ) {
                return [true, "event", 'Tooltip text'];
            } else {
                return [true, '', ''];
            }
        }
    });


    var openingHourse = '{{isset($autoApproval)?1:0}}';

    if (openingHourse == 1) {
        $(".opening .openingHours ").each(function (index, value) {
          if($(value).attr('data-val') == ''){
              $('#' + $(value).attr('id')).wickedpicker({
               now: "10:00",
                twentyFour: true,
                 });
          }else{
              $('#' + $(value).attr('id')).wickedpicker({
                now: $(value).attr('data-val'),
                twentyFour: true,
                });
          }
            
        });

        $(".closing .closingHours ").each(function (index, value) {
            if($(value).attr('data-val') == ''){
                 $('#' + $(value).attr('id')).wickedpicker({
               now: "17:00",
                twentyFour: true,
                 });
            }else{
                $('#' + $(value).attr('id')).wickedpicker({
                now: $(value).attr('data-val'),
                twentyFour: true,
            });
            }
            
        });
    } else {
        $('.openingHours').wickedpicker(
                {
                    now: "10:00",
                    twentyFour: true,
                    title: ''
                }
        );

        $('.closingHours').wickedpicker({
            now: "17:00",
            twentyFour: true,
            title: ''

        });
    }
    

    $(".is_off").on("click", function () {

        var tempId = $(this).attr('id');
        var id = tempId.replace("is_off_", "");
        if ($("#is_off_" + id).is(':checked')) {
            $('.day-open-close-'+id).text('Opened');
//            $("#opening_hours_" + id).css('background-color', '#F1F3F0');
//            $("#closing_hours_" + id).css('background-color', '#F1F3F0');
//            $("#opening_hours_" + id).attr("disabled", true);
//            $("#closing_hours_" + id).attr("disabled", true);

        } else {
                $('.day-open-close-'+id).text('Closed');
//            $("#opening_hours_" + id).css('background-color', '#ffffff');
//            $("#closing_hours_" + id).css('background-color', '#ffffff');
//            $("#opening_hours_" + id).attr("disabled", false);
//            $("#closing_hours_" + id).attr("disabled", false);
        }
    });

});
</script>
@endpush