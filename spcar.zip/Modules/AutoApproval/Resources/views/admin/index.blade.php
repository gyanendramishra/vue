@extends('layouts.admin.app')

@section('title', !empty($category) ? 'Edit Category' : 'Add Category')
@push('styles')
{!! Html::style('css/wickedpicker.min.css') !!}
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.css"/>
<style>
    .fc-today
    {
        background-color:inherit !important;
    }
    .unselectable{
     cursor: not-allowed;
}
</style>
@endpush
@section('content')

<div class="wojo-grid">
    <div class="wojo form segment">
        <div class="wojo secondary icon message"> 
            <h3>Auto Approval Settings</h3>
        </div>
        <div class="wojo secondary message">
            @if(isset($autoApproval)) 
            {{ Form::model($autoApproval, ['route' => ['admin.autoapproval.update', $autoApproval->id], 'method' => 'patch','files' => true,'id'=>'wojo_form','name'=>'wojo_form']) }}
            @else
            {{ Form::open(['route' => 'admin.autoapproval.store','files' => true,'id'=>'wojo_form','name'=>'wojo_form']) }}
            @endif

            <div class="container">
                @include('layouts.flash.alert')
                <div class="field">
                    <h5>Working Hours</h5>
                </div>
                <div class="three fields">


                    @for ($i = 0; $i < 7; $i++)

                    @php 
                    if($i==0)
                    $day='Sunday';
                    else if($i==1)
                    $day='Monday';
                    else if($i==2)
                    $day='Tuesday';
                    else if($i==3)
                    $day='Wednesday';
                    else if($i==4)
                    $day='Thursday';
                    else if($i==5)
                    $day='Friday';
                    else	
                    $day='Saturday';
                    @endphp
                    {{ Form::hidden("vehicleOffArr[$i][days]",$day)}}

                    <div class="field" >
                        <label class="checkbox">
                            {{ Form::checkbox("vehicleOffArr[$i][is_off]",1,(isset($autoApproval->workingTimes[$i]->is_off) && $autoApproval->workingTimes[$i]->is_off == 1)?false:true, array('id'=>'is_off_'.$i,'class'=>'is_off')) }}
                            <i></i>{{$day}}

                        </label>
                        <span class=" hours day-open-close-{{$i}}">{{(isset($autoApproval->workingTimes[$i]->is_off) && $autoApproval->workingTimes[$i]->is_off == 1)?'Closed':'Opened'}}</span>


                    </div>
                    <div class="field opening">
                        <label for="opening_hours"> {{ __('Opening Hours') }} </label>
                        {{ Form::text("vehicleOffArr[$i][opening_hours]",isset($autoApproval->workingTimes[$i]['opening_hours']) ? $autoApproval->workingTimes[$i]['opening_hours'] : '' , ['data-val'=>isset($autoApproval->workingTimes[$i]['opening_hours']) ? $autoApproval->workingTimes[$i]['opening_hours'] : '','class' => 'openingHours','id'=>'opening_hours_'.$i,'placeholder' => 'Opening Hours']) }}

                        @if($errors->has('opening_hours'))
                        <span class="help-block">{{ $errors->first('opening_hours') }}</span>
                        @endif

                    </div>

                    <div class="field closing">
                        <label for="name"> {{ __('Closing Hours') }}</label>
                        {{ Form::text("vehicleOffArr[$i][closing_hours]",isset($autoApproval->workingTimes[$i]['closing_hours']) ? $autoApproval->workingTimes[$i]['closing_hours'] : '' , ['data-val'=>isset($autoApproval->workingTimes[$i]['closing_hours']) ? $autoApproval->workingTimes[$i]['closing_hours'] : '','class' => 'closingHours','id'=>'closing_hours_'.$i,'placeholder' => 'Closing Hours']) }}
                        @if($errors->has('closing_hours'))
                        <span class="help-block">{{ $errors->first('closing_hours') }}</span>
                        @endif

                    </div>
                    @endfor 
                </div>
                <div class="field">
                    <h5>TIme slot for auto-approval of Vehicles</h5>
                </div>
                <div class="two fields">
                    <div class="field col-sm-3">

                        {{ Form::select('watch_hours', $workingHours,null, ['class'=>'watchHours','id'=>'watchHours']) }}

                        @if($errors->has('watch_hours'))
                        <span class="help-block">{{ $errors->first('watch_hours') }}</span>
                        @endif

                    </div>
                    
                    <div class="field right approval-button">

                        <button type="submit" data-action="updateAccount1" name="dosubmit1" class="wojo positive button">Save</button>
                    </div>
                </div>
            
                <div class="field">
                    <h5>Set Holidays</h5>
                </div>
                <div class="two fields">
                    <div class="field">
                        <div id="calendar"></div>
                    </div>
                </div>

            </div>


            {{ Form::close() }}
        </div>
    </div>
</div>
@stop
@push('scripts')
<script src="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.js"></script>
<script src='https://unpkg.com/@fullcalendar/core@4.4.0/main.min.js'></script>
<script src='https://unpkg.com/@fullcalendar/interaction@4.4.0/main.min.js'></script>
<script src='https://unpkg.com/@fullcalendar/daygrid@4.4.0/main.min.js'></script>
<script src='https://unpkg.com/@fullcalendar/timegrid@4.4.0/main.min.js'></script>

<script type="text/javascript">
    $('.unselectable').prop("disabled",true)
var dates = '@json($events)';
var date = $.parseJSON(dates);
console.log(date);
//date.push({
//      daysOfWeek: [0,6], //Sundays and saturdays
//      rendering:"background",
//      color: "#ff9f89",
//      overLap: false,
//      allDay: true,
//      className: 'unselectable',
//    });
    console.log(date);
document.addEventListener('DOMContentLoaded', function () {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
        plugins: ['interaction', 'dayGrid', 'timeGrid'],
        selectable: true,

        header: {
            left: 'prevYear,prev,next,nextYear',
            center: 'title',
            right: ''
        },
         buttonText: {
            prev: '< Prev',
            next: 'Next >',
            prevYear: '<< Year',
            nextYear: 'Year >>',
          },
        events: date,
        dateClick: function (info) {
            
            $.ajax({
                type: 'post',
                url: "{{ route('admin.autoapproval.addDates') }}",
                data: {date: info.dateStr, 'id': "{{$autoApproval->id}}"},
                dataType: "JSON",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function (data) {

                    var eventSources = calendar.getEventSources();
                    var len = eventSources.length;
                    for (var i = 0; i < len; i++) {
                        eventSources[i].remove();
                    }
                    calendar.addEventSource(data.data);
                    $('.fc-highlight-skeleton').find('.fc-highlight').remove();
                    calendar.refetchEvents();
                }
            });

        },

    });

    calendar.render();
});
$(document).ready(function () {


    var openingHourse = '{{isset($autoApproval)?1:0}}';

    if (openingHourse == 1) {
        $(".opening .openingHours ").each(function (index, value) {
            if ($(value).attr('data-val') == '') {
                $('#' + $(value).attr('id')).wickedpicker({
                    now: "10:00",
                    twentyFour: true,
                    title: 'Select hours'
                });
            } else {
                $('#' + $(value).attr('id')).wickedpicker({
                    now: $(value).attr('data-val'),
                    twentyFour: true,
                    title: 'Select hours'
                });
            }

        });

        $(".closing .closingHours ").each(function (index, value) {
            if ($(value).attr('data-val') == '') {
                $('#' + $(value).attr('id')).wickedpicker({
                    now: "17:00",
                    twentyFour: true,
                    title: 'Select hours'
                });
            } else {
                $('#' + $(value).attr('id')).wickedpicker({
                    now: $(value).attr('data-val'),
                    twentyFour: true,
                    title: 'Select hours'
                });
            }

        });
    } else {
        $('.openingHours').wickedpicker(
                {
                    now: "10:00",
                    twentyFour: true,
                    title: 'Select hours'
                }
        );

        $('.closingHours').wickedpicker({
            now: "17:00",
            twentyFour: true,
            title: 'Select hours'

        });
    }


    $(".is_off").on("click", function () {

        var tempId = $(this).attr('id');
        var id = tempId.replace("is_off_", "");
        if ($("#is_off_" + id).is(':checked')) {
            $('.day-open-close-' + id).text('Opened');

        } else {
            $('.day-open-close-' + id).text('Closed');

        }
    });

});


</script>
@endpush