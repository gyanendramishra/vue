<?php

namespace Modules\AutoApproval\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\AutoApproval\Entities\AutoApproval;
use Modules\AutoApproval\Http\Requests\AutoApprovalRequest;

class AutoApprovalController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        $title = 'Auto Approval Setting';
        if (\Auth::user('admin')->can('listing', \Modules\AutoApproval\Entities\AutoApproval::class)) {
            $workingHours = array();
            for ($i = 0; $i < 12; $i++) {
                $workingHours[''] = 'Select Working Hours';
                $workingHours[$i + 1] = $i + 1;
            }


            $autoApproval = AutoApproval::first();

            return view('autoapproval::admin.index', compact('workingHours', 'autoApproval', 'title'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        if (\Auth::user('admin')->can('create', \Modules\AutoApproval\Entities\AutoApproval::class)) {
            return view('autoapproval::create');
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request, AutoApprovalRequest $AutoApprovalRequest) {

        $autoApproval = new AutoApproval;
        $autoApproval->watch_hours = $request->input('watch_hours');

        if ($autoApproval->save()) {

            if ($request->has('vehicleOffArr')) {

                $autoApproval->workingTimes()->delete();
                $workingHours = [];

                foreach ($request->input('vehicleOffArr') as $k => $value) {
                    $workingHours[] = new \Modules\AutoApproval\Entities\WorkingTime([
                        'day' => isset($value['days']) ? $value['days'] : null,
                        'opening_hours' => isset($value['opening_hours']) ? date('h:i:s', strtotime(str_replace(' ', '', $value['opening_hours']))) : null,
                        'closing_hours' => isset($value['closing_hours']) ? date('h:i:s', strtotime(str_replace(' ', '', $value['closing_hours']))) : null,
                        'is_off' => isset($value['is_off']) ? $value['is_off'] : 0
                    ]);
                }


                $autoApproval->workingTimes()->saveMany($workingHours);
            }



            if ($request->has('non_working')) {

                $nonWorkingDays = [];

                $non_working_days = explode(',', $request->input('non_working'));

                foreach ($non_working_days as $k => $value) {

                    $nonWorkingDays[] = new \Modules\AutoApproval\Entities\NonWorkingDay([
                        'auto_approval_id' => $autoApproval->id,
                        'non_working_date' => date("y-m-d", strtotime($value)),
                    ]);
                }

                $autoApproval->nonworkingDays()->saveMany($nonWorkingDays);
            }

            return redirect()->route('admin.autoapproval.index')->with('success', 'Record has been updated Successfully');
        } else {
            
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id) {
        return view('autoapproval::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id) {
        if (\Auth::user('admin')->can('update', \Modules\AutoApproval\Entities\AutoApproval::class)) {
            return view('autoapproval::edit');
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, AutoApprovalRequest $AutoApprovalRequest, $id) {
        $autoApproval = AutoApproval::find($id);
        $autoApproval->watch_hours = $request->input('watch_hours');

        if ($autoApproval->save()) {

            if ($request->has('vehicleOffArr')) {
                $autoApproval->workingTimes()->delete();
                $workingHours = [];
                
                foreach ($request->input('vehicleOffArr') as $k => $value) {
                   
                        $workingHours[] = new \Modules\AutoApproval\Entities\WorkingTime([
                            'day' => isset($value['days']) ? $value['days'] : null,
                            'opening_hours' => ($value['opening_hours']) ? date('H:i:s', strtotime(str_replace(' ', '', $value['opening_hours']))) : @$autoApproval->opening_hours,
                            'closing_hours' => ($value['closing_hours']) ? date('H:i:s', strtotime(str_replace(' ', '', $value['closing_hours']))) : @$autoApproval->closing_hours,
                            'is_off' => isset($value['is_off']) ? 0 : 1
                        ]);
                   
                }


                
                $autoApproval->workingTimes()->saveMany($workingHours);
            }



            if ($request->has('non_working')) {
                $autoApproval->nonworkingDays()->delete();
                $nonWorkingDays = [];

                $non_working_days = explode(',', $request->input('non_working'));

                foreach ($non_working_days as $k => $value) {

                    $nonWorkingDays[] = new \Modules\AutoApproval\Entities\NonWorkingDay([
                        'auto_approval_id' => $autoApproval->id,
                        'non_working_date' => date("y-m-d", strtotime($value)),
                    ]);
                }

                $autoApproval->nonworkingDays()->saveMany($nonWorkingDays);
            }

            return redirect()->route('admin.autoapproval.index')->with('success', 'Record has been updated Successfully');
        } else {
            
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id) {
        //
    }

}
