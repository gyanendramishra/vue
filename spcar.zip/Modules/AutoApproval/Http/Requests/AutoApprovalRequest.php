<?php

namespace Modules\AutoApproval\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use \Illuminate\Http\Request;

class AutoApprovalRequest extends FormRequest {

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(Request $request) {
       
        return [
            'opening_hours.*' => 'required',
            'closing_hours.*' => 'required',
            'watch_hours' => 'required'
        ];
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages() {
        return [
            'watch_hours.required' => 'Please Select Working Hours ',
            'opening_hours.*.required' => 'Please Enter opening hours ',
            'closing_hours.*.required' => 'Please Enter closing hours'
            

        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

}
