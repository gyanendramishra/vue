<?php

namespace Modules\AutoApproval\Entities;

use Illuminate\Database\Eloquent\Model;

class NonWorkingDay extends Model
{
    protected $guarded = [];

    public function autoApproval() {

        return $this->belongsTo(\Modules\AutoApproval\Entities\AutoApproval::class);
    }

}
