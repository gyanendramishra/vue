<?php

namespace Modules\AutoApproval\Entities;

use Illuminate\Database\Eloquent\Model;

class AutoApproval extends Model
{
    protected $fillable = ['watch_hours'];

    public function workingTimes() {

        return $this->hasMany(\Modules\AutoApproval\Entities\WorkingTime::class);
    
    }
    public function nonworkingDays() {

        return $this->hasMany(\Modules\AutoApproval\Entities\NonWorkingDay::class);
    
    }
}
