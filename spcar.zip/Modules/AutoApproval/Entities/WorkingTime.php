<?php

namespace Modules\AutoApproval\Entities;

use Illuminate\Database\Eloquent\Model;

class WorkingTime extends Model
{
    protected $fillable = [
        'day',
        'opening_hours',
        'closing_hours',
        'is_off'
    ];
    
    public function autoApproval() {

        return $this->belongsTo(\Modules\AutoApproval\Entities\AutoApproval::class);
    }

}
