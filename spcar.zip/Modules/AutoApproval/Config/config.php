<?php

return [
    'name' => 'AutoApproval'
];
