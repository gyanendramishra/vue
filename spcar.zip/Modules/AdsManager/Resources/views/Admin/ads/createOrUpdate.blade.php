@extends('layouts.admin.app')
@section('title', !empty($ads) ? 'Edit Ad' : 'Add Ad')
@push('styles')
{!! Html::style('/css/migration/custom.css') !!}

@endpush
@section('content')

<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.ads.index'],['label' => !empty($ads) ? 'Edit Ad' : 'Add Ad' ]]]) }}
    </div>
</div>

<div class="wojo-grid">
    <div class="wojo form segment">
      <div class="wojo secondary icon message"><!--  <i class="lock icon"></i> -->
            <div class="content">
                <div class="header">  {{ !empty($ads) ? 'Edit Ad' : 'Add Ad' }}</div>
                <p>Here you can manage your Ads</p>
            </div>
        </div>
        @if(session()->has('success'))
        <div class="alert alert-success">
            {{ session()->get('success') }}
        </div>
        @endif

        @if(isset($ads))
        {{ Form::model(@$ads, ['route' => ['admin.ads.update', $ads->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}
        @else
        {{ Form::open(['route' => 'admin.ads.store','enctype'=>'multipart/form-data']) }}

        @endif

        @php

        $locales = config('app.locales');

        @endphp

        @include('layouts.flash.alert')
        <div class="wojo secondary message">
            <ul class="wojo tabs fixed clearfix">
                @foreach($locales as $key=>$val)
                <li class="{{ ($key=='en')?'active':'' }}">
                    
                </li>
                @endforeach
            </ul>
            @foreach($locales as $key=>$val)
            @if($key=='en')

            <div id="{{ $key.'_tab' }}" class="wojo tab item " style="{{ ($key=='en')?'display: block;':'' }}">
                <div class="two fields">
                    <div class="field required {{ $errors->has($key.'_title') ? 'has-error' : '' }}">


                        <label for="title">{{ __('Title') }} <span class="asterisk">*</span></label>

                        {{ Form::text($key.'_title', old($key.'_title', (isset($ads))?$ads->translate($key)['title']:"") , ['class' => '','placeholder' => 'Title']) }}

                        @if($errors->has($key.'_title'))
                        <span class="help-block">{{  $errors->first($key.'_title')  }}</span>
                        @endif

                    </div>
                    <div class="field {{ $errors->has($key.'image_type') ? 'has-error' : '' }}">
                        <label for="title">{{ __('Type') }}  </label>

                        {!!Form::select($key.'_image_type', [1=>'Image',2=>'Script'],  old($key.'_image_type', (isset($ads))?$ads->translate($key)['image_type']:""), ['class' => 'form-control image_type','data-value'=>$key])!!}

                        @if($errors->has($key.'_image_type'))
                        <span class="help-block">{{  $errors->first($key.'_image_type')  }}</span>
                        @endif

                    </div>
                </div>

                <div class="image_{{$key}} two field">

                    
                    
                     <div class="field required {{$errors->has($key.'_image')  ? 'has-error' : '' }}">
                         <label for="image">{{ __('Image') }} </label>
                        
                        @php
                            $filepath = '/uploads/adsImages/';
                        @endphp
                        
                        @if(isset($ads))
                        
                            @if(!empty($ads->translate($key)['image']) && file_exists(public_path() . $filepath . $ads->translate($key)['image']))
                            <input type="file" name="{{ $key }}_image" data-type="image" data-exist="{{ URL::asset('/uploads/adsImages/'.$ads->image) }}" accept="image/png, image/jpeg">
                                    <?php $imageurl = \App\Helpers\Helper::imageUrl(url($filepath . $ads->translate($key)['image']), '500', '200', '100'); ?>
                                    <!-- <img src="{{$imageurl}}"> -->
                            @endif

                        @else
                        
                            <input type="file" name="{{ $key }}_image" data-type="image" data-exist="{{ URL::asset('/images/migration/no-image.png') }}" accept="image/png, image/jpeg">
                        @endif

                    </div>
                    
                    
                    <div class="field required {{ $errors->has($key.'_url') ? 'has-error' : '' }}">

                        <label for="title">Url <span class="asterisk">*</span></label>
                        {{ Form::text($key.'_url', old($key.'_title', (isset($ads))?$ads->translate($key)['url']:"") , ['class' => 'form-control','placeholder' => 'Url']) }}
                        <span>Note: Url start with either http:// or https://.</span>
                        @if($errors->has($key.'_url'))

                        <span class="help-block">{{  $errors->first($key.'_url')  }}</span>
                        @endif
                    </div>
                </div>


                <div class="script_{{$key}} hide two field">
                    <div class="field required {{ $errors->has($key.'_image_scripts') ? 'has-error' : '' }}">
                        <label for="title">Ad Script <span class="asterisk"></span></label>
                        {{ Form::text($key.'_image_scripts', old($key.'_image_scripts', (isset($ads))?$ads->translate($key)['image_scripts']:"") , ['class' => 'form-control','placeholder' => 'Ad Script ']) }}
                        @if($errors->has($key.'_image_scripts'))
                        <span class="help-block">{{  $errors->first($key.'_image_scripts')  }}</span>
                        @endif
                    </div>
                </div>

            </div>


            <div class="two fields">
                <div class="field {{ $errors->has($key.'page_location_id') ? 'has-error' : '' }}">
                    <label for="title">{{ __('Page Location') }} </label>

                    {{ Form::select('page_location_id', $pageLocation,old('page_location_id'), ['class' => 'form-control']) }}

                    @if($errors->has('page_location_id'))
                    <span class="help-block">{{ $errors->first('page_location_id') }}</span>
                    @endif

                </div>
                <div class="field {{ $errors->has($key.'position_id') ? 'has-error' : '' }}">
                    <label for="title">{{ __('Position') }} </label>
                    <div class="wojo labeled icon input">
                        {{ Form::select('position_id', $position,old('position_id'), ['class' => 'form-control']) }}
                        @if($errors->has('position_id'))
                        <span class="help-block">{{ $errors->first('position_id') }}</span>
                        @endif
                    </div>
                </div>
            </div>
            <div class="two fields">
                <div class="field {{ $errors->has($key.'status') ? 'has-error' : '' }}">
                    <label for="title">{{ __('Status') }} </label>

                    {{ Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control']) }}
                    @if($errors->has('status'))
                    <span class="help-block">{{ $errors->first('status') }}</span>
                    @endif

                </div>

            </div>
            @endif
            @endforeach

            <div class="wojo fitted divider"></div>
            <div class="wojo footer">
                <button type="submit" data-action="updateAccount" name="dosubmit" class="wojo positive button">Save</button>
                <a href="{{ route('admin.ads.index') }}" class="wojo negative button" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
            </div>
            </form>
        </div>
    </div>

    @stop
    @section('per_page_style')
    <!--<link href="{{ asset('plugins/select2-develop/dist/css/select2.min.css') }}" rel="stylesheet" />-->
    <style>
        .ui-sortable-helper {
            display: table;
        }
    </style>
    @stop

    @push('scripts')

    <script>


        $(document).ready(function () {
            var key = $('.image_type').attr('data-value');

            var en_image_type = $('select[name="en_image_type"]').find(":selected").val();
            var kh_image_type = $('select[name="kh_image_type"]').find(":selected").val();

            if (en_image_type == 1) {
                $('.image_en').removeClass('hide')
                $('.script_en').addClass('hide')
            } else {
                $('.image_en').addClass('hide')
                $('.script_en').removeClass('hide')
            }
            if (kh_image_type == 1) {
                $('.image_kh').removeClass('hide')
                $('.script_kh').addClass('hide')
            } else {
                $('.image_kh').addClass('hide')
                $('.script_kh').removeClass('hide')
            }
            if (key == 'en') {
                if ($('.image_type option:selected').val() == 1) {
                    $('.image_' + key).removeClass('hide')
                    $('.script_' + key).addClass('hide')
                } else {
                    $('.image_' + key).addClass('hide')
                    $('.script_' + key).removeClass('hide')
                }
            }
            if (key == 'kh') {
                if ($('.image_type option:selected').val() == 1) {
                    $('.image_' + key).removeClass('hide')
                    $('.script_' + key).addClass('hide')
                } else {
                    $('.image_' + key).addClass('hide')
                    $('.script_' + key).removeClass('hide')
                }
            }


            $('.image_type').on('change', function () {

                var key = $(this).attr('data-value');
                if (key == 'en') {

                    if ($(this).val() == 1) {
                        $('.image_' + key).removeClass('hide')
                        $('.script_' + key).addClass('hide')
                    } else {
                        $('.image_' + key).addClass('hide')
                        $('.script_' + key).removeClass('hide')
                    }
                }
                if (key == 'kh') {
                    if ($(this).val() == 1) {
                        $('.image_' + key).removeClass('hide')
                        $('.script_' + key).addClass('hide')
                    } else {
                        $('.image_' + key).addClass('hide')
                        $('.script_' + key).removeClass('hide')
                    }
                }

            });
        })


    </script>
    @endpush