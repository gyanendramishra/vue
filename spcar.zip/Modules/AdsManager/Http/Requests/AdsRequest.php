<?php

namespace Modules\AdsManager\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use \Illuminate\Http\Request;

class AdsRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(Request $request)
    {
         
        if($request->_method == 'PATCH'){
           $rules = [
                'title' => 'required|min:3|max:200',
                'page_location_id' => 'required',
                'position_id' => 'required',
                'url' => 'required|url',
                'image'=>'image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048'
            ]; 
            return $rules;
        }else{

            $rules = [
                'title' => 'required|min:3|max:200',
                'page_location_id' => 'required',
                'position_id' => 'required',
                'url' => 'required|url',
    			'image'=>'required|image|mimes:jpeg,png,jpg,bmp,gif,svg|max:2048'
            ];
            
            return $rules;
        }
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'title.required'  => 'Please enter title!',
            'title.min'  => 'Ad Title must be at least 3 characters long!',
            'page_location_id.required' => 'Please select location!',           
            'position.required'  => 'Please select position!',         
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
}
