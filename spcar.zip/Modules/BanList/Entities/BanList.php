<?php

namespace Modules\BanList\Entities;

use Illuminate\Database\Eloquent\Model;

class BanList extends Model
{
    protected $fillable = ['ban_item', 'ban_type', 'comment'];
}
