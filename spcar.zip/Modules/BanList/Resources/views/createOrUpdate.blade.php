@extends('layouts.admin.app')
@section('title', !empty($banList) ? 'Edit BanList' : 'Add BanList')
@section('content')
<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.banlist.index'],['label' => !empty($banList) ? 'Edit BanList' : 'Add BanList' ]]]) }}
    </div>
</div>
<div class="wojo-grid">
    @if(session()->has('success'))
    <div class="alert alert-success">
        {{ session()->get('success') }}
    </div>
    @endif
    <div class="wojo form segment">
        <div class="wojo secondary icon message"> 
            <div class="content">
                <div class="header">  {{ !empty($banList) ? 'Edit BanList' : 'Add BanList' }}  </div>
            </div>
        </div>
        @if(isset($banList))
        {{ Form::model($banList, ['route' => ['admin.banlist.update', $banList->id], 'method' => 'patch']) }}
        @else
        {{ Form::open(['route' => 'admin.banlist.store']) }}
        @endif
        @php
        $locales = config('app.locales');
        @endphp

        @include('layouts.flash.alert')

        <div class="wojo secondary message">
            <div class="two fields">
                <div class="field">
                    <div class="required {{ $errors->has('ban_item') ? 'has-error' : '' }}">
                        <label for="ban_item">{{ __('Ban Item') }} <span class="asterisk">*</span></label>
                        {{ Form::text('ban_item', old('ban_item'), ['class' => 'form-control','placeholder' => 'Ban Item']) }}
                        @if($errors->has('ban_item'))
                        <span class="help-block">{{ $errors->first('ban_item') }}</span>
                        @endif
                    </div>
                </div>
                <input type="hidden" name="ban_type" value="IP Address">
                
            </div>
            <div class="two fields ">
                <div class="field">
                    <div class="">
                        <label for="comment">{{ __('Comment') }} </label>
                        {{ Form::textarea('comment', old('comment'), ['class' => 'form-control','placeholder' => 'Comment']) }}
                    </div>
                </div>
            </div>
            <div class="wojo fitted divider"></div>
            <div class="wojo footer">
                <button type="submit" data-action="updateAccount" name="dosubmit" class="wojo positive button">Save</button>
                <a href="{{ route('admin.banlist.index') }}" class="wojo negative button" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
            </div>
        </div>

        {{ Form::close() }}
    </div>
</div>
@stop
