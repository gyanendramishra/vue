@extends('layouts.admin.app')
@push('styles')
{!! Html::style('/css/bootstrap.min.css') !!}
{!! Html::style('css/datatables.net-bs/dataTables.bootstrap.min.css') !!}
@endpush

@section('content')
<div id="crumbs" class="clearfix"> 
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> \Request::route()->getName()],['label' => 'List Cms Page']]]) }}
    </div>
</div>
<div class="wojo-grid">
    <div class="wojo secondary icon message">
        <div class="content">
            <div class="header"> {{  __( 'List Pages' ) }}    </div>
        </div>
    </div>
    @include('layouts.flash.alert')
    <div class="wojo quaternary segment">
        <div class="header">Filtering Options</div>
        <div class="content">
            <div class="wojo form">
                <div class="three fields">
                    <div class="field">
                        <label>Status</label>
                        {{ Form::select('status', ['' => 'Select',1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control','id'=>'statuss','data-cover'=>'true']) }}
                    </div>        
                </div>
            </div>
        </div>
    </div>
    <div class="wojo tertiary segment">
        <div class="header clearfix">
            <span>{{ __('List Pages') }}</span> 
            @can('create',  \Modules\CmsManager\Entities\Page::class)
            <!--            <a class="wojo large top right detached action label wojo-tooltip-element" data-content="Add Category" href="{{ route('admin.pages.create') }}">
                            <i class="icon plus"></i>
                        </a>-->
            @endcan
        </div>


        {{ Form::hidden('searchslug', '',array('id'=>'searchslug')) }}

        <table class="wojo sortable table" id="pages-datatable" data-table="pages">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Title</th>                              
                    <th>Created At</th>
                    <th class="no-sort">Actions</th>
                </tr>
            </thead>
        </table>


    </div>
    <div id="msgholder"></div>
</div>
@stop

@push('scripts')
<script type="text/javascript">
    jQuery(function ($) {
        var t = $('#pages-datatable').DataTable({
            processing: true,
            serverSide: true,
            aaSorting: [[0, 'desc']],
            language: {

                sLengthMenu: "_MENU_",
                search: "<i class='find icon'></i>",
                searchPlaceholder: "Search...",

            },
            ajax: {
                url: "{{ route('admin.page.ajax.list') }}",
                type: 'GET',
                data: function (d) {

                    d.status = $('#statuss').val();
                    d.slug = $('#searchslug').val();
                }
            },
            columns: [
                {data: 'id', name: 'id'},
                {data: 'title', name: 'title'},

                {data: 'created_at', name: 'created_at'},
                {data: 'action', name: 'action'}
            ],
            "deferRender": true,
            "columnDefs": [
                {
                    "targets": 'no-sort',
                    "orderable": false,
                },
                {
                    "targets": 2,
                    "data": "created_at",
                    "render": function (data, type, full, meta) {
                        return moment(data).format('DD MMMM, YYYY ');
                    }
                },
            ],

        })
        t.on('order.dt search.dt', function () {
            t.column(0, {search: 'applied', order: 'applied'}).nodes().each(function (cell, i) {
                cell.innerHTML = i + 1;
            });
        });
        $('#statuss').on('change', function () {

            $('#pages-datatable').DataTable().draw(true);
        });

        $(document).on('click', ".delete-it", function () {
            var ths = $(this);
            bootbox.confirm("Are you sure want to delete this page?", function (result) {
                if (result)
                    window.location = ths.attr('data-url');
            });
        });

        var alphabet = $('<div class="alphabet"/>').append('Search: ');

        $('<span class="clear active"/>')
                .data('letter', '')
                .html('None')
                .appendTo(alphabet);

        for (var i = 0; i < 26; i++) {

            var letter = String.fromCharCode(65 + i);

            $('<span/>')
                    .data('letter', letter)
                    .html(letter)
                    .appendTo(alphabet);
        }

        alphabet.insertBefore(t.table().container());

        alphabet.on('click', 'span', function () {

            alphabet.find('.active').removeClass('active');
            $(this).addClass('active');
            _alphabetSearch = $(this).data('letter');
            $("#searchslug").val(_alphabetSearch);

            t.draw();
        });
    })
</script>
@endpush