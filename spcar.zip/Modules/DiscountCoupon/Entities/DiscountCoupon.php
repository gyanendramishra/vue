<?php

namespace Modules\DiscountCoupon\Entities;

use Illuminate\Database\Eloquent\Model;

class DiscountCoupon extends Model
{
    protected $fillable = ['name','code','discount','discount_type','start_date','end_date','is_publish'];
    
   
}
