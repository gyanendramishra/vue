<?php

namespace Modules\AdminRole\Entities;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;

class AdminRole extends Model {

    use Sluggable;

    protected $fillable = ['slug', 'name', 'status'];

    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function sluggable() {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }

     /**
     * Get the roles that associated with the user.
     */
    public function adminRolePermissions() {
        return $this->belongsToMany('Modules\AdminRole\Entities\AdminPermission');
    }
}
