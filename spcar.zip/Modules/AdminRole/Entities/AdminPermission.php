<?php

namespace Modules\AdminRole\Entities;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;

class AdminPermission extends Model {

    protected $fillable = ['module', 'display_name', 'name', 'status'];

}
