<?php

namespace Modules\AdminRole\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use \Modules\AdminRole\Entities\AdminRole;
use \Modules\AdminRole\Entities\AdminPermission;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use Modules\AdminRole\Http\Requests\AdminRoleRequest;

class AdminRolesController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        if (\Auth::user('admin')->can('listing', \Modules\AdminRole\Entities\AdminRole::class)) {
            return view('adminrole::index');
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $loginUser = \Auth::user('admin');
        $roles = AdminRole::where('name','!=','admin');
        if ($request->status != '') {
            $roles = $roles->where('status', $request->status);
        }

        $roles = $roles->get();

        return datatables()->of($roles)
                        ->addColumn('action', function ($roles) use($loginUser) {
                            $actions = "";
                            if (\Auth::user('admin')->can('update', \Modules\AdminRole\Entities\AdminRole::class)) {
                                $actions .= "&nbsp;<a title='Edit' href=\"" . route('admin.adminrole.edit', ['id' => $roles->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                            }
                            if (\Auth::user('admin')->can('delete', \Modules\AdminRole\Entities\AdminRole::class)) {
                                $actions .= "&nbsp;<a title='Delete' data-id='" . $roles->id . "' class='Delete' data-set='{&quot;title&quot;: &quot;Delete Role&quot;, &quot;parent&quot;: &quot;tr&quot;, &quot;option&quot;: &quot;deleteListing&quot;, &quot;id&quot;: 17, &quot;name&quot;: &quot;Infiniti Coupe Concept&quot;}''><i class='rounded outline icon negative trash link'></i></a>";
                            }
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        if (\Auth::user('admin')->can('create', \Modules\AdminRole\Entities\AdminRole::class)) {
            $associated_permissions[] = '';
            $title = "Add Admin Role";
            $permissions = AdminPermission::where('status', 1)->get();
            $permissions = $permissions->groupBy('display_name');
            return view('adminrole::createOrUpdate', compact('title', 'permissions', 'associated_permissions'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(AdminRoleRequest $request) {
        try {
            \DB::beginTransaction();

            $adminRole = new AdminRole;
            $adminRole->name = $request->name;
            $adminRole->status = $request->status;
            if ($adminRole->save()) {
                $adminRole->adminRolePermissions()->attach($request->permission_id);
                \DB::commit();
                return redirect()->route('admin.adminrole.index')->with('success', 'Role has been saved Successfully');
            } else {
                return back()->withError('Oops! Something went wrong.')->withInput();
            }
        } catch (Exception $ex) {
            return back()->withError($e->getMessage())->withInput();
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id) {
        if (\Auth::user('admin')->can('view', \Modules\AdminRole\Entities\AdminRole::class)) {
            return view('adminrole::show');
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id) {
        if (\Auth::user('admin')->can('update', \Modules\AdminRole\Entities\AdminRole::class)) {
            $title = "Add Admin Role";
            $adminRole = AdminRole::find($id);
            $permissions = AdminPermission::where('status', 1)->get();
            $permissions = $permissions->groupBy('display_name');
            $associated_permissions = $adminRole->adminRolePermissions()->pluck('admin_permission_id')->toArray();
            return view('adminrole::createOrUpdate', compact('title', 'permissions', 'adminRole', 'associated_permissions'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(AdminRoleRequest $request, $id) {
        try {
            \DB::beginTransaction();

            $adminRole = AdminRole::find($id);
            $adminRole->name = $request->name;
            $adminRole->status = $request->status;
            if ($adminRole->save()) {
                $adminRole->adminRolePermissions()->sync($request->permission_id);
                \DB::commit();
                return redirect()->route('admin.adminrole.index')->with('success', 'Role has been updated Successfully');
            } else {
                return back()->withError('Oops! Something went wrong.')->withInput();
            }
        } catch (Exception $ex) {
            return back()->withError($e->getMessage())->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id) {
        try {

            if (\Auth::user('admin')->can('delete', \Modules\AdminRole\Entities\AdminRole::class)) {
                \DB::beginTransaction();
                \Modules\StaffManager\Entities\AdminUser::whereHas('adminRoleUsers', function($q) use($id) {
                    $q->where('admin_role_id', $id);
                })->delete();
                if (AdminRole::where('id', $id)->delete()) {
                    \DB::commit();
                    $responce = ['status' => true, 'message' => 'This role has been deleted Successfully!'];
                } 
                \DB::rollBack();
            } else {
                return view('Admin.not-authorised');
            }
        } catch (\Exception $e) {
            \DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

}
