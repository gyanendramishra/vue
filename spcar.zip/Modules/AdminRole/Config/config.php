<?php

return [
    'name' => 'AdminRole'
];
