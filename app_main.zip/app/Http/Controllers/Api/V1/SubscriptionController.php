<?php

namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\SubscriptionManager\Entities\Subscription;

class SubscriptionController extends Controller {

    public $successStatus = 200;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request) {
        //$authInformation = $request->header();
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
    }

    /**
     * @desc lists all subscription plan according to logged in user
     *
     * @return \Illuminate\Http\Response
     */
    public function lists(Request $request) {
        try {
            $userType = \Auth::user()->roles()->first();
            if ($userType->slug != 'buyer') {
                $subscriptions =  new \App\Http\Resources\Collection\SubscriptionCollection(Subscription::where('user_type',$userType->name)->withTranslation()->get());
                $data['data'] = $subscriptions;
                $data['status'] = true;
                $data['code'] = 200;
                return response()->json($data);
            } else {
                $data['data'] = (object) [];
                $data['status'] = false;
                $data['message'] = "Something went wrong.";
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {
            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

}
