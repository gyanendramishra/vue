<?php

namespace App\Http\Controllers\Frontend\Api;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\VehicleRepository;
use Modules\VehicleManager\Entities\Vehicle;
use Modules\VehicleManager\Entities\VehicleImage;
use App\Http\Requests\Frontend\VehiclePhotosRequest;
use App\Http\Requests\Frontend\VehicleDetailsRequest;
use App\Http\Requests\Frontend\VehicleFeaturesRequest;
use App\Http\Requests\Frontend\VehicleGeneralInfoRequest;

class ManageVehicleController extends Controller {

    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(VehicleRepository $vehicleRepository) {
        $this->vehicleRepository = $vehicleRepository;
    }

    
    /**
     * Store or update resource in storage.
     *
     * @param  \App\Http\Requests\Frontend\VehicleGeneralInfoRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function manageGeneralInfo(VehicleGeneralInfoRequest $request) {
        try {
            \DB::beginTransaction();

            if($request->has('vehicle_slug')){
                $vehicle = Vehicle::whereSlug($request->vehicle_slug)->first();
            }else{
                
                $vehicle = new Vehicle();
                $vehicle->user_id = \Auth::guard('user')->id();
                $vehicle->role = \Auth::guard('user')->user()->role;
                $vehicle->status = 0;
            }
            $vehicle->title = $request->title;
            $vehicle->category_id = $request->type;
            $vehicle->makes_id = $request->make_id;
            $vehicle->models_id = $request->model_id;
            $vehicle->badge_id = $request->badge_id;
            $vehicle->series_id = $request->series_id;
            $vehicle->body_styles_id = $request->body_type_id;
            $vehicle->fuel_types_id = $request->fuel_type_id;
            $vehicle->drive_types_id = $request->drive_type_id;
            $vehicle->transmissions_id = $request->transmission_id;
            $vehicle->doors = $request->doors;
            $vehicle->seats = $request->seats;
            $vehicle->gears = $request->gears;
            $vehicle->cylinders_id = $request->cylinders;
            $vehicle->month_build = $request->month_built;
            $vehicle->year_build = $request->year_built;
            $vehicle->year_complied = $request->year_complied;
            $vehicle->turbo = $request->turbo;
            $vehicle->engine_capacity = $request->engine_capacity;
            $vehicle->chassis_number = $request->chassis_number;
            if($vehicle->steps < 1){
                $vehicle->steps = 1;
            }
            // save vehicle
            if ($vehicle->save()) {

                // DB commit
                \DB::commit();

                return response()->json([
                            "status" => "success",
                            "slug"   => $vehicle->slug,
                            "message" => __('frontend.VEHICLE_GENERAL_INFO_SAVED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Store or update resource in storage.
     *
     * @param  \App\Http\Requests\Frontend\VehicleFeaturesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function manageFeatures(VehicleFeaturesRequest $request) {
        try {
            \DB::beginTransaction();

            $vehicle = Vehicle::whereSlug($request->vehicle_slug)->first();
            $vehicle->vehicleFeatures()->sync($request->features);
            if($vehicle->steps < 2){
                $vehicle->steps = 2;
            }
            // save vehicle
            if ($vehicle->save()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "slug"   => $vehicle->slug,
                            "message" => __('frontend.VEHICLE_FEATURES_SAVED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __($e->getMessage())
                            ], 200);
        }
    }

    /**
     * Store or update resource in storage.
     *
     * @param  \App\Http\Requests\Frontend\VehicleDetailsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function manageDetails(VehicleDetailsRequest $request) {
        try {
            \DB::beginTransaction();

            $vehicle = Vehicle::whereSlug($request->vehicle_slug)->first();
            // save detail
            $vehicle->address = $request->address;
            $vehicle->country = $request->country;
            $vehicle->state = $request->state;
            $vehicle->city = $request->city;
            $vehicle->postcode = $request->postcode;
            $vehicle->latitude = $request->latitude;
            $vehicle->longitude = $request->longitude;
            $vehicle->odometer = $request->odometer;
            $vehicle->price = $request->sale_price;
            $vehicle->discount_price = $request->discounted_price;
            $vehicle->interior_colour_id = $request->interior_color_id;
            $vehicle->exterior_colour_id = $request->exterior_color_id;
            $vehicle->lifestyle_id = $request->lifestyle_id;
            $vehicle->plate_number = $request->registration_plate_number;
            $vehicle->expiry_month = $request->registration_expiry_month;
            $vehicle->expiry_year = $request->registration_expiry_year;
            $vehicle->fuel_economy_id = $request->fuel_economy_id;
            $vehicle->phone = $request->contact_phone_number;
            $vehicle->written_off = $request->is_written_off;
            $vehicle->roadworthy = $request->is_roadworthy;
            $vehicle->is_registered = $request->is_car_registered;
            // prepair locales
            $vehicle->translations()->saveMany([
                new \Modules\VehicleManager\Entities\VehicleTranslation([
                    "locale"=>'en',
                    "description"=> $request->english_comment
                ]),
                new \Modules\VehicleManager\Entities\VehicleTranslation([
                    "locale"=>'kh',
                    "description"=> $request->khmer_comment
                ])
            ]);
            
            if($vehicle->steps < 3){
                $vehicle->steps = 3;
            }
            // save vehicle
            if ($vehicle->save()) {
                // DB commit
                \DB::commit();
                
                return response()->json([
                            "status" => "success",
                            "slug"   => $vehicle->slug,
                            "message" => __('frontend.VEHICLE_DETAILS_SAVED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }
    /**
     * Store or update resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function managePhotos(Request $request) {
        try {
            \DB::beginTransaction();
            $vehicle = Vehicle::whereSlug($request->vehicle_slug)->first();
            // save detail
            if($vehicle->steps < 4){
                $vehicle->steps = 4;
            }
            // save vehicle
            if ($vehicle->save()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "slug"   => $vehicle->slug,
                            "message" => __('frontend.VEHICLE_PHOTOS_SAVED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }
    /**
     * Delete resource in storage.
     *
     * @param  \App\Http\Requests\Frontend\VehiclePhotosRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function savePhotos(VehiclePhotosRequest $request) {
        try {
            \DB::beginTransaction();
            $vehicle = Vehicle::whereSlug($request->vehicle_slug)->first();
            if($request->has('image_id')){
                $image = VehicleImage::find($request->image_id);
                // delete old image
                \Storage::disk('public')->delete($image->image);
            }else{
                $image = new VehicleImage();
            }
            $file = $request->file('file');
            
            // create image
            $img = \Image::make($file);
            // and insert a watermark for example
            $img->insert(public_path('frontend/images/watermark.png'), 'bottom-right', 50, 50);
            // Store img
            $fileName = ($vehicle->vehicle_images->count() + 1).'_'.$file->getClientOriginalName();
            //$img = \Storage::disk('public')->put('vehicle/'.$fileName, $img);
            $img->save(public_path('storage/vehicle/') . $fileName);
            $image->vehicle_id = $vehicle->id;
            $image->image = $fileName;
            $image->image_type = ($request->image_type === 1) ? 'front' : 'rear';
            $image->sort_order = ($vehicle->vehicle_images->count() + 1);
            $image->caption = "image";

            // save vehicle image
            if ($image->save()) {
                // DB commit
                \DB::commit();
                return response()->json([
                    "status" => "success",
                    "id"   => $image->id,
                    "message" => __('frontend.VEHICLE_PHOTOS_SAVED')
                        ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()//__('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Delete resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function deletePhotos(Request $request, VehicleImage $vehicleImage) {
        try {
            \DB::beginTransaction();
            // delete old image
            \Storage::disk('public')->delete($vehicleImage->image);
            // delete vehicle image
            if ($vehicleImage->delete()) {
                // DB commit
                \DB::commit();
                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.VEHICLE_PHOTOS_DELETED')
                                ], 200);
            }
            throw new \Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

}
