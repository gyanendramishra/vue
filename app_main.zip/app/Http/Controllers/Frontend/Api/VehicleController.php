<?php

namespace App\Http\Controllers\Frontend\Api;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Mail\Frontend\VehicleInquiryMail;
use App\Mail\Frontend\VehicleReportAdMail;
use App\Repositories\VehicleRepository;
use App\Http\Requests\Frontend\VehicleInquiryRequest;

class VehicleController extends Controller {

    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(VehicleRepository $vehicleRepository) {
        $this->vehicleRepository = $vehicleRepository;
    }

    /**
     * Get vehicle types.
     *
     * @return \Illuminate\Http\Response
     */
    public function getTypes() {
        try {
            $types = $this->vehicleRepository->getAllType();
            return response()->json([
                        "status" => "success",
                        "data" => $types
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get makes.
     *
     * @return \Illuminate\Http\Response
     */
    public function getMakes() {
        try {
            $makes = $this->vehicleRepository->getAllMake();
            return response()->json([
                        "status" => "success",
                        "data" => $makes
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get body types.
     *
     * @return \Illuminate\Http\Response
     */
    public function getBodyTypes() {
        try {
            $bodyTypes = $this->vehicleRepository->getAllBodyType();
            return response()->json([
                        "status" => "success",
                        "data" => $bodyTypes
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get fuel types.
     *
     * @return \Illuminate\Http\Response
     */
    public function getFuelTypes() {
        try {
            $fuelTypes = $this->vehicleRepository->getAllFuelType();
            return response()->json([
                        "status" => "success",
                        "data" => $fuelTypes
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get models by make slug.
     *
     * @param  (int) $slug
     * @return \Illuminate\Http\Response
     */
    public function getModelsByMakeSlug($slug) {
        try {
            $models = $this->vehicleRepository->getMakeModelBySlug($slug);
            return response()->json([
                        "status" => "success",
                        "data" => $models
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __($e->getMessage())
                            ], 200);
        }
    }

    /**
     * Get models by make id.
     *
     * @param  (int) $id
     * @return \Illuminate\Http\Response
     */
    public function getModelsByMakeId($id) {
        try {
            $models = $this->vehicleRepository->getMakeModelById($id);
            return response()->json([
                        "status" => "success",
                        "data" => $models
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __($e->getMessage())
                            ], 200);
        }
    }

    /**
     * Get badges by model slug.
     *
     * @param  (int) $slug
     * @return \Illuminate\Http\Response
     */
    public function getBadgesByModelSlug($slug) {
        try {
            $badges = $this->vehicleRepository->getModelBadgeBySlug($slug);
            return response()->json([
                        "status" => "success",
                        "data" => $badges
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __($e->getMessage())
                            ], 200);
        }
    }

    /**
     * Get badges by id.
     *
     * @param  (int) $id
     * @return \Illuminate\Http\Response
     */
    public function getBadgesByModelId($id) {
        try {
            $badges = $this->vehicleRepository->getModelBadgeById($id);
            return response()->json([
                        "status" => "success",
                        "data" => $badges
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __($e->getMessage())
                            ], 200);
        }
    }

    /**
     * Get series by badge.
     *
     * @param  (int) $badgeId
     * @return \Illuminate\Http\Response
     */
    public function getSeriesByBadgeId($badgeId) {
        try {
            $series = $this->vehicleRepository->getBadgeSeriesById($badgeId);
            return response()->json([
                        "status" => "success",
                        "data" => $series
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get cities by state.
     *
     * @param  (int) $stateId
     * @return \Illuminate\Http\Response
     */
    public function getCitiesByStateId($stateId) {
        try {
            $cities = $this->vehicleRepository->getStateCitiesById($stateId);
            return response()->json([
                        "status" => "success",
                        "data" => $cities
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __($e->getMessage())
                            ], 200);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Frontend\VehicleInquiryRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function saveVehicleQuery(VehicleInquiryRequest $request) {
        try {
            \DB::beginTransaction();
            $inquiry = new \Modules\VehicleEnquiresManager\Entities\VehicleEnquiry($request->all());
            $inquiry->vehicle_id = $request->vehicle_id;
            $inquiry->name = $request->name;
            $inquiry->email = $request->email;
            $inquiry->phone = $request->phone;
            $inquiry->postcode = $request->post_code;
            $inquiry->details = $request->message;
            $inquiry->is_trade_in = $request->is_trade_in;
            $inquiry->is_dealer_response = $request->is_dealer_response ? 1 : 0;

            if ($inquiry->save()) {
                // DB commit
                \DB::commit();

                // Send inquiry mail to admin
                if (!empty(config('get.ADMIN_EMAIL'))) {
                    \Mail::to(config('get.ADMIN_EMAIL'))->send(new VehicleInquiryMail($inquiry));
                }
                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.VEHICLE_INQUIRY_SAVED')
                                ], 200);
            }

            \DB::rollBack();
            throw new Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __($e)
                            ], 200);
        }
    }

    /**
     * Toggle favourite cars in storage.
     *
     * @param  vehical id  $id
     * @return \Illuminate\Http\Response
     */
    public function toogleFavourite($id) {
        try {
            $fav = 0;
            \DB::beginTransaction();
            if (\Auth::guard('user')->check()) {
                $vehicalFav = \Auth::guard('user')->user()->favouriteVehicles()->wherePivot('vehicle_id', $id)->first();

                if ($vehicalFav) {
                    if ($vehicalFav->pivot->is_favourite == 1) {
                        \Auth::guard('user')->user()->favouriteVehicles()->updateExistingPivot($id, ['is_favourite' => 0]);
                        $fav = 0;
                        $msg = 'frontend.VEHICLE_FAVOURITE_UNSAVED';
                    } else {
                        \Auth::guard('user')->user()->favouriteVehicles()->updateExistingPivot($id, ['is_favourite' => 1]);
                        $fav = 1;
                        $msg = 'frontend.VEHICLE_FAVOURITE_SAVED';
                    }
                } else {

                    \Auth::guard('user')->user()->favouriteVehicles()->attach($id, ['is_favourite' => 1]);
                    $fav = 1;
                    $msg = 'frontend.VEHICLE_FAVOURITE_SAVED';
                }

                \DB::commit();
                return response()->json([
                            "data" => $fav,
                            "status" => "success",
                            "message" => __($msg)
                                ], 200);
            }
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __($e)
                            ], 200);
        }
    }

    /**
     *  REPORT ADS FOR VEHICLE in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function reportAd(Request $request) {
        try {
            if (!empty(config('get.ADMIN_EMAIL'))) {
               
                \Mail::to(config('get.ADMIN_EMAIL'))->send(new VehicleReportAdMail($request->all()));
            }
            return response()->json([
                        "status" => "success",
                        "message" => __('frontend.REPORT_AD_LOGGED')
                            ], 200);
        } catch (Exception $ex) {
            return response()->json([
                        "status" => "error",
                        "message" => __($e)
                            ], 200);
        }
    }

}
