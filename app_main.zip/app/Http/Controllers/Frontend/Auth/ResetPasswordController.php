<?php

namespace App\Http\Controllers\Frontend\Auth;

use App\Http\Requests\Frontend\ResetPasswordRequest;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use \Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\User;
use Carbon\Carbon;
use Aloha\Twilio\Twilio;

class ResetPasswordController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest:user');
    }

    /**
     * Handle password reset.
     *
     * @param  App\Http\Requests\ResetPasswordRequest  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response
     */
    public function resetPassword(ResetPasswordRequest $request) {
        try {

            $query = User::where('phone', $request->phone);
            if ($query->exists()) {
                $user = $query->first();

                $user->password = bcrypt($request->password);
                $user->save();
                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.RESET_PASSWORD_SUCCESS')
                                ], 200);
            } else {
                return response()->json([
                            "status" => "error",
                            "message" => __('frontend.RESET_PASSWORD_FAILED')
                                ], 200);
            }
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

}
