<?php

namespace App\Http\Controllers\Frontend\Auth;

use App\Http\Requests\Frontend\ForgotPasswordRequest;
use App\Http\Controllers\Controller;
use App\Mail\Frontend\ResetPasswordMail;
use \Illuminate\Http\Request;
use App\User;
use Aloha\Twilio\Twilio;

class ForgotPasswordController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest:user');
    }

    /**
     * Display a forgot password view.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {

        return view('frontend.auth.passwords.email');
    }

    /**
     * Handle a send reset link email request to the application.
     *
     * @param  App\Http\Requests\ForgotPasswordRequest  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response
     */
    public function sendResetLinkEmail(ForgotPasswordRequest $request) {

        $RandomNumber = rand(100000, 999999);
        $account_id = env('TWILIO_SID');
        $auth_token = env('TWILIO_TOKEN');
        $from_phone_number = env('TWILIO_FROM');
        $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
        try {
            $query = User::where('phone', $request->phone);
            if ($query->exists()) {
                $user = $query->first();
               
                if ($user->is_otp_verified == 0) {
                 
                    \App\UserVerification::firstOrCreate([
                        'user_id' => $user->id
                    ], [
                        'user_id' => $user->id,
                        'otp' => '123456',
                        'otp_type' => 2,
                    ]);
                    
                    $str = '123456' . ' is your one time password (OTP) for car market phone verification';
                    if (!$request->countryCode) {
                        $phoneNo = $user->country_code . $user->phone;
                    } else {
                        $phoneNo = $request->countryCode . $user->phone;
                    }

                    $twilio->message($phoneNo, $str);

                    return response()->json([
                                "status" => "success",
                                "code" => 105,
                                "message" => __('frontend.RESET_FAILED_DUE_TO_ACCOUNT_VERIFICATION')
                                    ], 200);
                }
                \App\UserVerification::firstOrCreate([
                        'user_id' => $user->id
                    ], [
                        'user_id' => $user->id,
                        'otp' => '123456',
                        'otp_type' => 2,
                    ]);

                $str = '123456' . ' is your one time password (OTP) for car market phone verification';

                $phoneNo = $request->countryCode . $user->phone;
                $twilio->message($phoneNo, $str);

                return response()->json([
                            "status" => "success",
                            "message" => __('frontend.FORGOT_PASSWORD_SUCCESS')
                                ], 200);
            } else {
                return response()->json([
                            "status" => "error",
                            "message" => __('frontend.FORGOT_PASSWORD_EMAIL_NOT_EXISTS')
                                ], 200);
            }
        } catch (\Exception $e) {
            
            return response()->json([
                        "status" => "error",
                        "message" => $e->getMessage()//__('frontend.OOPS')
                            ], 200);
        }
    }

}
