<?php

namespace App\Http\Controllers\Admin;

use Modules\Admin\Http\Requests\EmailTemplateRequest;
use App\EmailTemplate;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Input;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use File;
use DB;
use Config;

class EmailTemplatesController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {

        $title = 'Email Templates Listing';
        return view('Admin.email_templates.index', compact('title'));
    }

    /**
     * Feeding list of roles to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $emailtemplates = Emailtemplate::get();

        return datatables()->of($emailtemplates)
                        ->addColumn('action', function ($emailtemplates) {
                            $actions = '';
                            $actions .= "<a href=\"" . route('admin.emailtemplates.show', ['id' => $emailtemplates->id]) . "\" class=\"\"><i class=\"rounded outline primary icon user profile link\"></i></a>";
                            $actions .= "&nbsp;<a href=\"" . route('admin.emailtemplates.edit', ['id' => $emailtemplates->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";

                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        $title = 'Add New Email Template';
        return view('Admin.email_templates.form', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Modules\Admin\Http\Requests\EmailTemplateRequest $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) {


        $locales = config('app.locales');
        $valRule = [
            'type' => 'required|unique:email_templates,type,' . $request->segment(3),
            'status' => 'required'
        ];

        foreach ($locales as $key => $value) {
            $valRule[$key . '_subject'] = 'required|max:255';
            $valRule[$key . '_template'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_subject.required'] = ' The subject field is required in '. $value .' language.';
            $valMessage[$key . '_subject.max'] = ' Sorry, you can\'t add the subject more than the 255 characters in '. $value .' language.';
            $valMessage[$key . '_template.required'] = ' The Template field is required in '. $value .' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['subject'] = $request->input($key . '_subject');
                $article_data[$key]['template'] = $request->input($key . '_template');
            }
            $article_data['status'] = $request->input('status');
            $article_data['type'] = $request->input('type');

            $EmailTemplate = EmailTemplate::create($article_data);


            if ($EmailTemplate) {
                return redirect()->route('admin.emailtemplates.index')->with('success', 'Email template has been added successfully!');
            } else {
                return redirect()->back();
            }
        } catch (Exception $ex) {
            dd($ex);
            return redirect()->back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \Modules\Admin\Entities\EmailTemplate $emailtemplate
     * @return \Illuminate\Http\Response
     */
    public function show($id) {
        $emailtemplate = Emailtemplate::find($id);

        $title = 'View Email Template';
        // $emailtemplate->template = File::get(resource_path("views/emails/" . $emailtemplate->type . ".blade.php"));
        return view('Admin.email_templates.show', compact('title', 'emailtemplate'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \Modules\Admin\Entities\EmailTemplate $emailtemplate
     * @return \Illuminate\Http\Response
     */
    public function edit($id) {

        $row = EmailTemplate::find($id);
        $title = 'Edit Email Template';
        return view('Admin.email_templates.form', compact('title', 'row'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Modules\Admin\Http\Requests\EmailTemplateRequest $request
     * @param  \Modules\Admin\Entities\EmailTemplate $emailtemplate
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id) {

        $locales = config('app.locales');
        $valRule = [
            'type' => 'required|unique:email_templates,type,' . $request->segment(3),
            'status' => 'required'
        ];

        foreach ($locales as $key => $value) {
            $valRule[$key . '_subject'] = 'required|max:255';
            $valRule[$key . '_template'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_subject.required'] = ' The subject field is required in '. $value .' language.';
            $valMessage[$key . '_subject.max'] = ' Sorry, you can\'t add the subject more than the 255 characters in '. $value .' language.';
            $valMessage[$key . '_template.required'] = ' The Template field is required in '. $value .' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['subject'] = $request->input($key . '_subject');
                $article_data[$key]['template'] = $request->input($key . '_template');
            }
            $article_data['status'] = $request->input('status');
            $article_data['type'] = $request->input('type');

            $EmailTemplate = EmailTemplate::findOrFail($id);
            if ($EmailTemplate->update($article_data)) {
                return redirect()->route('admin.emailtemplates.index')->with('success', 'Email template has been updated successfully!');
            } else {
                return redirect()->back();
            }
        } catch (Exception $ex) {
            return redirect()->back();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Modules\Admin\Http\Requests\EmailTemplateRequest $request
     * @param  \Modules\Admin\Entities\EmailTemplate $emailtemplate
     * @return \Illuminate\Http\Response
     */
    public function destroy(EmailTemplateRequest $request, EmailTemplate $emailtemplate) {
        $response = [];
        if ($request->ajax()) {
            if ($emailtemplate->delete()) {
                $response['status'] = "success";
                $response['message'] = __('admin::email_template.deleted');
            } else {
                $response['status'] = "error";
                $response['message'] = __('admin::email_template.not_deleted');
            }
        }

        return \Response::json($response);
    }

    /**
     * Remove the multiple resource from storage.
     *
     * @param  object  $request
     * @return \Illuminate\Http\Response
     */
    public function destroy_multiple(Request $request) {
        $response = [];
        if ($request->ajax()) {
            $ids = $request->input('ids');
            if (!empty($ids)) {
                $page = Page::whereIn('id', $ids);
                if ($page->delete()) {
                    $response['status'] = "success";
                    $response['message'] = "Pages has been deleted.";
                } else {
                    $response['status'] = "error";
                    $response['message'] = "Somthing went wrong try again later.";
                }
            }
        }

        return \Response::json($response);
    }

    /**
     * Show a list of all the pages formatted for Datatables.
     *
     * @param Modules\Admin\Http\Requests\EmailTemplateRequest $request
     * @param \Yajra\DataTables\DataTables $datatables
     * @return \Illuminate\Http\Response JSON
     */
    public function dataList(EmailTemplateRequest $request, DataTables $datatables) {
        if ($request->ajax()) {
            \DB::statement(DB::raw('set @rownum=0'));
            $builder = EmailTemplate::query()->select(\DB::raw('@rownum := @rownum + 1 AS rank'), 'id', 'type', 'subject', 'is_active', 'updated_at');
            return $datatables->eloquent($builder)
                            ->orderColumn('id $1', 'type $1', 'subject $1', 'is_active $1', 'updated_at $1')
                            ->filter(function ($query) use ($request) {

                                if ($request->has('search')) {
                                    $keyword = $request->search['value'];
                                    $query->where('id', 'like', "%$keyword%")
                                    ->orWhere('type', 'like', "%$keyword%")
                                    ->orWhere('subject', 'like', "%$keyword%");
                                }
                            })
                            ->editColumn('id', function($model) {
                                return $model->rank;
                            })
                            ->editColumn('type', function($model) {
                                return link_to(route('admin.emailtemplates.show', $model->id), config('constants.email_template_types')[$model->type], [], true);
                            })
                            ->editColumn('is_active', function($model) {
                                return ($model->is_active == Config::get('constants.BOOLEAN_STATUS.TRUE')) ? '<span class="label label-xs label-success"> Active </span>' : '<span class="label label-danger"> In Active </span>';
                            })
                            ->addColumn('actions', function($model) {
                                return "<a href='" . route('admin.emailtemplates.edit', $model->id) . "' class='btn btn-sm blue tooltips' title='" . __('admin::email_template.edit_link.title') . "'><i class='fa fa-edit'></i></a>";
                            })
                            ->rawColumns([0, 1, 2, 5])
                            ->make(true);
        }
    }

}
