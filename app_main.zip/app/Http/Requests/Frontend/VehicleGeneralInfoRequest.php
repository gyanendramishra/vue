<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class VehicleGeneralInfoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('user')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title'            =>'required',
            'type'             =>'required',
            'make_id'          =>'required',
            'model_id'         =>'required',
            'badge_id'         =>'required',
            'series_id'        =>'required',
            'body_type_id'     =>'required',
            'fuel_type_id'     =>'required',
            'drive_type_id'    =>'required',
            'transmission_id'  =>'required',
            'doors'            =>'required',
            'seats'            =>'required',
            'gears'            =>'required',
            'cylinders'        =>'required',
            'year_built'       =>'required',
            'month_built'      =>'required',
            'year_complied'    =>'required',
            'turbo'            =>'required',
            'engine_capacity'  =>'required',
            'chassis_number'   =>'required'
        ];
    }
}
