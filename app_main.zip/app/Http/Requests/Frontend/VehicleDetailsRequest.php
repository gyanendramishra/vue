<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class VehicleDetailsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('user')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'vehicle_slug'              =>'required',
            'address'                   =>'required',
            'country'                   =>'required',
            'state'                     =>'required',
            'city'                      =>'required',
            'postcode'                  =>'required',
            'latitude'                  =>'required',
            'longitude'                 =>'required',
            'odometer'                  =>'required',
            'sale_price'                =>'required',
            'discounted_price'          =>'required',
            'interior_color_id'         =>'required',
            'exterior_color_id'         =>'required',
            'lifestyle_id'              =>'required',
            'registration_plate_number' =>'required',
            'registration_expiry_month' =>'required',
            'registration_expiry_year'  =>'required',
            'fuel_economy_id'           =>'required',
            'contact_phone_number'      =>'required',
            'is_written_off'            =>'required',
            'is_roadworthy'             =>'required',
            'is_car_registered'         =>'required'
        ];
    }
}
