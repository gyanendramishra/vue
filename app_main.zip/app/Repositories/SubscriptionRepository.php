<?php

namespace App\Repositories;

use Illuminate\Http\Request;
use \Illuminate\Database\Eloquent\Collection;
use App\Repositories\Interfaces\SubscriptionInterface;
use Modules\SubscriptionManager\Entities\Subscription;

class SubscriptionRepository implements SubscriptionInterface {
    /* Get user saved vehicles */

    public function getSubscriptionPlansAsPerUserRoles($roles) {
        $userRoles = [];
        if($roles->isNotEmpty()){
            foreach($roles as $role){
                $userRoles[] = $role;
            }
            return Subscription::select(
                'id', 
                'duration', 
                'duration_type', 
                'price',
                'total_on_sale_count',
                'total_featured_count',
                'total_listing_count'
            )
            ->whereIn('user_type', $userRoles)
            ->active()
            ->with([
                'translations:id,subscription_id,locale,title,description',
            ])
            ->get();
        }
        return Collection::make(new Subscription);;
    }

}
