<?php
namespace App\Repositories\Interfaces;

use Illuminate\Http\Request;

interface UserInterface {
    
    public function getSavedVehicle();
    
    public function getMyVehicle();
    
    public function getTotalVehicle();
    
    public function getTotalFeaturedVehicle();
    
    public function getTotalVehiclesInquiry();
    
    public function getTotalFavouriteVehicles();

  
}
