<?php

namespace App\Mail\Frontend;

use App\EmailTemplate;
use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class VehicleReportAdMail extends Mailable {

    use Queueable,
        SerializesModels;
    
    public $vehicleAd;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($vehicleAd)
    {
        $this->vehicleAd = $vehicleAd;
    }
   
    /**
     * Build the message.
     *
     * @return $this
     */
    public function build() {
       
        $vehical = \Modules\VehicleManager\Entities\Vehicle::find($this->vehicleAd['vehicle_id']);

        $et = EmailTemplate::whereType('vehicle_report_ad_mail_to_admin')
                ->with('translations:id,email_template_id,locale,subject,template')
                ->first(['id']);
        if ($et) {
            $subject = $et->subject;
            $body = $et->template;
            $body = str_replace('##VEHICLE_TITLE##', $vehical->title, $body);
            $body = str_replace('##VEHICLE_CODE##', $vehical->id, $body);
            $body = str_replace('##NAME##', $this->vehicleAd['name'], $body);
            $body = str_replace('##EMAIL##', $this->vehicleAd['email'], $body);
            $body = str_replace('##PHONE##', $this->vehicleAd['phone'], $body);
            $body = str_replace('##TYPE##', \Config('constants.REPORT_FOR.' . $this->vehicleAd['type']), $body);
            $body = str_replace('##MESSAGE##', $this->vehicleAd['message'], $body);

            $this->subject($subject)
                    ->view('frontend.emails.template')
                    ->with(['template' => $body]);
        }
    }

}
