<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\NewsManager\\Providers\\NewsManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\NewsManager\\Providers\\NewsManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);