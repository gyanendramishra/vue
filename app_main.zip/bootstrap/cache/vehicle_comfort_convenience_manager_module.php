<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleComfortConvenienceManager\\Providers\\VehicleComfortConvenienceManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleComfortConvenienceManager\\Providers\\VehicleComfortConvenienceManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);