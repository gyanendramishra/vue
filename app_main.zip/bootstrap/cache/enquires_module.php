<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\EnquiresManager\\Providers\\EnquiresServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\EnquiresManager\\Providers\\EnquiresServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);