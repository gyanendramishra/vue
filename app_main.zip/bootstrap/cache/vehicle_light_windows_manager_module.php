<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleLightWindowsManager\\Providers\\VehicleLightWindowsManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleLightWindowsManager\\Providers\\VehicleLightWindowsManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);