<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CmsManager\\Providers\\CmsManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CmsManager\\Providers\\CmsManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);