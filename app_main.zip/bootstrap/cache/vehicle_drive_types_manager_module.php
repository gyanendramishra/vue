<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleDriveTypesManager\\Providers\\VehicleDriveTypesManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleDriveTypesManager\\Providers\\VehicleDriveTypesManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);