<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleFeatureManager\\Providers\\VehicleFeatureManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleFeatureManager\\Providers\\VehicleFeatureManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);