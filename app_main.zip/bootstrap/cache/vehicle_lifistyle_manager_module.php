<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleLifistyleManager\\Providers\\VehicleLifistyleManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleLifistyleManager\\Providers\\VehicleLifistyleManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);