<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleManager\\Providers\\VehicleManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleManager\\Providers\\VehicleManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);