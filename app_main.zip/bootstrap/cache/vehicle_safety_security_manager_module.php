<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleSafetySecurityManager\\Providers\\VehicleSafetySecurityManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleSafetySecurityManager\\Providers\\VehicleSafetySecurityManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);