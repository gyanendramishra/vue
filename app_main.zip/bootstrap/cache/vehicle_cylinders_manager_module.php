<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleCylindersManager\\Providers\\VehicleCylindersManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleCylindersManager\\Providers\\VehicleCylindersManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);