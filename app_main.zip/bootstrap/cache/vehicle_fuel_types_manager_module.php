<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleFuelTypesManager\\Providers\\VehicleFuelTypesManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleFuelTypesManager\\Providers\\VehicleFuelTypesManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);