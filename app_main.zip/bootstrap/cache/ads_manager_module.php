<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AdsManager\\Providers\\AdsManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AdsManager\\Providers\\AdsManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);