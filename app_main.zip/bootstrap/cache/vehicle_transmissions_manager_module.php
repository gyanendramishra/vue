<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleTransmissionsManager\\Providers\\VehicleTransmissionsManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleTransmissionsManager\\Providers\\VehicleTransmissionsManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);