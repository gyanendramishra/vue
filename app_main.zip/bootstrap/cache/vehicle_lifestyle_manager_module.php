<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleLifestyleManager\\Providers\\VehicleLifestyleManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleLifestyleManager\\Providers\\VehicleLifestyleManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);