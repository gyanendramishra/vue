<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\EmailManager\\Providers\\EmailManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\EmailManager\\Providers\\EmailManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);