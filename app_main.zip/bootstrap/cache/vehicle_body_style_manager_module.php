<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleBodyStyleManager\\Providers\\VehicleBodyStyleManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleBodyStyleManager\\Providers\\VehicleBodyStyleManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);