<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleEngineCapacityManager\\Providers\\VehicleEngineCapacityManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleEngineCapacityManager\\Providers\\VehicleEngineCapacityManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);