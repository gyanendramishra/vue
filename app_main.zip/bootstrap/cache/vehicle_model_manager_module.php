<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleModelManager\\Providers\\VehicleModelManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleModelManager\\Providers\\VehicleModelManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);