<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleWheelsTyreManager\\Providers\\VehicleWheelsTyreManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleWheelsTyreManager\\Providers\\VehicleWheelsTyreManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);