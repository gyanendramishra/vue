<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleSeriesManager\\Providers\\VehicleSeriesManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleSeriesManager\\Providers\\VehicleSeriesManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);