<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleBodyManager\\Providers\\VehicleBodyManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleBodyManager\\Providers\\VehicleBodyManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);