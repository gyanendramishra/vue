<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleEnquiresManager\\Providers\\VehicleEnquiresServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleEnquiresManager\\Providers\\VehicleEnquiresServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);