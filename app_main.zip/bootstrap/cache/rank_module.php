<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Rank\\Providers\\RankServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Rank\\Providers\\RankServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);