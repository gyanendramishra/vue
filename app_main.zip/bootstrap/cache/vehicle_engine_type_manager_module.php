<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleEngineTypeManager\\Providers\\VehicleEngineTypeManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleEngineTypeManager\\Providers\\VehicleEngineTypeManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);