<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SettingManager\\Providers\\SettingManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SettingManager\\Providers\\SettingManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);