<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleExteriorManager\\Providers\\VehicleExteriorManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleExteriorManager\\Providers\\VehicleExteriorManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);