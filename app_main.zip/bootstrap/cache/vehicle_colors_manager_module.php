<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleColorsManager\\Providers\\VehicleColorsManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleColorsManager\\Providers\\VehicleColorsManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);