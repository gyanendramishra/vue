<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleAudioCommunicationManager\\Providers\\VehicleAudioCommunicationManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleAudioCommunicationManager\\Providers\\VehicleAudioCommunicationManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);