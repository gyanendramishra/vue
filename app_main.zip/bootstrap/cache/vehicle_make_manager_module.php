<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VehicleMakeManager\\Providers\\VehicleMakeManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VehicleMakeManager\\Providers\\VehicleMakeManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);