<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Vehicle\\Providers\\VehicleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Vehicle\\Providers\\VehicleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);