@extends('layouts.admin.app')
@section('title','View Ad Detail')
@section('content')
<style>
    .box{border-top: 0px !important;}
</style>
<div class="content-wrapper">
    <!-- Content Header (Ad header) -->
    <section class="content-header">
        <h1>
            Manage Subscription
        </h1>
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.subscription.index'],['label' => 'View Subscription Detail']]]) }}
    </section>

    <section class="content">
        <!-- Default box -->
        <div class="box">

            <div class="box-header with-border">

                <a href="{{route('admin.subscription.index')}}" class="btn btn-default pull-right" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
            </div>
            <div class="box-body">
                @php $locales = config('app.locales');@endphp
                @foreach($locales as $key=>$val)
                <div class="box-header with-border">
                    <h3 class="box-title">{{  $val }}</h3>
                
                <table class="table table-hover table-striped">


                    <tr>
                        <th scope="row">{{ __('Title') }}</th>
                        <td>{{ $subscription->translate($key)['title'] }}</td>
                    </tr>
                    <tr>
                        <th scope="row">{{ __('Description') }}</th>
                        <td>{{ $subscription->translate($key)['description'] }}</td>
                    </tr>



                </table>
                    </div>
                @endforeach
                
                <div class="box-header with-border">
                    <h3 class="box-title">General Details</h3>
                <table class="table table-hover table-striped">

                    <tr>
                        <th scope="row">{{ __('Period') }}</th>
                        <td>{{ $subscription->period.' '.$subscription->period_type }}</td>
                    </tr>
                    <tr>
                        <th scope="row">{{ __('Is private') }}</th>
                        <td>{{ $subscription->is_private==1?'Yes':'No' }}</td>
                    </tr>
                    <tr>
                        <th scope="row">{{ __('Is featured') }}</th>
                        <td>{{ $subscription->is_featured==1?'Yes':'No' }}</td>
                    </tr>
                    <tr>
                        <th scope="row">{{ __('Listings') }}</th>
                        <td>{{ $subscription->listings }}</td>
                    </tr>
                    <tr>
                        <th scope="row">{{ __('Price') }}</th>
                        <td>{{ $subscription->price }}</td>
                    </tr>

                    <tr>
                        <th scope="row"><?= __('Created') ?></th>
                        <td>{{ $subscription->created_at->toFormattedDateString() }}</td>
                    </tr>
                    <tr>
                        <th scope="row">{{ __('Modified') }}</th>
                        <td>{{ $subscription->updated_at->toFormattedDateString() }}</td>
                    </tr>
                    <tr>
                        <th scope="row">{{ __('Status') }}</th>
                        <td>{{ $subscription->status ? __('Active') : __('Inactive')  }}</td>
                    </tr>
                    @if(!empty($subscription->image))
                    <tr>
                        <th scope="row">{{ __('Image') }}</th>
                        @php
                        $filepath = '/uploads/subscriptionImages/';
                        @endphp
                        @if(!empty($subscription->image) && file_exists(public_path() . $filepath . $subscription->image))
                        <?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url($filepath . $subscription->image), '500', '200', '100'); ?>
                        <td>
                            <img src="{{$imageurl}}">
                        </td>
                        @endif

                    </tr>
                    @endif

                </table>
                </div>
            </div>
            <div class="box-footer">
                <a href="{{route('admin.subscription.index')}}" class="btn btn-default pull-left" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
            </div>
            <!-- /.box-body -->

            <!-- /.box-footer-->
        </div>
        <!-- /.box -->

    </section>
    <!-- /.content -->
</div>
@stop
