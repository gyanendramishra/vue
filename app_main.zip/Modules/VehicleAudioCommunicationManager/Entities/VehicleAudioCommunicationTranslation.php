<?php

namespace Modules\VehicleAudioCommunicationManager\Entities;

use Illuminate\Database\Eloquent\Model;

class VehicleAudioCommunicationTranslation extends Model {

    public $timestamps = false;
    protected $fillable = ['name'];

    /**
     * Get the comments for the blog post.
     */
}
