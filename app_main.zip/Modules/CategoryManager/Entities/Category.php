<?php

namespace Modules\CategoryManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use \Dimsav\Translatable\Translatable;

class Category extends Model {

    use Translatable;

    const ACTIVE = 1;
    const IN_ACTIVE = 0;

    public $translatedAttributes = ['name'];

    use Sluggable;

    protected $fillable = ["slug", "status", "icon"];

    /**
     * Get the comments for the blog post.

     * Scope a query to only include active competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query) {
        return $query->where('status', self::ACTIVE);
    }

    /**
     * Scope a query to include given type of competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfActive($query, $type) {
        return $query->whereStatus($type);
    }

    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function sluggable() {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }
    public function vehicles() {

        return $this->hasMany(\Modules\VehicleManager\Entities\Vehicle::class);
    }

}
