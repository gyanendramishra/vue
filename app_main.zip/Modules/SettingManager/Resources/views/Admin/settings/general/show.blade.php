@extends('layouts.admin.app')


@section('content')
<div id="crumbs" class="clearfix">
    <div class="wojo breadcrumb">
      <ol class="breadcrumb">
                <li><a href="{{url('admin/dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="{{route('setting.general')}}">{{ __("Settings") }}</a></li>
                <li><a href="javascript:void(0)" class="active">View General Setting</a></li>
            </ol>
    </div>
  </div>
<div class="wojo-grid">
    <div class="wojo form segment">
        <div class="wojo secondary icon message"> 
        <div class="content">
          <div class="header"> {{ __('Manage Setting')}} </div>
          
          
        </div>
      </div>
     
        <table class="wojo two column table">
          <thead>
            <tr>
              <th  colspan="2"> <strong> {{ __( 'Setting Detail' ) }} </strong> </th>
             
            </tr>
          </thead>
          <tbody>
             
               <tr>
                            <td>Title</td>
                            <td>{{$settings->title}}</td>
                        </tr>
                        <tr>
                            <td>Manager</td>
                            <td>{{$settings->manager}}</td>
                        </tr>
                        <tr>
                            <td>Constant/Slug</td>
                            <td>{{$settings->slug}}</td>
                        </tr>
                        <tr>
                            <td>Config Value</td>
                            <td>{{$settings->config_value}}</td>
                        </tr>
                        <tr>
                            <td>Field Type</td>
                            <td>{{$settings->field_type}}</td>
                        </tr>
                        <tr>
                            <td>Created</td>
                            <td>{{$settings->created_at}}</td>
                        </tr>
                        <tr>
                            <td>Modified</td>
                            <td>{{$settings->updated_at}}</td>
                        </tr>
                     
            
          </tbody>
        </table>
       
      
      
    
    </div>
  </div>


@stop