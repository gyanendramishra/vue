@extends('layouts.admin.app')


@section('content')

<div class="wojo-grid">
    <div class="wojo form segment">
      
      <div id="cms" class="wojo tab item">
          @include('layouts.flash.alert')
        <table class="wojo two column table">
          <thead>
            <tr>
              <th  colspan="2"> {{ __( 'Enquiry Details' ) }}  </th>
             
            </tr>
          </thead>
          <tbody>
        
            <tr>
                <td>{{ __('Email') }}</td>
                <td>{{ $inquiry->email}}</td>
            </tr>
            <tr>
                <td>{{ __('Type') }}</td>
                <td>{{ \Config('constants.INQUERY_FOR.'.$inquiry->type) }}</td>
            </tr>
             <tr>
                <td>{{ __('Subject') }}</td>
                <td>{{ $inquiry->subject}}</td>
            </tr>
              <tr>
                <td>{{ __('Message') }}</td>
                <td>{{ $inquiry->message}}</td>
            </tr>
            <tr>
                <td><?= __('Created') ?></td>
                <td>{{ $inquiry->created_at }}</td>
            </tr>
            
          </tbody>
        </table>
      </div>
      
      
    
    </div>
  </div>


@stop