<?php

namespace Modules\CmsManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\CmsManager\Entities\Page;
use Modules\CmsManager\Http\Requests\PagesRequest;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use File;
use Illuminate\Support\Facades\Input;

class PagesController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        $title = "Pages";
        return view('cmsmanager::Admin.pages.index', compact('title'));
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {

        $pages = Page::get();

        if ($request->status != '') {
            $pages = $pages->where('status', $request->status);
        }

        return datatables()->of($pages)
                        ->addColumn('action', function ($page) {
                            $actions = "";
                            $actions .= "<a href=\"" . route('admin.pages.show', ['id' => $page->id]) . "\" class=\"\"><i class=\"rounded outline primary icon user profile link\"></i></a>";
                            $actions .= "&nbsp;<a href=\"" . route('admin.pages.edit', ['id' => $page->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                           // $actions .= "<a data-url=\"" . route('admin.pages.delete', ['id' => $page->id]) . "\" href=\"#\" class=\"btn btn-xs btn-primary btn-flat info-btn delete-it\"><i class=\"glyphicon glyphicon-remove\"></i> Delete</a>";
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        $title = "Add Pages";
        return view('cmsmanager::Admin.pages.createOrUpdate', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request) {

        $locales = config('app.locales');
        $valRule = [
            //'position' => 'required',
            'status' => 'required'
        ];
        $valMessage = [
            //'position.required' => ' The position field is required.',
            'status.required' => ' The status field is required.'
        ];
        foreach ($locales as $key => $value) {
            $valRule[$key . '_title'] = 'required|max:200|unique:page_translations,title|unique_space_check:page_translations,title';
            $valRule[$key . '_description'] = 'required';
            $valRule[$key . '_meta_title'] = 'required|max:200';
            //$valRule[$key . '_sub_title'] = 'required|max:200';
            $valRule[$key . '_meta_keyword'] = 'required|max:200';
            $valRule[$key . '_meta_description'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_title.required'] = ' The title field is required in ' . $value . ' language.';
            $valMessage[$key . '_title.max'] = 'Sorry, you can\'t add the title more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_title.unique'] = ' Title must be unique in ' . $value . ' language.';
            $valMessage[$key . '_title.unique_space_check'] = ' Title must be unique in '. $value .' language.';

            $valMessage[$key . '_description.required'] = ' The description field is required in ' . $value . ' language.';
            $valMessage[$key . '_meta_title.required'] = ' The meta title field is required in ' . $value . ' language.';
            $valMessage[$key . '_meta_title.max'] = 'Sorry, you can\'t add the meta title more than the 200 characters in ' . $value . ' language.';
           /* $valMessage[$key . '_sub_title.required'] = ' The sub title field is required in ' . $value . ' language.';
            $valMessage[$key . '_sub_title.max'] = ' Sorry, you can\'t add the sub title more than the 200 characters in ' . $value . ' language.';*/
            $valMessage[$key . '_meta_keyword.required'] = ' The meta keyword field is required in ' . $value . ' language.';
            $valMessage[$key . '_meta_keyword.max'] = ' Sorry, you can\'t add the meta keyword more than the 200 characters in ' . $value . ' language.';

            $valMessage[$key . '_meta_description.required'] = ' The meta description field is required in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['title'] = $request->input($key . '_title');
                $article_data[$key]['description'] = $request->input($key . '_description');
                $article_data[$key]['meta_title'] = $request->input($key . '_meta_title');
               // $article_data[$key]['sub_title'] = $request->input($key . '_sub_title');
                $article_data[$key]['meta_keyword'] = $request->input($key . '_meta_keyword');
                $article_data[$key]['meta_description'] = $request->input($key . '_meta_description');
                //$article_data[$key]['short_description'] = $request->input($key . '_short_description');
            }
            $article_data['status'] = $request->input('status');
            //$article_data['position'] = $request->input('position');
            //$article_data['slug'] = str_replace(" ", "_", $request->input('en_title'));

            Page::create($article_data);
        } catch (\Illuminate\Database\QueryException $e) {

            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.pages.index')->with('success', 'CMS Page has been saved Successfully');
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show(Page $page) {
        $title = "Page Detail";
        return view('cmsmanager::Admin.pages.show', compact('title', 'page'));
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id) {
        $title = "Add Pages";
        $pages = Page::where('id', '=', $id)->first();
        return view('cmsmanager::Admin.pages.createOrUpdate', compact('title', 'pages'));
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id) {
        $locales = config('app.locales');
        $valRule = [
           // 'position' => 'required',
            'status' => 'required'
        ];
        $valMessage = [
            //'position.required' => ' The position field is required.',
            'status.required' => ' The status field is required.'
        ];
        foreach ($locales as $key => $value) {
            $valRule[$key . '_title'] = 'required|max:200|unique:page_translations,title,' . $request->segment(3) . ',page_id|unique_space_check:page_translations,title,'. $request->segment(3).',page_id';
            $valRule[$key . '_description'] = 'required';
            $valRule[$key . '_meta_title'] = 'required|max:200';
          //  $valRule[$key . '_sub_title'] = 'required|max:200';
            $valRule[$key . '_meta_keyword'] = 'required';
            $valRule[$key . '_meta_description'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_title.required'] = ' The title field is required in ' . $value . ' language.';
            $valMessage[$key . '_title.max'] = 'Sorry, you can\'t add the title more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_title.unique'] = ' Title must be unique in ' . $value . ' language.';
             $valMessage[$key . '_title.unique_space_check'] = ' Title must be unique in '. $value .' language.';
            $valMessage[$key . '_description.required'] = ' The description field is required in ' . $value . ' language.';
            $valMessage[$key . '_meta_title.required'] = ' The meta title field is required in ' . $value . ' language.';
            $valMessage[$key . '_meta_title.max'] = 'Sorry, you can\'t add the meta title more than the 200 characters in ' . $value . ' language.';
           /* $valMessage[$key . '_sub_title.required'] = ' The sub title field is required in ' . $value . ' language.';
            $valMessage[$key . '_sub_title.max'] = ' Sorry, you can\'t add the sub title more than the 200 characters in ' . $value . ' language.';*/
            $valMessage[$key . '_meta_keyword.required'] = ' The meta keyword field is required in ' . $value . ' language.';
            $valMessage[$key . '_meta_keyword.max'] = ' Sorry, you can\'t add the meta keyword more than the 200 characters in ' . $value . ' language.';

            $valMessage[$key . '_meta_description.required'] = ' The meta description field is required in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['title'] = $request->input($key . '_title');
                $article_data[$key]['description'] = $request->input($key . '_description');
                $article_data[$key]['meta_title'] = $request->input($key . '_meta_title');
                //$article_data[$key]['sub_title'] = $request->input($key . '_sub_title');
                $article_data[$key]['meta_keyword'] = $request->input($key . '_meta_keyword');
                $article_data[$key]['meta_description'] = $request->input($key . '_meta_description');
               // $article_data[$key]['short_description'] = $request->input($key . '_short_description');
            }
            $article_data['status'] = $request->input('status');
            //$article_data['position'] = $request->input('position');
            //$article_data['slug'] = str_replace(" ", "_", $request->input('en_title'));



            $page = Page::find($id);

            $page->update($article_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.pages.index')->with('success', 'CMS Page has been updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id) {
        Page::where('id', $id)->delete();
        return redirect()->route('admin.pages.index')->with('success', 'Page deleted successfully.');
    }

}
