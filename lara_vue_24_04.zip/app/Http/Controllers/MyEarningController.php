<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\BookingService;

class MyEarningController extends Controller
{ 

    /**
     * Show the user earnings.
     *
     * @param Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request){
    
        return view('my_earning.index');
    }

    /**
     * Get the user earnings.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\BookingService $service
     * @return \Illuminate\Http\Response
     */
    public function getEarnings(Request $request, BookingService $service){
        try{
            $response = $service->getMyEarningsService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

}
