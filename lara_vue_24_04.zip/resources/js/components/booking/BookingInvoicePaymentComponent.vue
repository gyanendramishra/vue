<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div class="loginBox" id="trans_form">
                    <form @submit.prevent="makePayment">
                        <fieldset>
                            <div class="payment-card-panel card-swip">
                                <div class="payment-card-panel-bg card-front-side">
                                    <div class="card-type-sec">
                                        <span class="card-type-name">Card Preview</span>
                                    </div>
                                    <div class="card-no-sec">
                                        <span id="card-number">{{ (card.number === "")?"XXXX XXXX XXXX XXXX":card.number }}</span>
                                    </div>
                                    <div class="card-name-and-date">
                                        <div class="holder-name">{{ (card.name === "")?"Account Holder Name":card.name }}</div>
                                        <div class="card-date-col">
                                            <span class="card-month">{{ (card.exp_month === "")?"01":card.exp_month }}</span>/
                                            <span class="card-year">{{ (card.exp_year === "")?"20":card.exp_year }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="payment-card-panel-bg card-panel-back-side">	
                                    <div class="cvv-col-outer">
                                        <div class="cvv-text">{{ (card.cvc === "")?"000":card.cvc }}</div>
                                        <span>CVV</span>
                                    </div>         
                                </div>
                            </div>
                            
                            <div class="card_div_left">
                                <p class="form-row cardholder_name_div">
                                    <input type="text" class="input-text" autocomplete="off" placeholder="Your Cardholder Name *" v-model="card.name" v-validate="'required|max:255'" data-vv-name="name" data-vv-as="name">
                                    <div v-if="errors.has('name')" class="text-danger">
                                        {{ errors.first('name') }}
                                    </div>
                                </p>
                                <p class="form-row card_number_div">
                                    <input type="text" class="input-text" autocomplete="off" placeholder="Enter Your Card Number *" v-model="card.number" v-validate="'required|credit_card|max:16'" data-vv-name="number" data-vv-as="card number">
                                    <div v-if="errors.has('number')" class="text-danger">
                                        {{ errors.first('number') }}
                                    </div>
                                </p>
                            </div>
                            <div class="card_div_right">
                                <div class="card-month-input-sec">
                                    <p class="form-row card_month_div">
                                        <select name="exp_month" v-model="card.exp_month" v-validate="'required|numeric|digits:2'" data-vv-name="exp_month" data-vv-as="exp month">
                                            <option value="">Month</option>
                                            <option value="01">01 - January</option>
                                            <option value="02">02 - February</option>
                                            <option value="03">03 - March</option>
                                            <option value="04">04 - April</option>
                                            <option value="05">05 - May</option>
                                            <option value="06">06 - June</option>
                                            <option value="07">07 - July</option>
                                            <option value="08">08 - August</option>
                                            <option value="09">09 - September</option>
                                            <option value="10">10 - October</option>
                                            <option value="11">11 - November</option>
                                            <option value="12">12 - December</option>
                                        </select>
                                    </p>
                                    <p class="form-row card_year_div">
                                        <select v-model="card.exp_year" v-validate="'required|numeric|digits:4'" data-vv-name="exp_year" data-vv-as="exp year">
                                            <option value="">Year</option>
                                            <option value="2018">2018</option>
                                            <option value="2019">2019</option>
                                            <option value="2020">2020</option>
                                            <option value="2021">2021</option>
                                            <option value="2022">2022</option>
                                            <option value="2023">2023</option>
                                            <option value="2024">2024</option>
                                            <option value="2025">2025</option>
                                            <option value="2026">2026</option>
                                            <option value="2027">2027</option>
                                            <option value="2028">2028</option>
                                            <option value="2029">2029</option>
                                            <option value="2030">2030</option>
                                            <option value="2031">2031</option>
                                            <option value="2032">2032</option>
                                            <option value="2033">2033</option>
                                            <option value="2034">2034</option>
                                            <option value="2035">2035</option>
                                        </select>
                                    </p>
                                </div>
                                <p class="form-row card_cvn_div">
                                    <input type="text" class="input-text" autocomplete="off" placeholder="CVC" v-model="card.cvc" v-validate="'required|numeric|min:3|max:4'" data-vv-name="cvc" data-vv-as="cvc">
                                    
                                </p>
                                <div v-if="errors.has('exp_month') || errors.has('exp_year') || errors.has('cvc')" class="text-left text-danger">
                                    <p>
                                        {{ errors.first('exp_month') }}
                                    </p>
                                    <p>
                                        {{ errors.first('exp_year') }}
                                    </p>
                                    <p>
                                        {{ errors.first('cvc') }}
                                    </p>
                                </div>
                            </div>
                            <div class="card_div_left">
                                <p class="form-row card_pay_btn"> 
                                    <input type="submit" value="Pay" :disabled="errors.any()">
                                </p>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import VeeValidate from 'vee-validate';
    import mixin from '../../mixin/mixin.js';
    import LoaderComponent from "../LoaderComponent.vue";
    Vue.use(VeeValidate);
    export default {
        name: "booking-invoice-payment-component",
        components:{
            LoaderComponent
        },
        mixins: [mixin],
        props:["bookingId"],
        data: function () {
            return {
                loading: false,
                booking: {},
                booking: {},
                card: {
                    name: '',
                    number: '',
                    cvc: '',
                    exp_month: '',
                    exp_year: ''
                }
            }
        },
        created: function(){
            this.loading = true;
            this.getBooking();
        },
        filters: {
            prepareSlug (str, uri, id) {
                if(!str) return "";
                str = str.toLowerCase();
                str = str.replace(/[^a-zA-Z0-9]/g, '-');
                str = str.replace(/[-]+/g, '-');
                return uri+"/"+str+"-"+id;
            }
        },
        methods: {
            getBooking() {
                this.loading = true;
                axios.post('/booking/get/data', {
                    id: this.bookingId
                }).then(response => {
                    if(response.data.status === true){
                        this.booking = response.data.data;
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            makePayment() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        this.createToken();
                    }else{
                        this.loading = false;
                    }
                });
            },
            createToken() {
                Stripe.setPublishableKey(this.booking.stripe_public_key);
                Stripe.createToken(this.card, $.proxy(this.stripeResponseHandler, this));
            },
            stripeResponseHandler(status, response) {
                if (response.error) {
                    flash(response.error.message, 'error');
                    this.loading = false;
                } else {
                    // token to create charge  
                    var token = response.id;
                    axios.post('/booking/invoice/payment/make-payment', {
                        stripeToken: token,
                        booking_id: this.booking.id,
                    }).then(response => {
                        if(response.data.status === true){
                            flash(response.data.message, 'success');
                            window.location = '/booking/detail/'+this.booking.title.toLowerCase().replace(/ /g, '-')+"-"+this.booking.id; 
                        }else{
                            this.authorize(response);
                        }
                        this.loading = false;
                    }).catch(error => {
                        this.loading = false;
                        console.log(error);
                    });
                }
            }
        }
    }
</script>
