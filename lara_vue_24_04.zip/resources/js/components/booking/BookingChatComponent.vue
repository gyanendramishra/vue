<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div class="chat-booking-page">
                    <div class="right-chat-screen">
                        <div class="chat_area" v-chat-scroll="{always: false, smooth: true, scrollonremoved:true}">
                            <p v-if="messages.length == 0">No messages yet!</p>
                            <ul class="list-unstyled">
                                <div v-for="message in messages">
                                    <li class="left clearfix admin_chat" v-if="message.sender.id == loggedinUserId">
                                        <span class="chat-img1 pull-right">
                                            <img :src="(booking.user_id == message.sender.id) ? booking.user_full_image_path : booking.provider_full_image_path | prepareImage" alt="" >
                                        </span>
                                        <div class="chat-body1 clearfix">
                                            <div class="chat-user-name-right">{{ message.sender.displayName }}</div>
                                            <div class="chatarea-col" v-if="message.data.hasOwnProperty('photo')">
                                                <a :href="message.data.photo" target="_blank">
                                                    <img :src="message.data.photo">
                                                </a>
                                            </div>
                                            <div class="chatarea-col" v-else-if="message.data.hasOwnProperty('file')">
                                                <a :href="message.data.file" target="_blank">
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                            <div class="chatarea-col" v-else>{{ message.data.text }}</div>
                                            <div class="chat_time pull-left">{{ message.sentDate | formatDate }}</div>
                                        </div>
                                    </li>
                                    <li class="left clearfix" v-else>
                                        <span class="chat-img1 pull-left">
                                            <img :src="(booking.user_id == message.sender.id) ? booking.user_full_image_path : booking.provider_full_image_path | prepareImage" alt="" >
                                        </span>
                                        <div class="chat-body1 clearfix">
                                            <div class="chat-user-name-left">{{ message.sender.displayName }}</div>
                                            <div class="chatarea-col" v-if="message.data.hasOwnProperty('photo')">
                                                <a :href="message.data.photo" target="_blank">
                                                    <img :src="message.data.photo">
                                                </a>
                                            </div>
                                            <div class="chatarea-col" v-else-if="message.data.hasOwnProperty('file')">
                                                <a :href="message.data.file" target="_blank">
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </div>
                                            <div class="chatarea-col" v-else>{{ message.data.text }}</div>
                                            <div class="chat_time pull-right">{{ message.sentDate | formatDate }}</div>
                                        </div>
                                    </li>
                                    
                                </div>
                            </ul>
                        </div>
                        <form @submit.prevent="createMessage">
                            <div class="chatting-text-box">
                                <textarea v-model="newMessage" placeholder="Enter message"></textarea>
                            </div>
                            <div class="chatting-sms-btn-sec">
                                <div class="browse-btn">
                                    <span v-if="isFileSent">BROWSE</span> 
                                    <span v-else>Sending...</span> 
                                    <input type="file" ref="chat_file" v-on:change="createFileMessage" />
                                </div>
                                <button class="btn btn-sm btn-yellow" type="submit">
                                    <span v-if="isMessageSent">SEND MESSAGE</span>
                                    <span v-else>Sending...</span>
                                </button>          
                            </div>
                        </form>
                    </div>
                </div>  
            </div>
        </div>
    </div>
</template>
<script>
    import moment from "moment";
    import fire from '../../firebase/init';
    import mixin from '../../mixin/mixin.js';
    import VueChatScroll from 'vue-chat-scroll';
    import LoaderComponent from "../LoaderComponent.vue";
    Vue.use(VueChatScroll);

    export default {
        name: "booking-chat-component",
        components:{
            LoaderComponent
        },
        mixins: [mixin],
        props:["bookingId", "loggedinUserId"],
        data: function () {
            return {
                loading: false,
                isMessageSent: true,
                isFileSent: true,
                booking: {},
                messages: [],
                newMessage: ""
            }
        },
        created: function(){
            this.loading = true;
            this.getBooking();
        },
        filters: {
            formatDate (value) {
                return moment(new Date(value), 'YYYY-MM-DD H:i:s').format('DD MMM YYYY h:mm a');
            },
            prepareImage(image){
                if(!image){
                    image = "/images/profile_default_icon.png";
                }
                return image;
            }
        },
        methods: {
            getBooking() {
                this.loading = true;
                axios.post('/booking/get/data', {
                    id: this.bookingId
                }).then(response => {
                    if(response.data.status === true){
                        this.booking = response.data.data;
                        this.getMessages();
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            NotifyReceiver(){
                let message = "Booking:";
                message += this.booking.title+ " ";
                message += (this.booking.is_customer) ? this.booking.user_name : this.booking.provider_name;
                message += " sent a message";
                axios.post('/booking/chat/notify/user', {
                    token: this.booking.second_person_fcm_token,
                    device_type: this.booking.second_person_device_type,
                    message: message,
                    model: {
                        jobId: this.booking.id+"",
                        jobName: this.booking.title,
                        name: (this.booking.is_customer) ? this.booking.provider_name : this.booking.user_name,
                        reciverId: (this.booking.is_customer) ? this.booking.provider_id+"" : this.booking.user_id+"",
                        deviceType: this.booking.second_person_device_type,
                        pushToken: this.booking.second_person_fcm_token,
                        type: "CHAT_MESSAGE",
                        msg: message,
                        image: (this.booking.is_customer) ? this.booking.provider_full_image_path : this.booking.user_full_image_path
                    }
                }).then(response => {
                    console.log("success");
                }).catch(error => {
                    console.log(error);
                });
            },
            createMessage () {
                this.isMessageSent = false;
                let vm = this;
                if (this.newMessage) {
                    fire.database().ref('conversation').child(this.booking.id).child('chat').push({
                        data:{
                            text: this.newMessage
                        },
                        isRead: false,
                        receiver: {
                            displayName: (this.booking.is_customer) ? this.booking.provider_name : this.booking.user_name,
                            id: (this.booking.is_customer) ? this.booking.provider_id+"" : this.booking.user_id+""
                        },
                        sender: {
                            displayName: (this.booking.is_customer) ? this.booking.user_name : this.booking.provider_name,
                            id: (this.booking.is_customer) ? this.booking.user_id+"" : this.booking.provider_id+""
                        },
                        sentDate: Date.now()
                    }, function(error) {
                        if(error){
                            flash(error, "error");
                        }else{
                            vm.NotifyReceiver();
                            vm.newMessage = null;
                        }
                        vm.isMessageSent = true;
                    });
                } else {
                    vm.isMessageSent = true;
                    flash("A message must be entered!", "error");
                }
            },
            createFileMessage () {
                this.isFileSent = false;
                let vm = this;
                let file = this.$refs.chat_file.files[0];
                let fileExt = file.name.split('.').pop();
                let dataKey = "text";
                if((fileExt === "jpeg") || (fileExt === "jpg") || (fileExt === "png")){
                    dataKey = "photo";
                }else if(fileExt === "pdf"){
                    dataKey = "file";
                }else{
                    flash("You can share only jpeg|png|jpg|pdf format files", "error");
                    vm.isFileSent = true;
                    return false;
                }
                let storageRef = fire.storage().ref();
                let uploadTask  = storageRef.child(this.booking.id+"/").child(file.name).put(file);
                uploadTask.on('state_changed', function(snapshot){
                    var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                    console.log('Upload is ' + progress + '% done');
                }, function(error) {
                    flash(error, "error");
                    vm.isFileSent = true;
                }, function() {
                    uploadTask.snapshot.ref.getDownloadURL().then(function(downloadURL) {
                        console.log('File available at', downloadURL);
                        let chat = {};
                        chat[dataKey] = downloadURL;
                        fire.database().ref('conversation').child(vm.booking.id).child('chat').push({
                            data: chat,
                            isRead: false,
                            receiver: {
                                displayName: (vm.booking.is_customer) ? vm.booking.provider_name : vm.booking.user_name,
                                id: (vm.booking.is_customer) ? vm.booking.provider_id+"" : vm.booking.user_id+""
                            },
                            sender: {
                                displayName: (vm.booking.is_customer) ? vm.booking.user_name : vm.booking.provider_name,
                                id: (vm.booking.is_customer) ? vm.booking.user_id+"" : vm.booking.provider_id+""
                            },
                            sentDate: Date.now()
                        }, function(error) {
                            if(error){
                                flash(error, "error");
                            }else{
                                vm.NotifyReceiver();
                            }
                            vm.isFileSent = true;
                        });
                    });
                });
            },
            getMessages(){
                let ref = fire.database().ref('conversation');
                ref.child(this.booking.id).child('chat').on('value', snapshot => {
                    let data = snapshot.val();
                    this.messages = [];
                    if(data){
                        Object.keys(data).forEach(key => {
                            this.messages.push(data[key]);
                        });
                    }else{
                        fire.database().ref('conversation').child(this.booking.id).set({
                            chat: "",
                            conversationId: this.booking.id
                        });
                    }
                });
            }
        }
    }
</script>
