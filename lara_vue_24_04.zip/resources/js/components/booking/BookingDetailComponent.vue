<template>
    <div>
        <loader-component :loading="loading"></loader-component>
        <div class="formBox editProfileForm">
            <div class="formBoxInner">
                <div class="dashbord-sec">   
                    <div class="my-booking-sec my-booking-detail">
                        <a class="booking-cancel-btn" href="javascript:;"  
                            v-if="
                                ((booking.booking_status === 'awaiting') && booking.is_customer) || 
                                (booking.booking_status === 'accepted') || 
                                (booking.booking_status === 'scheduled')
                            " 
                            v-on:click="cancelBooking">
                            Cancel
                        </a>
                        <a class="booking-cancel-btn" :href="booking.title | prepareSlug('/booking/complaint', booking.id)"  
                            v-if="
                                (booking.booking_status === 'started') || 
                                (booking.booking_status === 'ended') || 
                                (booking.booking_status === 'completed') || 
                                (booking.booking_status === 'complained') ||
                                (booking.booking_status === 'refunded')
                            " 
                            >
                            Complaint
                        </a>
                        <h3>{{ booking.title }}</h3>
                        <div class="inner-page-sec-title">
                            <h4>Description</h4>
                        </div>
                        <p>{{ booking.description }}</p>
                        <div class="schedule-and-budget">
                            <div class="schedule-time">
                                <strong>
                                    Schedule Time:
                                </strong> 
                                <span>
                                    {{ booking.service_date_time | formatDate }}
                                </span>
                            </div>
                            <div class="booking-budget"> 
                                <strong>Budget:</strong> 
                                <span class="price-booking">${{ booking.budget | formatNumber }}</span> 
                                <small>(incl. all taxes)</small>
                            </div>
                        </div>
                        <div class="booking-provider-sec" v-if="booking.is_customer  === false">
                            <div class="booking-provider-col">
                                <img :src="booking.user_full_image_path | prepareImage" alt="" />
                                <h5>{{ booking.user_name }}</h5>
                                <span>{{ booking.category_title }}</span>
                            </div>
                            <a href="javascript:;" class="book-pro-arrow">
                                <img src="/images/booking_provider_arrow.png" alt="" />
                            </a>
                        </div>
                        <div class="booking-provider-sec" v-else>
                            <div class="booking-provider-col">
                                <img :src="booking.provider_full_image_path | prepareImage" alt="" />
                                <h5>{{ booking.provider_name }}</h5>
                                <span>{{ booking.category_title }}</span>
                            </div>
                            <a :href="booking.provider_name | prepareSlug('/service', booking.service_id)" class="book-pro-arrow">
                                <img src="/images/booking_provider_arrow.png" alt="" />
                            </a>
                        </div>
                        <div class="book-pay-status-sec">
                            <ul>
                                <li>
                                    <div class="book-status-left">
                                        <strong>Booking Status</strong>
                                    </div>
                                    <div class="book-status-right">
                                        <span :class="'booking-status-label '+ booking.booking_status">
                                            {{ booking.booking_status }}
                                        </span>
                                    </div>
                                </li>
                                <div v-if="(booking.payable_amount > 0) && (booking.booking_status != 'complained')">
                                    <li>
                                        <div class="book-status-left">
                                            <strong>Payble Amount</strong>
                                        </div>
                                        <div class="book-status-right">
                                            <span class="price-booking">
                                                ${{ booking.payable_amount | formatNumber }}
                                            </span> 
                                            <small>(incl. all taxes)</small>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="book-status-left">
                                            <strong>Payment Status</strong>
                                        </div>
                                        <div class="book-status-right">
                                            <div :class="booking.payment_status">
                                                {{ booking.payment_status }}
                                            </div>
                                        </div>
                                    </li>
                                </div>
                            </ul>
                            <div class="chat-and-link-sec">
                                <a :href="booking.invoice_file_path" target="_blank" class="invoice-link" v-if="(booking.booking_status != 'complained') && (booking.payable_amount > 0)">View Invoice</a>
                                
                                <div class="chat-btn">
                                    <a :href="booking.title | prepareSlug('/booking/chat', booking.id)">
                                        <img src="/images/profile_default_icon.png" alt="" />
                                        <span>Chat</span>
                                    </a>
                                </div>
                            </div>
                            <div v-if="booking.is_customer === false">
                                <div class="book-btn-sec" v-if="booking.booking_status === 'awaiting'">
                                    <a href="javascript:;" class="btn-default" v-on:click="rejectBooking">Reject</a>
                                    <a href="javascript:;" class="btn-default" v-on:click="acceptBooking">Accept</a>
                                </div>
                                <div class="book-btn-sec" v-if="booking.booking_status === 'accepted'">
                                    <a :href="booking.title | prepareSlug('/booking/invoice', booking.id)" class="btn-default">Generate Invoice</a>
                                </div>
                                <div class="book-btn-sec" v-if="booking.booking_status === 'scheduled'">
                                    <a href="javascript:;" class="btn-default" v-on:click="startBookingJob">Start Job</a>
                                </div>
                                <div class="book-btn-sec" v-if="booking.booking_status === 'started'">
                                    <a href="javascript:;" class="btn-default" v-on:click="endBookingJob">End Job</a>
                                </div>
                                <div class="book-btn-sec" v-if="booking.booking_status === 'ended'">
                                    <a href="javascript:;" class="btn-default">Waiting for Approval</a>
                                </div>
                            </div>
                            <div v-else>
                                <div class="book-btn-sec" v-if="(booking.payable_amount > 0) && (booking.payment_status === 'unpaid')">
                                    <a :href="booking.title | prepareSlug('/booking/invoice/payment', booking.id)" class="btn-default">Make Payment</a>
                                </div>
                                <div class="book-btn-sec" v-if="booking.booking_status === 'ended'">
                                    <a :href="booking.title | prepareSlug('/booking/review', booking.id)" class="btn-default">Approve & Review</a>
                                </div>
                            </div>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import moment from "moment";
    import bootbox from "bootbox";
    import fire from '../../firebase/init';
    import mixin from '../../mixin/mixin.js';
    import LoaderComponent from "../LoaderComponent.vue";
    export default {
        name: "booking-detail-component",
        components:{
            LoaderComponent
        },
        mixins: [mixin],
        props:["bookingId"],
        data: function () {
            return {
                loading: false,
                booking: {},
                isChatInitiated: false
            }
        },
        created: function(){
            this.loading = true;
            this.getBooking();
        },
        filters: {
            formatDate : function(date){
                return moment(date).format('DD MMM YYYY h:mm a');
            },
            formatNumber(value) {
                return (value/1).toFixed(2);
            },
            prepareSlug (str, uri, id) {
                if(!str) return "";
                str = str.toLowerCase();
                str = str.replace(/[^a-zA-Z0-9]/g, '-');
                str = str.replace(/[-]+/g, '-');
                return uri+"/"+str+"-"+id;
            },
            prepareImage(image){
                if(!image){
                    image = "/images/profile_default_icon.png";
                }
                return image;
            }
        },
        methods: {
            getBooking() {
                this.loading = true;
                axios.post('/booking/get/data', {
                    id: this.bookingId
                }).then(response => {
                    if(response.data.status === true){
                        this.booking = response.data.data;
                        let ref = fire.database().ref('conversation');
                        ref.child(this.booking.id).child('chat').on('value', snapshot => {
                            let data = snapshot.val();
                            if(data){
                                this.isChatInitiated = true;
                            }
                        });
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            acceptBooking(){
                let status = "accepted";
                let label = "accept";
                this.changeBookingStatus(status, label);
            },
            rejectBooking(){
                let status = "rejected";
                let label = "reject";
                this.changeBookingStatus(status, label);
            },
            cancelBooking(){
                let status = "cancelled";
                let label = "cancel";
                this.changeBookingStatus(status, label);
            },
            startBookingJob(){
                let status = "started";
                let label = "start";
                this.changeBookingStatus(status, label);
            },
            endBookingJob(){
                let status = "ended";
                let label = "end";
                this.changeBookingStatus(status, label);
            },
            changeBookingStatus(status, label) {
                let vm = this;
                bootbox.confirm("Are you sure you want to "+label+" the job ?", function(result){ 
                    if(result){
                        vm.loading = true;
                        axios.post('/booking/change-booking-status', {
                            id: vm.bookingId,
                            status: status,
                        }).then(response => {
                            if(response.data.status === true){
                                vm.getBooking();
                                flash(response.data.message, "success");
                            }else{
                                vm.authorize(response);
                            }
                            vm.loading = false;
                        }).catch(error => {
                            vm.loading = false;
                            console.log(error);
                        }); 
                    }
                });
            }
        },
    }
</script>
