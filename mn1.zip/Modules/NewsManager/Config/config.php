<?php

return [
    'name' => 'NewsManager'
];
