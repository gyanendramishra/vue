<?php

namespace Modules\NewsManager\Entities;

use Illuminate\Database\Eloquent\Model;
use \Dimsav\Translatable\Translatable;
use Cviebrock\EloquentSluggable\Sluggable;

class News extends Model {

    use Translatable;
    use Sluggable;

    protected $table = 'newss';

    const ACTIVE = 1;
    const IN_ACTIVE = 0;

    protected $fillable = ["start_date", "end_date", 'news_type', 'image', 'video', "status"];
    public $translatedAttributes = ["title", "excerpt", "description"];

    /**
     * Scope a query to only include active competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query) {
        return $query->where('status', self::ACTIVE);
    }

    /**
     * Scope a query to include given type of competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfActive($query, $type) {
        return $query->whereStatus($type);
    }

    /* 07-01 */

    public function NewsTranslation() {

        return $this->hasMany(\Modules\NewsManager\Entities\NewsTranslation::class, 'news_id', 'id');
    }

    /**
     * Get the sluggable.
     */
    public function sluggable() {
        return [
            'slug' => [
                'source' => 'title'
            ]
        ];
    }

}
