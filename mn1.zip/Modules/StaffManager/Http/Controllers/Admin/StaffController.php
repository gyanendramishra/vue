<?php

namespace Modules\StaffManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\StaffManager\Http\Requests\StaffRequest;
use Modules\StaffManager\Entities\AdminUser;
use Yajra\DataTables\Utilities\Request as DatatableRequest;

class StaffController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        if (\Auth::user('admin')->can('listing', \Modules\StaffManager\Entities\AdminUser::class)) {
            return view('staffmanager::index');
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $loginUser = \Auth::user('admin');
        $adminUsers = AdminUser::with(['adminRoleUsers']);
        if ($request->status != '') {
            $adminUsers = $adminUsers->where('status', $request->status);
        }
        if ($request->slug != '') {
            $slug = $request->slug;
            $adminUsers = $adminUsers->where(function($q) use($slug) {
                $q->where('name', 'LIKE', ucfirst($slug) . '%');
                $q->orWhere('name', 'LIKE', lcfirst($slug) . '%');
                $q->orWhere('name', 'LIKE', $slug . '%');
            });
        }
        $adminUsers = $adminUsers->get();
        return datatables()->of($adminUsers)
                        ->addColumn('action', function ($adminUsers) use($loginUser) {
                            $actions = "";
                            if ($loginUser->can('update', \Modules\StaffManager\Entities\AdminUser::class)) {
                                $actions .= "&nbsp;<a href=\"" . route('admin.staffmanager.edit', ['id' => $adminUsers->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                            }
                            if ($loginUser->can('delete', \Modules\StaffManager\Entities\AdminUser::class)) {
                                $actions .= "&nbsp;<a title='Delete' data-id='" . $adminUsers->id . "' class='Delete' data-set='{&quot;title&quot;: &quot;Delete Listing&quot;, &quot;parent&quot;: &quot;tr&quot;, &quot;option&quot;: &quot;deleteListing&quot;, &quot;id&quot;: 17, &quot;name&quot;: &quot;Infiniti Coupe Concept&quot;}''><i class='rounded outline icon negative trash link'></i></a>";
                            }
                            return $actions;
                        })
                        ->addColumn('admin_role', function ($adminUsers) {
                            $actions = "";
                            $name = $adminUsers->adminRoleUsers()->first();
                            $actions .= $name->name;
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        if (\Auth::user('admin')->can('create', \Modules\StaffManager\Entities\AdminUser::class)) {
            $title = 'Add Staff';
            $adminRoles = \Modules\AdminRole\Entities\AdminRole::where('status', 1)->pluck('name', 'id')->prepend('Select Account Type', '');
            return view('staffmanager::createOrUpdate', compact('title', 'adminRoles'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(StaffRequest $request) {
        try {

            $adminUsers = new AdminUser ();
            $adminUsers->name = $request->name;
            $adminUsers->email = $request->email;
            $adminUsers->phone = $request->phone;
            $adminUsers->password = bcrypt($request->password);
            if ($adminUsers->save()) {

                $adminUsers->adminRoleUsers()->sync($request->admin_role_id);
                return redirect()->route('admin.staffmanager.index')->with('success', 'Staff has been saved Successfully');
            } else {
                return back()->withError('Oops! Something went wrong.')->withInput();
            }
        } catch (\Illuminate\Database\QueryException $e) {

            return back()->withError($e->getMessage())->withInput();
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id) {
        if (\Auth::user('admin')->can('view', \Modules\StaffManager\Entities\AdminUser::class)) {
            return view('staffmanager::show');
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id) {
        if (\Auth::user('admin')->can('update', \Modules\StaffManager\Entities\AdminUser::class)) {
            $title = 'Edit Staff';
            $adminRoles = \Modules\AdminRole\Entities\AdminRole::where('status', 1)->pluck('name', 'id')->prepend('Select Account Type', '');
            $staff = AdminUser::find($id);
            return view('staffmanager::createOrUpdate', compact('title', 'adminRoles', 'staff'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(StaffRequest $request, $id) {
        try {

            $adminUsers = AdminUser::find($id);
            $adminUsers->name = $request->name;
            $adminUsers->email = $request->email;
            $adminUsers->phone = $request->phone;
            if (!empty($request->password)) {
                $adminUsers->password = bcrypt($request->password);
            }
            if ($adminUsers->save()) {
                $adminUsers->adminRoleUsers()->sync($request->admin_role_id);
                return redirect()->route('admin.staffmanager.index')->with('success', 'Staff has been saved Successfully');
            } else {
                return back()->withError('Oops! Something went wrong.')->withInput();
            }
        } catch (\Illuminate\Database\QueryException $e) {

            return back()->withError($e->getMessage())->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id) {
        //
    }

}
