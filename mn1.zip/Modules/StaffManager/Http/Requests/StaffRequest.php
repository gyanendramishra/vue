<?php

namespace Modules\StaffManager\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StaffRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        switch ($this->method()) {

            case 'POST':
                return [
                    'name' => 'bail|required|max:50',
                    'email' => 'required|email|max:50|unique:admin_users,email|unique:users,email',
                    'password' => 'bail|required|confirmed|min:8|max:12',
                    'phone' => 'bail|required|digits_between:4,16',
                    'admin_role_id' => 'bail|required',
                ];

            case 'PATCH':
                return [
                    'name' => 'bail|required|max:50',
                    'email' => 'required|email|max:50|unique:admin_users,email,' . \Request::segment(3).'|unique:users,email,'. \Request::segment(3),
                    'password' => 'nullable|confirmed|min:8|max:12',
                    'phone' => 'bail|required|digits_between:4,16',
                    'admin_role_id' => 'bail|required',
                ];
            default:break;
        }
       
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages() {
        return [
            'admin_role_id.required' => 'The account type field is required.',
            'email.unique' => 'The email has already been takens.',
        ];
    }

}
