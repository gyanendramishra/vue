@extends('layouts.admin.app')
@section('title', !empty($ads) ? 'Edit Ad' : 'Add Ad')
@push('styles')
{!! Html::style('/css/migration/custom.css') !!}
@endpush
@section('content')
<div id="crumbs" class="clearfix">
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.staffmanager.index'],['label' => !empty($staff) ? 'Edit Staff' : 'Add Staff' ]]]) }}
    </div>
</div>
<div class="wojo-grid">
    <div class="wojo form segment">
      <div class="wojo secondary icon message"> <!-- <i class="lock icon"></i> -->
            <div class="content">
                <div class="header">  {{ !empty($staff) ? 'Edit Staff' : 'Add Staff' }} </div>
            </div>
        </div>
        @if(isset($staff))
        {{ Form::model($staff, ['route' => ['admin.staffmanager.update', $staff->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}
        @else
        {{ Form::open(['route' => 'admin.staffmanager.store','enctype'=>'multipart/form-data']) }}
        @endif
        @php
        $locales = config('app.locales');
        @endphp
        @include('layouts.flash.alert')
        <div class="wojo secondary message">
            <div class="two fields">
                <div class="field required {{ $errors->has('name') ? 'has-error' : '' }}">
                    <label for="title">{{ __('Name') }} <span class="asterisk">*</span></label>
                    {{ Form::text('name', old('name', (isset($staff))?$staff->name:"") , ['class' => '','placeholder' => 'Name']) }}
                    @if($errors->has('name'))
                    <span class="help-block">{{  $errors->first('name')  }}</span>
                    @endif
                </div>
                <div class="field required {{ $errors->has('email') ? 'has-error' : '' }}">
                    <label for="email">{{ __('Email') }} <span class="asterisk">*</span></label>
                    {{ Form::email('email', old('email', (isset($staff))?$staff->email:"") , ['class' => '','placeholder' => 'Email']) }}
                    @if($errors->has('email'))
                    <span class="help-block">{{  $errors->first('email')  }}</span>
                    @endif
                </div>
            </div>
            <div class="two fields">
                <div class="field required {{ $errors->has('password') ? 'has-error' : '' }}">
                    <label for="title">{{ __('Password') }} <span class="asterisk">*</span></label>
                    {{ Form::password('password',['class' => '','placeholder' => 'Password','type'=>'password']) }}
                    @if($errors->has('password'))
                    <span class="help-block">{{  $errors->first('password')  }}</span>
                    @endif
                </div>
                <div class="field required {{ $errors->has('password_confirmation') ? 'has-error' : '' }}">
                    <label for="confirm_password">{{ __('Confirm Password') }} <span class="asterisk">*</span></label>
                    {{ Form::password('password_confirmation',['class' => '','placeholder' => 'Confirm Password']) }}
                    @if($errors->has('password_confirmation'))
                    <span class="help-block">{{  $errors->first('password_confirmation')  }}</span>
                    @endif
                </div>
            </div>
            <div class="two fields">
                <div class="field required {{ $errors->has('phone') ? 'has-error' : '' }}">
                    <label for="title">{{ __('Phone') }} <span class="asterisk">*</span></label>
                    {{ Form::text('phone',old('phone', (isset($staff))?$staff->phone:""),['class' => '','placeholder' => 'Phone']) }}
                    @if($errors->has('phone'))
                    <span class="help-block">{{  $errors->first('phone')  }}</span>
                    @endif
                </div>
                 <div class="field">
                    <div class="field type {{ $errors->has('admin_role_id') ? 'has-error' : '' }}">
                         <label for="admin_role_id">{{ __('Account ') }} <span class="asterisk">*</span></label>
                        {!!Form::select('admin_role_id', $adminRoles,  old('admin_role_id', (isset($staff))?$staff->adminRoleUsers()->first()->admin_role_id:""), ['class' => 'admin_role_id'])!!}
                        @if($errors->has('admin_role_id'))
                        <span class="help-block">{{  $errors->first('admin_role_id')  }}</span>
                        @endif
                    </div>
                </div>
            </div>
            <div class="wojo fitted divider"></div>
            <div class="wojo footer">
                <button type="submit" data-action="updateAccount" name="dosubmit" class="wojo positive button">Save</button>
                <a href="{{ route('admin.staffmanager.index') }}" class="wojo negative button" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
            </div>
            </form>
        </div>
    </div>

    @stop
    @section('per_page_style')
    <style>
        .ui-sortable-helper {
            display: table;
        }
    </style>
    @stop
