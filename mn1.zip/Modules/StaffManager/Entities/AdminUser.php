<?php

namespace Modules\StaffManager\Entities;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Notifications\ResetPasswordNotification;

class AdminUser extends Authenticatable {

    use Notifiable;

    protected $fillable = ['name', 'email', 'password', 'phone', 'status'];

    /**
     * Get the roles that associated with the user.
     */
    public function adminRoleUsers() {
        return $this->belongsToMany('Modules\AdminRole\Entities\AdminRole');
    }

    /**
     * Set the reset password notification for user.
     */
    public function sendPasswordResetNotification($token) {
        $this->notify(new ResetPasswordNotification($token));
    }

}
