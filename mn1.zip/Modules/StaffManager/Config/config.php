<?php

return [
    'name' => 'StaffManager'
];
