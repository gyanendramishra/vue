<?php

namespace Modules\DiscountCoupon\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\DiscountCoupon\Entities\DiscountCoupon;
use Yajra\DataTables\Utilities\Request as DatatableRequest;

class DiscountCouponsController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        if (\Auth::user('admin')->can('delete', \Modules\DiscountCoupon\Entities\DiscountCoupon::class)) {
            return view('discountcoupon::index');
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $discountCoupon = DiscountCoupon::query();
        if ($request->status != '') {
            $discountCoupon = $discountCoupon->where('is_publish', $request->is_publish);
        }

        $discountCoupon = $discountCoupon->get();

        return datatables()->of($discountCoupon)
                        ->addColumn('action', function ($discountCoupon) {
                            $actions = "";
                            if (\Auth::user('admin')->can('update', \Modules\DiscountCoupon\Entities\DiscountCoupon::class)) {
                                $actions .= "&nbsp;<a href=\"" . route('admin.discountcoupon.edit', ['id' => $discountCoupon->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                            }
                            if (\Auth::user('admin')->can('delete', \Modules\DiscountCoupon\Entities\DiscountCoupon::class)) {
                                $actions .= "&nbsp;<a title='Delete' data-id='" . $discountCoupon->id . "' class='Delete' data-set='{&quot;title&quot;: &quot;Delete Listing&quot;, &quot;parent&quot;: &quot;tr&quot;, &quot;option&quot;: &quot;deleteListing&quot;, &quot;id&quot;: 17, &quot;name&quot;: &quot;Infiniti Coupe Concept&quot;}''><i class='rounded outline icon negative trash link'></i></a>";
                            }
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        if (\Auth::user('admin')->can('create', \Modules\DiscountCoupon\Entities\DiscountCoupon::class)) {
            $title = "Add Discount Coupons";
            return view('discountcoupon::createOrUpdate', compact('title'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request) {
        $locales = config('app.locales');
        $valRule = [
            'name' => 'required',
            'code' => 'required',
            'discount' => 'required',
            'discount_type' => 'required',
            'start_date' => 'required|date',
            'end_date' => 'required|date',
        ];
        $valMessage = [
            'start_date.required' => 'The start date field is required.',
            'start_date.date' => 'Please enter the date.',
            'end_date.required' => 'The end date field is required.',
            'end_date.date' => 'Please enter the date.',
            'discount_type.required' => 'The discount type field is required.',
        ];
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $discount_data = array();

            $discount_data['name'] = $request->input('name');
            $discount_data['code'] = $request->input('code');
            $discount_data['discount'] = $request->input('discount');
            $discount_data['discount_type'] = $request->input('discount_type');
            $discount_data['is_publish'] = $request->input('is_publish');
            $discount_data['start_date'] = $request->input('start_date');
            $discount_data['end_date'] = $request->input('end_date');

            $discount = DiscountCoupon::create($discount_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.discountcoupon.index')->with('success', 'Coupon has been saved Successfully');
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id) {
        if (\Auth::user('admin')->can('view', \Modules\DiscountCoupon\Entities\DiscountCoupon::class)) {
            return view('discountcoupon::show');
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id) {
        if (\Auth::user('admin')->can('update', \Modules\DiscountCoupon\Entities\DiscountCoupon::class)) {
            $title = "Add News";
            $discountCoupon = DiscountCoupon::find($id);
            return view('discountcoupon::createOrUpdate', compact('title', 'discountCoupon'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id) {
        $locales = config('app.locales');
        $valRule = [
            'name' => 'required',
            'code' => 'required',
            'discount' => 'required',
            'discount_type' => 'required',
            'start_date' => 'required|date',
            'end_date' => 'required|date',
        ];
        $valMessage = [
            'start_date.required' => 'The start date field is required.',
            'start_date.date' => 'Please enter the date.',
            'end_date.required' => 'The end date field is required.',
            'end_date.date' => 'Please enter the date.',
            'discount_type.required' => 'The discount type field is required.',
        ];
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $discount_data = array();

            $discount_data['name'] = $request->input('name');
            $discount_data['code'] = $request->input('code');
            $discount_data['discount'] = $request->input('discount');
            $discount_data['discount_type'] = $request->input('discount_type');
            $discount_data['is_publish'] = $request->input('is_publish');
            $discount_data['start_date'] = $request->input('start_date');
            $discount_data['end_date'] = $request->input('end_date');
            $discount = DiscountCoupon::find($id);

            $discount->update($discount_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.discountcoupon.index')->with('success', 'Coupon has been updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id) {
        try {
            if (\Auth::user('admin')->can('delete', \Modules\DiscountCoupon\Entities\DiscountCoupon::class)) {
                DiscountCoupon::where('id', $id)->delete();
                $responce = ['status' => true, 'message' => 'This news has been deleted Successfully!'];
            } else {
                return view('Admin.not-authorised');
            }
        } catch (\Exception $e) {
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

}
