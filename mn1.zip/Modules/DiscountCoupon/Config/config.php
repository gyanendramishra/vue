<?php

return [
    'name' => 'DiscountCoupon'
];
