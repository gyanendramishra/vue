@extends('layouts.admin.app')
@section('title', !empty($discountCoupon) ? 'Edit Discount Coupon' : 'Add Discount Coupon')
@push('styles')
<link href="{{ asset('/css/migration/jquery-ui.css') }}" rel="stylesheet" />
<style>
    .hide{display: none;}

</style>
@endpush
@section('content')

<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.discountcoupon.index'],['label' => !empty($ads) ? 'Edit Discount Coupon' : 'Add Discount Coupon' ]]]) }}
    </div>
</div>

<div class="wojo-grid">


    @if(session()->has('success'))
    <div class="alert alert-success">
        {{ session()->get('success') }}
    </div>
    @endif

    <div class="wojo form segment">
        <div class="wojo secondary icon message"> 
            <div class="content">
                <div class="header">  {{ !empty($discountCoupon) ? 'Edit Discount Coupon' : 'Add Discount Coupon' }}  </div>
            </div>
        </div>
        @if(isset($discountCoupon))
        {{ Form::model($discountCoupon, ['route' => ['admin.discountcoupon.update', $discountCoupon->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}
        @else
        {{ Form::open(['route' => 'admin.discountcoupon.store','enctype'=>'multipart/form-data']) }}
        @endif

        @php
        $locales = config('app.locales');
        @endphp

        @include('layouts.flash.alert')

        <div class="wojo secondary message">
           

            <div class="two fields">
                <div class="field">
                    <div class="required {{ $errors->has('name') ? 'has-error' : '' }}">
                        <label for="status">{{ __('Name') }} <span class="asterisk">*</span> </label>
                        {{ Form::text('name', old('name'), ['class' => 'form-control','placeholder' => 'Name']) }}
                        @if($errors->has('name'))
                        <span class="help-block">{{ $errors->first('name') }}</span>
                        @endif
                    </div>
                </div>
                <div class="field">
                    <div class="required {{ $errors->has('code') ? 'has-error' : '' }}">
                        <label for="status">{{ __('Coupon Code') }} <span class="asterisk">*</span></label>
                        {{ Form::text('code', old('code'), ['class' => 'form-control','placeholder' => 'Coupon Code']) }}
                        @if($errors->has('code'))
                        <span class="help-block">{{ $errors->first('code') }}</span>
                        @endif
                    </div>
                </div>
            </div>
            <div class="two fields">
                <div class="field">
                    <div class="required {{ $errors->has('discount') ? 'has-error' : '' }}">
                        <label for="status">{{ __('Discount') }} <span class="asterisk">*</span></label>
                        {{ Form::number('discount', old('discount'), ['class' => 'form-control','placeholder' => 'Discount']) }}
                        @if($errors->has('discount'))
                        <span class="help-block">{{ $errors->first('discount') }}</span>
                        @endif
                    </div>
                </div>
                <div class="field">
                    <div class="required {{ $errors->has('discount') ? 'has-error' : '' }}">
                        <label for="title">{{ __('Type') }} </label>
                        {!!Form::select('discount_type', ['percentage'=>'Percentage','amount'=>'Amount'],  old('discount_type'), ['class' => 'form-control'])!!}
                        @if($errors->has('discount_type'))
                        <span class="help-block">{{  $errors->first('discount_type')  }}</span>
                        @endif
                    </div>
                </div>
            </div>

            <div class="two fields ">
                <div class="field">
                    <div class="required {{ $errors->has('start_date') ? 'has-error' : '' }}">
                        <label for="status">{{ __('Start date') }} <span class="asterisk">*</span></label>
                        {{ Form::text('start_date', old('start_date'), ['class' => 'form-control datepicker_start','placeholder' => 'Start date']) }}
                        @if($errors->has('start_date'))
                        <span class="help-block">{{ $errors->first('start_date') }}</span>
                        @endif
                    </div>
                </div>
                <div class="field">
                    <div class="required {{ $errors->has('end_date') ? 'has-error' : '' }}">
                        <label for="status">{{ __('End date') }} <span class="asterisk">*</span></label>
                        {{ Form::text('end_date', old('end_date'), ['class' => 'form-control datepicker_end','placeholder' => 'End date']) }}
                        @if($errors->has('end_date'))
                        <span class="help-block">{{ $errors->first('end_date') }}</span>
                        @endif
                    </div>
                </div>


                <div class="field">
                    <div class="required {{ $errors->has('is_publish') ? 'has-error' : '' }}">
                        <label for="status">{{ __('Status') }} </label>
                        {{ Form::select('is_publish', [1 => 'Active', 0 => 'Inactive'], old("is_publish"), ['class' => '']) }}

                        @if($errors->has('is_publish'))
                        <span class="help-block">{{ $errors->first('is_publish') }}</span>
                        @endif
                    </div>
                </div>
            </div>

            <div class="wojo fitted divider"></div>


            <div class="wojo fitted divider"></div>
            <div class="wojo footer">
                <button type="submit" data-action="updateAccount" name="dosubmit" class="wojo positive button">Save</button>
                <a href="{{ route('admin.discountcoupon.index') }}" class="wojo negative button" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
            </div>
        </div>

        {{ Form::close() }}
    </div>
</div>
@stop

@push('scripts')

<script src="{{ asset('js/migration/jquery-ui.js') }}"></script>
<script src="{{asset('ckeditor/ckeditor.js')}}"></script>
<script>
$(function () {
    $(".datepicker_start").datepicker({
        minDate: 0,
        dateFormat: 'yy-mm-dd',
        onSelect: function (selected) {
            var dt = new Date(selected);
            dt.setDate(dt.getDate() + 1);
            $(".datepicker_end").datepicker("option", "minDate", dt);
        }
    });
    $(".datepicker_end").datepicker({
        dateFormat: 'yy-mm-dd',
        onSelect: function (selected) {
            var dt = new Date(selected);
            dt.setDate(dt.getDate() - 1);
            $(".datepicker_start").datepicker("option", "maxDate", dt);
        }
    });
});
</script>
@endpush
