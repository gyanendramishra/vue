@extends('layouts.admin.app')

@push('styles')
{!! Html::style('/css/bootstrap.min.css') !!}
{!! Html::style('css/datatables.net-bs/dataTables.bootstrap.min.css') !!}
@endpush
@section('content')
<div id="crumbs" class="clearfix"> 
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> 'Discount Coupon','route'=> \Request::route()->getName()],['label' => 'List Discount Coupon']]]) }}
    </div>
</div>
<div class="wojo-grid">
    <div class="wojo secondary icon message">
        <div class="content">
            <div class="header">  {{ __( 'Discount Coupons' ) }}  
            </div>
        </div>
    </div>
    @include('layouts.flash.alert')
    <div class="wojo quaternary segment">
        <div class="header">Filtering Options</div>
        <div class="content">
            <div class="wojo form">
                <div class="three fields">
                    <div class="field">
                        <label>Status</label>
                        {{ Form::select('is_publish', ['' => 'Select',1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control','id'=>'statuss','data-cover'=>'true']) }}
                    </div>        
                </div>
            </div>
        </div>
    </div>
    <div class="wojo tertiary segment">
        <div class="header clearfix"><span>{{ __('Discount Coupons') }}</span>
            @can('create',\Modules\DiscountCoupon\Entities\DiscountCoupon::class)
            <a class="wojo large top right detached action label" data-content="Add Listing" href="{{route('admin.discountcoupon.create')}}"><i class="icon plus"></i></a>
            @endcan
        </div>

        <table class="wojo sortable table"  id="discount-coupon-datatable" data-table="discount_coupons">
            <thead>
                <tr>
                    <th>Id</th>

                    <th>Name</th>
                    <th>Coupon Code</th>
                    <th>Discount</th>
                    <th>Discount Type</th>
                    <th>Publish/Unpublish</th>
                    <th>Created At</th>
                    <th class="no-sort">Action</th>
                </tr>
            </thead>
        </table>
    </div>
    <div id="msgholder"></div>
</div>
@stop

@push('scripts')

<script type="text/javascript">
    jQuery(function ($) {
        var t = $('#discount-coupon-datatable').DataTable({
            processing: true,
            serverSide: true,
            aaSorting: [[0, 'desc']],
            language: {
                sLengthMenu: "_MENU_",
                search: "<i class='find icon'></i>",
                searchPlaceholder: "Search...",
            },

            ajax: {
                url: "{{ route('admin.discountcoupon.ajax.list') }}",
                type: 'GET',
                data: function (d) {
                    d.status = $('#statuss').val();
                }
            },
            columns: [
                {data: 'id', name: 'id'},
                {data: 'name', name: 'name'},
                {data: 'code', name: 'code'},
                {data: 'discount', name: 'discount'},
                {data: 'discount_type', name: 'discount_type'},
                {data: 'is_publish', name: 'is_publish'},
                {data: 'created_at', name: 'created_at'},
                {data: 'action', name: 'action'}
            ],
            "deferRender": true,
            "columnDefs": [
                {
                    "targets": 'no-sort',
                    "orderable": false,
                },
                {
                    "targets": 6,
                    "data": "created_at",
                    "render": function (data, type, full, meta) {
                        return moment(data).format('DD MMMM, YYYY ');
                    }
                },
                {

                    "targets": 5,
                    "data": "status",
                    "render": function (data, type, full, meta) {
                        return '<input id="status" class="switch-status change-request" data-id="' + full.id + '" data-field="is_publish" data-size="mini" ' + ((data == true) ? 'checked' : '') + ' name="status" type="checkbox">';
                    }
                }
            ],
            "fnDrawCallback": function (settings) {

                $('input.switch-status').not('[data-switch-no-init]').bootstrapSwitch();
                $('[data-toggle="tooltip"]').tooltip();

                $('.switch-status.change-request').on('switchChange.bootstrapSwitch', function (e, state) {
                    var _this = $(this);
                    var _id = _this.data("id")
                    var table = _this.closest("table").data("table");
                    if (e.target.checked == true) {
                        var changedval = 1;
                    } else {
                        var changedval = 0;
                    }
                    changeStatus(table, _id, changedval, _this);
                });
            }


        })
        t.on('order.dt search.dt', function () {
            t.column(0, {search: 'applied', order: 'applied'}).nodes().each(function (cell, i) {
                cell.innerHTML = i + 1;
            });
        });
        $('#statuss').on('change', function () {

            $('#news-datatable').DataTable().draw(true);
        });

        var config = {
            weekstart: 0,
            lang: {

                button_text: "Choose file...",
                mbutton_text: "Choose multiple files...",
                empty_text: "No file...",
                monthsFull: '',
                monthsShort: '',
                weeksFull: '',
                weeksShort: '',
                weeksMed: '',
                today: "Today",
                delBtn: "Delete Record",
                approve: "Change Status",
                clear: "Clear",
                selProject: "Select Project",
                invImage: "Invalid Image type",
                delMsg1: "Are you sure you want to delete this record?",
                delMsg2: "Do you really want to set car of the week this car?",
                delMsg3: "Do you really want to approve/unapprove this car?",
                delMsg4: "Do you really want to set car of the week this car?",
                working: "working..."
            }
        };
        $(document).on('click', 'a.Delete', function () {

            var id = $(this).data('id');
            var tempurl = "{{ url('admin/discountcoupon/') }}";
            var url = tempurl + "/delete/" + id;
            var data = $(this).data("set");
            var $parent = $(this).closest(data.parent);
            new Messi("<div class=\"messi-warning\"><i class=\"huge icon negative notification sign\"></i><p>" + config.lang.delMsg1 + "<br><strong>" + config.lang.delMsg1 + "</strong></p></div>", {

                title: data.title,
                titleClass: '',
                modal: true,
                closeButton: true,
                buttons: [{
                        id: id,
                        label: config.lang.delBtn,
                        class: 'negative',
                        icon: '<i class="icon trash"></i>',
                        val: 'Y'
                    }],
                callback: function (val) {

                    $.ajax({

                        type: 'GET',
                        url: url,
                        datatype: 'json',
                        beforeSend: function () {

                            $parent.css({
                                'opacity': '.35'
                            });
                        },
                        success: function (json) {

                            $('#discount-coupon-datatable').DataTable().draw(true);
                            $.sticky(decodeURIComponent(json.message), {
                                type: json.type,
                                title: json.title
                            });
                        }
                    });
                }
            });
        });


    })

</script>
@endpush
