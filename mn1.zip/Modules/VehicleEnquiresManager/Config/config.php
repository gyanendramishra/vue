<?php

return [
    'name' => 'VehicleEnquiresManager'
];
