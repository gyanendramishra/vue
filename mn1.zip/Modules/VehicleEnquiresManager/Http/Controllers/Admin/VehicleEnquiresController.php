<?php

namespace Modules\VehicleEnquiresManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\VehicleEnquiresManager\Entities\VehicleEnquiry;
use Modules\VehicleEnquiresManager\Entities\VehicleEnquiryResponse;
use Modules\VehicleEnquiresManager\Http\Requests\VehicleEnquiresRequest;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use Mail;

class VehicleEnquiresController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        $title = "Vehicle Enquires";
        return view('vehicleenquires::Admin.vehicleenquires.index', compact('title'));
    }

    /**
     * Feeding list of enquires to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $enquires = VehicleEnquiry::query();
        if ($request->slug != '') {
            $slug = $request->slug;
            $enquires = $enquires->where(function($q) use($slug) {
                $q->where('name', 'LIKE', ucfirst($slug) . '%');
                $q->orWhere('name', 'LIKE', lcfirst($slug) . '%');
                $q->orWhere('name', 'LIKE', $slug . '%');
            });
        }

        $enquires = $enquires->get();

        return datatables()->of($enquires)
                        ->addColumn('action', function ($enquires) {
                            $actions = "";
                            $actions .= "<a href=\"" . route('admin.vehicleenquires.show', ['id' => $enquires->id]) . "\" class=\"\"><i class=\"rounded outline primary icon user profile link\"></i></a>";

                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id) {

        $title = 'Vehicle Enquires';
        $inquiry = VehicleEnquiry::find($id);
        return view('vehicleenquires::Admin.vehicleenquires.show', compact('inquiry', 'title'));
    }

}
