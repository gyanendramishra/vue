<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */

Route::prefix('admin')->middleware('auth:admin')->namespace('Admin')->as('admin.')->group(function() {

    Route::get('vehicleenquires/ajax/list', 'VehicleEnquiresController@ajaxList')->name('vehicleenquires.ajax.list');
    Route::get('vehicleenquiry-responses/ajax/list/{id}', 'VehicleEnquiresController@ajaxResponseList')->name('vehicleenquiry-responses.ajax.list');
    Route::get('vehicleenquires/delete/{id}', 'VehicleEnquiresController@destroy')->name('vehicleenquires.delete');
    Route::get('vehicleenquires/view-response/{id}', 'VehicleEnquiresController@reponses')->name('vehicleenquires.view-response');
    Route::post('vehicleenquires/vehicleenquiry-response', 'VehicleEnquiresController@enquiryReply')->name('vehicleenquires.enquiry-response');
    Route::resources([
        'vehicleenquires' => 'VehicleEnquiresController',
    ]);
});


