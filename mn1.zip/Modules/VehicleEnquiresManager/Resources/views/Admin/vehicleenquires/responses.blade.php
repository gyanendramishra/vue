@extends('layouts.admin.app')
@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            {{ __('View Response Details') }}           
        </h1>
		<ol class="breadcrumb">
			<li><a href="{{ url('user/dashboard') }}">{{ config('backpack.base.project_name') }}</a></li>
			<li class="active">{{ trans('backpack::base.dashboard') }} </li>
		</ol>		
      {{-- Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> \Request::route()->getName()],['label' => 'List Vehicle Enquires Response']]]) --}}
    </section>

    <!-- Main content -->
    <section class="content">
        @include('layouts.flash.alert')
        <div class="box">

            <div class="box-header with-border">
                <h3 class="box-title">{{ __('List Vehicle Enquires Response') }}</h3>
                <div class="box-tools pull-right">
                    <!--<a href="{{route('admin.vehicleaudiocommunication.create')}}" class="btn btn-primary">Add New Vehicle Enquires</a>-->
					<a  href="{{ route('admin.vehicleenquires.index', app('request')->query()) }}" class="btn btn-primary btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back </a>
					<!-- <a href="javascript:void(0);" class="btn btn-info btn-sm" data-toggle="modal" data-target="#globleModal"><i class="fa fa-reply"></i>Vehicle Enquiry Response </a> -->

                </div>
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Action</label>
                            <select name="action" class="form-control" id="action">
                                <option value="">Select</option>
                                <option value="On Hold">On Hold</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Closed">Closed</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-body">
			  <div class="custom-table-responsive"> 
                <table class="table table-bordered" id="vehicle_enquiry_responses-datatable" data-table="vehicle_enquiry_responses">
                    <thead>
                        <tr>
							<th>Id</th>
							<th>Details</th>
                            <th>To Email</th>                           
							<th class="no-sort">Action</th>
							 <th>Date</th>
                        </tr>
                    </thead>
                </table>
			  </div>
            </div>
        </div>
		 <div id="globleModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
                    <h4 class="modal-title">Vehicle Enquiry Response</h4>
                </div>
				<form method="post" action="{{ url('admin/vehicleenquires/vehicleenquiry-response') }}" accept-charset="UTF-8" class="" >
                <div class="modal-body">
                              <div class="box-body">
                                  <div class="row">
                                      <div class="col-md-12">
                                        {{ csrf_field() }}
            
            <div class="form-group">
            {!! Form::label('details', 'Answer', ['class' => 'control-label']) !!}
            {!! Form::textarea('details', null, ['class' => 'form-control','required'=>true, 'rows' => 5, 'cols' => '80' ]) !!}
            <div class="formRow{{ $errors->has('details') ? ' has-error' : '' }}">
            <span class="help-block"> {{ $errors->first('details', ':message') }} </span>
            </div>             
            <input id="lead_id" type="hidden" name="enquiry_id" value="{{ $id }}">
                                              <div class="Description"></div>
                                          </div>

            <div class="form-group">
                {!! Form::label('action', 'Select Action', ['class' => 'control-label']) !!}
            {!! Form::select('action', $actions,null, ['class'=>'form-control','required'=>true]) !!}
            </div>

                                      </div>

                                  </div>
                              </div>
                            </div>
                          <div class="modal-footer">
                             <button type="submit"" class="btn btn-primary">Reply</button>
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                          </div>
                </form>
               
            </div>

        </div>
    </div>
    </section>
</div>
@stop
@push('scripts')
{!! Html::script('/plugins/jquery-confirm/dist/jquery-confirm.min.js') !!}
{!! Html::script('/plugins/gritter/js/jquery.gritter.js') !!}
{!! Html::script('/plugins/bootstrap-switch-master/dist/js/bootstrap-switch.js') !!}
<script type="text/javascript">
    jQuery(function ($) {
        var t = $('#vehicle_enquiry_responses-datatable').DataTable({
            processing: true,
            serverSide: true,
            aaSorting: [[0, 'desc']],
            ajax: {
                url: "{{ route('admin.vehicleenquiry-responses.ajax.list', ['id' => $id]) }}",
                type: 'GET',
                data: function (d) {

                    d.action = $('#action').val();
                }
            },
            columns: [
                {data: 'id', name: 'id'},
				{data: 'details', name: 'details'},
                {data: 'email', name: 'email'},               
                {data: 'action', name: 'action'},               
                {data: 'created_at', name: 'created_at'},               
            ],
            "deferRender": true,
            "columnDefs": [
                {
                    "targets": 'no-sort',
                    "orderable": false,
                },
                {
                    "targets": 4,
                    "data": "created_at",
                    "render": function (data, type, full, meta) {
                        return moment(data).format('DD MMMM, YYYY ');
                    }
                }                
            ],
            "fnDrawCallback": function(settings) {				
			
            }


        })
        t.on('order.dt search.dt', function () {
            t.column(0, {search: 'applied', order: 'applied'}).nodes().each(function (cell, i) {
                cell.innerHTML = i + 1;
            });
        });
        $('#action').on('change', function () {
            $('#vehicle_enquiry_responses-datatable').DataTable().draw(true);
        });		
    })
</script>
@endpush