<?php

namespace Modules\VehicleEnquiresManager\Entities;

use Illuminate\Database\Eloquent\Model;

class VehicleEnquiryResponse extends Model {

    protected $table = 'vehicle_enquiry_responses';
    protected $primaryKey = 'id';
    //protected $dates = ['deleted_at'];
    public $timestamps = true;
    protected $fillable = ['email', 'name','user_id','is_responded', 'details', 'action', 'enquiry_id'];

    //protected $casts = ['status'  => 'boolean'];
    public function vehicleEnquiry() {
        return $this->hasOne(\Modules\VehicleEnquiresManager\Entities\VehicleEnquiry::class, 'id', 'enquiry_id');
    }
//protected $casts = ['status'  => 'boolean'];
    public function user() {
        return $this->hasOne(\App\User::class, 'id', 'user_id');
    }
}
