<?php

namespace Modules\VehicleEnquiresManager\Entities;

use Illuminate\Database\Eloquent\Model;


class VehicleEnquiry extends Model {

    protected $table = 'vehicle_enquires';
    protected $primaryKey = 'id';
    public $timestamps = true;
    protected $fillable = ['name','vehicle_id','user_id', 'email', 'subject', 'details', 'phone'];

    
    
    public function vehicles()
    {
        return $this->hasOne(\Modules\VehicleManager\Entities\Vehicle::class, 'id', 'vehicle_id');
    }

    public function vehicle()
    {
        return $this->hasOne(\Modules\VehicleManager\Entities\Vehicle::class, 'id', 'vehicle_id');
    }


    
   
}
