<?php

namespace Modules\User\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use App\User;
use Modules\User\Entities\Role;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use Illuminate\Notifications\Notifiable;
use App\Notifications\ChangePasswordNotification;

class UsersController extends Controller {

    use Notifiable;

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index($role) {
        if (\Auth::user('admin')->can('listing', \App\User::class)) {
            $title = "Users";
            return view('user::Admin.users.index', ['role' => $role, 'title' => $title]);
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList($role, DatatableRequest $request) {
        $loginUser = \Auth::user('admin');
        $users = User::query();
        $users = $users->whereHas('roles', function($query) use ($role) {
            $query->where('slug', '=', $role->slug);
        });
        $urole = $role->slug;
        if ($request->status != '') {
            $users = $users->where('status', $request->status);
        }
        if ($request->slug != '') {
            $slug = $request->slug;
            $users = $users->where(function($q) use($slug) {
                $q->where('name', 'LIKE', ucfirst($slug) . '%');
                $q->orWhere('name', 'LIKE', $slug . '%');
            });
        }

        return datatables()->of($users)
                        ->addColumn('action', function ($user) use ($urole, $loginUser) {
                            $actions = "";
                            $actions .= '<a href="'.route("admin.users.edit", ['role' => $urole, 'id' => $user->id]).'" class=""><i class="rounded outline positive icon pencil link"></i> </a> &nbsp;';
                            if ($loginUser->can('view', \App\User::class)) {
                                $actions .= "<a title='view' href=\"" . route('admin.users.show', ['role' => $urole, 'id' => $user->id]) . "\"><i class=\"rounded outline primary icon user profile link\"></i></a>";
                            }

                            $actions .= "&nbsp;<a title='Delete' data-id='" . $user->id . "' class='Delete' data-set='{&quot;title&quot;: &quot;Delete Listing&quot;, &quot;parent&quot;: &quot;tr&quot;, &quot;option&quot;: &quot;deleteListing&quot;, &quot;id&quot;: 17, &quot;name&quot;: &quot;Infiniti Coupe Concept&quot;}''><i class='rounded outline icon negative trash link'></i></a>";
                            
                           
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create($role) {
       
        if (\Auth::user('admin')->can('create', \App\User::class)) {
            $title = "Add User";
            $roles = Role::where('slug', '!=', 'admin')->where('is_menu', 1)->get()->pluck('name', 'id');
            $roles->prepend('Select', '');
            return view('user::Admin.users.form', compact('title', 'role', 'roles'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Store a newly created resource in storage.
     * @param StoreUserRequest $request
     * @return Response
     */
    public function store(Request $request) {
        
        $validatedData = $request->validate([
            'name' => 'required|max:200',
            'email' => 'nullable|email|unique:users',
            'phone' => 'required|unique:users|max:20',
            'address' => 'required',
            'password' => 'required|min:8|confirmed',
            'password_confirmation' => 'required_with:password|same:password|min:8',
            'role_id' => 'required'
        ]);




        $request['password'] = \Hash::make($request->password);

        try {
            $user = \App\User::create($request->all(), ['_token']);
            
            $user->roles()->detach();
            $user->roles()->attach($request->role_id);
            
            if ($user->save()) {

               // $token = app('auth.password.broker')->createToken($user);
                //$user->notify(new ChangePasswordNotification($token));
            }
        } catch (Exception $e) {

            redirect()->back();
        }

        return redirect()->route('admin.users.index', ['roleSlug' => $user->roles->first()->slug])->withSuccess('User has been created successfully!');
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($role, $id) {
        if (\Auth::user('admin')->can('view', \App\User::class)) {
            $title = "Show User detail";

            $row = \App\User::findOrFail($id);
            return view('user::Admin.users.show', compact('title', 'role', 'row'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($role, $id) {
        if (\Auth::user('admin')->can('update', \App\User::class)) {
            $title = "Edit User";

            $row = \App\User::findOrFail($id);
            $roles = Role::where('slug', '!=', 'admin')->get()->pluck('name', 'id');

            $roles->prepend('-- Select --', '');

            return view('user::Admin.users.form', compact('title', 'role', 'row', 'roles'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id) {

        $user = \App\User::findOrFail($id);

         
        if($id=='') {

            $val = [ 'password' => 'required|min:6|confirmed',
                    'password_confirmation' => 'required_with:password|same:password|min:6'
                    ];
        }

        $val = [
            'name' => 'required|max:200',
            'email' => 'required|email|unique:users,email,' . $id,
            'phone' => 'required|max:20',
            'address' => 'required',
            'role_id' => 'required'
        ];
        
        if ($request->password != null) {
            $val['password'] = 'required|min:8|confirmed';
        }

        $validatedData = $request->validate($val);

        if ($request->password != null) {
            $request['password'] = \Hash::make($request->password);
        }

        try {
            $updated = $user->update($request->all());
            if ($updated && $request->role_id > 0) {

                // Saving headshot image.
                if ($request->profile_image) {
                    $headshotName = $user->id . '_' . time() . '.' . $request->profile_image->getClientOriginalExtension();
                    $file = $request->profile_image->move(public_path('uploads/user-images'), $headshotName);

                    if ($user->profile_image && \File::exists(public_path('uploads/user-images/' . $user->profile_image))) { // unlink or remove previous image from folder
                        unlink(public_path('uploads/user-images/' . $user->profile_image));
                    }
                    $insertionData['profile_image'] = $headshotName;
                }

                $user->roles()->detach();
                $user->roles()->attach($request->role_id);

                $user->save();
            }
             
        } catch (Exception $e) {
            // Todo: Exception handleing.
        }

        return redirect()->route('admin.users.index', ['roleSlug' => $user->roles->first()->slug])->withSuccess('User has been updated successfully!');
    }

    public function destroy($id) {
          
        try {
            if (\Auth::user('admin')->can('delete', \App\User::class)) {
                User::where('id', $id)->delete();

                $responce = ['status' => true, 'message' => 'This user has been deleted Successfully!'];
            } else {
                return view('Admin.not-authorised');
            }
        } catch (\Exception $e) {
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

}
