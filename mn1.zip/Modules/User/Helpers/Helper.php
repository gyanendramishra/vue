<?php
use Modules\User\Entities\Role;
if (!function_exists('getAvailableRoles')) {    
    function getAvailableRoles()
    {
        $roles = Role::where('is_menu',1)->where('status',1)->get();
        return $roles;
    }
}