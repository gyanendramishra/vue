<?php

namespace Modules\User\Entities;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class Module extends Model {

    use Sortable;
    public $sortable = ['name', 'status', 'created_at'];
    protected $fillable = ['name', 'status'];

}
