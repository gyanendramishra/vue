<?php

namespace Modules\User\Entities;

use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Kyslik\ColumnSortable\Sortable;

class Role extends Model {

    use SoftDeletes;
    use Sortable;
    use HasSlug;

    public $sortable = ['name', 'status', 'created_at'];
    protected $dates = ['deleted_at'];
    protected $fillable = ['name', 'status','is_menu'];

    /**
     *
     * @return type
     */
    public function users() {
        return $this->belongsToMany('App\User');
    }

    /**
     * Get the roles that associated with the user.
     */
    public function permissions() {
        return $this->belongsToMany('Modules\User\Entities\Permission');
    }

    /**
     * Get the options for generating the slug.
     */
    public function getSlugOptions() : SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom('name')
            ->saveSlugsTo('slug');
    }

}
