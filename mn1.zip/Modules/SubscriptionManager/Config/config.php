<?php

return [
    'name' => 'SubscriptionManager'
];
