<?php

namespace Modules\BanList\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\BanList\Entities\BanList;
use Yajra\DataTables\Utilities\Request as DatatableRequest;

class BanListController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        if (\Auth::user('admin')->can('listing', \Modules\BanList\Entities\BanList::class)) {
            $title = "Ban Lists";
            return view('banlist::index', compact('title'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $banLists = BanList::query();
        $banLists = $banLists->get();

        return datatables()->of($banLists)
                        ->addColumn('action', function ($banLists) {
                            $actions = "";
                            if (\Auth::user('admin')->can('update', \Modules\BanList\Entities\BanList::class)) {
                                $actions .= "&nbsp;<a href=\"" . route('admin.banlist.edit', ['id' => $banLists->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                            }
                            if (\Auth::user('admin')->can('delete', \Modules\BanList\Entities\BanList::class)) {
                                $actions .= "&nbsp;<a title='Delete' data-id='" . $banLists->id . "' class='Delete' data-set='{&quot;title&quot;: &quot;Delete Listing&quot;, &quot;parent&quot;: &quot;tr&quot;, &quot;option&quot;: &quot;deleteListing&quot;, &quot;id&quot;: 17, &quot;name&quot;: &quot;Infiniti Coupe Concept&quot;}''><i class='rounded outline icon negative trash link'></i></a>";
                            }
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        if (\Auth::user('admin')->can('create', \Modules\BanList\Entities\BanList::class)) {
            $title = "Add Ban List";
            return view('banlist::createOrUpdate', compact('title'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request) {

        $valRule = [
            'ban_item' => 'required|max:191',
            'ban_type' => 'required',
        ];
        $valMessage = [
            'ban_item.required' => 'The ban item field is required.',
            'ban_type.required' => 'The ban type field is required.',
            'ban_item.max' => 'Sorry, you can\'t add the ban item more than the 191 characters',
        ];

        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $banLists = array();
            $banLists['ban_item'] = $request->input('ban_item');
            $banLists['ban_type'] = $request->input('ban_type');
            $banLists['comment'] = $request->input('comment');
            $banlist = BanList::create($banLists);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.banlist.index')->with('success', 'Ban Item has been saved Successfully');
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id) {
        if (\Auth::user('admin')->can('view', \Modules\BanList\Entities\BanList::class)) {
            return view('banlist::show');
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id) {
        if (\Auth::user('admin')->can('update', \Modules\BanList\Entities\BanList::class)) {
            $title = "Edit Ban List";
            $banList = BanList::find($id);
            return view('banlist::createOrUpdate', compact('title', 'banList'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id) {
        $valRule = [
            'ban_item' => 'required|max:191',
            'ban_type' => 'required',
        ];
        $valMessage = [
            'ban_item.required' => 'The ban item field is required.',
            'ban_type.required' => 'The ban type field is required.',
            'ban_item.max' => 'Sorry, you can\'t add the ban item more than the 191 characters',
        ];

        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $banLists = BanList::find($id);
            $banLists->ban_item = $request->input('ban_item');
            $banLists->ban_type = $request->input('ban_type');
            $banLists->comment = $request->input('comment');
            $banlist = $banLists->save();
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.banlist.index')->with('success', 'Ban Item has been updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id) {
        try {
            if (\Auth::user('admin')->can('delete', \Modules\BanList\Entities\BanList::class)) {
                BanList::where('id', $id)->delete();

                $responce = ['status' => true, 'message' => 'This ban item has been deleted Successfully!'];
            } else {
                return view('Admin.not-authorised');
            }
        } catch (\Exception $e) {
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

}
