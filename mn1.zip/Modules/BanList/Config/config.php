<?php

return [
    'name' => 'BanList'
];
