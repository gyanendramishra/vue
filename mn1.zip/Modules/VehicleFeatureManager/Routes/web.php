<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::prefix('admin')->middleware('auth:admin')->as('admin.')->group(function() {
    
    Route::get('vehiclefeaturemanager/ajax/list', 'VehicleFeatureManagerController@ajaxList')->name('vehiclefeaturemanager.ajax.list');
    Route::get('vehiclefeaturemanager/delete/{id}', 'VehicleFeatureManagerController@destroy')->name('vehiclefeaturemanager.delete');
    Route::resources([
        'vehiclefeaturemanager' => 'VehicleFeatureManagerController',
    ]);
});
