
@extends('layouts.admin.app')
@section('title', !empty($adminRole) ? 'Edit Admin Role' : 'Add Admin Role')
@push('styles')
<link href="{{ asset('/css/migration/jquery-ui.css') }}" rel="stylesheet" />

@endpush
@section('content')

<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.adminrole.index'],['label' => !empty($ads) ? 'Edit Admin Role' : 'Add Admin Role' ]]]) }}
    </div>
</div>

<div class="wojo-grid">


    @if(session()->has('success'))
    <div class="alert alert-success">
        {{ session()->get('success') }}
    </div>
    @endif

    <div class="wojo form segment">
        <div class="wojo secondary icon message"> 
            <div class="content">
                <div class="header">  {{ !empty($adminRole) ? 'Edit Admin Role' : 'Add Admin Role' }}  </div>
            </div>
        </div>
        @if(isset($adminRole))
        {{ Form::model($adminRole, ['route' => ['admin.adminrole.update', $adminRole->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}
        @else
        {{ Form::open(['route' => 'admin.adminrole.store','enctype'=>'multipart/form-data']) }}
        @endif

        @php
        $locales = config('app.locales');
        @endphp

        @include('layouts.flash.alert')

        <div class="wojo secondary message">

            <div class="two fields">
                <div class="field required {{ $errors->has('name') ? 'has-error' : '' }}">
                    <label for="title">{{ __('Name') }} <span class="asterisk">*</span></label>
                    {{ Form::text('name', old('name', (isset($adminRole))?$adminRole->name:"") , ['class' => '','placeholder' => 'Name']) }}
                    @if($errors->has('name'))
                    <span class="help-block">{{  $errors->first('name')  }}</span>
                    @endif
                </div>
                <div class="field required {{ $errors->has('status') ? 'has-error' : '' }}">
                    <label for="status">{{ __('Status') }} </label>
                    {{ Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control']) }}

                    @if($errors->has('status'))
                    <span class="help-block">{{ $errors->first('status') }}</span>
                    @endif
                </div>
            </div>
            <div class="wojo fitted divider"></div>
            
            <div id="feat" class="wojo tab item">
                <div class="two fields">
                    <div class="field ">
                        <h3>{{ __('Permissions')}}</h3>
                    </div>
                </div>
                <div class="wojo divider"></div>
                <div class="columns gutters" id="permissions">
                    @foreach($permissions as $k=>$permission)
                    <h4 class="screen-20 newaddheading">{{$k}}</h4>
                        
                        @foreach($permission as $key=>$permissionn)
                        @php $checked = false;@endphp
                        
                        @if(in_array($permissionn->id, $associated_permissions)) 
                            @php  $checked = true;@endphp
                        @endif
                        <div class="screen-20 tablet-50 phone-100">

                            <label class="checkbox">
                                <input name="permission_id[]" type="checkbox" value="{{$permissionn->id}}"  {{($checked)?'checked':''}}>
                                <i></i>{{$permissionn->name}}
                            </label>
                        </div>
                        @endforeach
                    @endforeach
                   <div class="wojo divider"></div>
                </div>
            </div>
            
            <div class="wojo footer">
                <button type="submit" data-action="updateAccount" name="dosubmit" class="wojo positive button">Save</button>
                <a href="{{ route('admin.adminrole.index') }}" class="wojo negative button" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
            </div>
        </div>

        {{ Form::close() }}
    </div>
</div>
@stop


