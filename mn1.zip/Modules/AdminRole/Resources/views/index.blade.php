@extends('layouts.admin.app')
@push('styles')
{!! Html::style('/css/bootstrap.min.css') !!}
{!! Html::style('css/datatables.net-bs/dataTables.bootstrap.min.css') !!}
@endpush

@section('content')
<div id="crumbs" class="clearfix"> 
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> \Request::route()->getName()],['label' => 'List Admin Roles']]]) }}
    </div>
</div>
<div class="wojo-grid">
    <div class="wojo secondary icon message">
        <div class="content">
            <div class="header"> {{  __( 'List Admin Roles' ) }}    </div>
        </div>
    </div>
    @include('layouts.flash.alert')
    <div class="wojo quaternary segment">
        <div class="header">Filtering Options</div>
        <div class="content">
            <div class="wojo form">
                <div class="three fields">
                    <div class="field">
                        <label>Status</label>
                        {{ Form::select('status', ['' => 'Select',1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control','id'=>'statuss','data-cover'=>'true']) }}
                    </div>        
                </div>
            </div>
        </div>
    </div>
    
    <div class="wojo tertiary segment">
        <div class="header clearfix">
            <span>{{ __('List Admin Roles') }}</span> 
            @can('create',\Modules\AdminRole\Entities\AdminRole::class)  
                <a class="wojo large top right detached action label wojo-tooltip-element" data-content="Add Admin Role" href="{{ route('admin.adminrole.create') }}">
                    <i class="icon plus"></i>
                </a>
            @endcan
        </div>


        <table class="wojo sortable table" id="role-datatable" data-table="admin_roles">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>                              
                    <th>Status</th>                              
                    <th>Created At</th>
                    <th class="no-sort">Actions</th>
                </tr>
            </thead>
        </table>


    </div>
    <div id="msgholder"></div>
</div>
@stop

@push('scripts')
<script type="text/javascript">
    jQuery(function ($) {
        var t = $('#role-datatable').DataTable({
            processing: true,
            serverSide: true,
            aaSorting: [[0, 'desc']],
            language: {

                sLengthMenu: "_MENU_",
                search: "<i class='find icon'></i>",
                searchPlaceholder: "Search...",

            },
            ajax: {
                url: "{{ route('admin.adminrole.ajax.list') }}",
                type: 'GET',
                data: function (d) {
                    d.status = $('#statuss').val();
                }
            },
            columns: [
                {data: 'id', name: 'id'},
                {data: 'name', name: 'name'},
                {data: 'status', name: 'status'},
                {data: 'created_at', name: 'created_at'},
                {data: 'action', name: 'action'}
            ],
            "deferRender": true,
            "columnDefs": [
                {
                    "targets": 'no-sort',
                    "orderable": false,
                },
                {

                    "targets": 2,
                    "data": "status",
                    "render": function (data, type, full, meta) {
                        return '<input id="status" class="switch-status change-request" data-id="' + full.id + '" data-field="status" data-size="mini" ' + ((data == true) ? 'checked' : '') + ' name="status" type="checkbox">';
                    }
                },
                {
                    "targets": 3,
                    "data": "created_at",
                    "render": function (data, type, full, meta) {
                        return moment(data).format('DD MMMM, YYYY ');
                    }
                },
            ],
         
            "fnDrawCallback": function (settings) {

                $('input.switch-status').not('[data-switch-no-init]').bootstrapSwitch();
                $('[data-toggle="tooltip"]').tooltip();

                $('.switch-status.change-request').on('switchChange.bootstrapSwitch', function (e, state) {
                    var _this = $(this);
                    var _id = _this.data("id")
                    var table = _this.closest("table").data("table");
                    if (e.target.checked == true) {
                        var changedval = 1;
                    } else {
                        var changedval = 0;
                    }
                    changeStatus(table, _id, changedval, _this);
                });
            }

        })
        t.on('order.dt search.dt', function () {
            t.column(0, {search: 'applied', order: 'applied'}).nodes().each(function (cell, i) {
                cell.innerHTML = i + 1;
            });
        });
        $('#statuss').on('change', function () {

            $('#pages-datatable').DataTable().draw(true);
        });

    })
</script>
@endpush