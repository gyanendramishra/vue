<?php

namespace Modules\AdminRole\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use \Modules\AdminRole\Entities\AdminRole;
use \Modules\AdminRole\Entities\AdminPermission;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use Modules\AdminRole\Http\Requests\AdminRoleRequest;

class AdminRolesController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        if (\Auth::user('admin')->can('listing', \Modules\AdminRole\Entities\AdminRole::class)) {
            return view('adminrole::index');
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $loginUser = \Auth::user('admin');
        $roles = AdminRole::query();
        if ($request->status != '') {
            $roles = $roles->where('status', $request->status);
        }

        $roles = $roles->get();

        return datatables()->of($roles)
                        ->addColumn('action', function ($roles) use($loginUser) {
                            $actions = "";
                            if (\Auth::user('admin')->can('update', \Modules\AdminRole\Entities\AdminRole::class)) {
                                $actions .= "&nbsp;<a href=\"" . route('admin.adminrole.edit', ['id' => $roles->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                            }
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        if (\Auth::user('admin')->can('create', \Modules\AdminRole\Entities\AdminRole::class)) {
            $associated_permissions[] = '';
            $title = "Add Admin Role";
            $permissions = AdminPermission::where('status', 1)->get();
            $permissions = $permissions->groupBy('module');
            return view('adminrole::createOrUpdate', compact('title', 'permissions', 'associated_permissions'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(AdminRoleRequest $request) {
        try {
            \DB::beginTransaction();

            $adminRole = new AdminRole;
            $adminRole->name = $request->name;
            $adminRole->status = $request->status;
            if ($adminRole->save()) {
                $adminRole->adminRolePermissions()->attach($request->permission_id);
                \DB::commit();
                return redirect()->route('admin.adminrole.index')->with('success', 'Role has been saved Successfully');
            } else {
                return back()->withError('Oops! Something went wrong.')->withInput();
            }
        } catch (Exception $ex) {
            return back()->withError($e->getMessage())->withInput();
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id) {
        if (\Auth::user('admin')->can('view', \Modules\AdminRole\Entities\AdminRole::class)) {
            return view('adminrole::show');
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id) {
        if (\Auth::user('admin')->can('update', \Modules\AdminRole\Entities\AdminRole::class)) {
            $title = "Add Admin Role";
            $adminRole = AdminRole::find($id);
            $permissions = AdminPermission::where('status', 1)->get();
            $permissions = $permissions->groupBy('module');
            $associated_permissions = $adminRole->adminRolePermissions()->pluck('admin_permission_id')->toArray();
            return view('adminrole::createOrUpdate', compact('title', 'permissions', 'adminRole', 'associated_permissions'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(AdminRoleRequest $request, $id) {
        try {
            \DB::beginTransaction();

            $adminRole = AdminRole::find($id);
            $adminRole->name = $request->name;
            $adminRole->status = $request->status;
            if ($adminRole->save()) {
                $adminRole->adminRolePermissions()->sync($request->permission_id);
                \DB::commit();
                return redirect()->route('admin.adminrole.index')->with('success', 'Role has been updated Successfully');
            } else {
                return back()->withError('Oops! Something went wrong.')->withInput();
            }
        } catch (Exception $ex) {
            return back()->withError($e->getMessage())->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id) {
        //
    }

}
