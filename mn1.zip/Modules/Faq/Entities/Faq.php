<?php

namespace Modules\Faq\Entities;

use Illuminate\Database\Eloquent\Model;
use \Dimsav\Translatable\Translatable;

class Faq extends Model {

    use Translatable;

    protected $fillable = [""];
    public $translatedAttributes = ["question", "answer"];
    
    public function FaqTranslation() {
        return $this->hasMany(\Modules\Faq\Entities\FaqTranslation::class, 'faq_id', 'id');
    }
}
