@extends('layouts.admin.app')
@section('title','View Subscription Detail')
@section('content')
<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.subscription.index'],['label' => 'View Subscription Detail']]]) }}
    </div>
</div>

<div class="wojo-grid">
    <div class="wojo form segment">    

        <table class="wojo two column table">
            <tdead>
                <tr class="viewheading">
                    <td colspan="2"> <span><strong> {{ __('Manage Faq')}} </strong></span></td>
                    <td> <a style="float:right;" href="{{route('admin.faq.index')}}" class="btn btn-primary"><span>Back</span></a></td>
                </tr>

            </tdead>
            @php $locales = config('app.locales');@endphp
            
            @foreach($locales as $key=>$val)
             
            <table class="wojo two column table">
                <tdead>
                    <tr>
                        <th  colspan="2">{{  $val }} </th>
                    </tr>
                </tdead>
                <tbody>
                    <tr>
                        <th>{{ __('Question') }}</th>
                        <td>{{  strip_tags($faqs->translate($key)['question'])  }}</td>
                    </tr>
                    <tr>
                        <th>{{ __('Answer') }}</th>
                        <td>{{  strip_tags($faqs->translate($key)['answer'])  }}</td>
                    </tr>
                </tbody>
            </table>
            @endforeach
           
    </div>
</div>


@stop