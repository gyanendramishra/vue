<?php

return [
    'name' => 'Faq'
];
