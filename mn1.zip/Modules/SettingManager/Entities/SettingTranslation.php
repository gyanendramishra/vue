<?php

namespace Modules\SettingManager\Entities;

use Illuminate\Database\Eloquent\Model;

class SettingTranslation extends Model {

    public $timestamps = false;
    
    protected $fillable = ["value"];

    /**
     * Get the comments for the blog post.
     */
}
