<?php

namespace Modules\SettingManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\SettingManager\Entities\Setting;
use Modules\SettingManager\Http\Requests\LogoRequest;
use Modules\SettingManager\Http\Requests\GeneralRequest;

class SettingManagerController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function getlogos(Request $request) {
        if (\Auth::user('admin')->can('logoListing', \Modules\SettingManager\Entities\Setting::class)) {
            $settings = Setting::where('manager', '=', 'theme_images')->get();
            $title = 'Setting Manager';
            return view('settingmanager::Admin.settings.logo-setting', compact('settings', 'title'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function themedelete($id) {
        $setting = Setting::find($id);
        try {
            $setting->delete();
            $responce = ['status' => true, 'message' => 'Setting has been deleted Successfully!', 'data' => $setting];
        } catch (\Exception $e) {
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

    public function storeLogos(LogoRequest $request) {
        $data = $request->input('setting');
        foreach ($request->input('setting') as $setting) {
            $newUser = Setting::updateOrCreate(
                            [
                        'id' => (isset($setting['id']) && !empty($setting['id'])) ? $setting['id'] : 0,
                            ], $setting);
        }

        //die("Done");

        return redirect()->route('settingtheme')->with(['success' => 'Setting saved successfully!']);
    }

    public function storeTempImage(Request $request) {

        $validatedData = $request->validate([
            'file' => 'required|image|mimes:jpeg,png,jpg,gif,icon|max:2048',
                ], [
            'file.max' => 'Image size exceeds 2MB'
                ]
        );

        $real_path = $request->file('file')->store('/public/temp');
        $fake_path = str_replace("public/", "", $real_path);
        $image_path = asset("/storage/" . $fake_path);
        $imageArray = explode("/", $fake_path);
        $imageName = end($imageArray);
        return json_encode(['success' => true, 'image_path' => $image_path, 'fake_path' => $fake_path, 'filename' => $imageName]);
    }

    public function getGeneralSetting(Request $request) {
         
        if (\Auth::user('admin')->can('generalListing', \Modules\SettingManager\Entities\Setting::class)) {
            $allowed_columns = ['id', 'title', 'slug'];
            $sort = in_array($request->get('sort'), $allowed_columns) ? $request->get('sort') : 'created_at';
            $order = $request->get('direction') === 'asc' ? 'asc' : 'desc';
            $settings = Setting::orderBy($sort, $order)->where('manager', 'general')->paginate(config('get.ADMIN_PAGE_LIMIT'));
            $title = 'Setting Manager';
            return view('settingmanager::Admin.settings.general.general-setting', compact('settings', 'title'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    public function addGeneralSetting() {
        $title = 'Setting Manager';
        return view('settingmanager::Admin.settings.general.add', compact('title'));
    }

    public function storeGeneralSetting(Request $request) {
        
        $locales = config('app.locales');
        
        $valRule = [
            'title' => 'required|unique:settings',
            'slug' => 'unique:settings',
        ];
        $valMessage = [
           'title.required' => 'Please enter setting title!',
           'slug.unique' => 'Each setting Constant/slug must have a unique Constant/slug! this Constant already added!!',
        ];

        foreach ($locales as $key => $value) {
            $valRule[$key . '_value'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_value.required'] = ' The value field is required in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);
        try {
            $setting_data = array();
            foreach ($locales as $key => $value) {
                $setting_data[$key]['value'] = $request->input($key . '_value');
            }
            $setting_data['title'] = $request->input('title');
            $setting_data['slug'] = $request->input('slug');
            $setting_data['manager'] = $request->input('manager');
            $setting_data['field_type'] = 'text';
            
            $setting = Setting::create($setting_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('setting.general')->with('success', 'General setting created successfully');
    }

    public function showGeneralSetting($id) {
        if (\Auth::user('admin')->can('view', \Modules\SettingManager\Entities\Setting::class)) {
            $settings = Setting::find($id);
            $title = 'Setting Manager';
            return view('settingmanager::Admin.settings.general.show', compact('settings', 'title'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    public function editGeneralSetting($id) {
        if (\Auth::user('admin')->can('update', \Modules\SettingManager\Entities\Setting::class)) {
            $settings = Setting::find($id);
            $title = 'Setting Manager';
            return view('settingmanager::Admin.settings.general.add', compact('settings', 'title'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    public function updateGeneralSetting(Request $request, $id) {
        
        $locales = config('app.locales');
        
        $valRule = [
            'title' => 'required|unique:settings,id,' . $request->segment(4),
            'slug' => 'unique:settings,id,' . $request->segment(4),
        ];
        $valMessage = [
           'title.required' => 'Please enter setting title!',
           'slug.unique' => 'Each setting Constant/slug must have a unique Constant/slug! this Constant already added!!',
        ];

        foreach ($locales as $key => $value) {
            $valRule[$key . '_value'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_value.required'] = ' The value field is required in ' . $value . ' language.';
        }
        try {
            $setting_data = array();
            foreach ($locales as $key => $value) {
                $setting_data[$key]['value'] = $request->input($key . '_value');
            }
            $setting_data['title'] = $request->input('title');
            $setting_data['slug'] = $request->input('slug');
            $setting_data['manager'] = $request->input('manager');
            $setting_data['field_type'] = 'text';
         
            $setting = Setting::find($id);
            $setting->update($setting_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('setting.general')->with('success', 'Setting updated successfully!');
    }

    public function getSmtpSetting() {
        $smtp = Setting::where('manager', 'smtp')->get();
        $title = 'Setting Manager';
        return view('settingmanager::Admin.settings.smtp', compact('smtp', 'title'));
    }

    public function updateSmtpSetting(Request $request) {
        //dd($request->all());
        foreach ($request->input('setting') as $setting) {
            $newUser = Setting::updateOrCreate(
                            [
                        'slug' => $setting['slug'],
                            ], $setting);
        }

        return redirect()->route('setting.smtp')->with(['success' => 'Settings updated successfully!']);
    }

    public function updateSmtpSettingOld(Request $request) {
        for ($i = 0; $i < count($request->input('slug')); $i++) {
            $setting = Setting::where('slug', $request->input('slug')[$i])->first();
            if ($setting != null) {
                $setting->config_value = $request->input('config_value')[$i];
                $setting->update();
            } else {
                $setting = new Setting();
                $setting->title = $request->input('title')[$i];
                $setting->slug = $request->input('slug')[$i];
                $setting->config_value = $request->input('config_value')[$i];
                $setting->field_type = $request->input('field_type')[$i];
                $setting->manager = $request->input('manager')[$i];
                $setting->save();
            }
        }

        return redirect()->route('setting.smtp')->with(['success' => 'Settings updated successfully!']);
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit() {
        $title = 'Setting Manager';
        return view('settingmanager::edit', compact('title'));
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request) {
        
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy() {
        
    }

}
