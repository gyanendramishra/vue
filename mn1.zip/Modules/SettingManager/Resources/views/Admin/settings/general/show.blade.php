@extends('layouts.admin.app')


@section('content')
<div id="crumbs" class="clearfix">
    <div class="wojo breadcrumb">
      <ol class="breadcrumb">
                <li><a href="{{url('admin/dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="{{route('setting.general')}}">{{ __("Settings") }}</a></li>
                <li><a href="javascript:void(0)" class="active">View General Setting</a></li>
            </ol>
    </div>
  </div>
<div class="wojo-grid">
    <div class="wojo form segment">
       
     
        <table class="wojo two column table">
        <thead>
             <tr class="viewheading">
              <td colspan="2"> <span><strong> {{ __('Setting Detail ')}} </strong></span></td>
              <td> <a style="float:right;" href="{{route('setting.general')}}" class="btn btn-primary"><span>Back</span></a></td>
            </tr>

          </thead>
         
          <tbody>
             
               <tr>
                            <td>Title</td>
                            <td>{{$settings->title}}</td>
                        </tr>
                        <tr>
                            <td>Manager</td>
                            <td>{{$settings->manager}}</td>
                        </tr>
                        <tr>
                            <td>Constant/Slug</td>
                            <td>{{$settings->slug}}</td>
                        </tr>
                        <tr>
                            <td>English Value</td>
                            <td>{{$settings->translate('en')->value}}</td>
                        </tr>
                         <tr>
                            <td>Khmer Value</td>
                            <td>{{$settings->translate('kh')->value}}</td>
                        </tr>
                        <tr>
                            <td>Field Type</td>
                            <td>{{$settings->field_type}}</td>
                        </tr>
                        <tr>
                            <td>Created</td>
                            <td>{{$settings->created_at}}</td>
                        </tr>
                        <tr>
                            <td>Modified</td>
                            <td>{{$settings->updated_at}}</td>
                        </tr>
                     
            
          </tbody>
        </table>
       
      
      
    
    </div>
  </div>


@stop