@extends('layouts.admin.app')
@section('title', 'Website Logo and fav icon')
@push('styles')
{!! Html::style('/css/bootstrap.min.css') !!}
{!! Html::style('css/datatables.net-bs/dataTables.bootstrap.min.css') !!}
{!! Html::style('css/migration/custom.css') !!}

@endpush

 
@section('content')

<div id="crumbs" class="clearfix">
    <div class="wojo breadcrumb">
    </div>
  </div>
  <div class="wojo-grid">
    <div class="wojo form segment wojo-left">
      <div class="wojo secondary icon message"> 
        <div class="content">
          <div class="header"> {{ __('Manage Setting')}} </div>
          <p>Here you can manage the settings</p>
          
        </div>
      </div>
      @include('layouts.flash.alert')
       <table class="table table-hover table-striped">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th scope="col"><a href="{{ URL::route('setting.general',['sort' => 'title','direction'=> request()->direction == 'asc' ? 'desc' : 'asc']) }}">Title</a></th>
                                    <th scope="col"><a href="{{ URL::route('setting.general',['sort' => 'slug','direction'=> request()->direction == 'asc' ? 'desc' : 'asc']) }}">Constant</a></th>
                                    <th scope="col">Value</th>
                                    <th scope="col" class="actions" style="width: 20%;">Actions</th>
                                </tr>
                                </thead>
                                    @if($settings->count() > 0)
                                    <tbody>
                                @php
                                $i = (($settings->currentPage() - 1) * ($settings->perPage()) + 1)
                                @endphp
                                @foreach($settings as $setting)
                                    
                                    
                                    <tr>
                                        <td> {{$i}}. </td>
                                        <td>{{$setting->title}}</td>
                                        <td>{{$setting->slug}}</td>
                                        <td>{{$setting->value}}</td>
                                        <td class="actions">
                                            <div class="btn-group">

                                                <a href="{{url('admin/settings/general/view/'.$setting->id)}}" class="" data-toggle="tooltip" alt="View setting" data-original-title="View"><i class="rounded outline primary icon user profile link "></i></a>

                                                <a href="{{url('admin/settings/general/edit/'.$setting->id)}}" class="" data-toggle="tooltip" alt="Edit" data-original-title="Edit"><i class="rounded outline positive icon pencil link"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                @php
                                    $i++;
                                   
                                @endphp
                                
                                @endforeach
                                </tbody>
                                @else
                                <tfoot>
                                    <tr>
                                        <td colspan='7' align='center'> <strong>Record Not Available</strong> </td>
                                    </tr>
                                </tfoot>
                                @endif
                            </table>
                            <div class="box-footer clearfix">
                            {{$settings->appends(Request::query())->links()}}
                         </div>
    </div>
    <div class="wojo form segment-second wojo-right">
      <div class="wojo secondary icon message"> 
        <div class="content">
          <div class="header">  <small>Important Rules </small> </div>
          <hr>
          <p class="accountmsg">For each config settings that would be added to the system, make sure it has these constant/slug:  </p>

        </div>
      </div>
       
        <div class="form-group">
            <div class="input text required">
               <ul>
                                <li>
                                    <small class="label bg-yellow">
                                        ADMIN_EMAIL 
                                    </small>
                                    - Will be replaced by admin email from the admin settings. 
                                </li>
                                <li>
                                    <small class="label bg-yellow">
                                         FROM_EMAIL 
                                    </small>
                                    -  Will be replaced by email from the admin settings.
                                </li>
                                <li>
                                    <small class="label bg-yellow">
                                          WEBSITE_OWNER  
                                    </small>
                                    -  Will be replaced by Owner name from admin settings.
                                </li>
                                <li>
                                    <small class="label bg-yellow">
                                          TELEPHONE  
                                    </small>
                                    -  Will be replaced by phone number from admin settings.
                                </li>
                                <li>
                                    <small class="label bg-yellow">
                                          ADMIN_PAGE_LIMIT  
                                    </small>
                                    -  Will be replaced by admin page limit from admin settings. 
                                </li>
                                <li>
                                    <small class="label bg-yellow">
                                          FRONT_PAGE_LIMIT  
                                    </small>
                                    -  Will be replaced by front page limit from admin settings.
                                </li>
                                <li>
                                    <small class="label bg-yellow">
                                          ADMIN_DATE_FORMAT  
                                    </small>
                                    - Will be replaced by admin date format from admin settings
                                </li>
                                <li>
                                    <small class="label bg-yellow">
                                          ADMIN_DATE_TIME_FORMAT  
                                    </small>
                                    - Will be replaced by admin date time format from admin settings. 
                                </li>
                                <li>
                                    <small class="label bg-yellow">
                                          FRONT_DATE_FORMAT  
                                    </small>
                                    -  Will be replaced by front date format from admin settings.
                                </li>
                                <li>
                                    <small class="label bg-yellow">
                                           FRONT_DATE_TIME_FORMAT   
                                    </small>
                                    -  Will be replaced by front date time format from admin settings. 
                                </li>
                                <li>
                                    <small class="label bg-yellow">
                                            DEVELOPMENT_MODE    
                                    </small>
                                    -  Will be replaced by debug mode from admin settings. 
                                </li>

                            </ul>
            </div>
        </div>
       
      
    </div>
  </div>
  @endsection
