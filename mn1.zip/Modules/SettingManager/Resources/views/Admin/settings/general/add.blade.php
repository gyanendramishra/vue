@extends('layouts.admin.app')
@section('title', 'Website Logo and fav icon')
@push('styles')
{!! Html::style('/css/bootstrap.min.css') !!}
{!! Html::style('css/datatables.net-bs/dataTables.bootstrap.min.css') !!}

@endpush


@section('content')

<div id="crumbs" class="clearfix">
    <div class="wojo breadcrumb">
        <ol class="breadcrumb">
            <li><a href="{{url('admin/dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{route('setting.general')}}">{{ __("Settings") }}</a></li>
            <li><a href="javascript:void(0)" class="active">{{ !empty($settings) ? 'Edit General Setting' : 'Add General Setting' }}</a></li>
        </ol>
    </div>
</div>
<div class="wojo-grid">
    <div class="wojo form segment wojo-left">
        <div class="wojo secondary icon message"> 
            <div class="content">
                <div class="header">  {{ !empty($settings) ? 'Edit' : 'Add' }} General Setting </div>
                <small>Here you can {{ !empty($settings) ? 'edit' : 'add' }} setting constant/Slug</small>

            </div>
        </div>
        @include('layouts.flash.alert')
        @if(isset($settings))
        {{ Form::model($settings, ['route' => ['setting.general.update', $settings->id], 'method' => 'patch']) }}
        @else
        {{ Form::open(['route' => 'setting.general.store']) }}
        @endif
        {{ Form::hidden('manager', 'general') }}
        <div class="two fields"> 
            <div class="field {{ $errors->has('title') ? 'has-error' : '' }}">
                <label for="name">{{ __('Title') }} </label>
                {{ Form::text('title', old('title'), ['class' => '','placeholder' => 'Title']) }}

                @if($errors->has('title'))
                <span class="help-block">{{ $errors->first('title') }}</span>
                @endif
            </div>
            <div class="field  {{ $errors->has('slug') ? 'has-error' : '' }}">
                <label for="name">{{ __('Constant/Slug') }} </label>
                {{ Form::text('slug', old('slug'), ['class' => '','placeholder' => 'Constant/Slug' ,'readonly' => isset($settings) ? true : false]) }}
                <span class="help-block settingrequiremsg">No space, separate each word with underscore. (if you want auto generated then please leave blank)</span>
            </div>
        </div>
       
            <div class="two field">
                
                    <div class="required {{ $errors->has('en_value') ? 'has-error' : '' }}">
                        <label for="name">{{ __('English Value') }} </label>

                        {{ Form::textarea('en_value',old('en_value',(isset($settings))?$settings->translate('en')['value']:""), ['class' => 'form-control','placeholder' => 'Value' ,'rows' => 5]) }}

                        @if($errors->has('en_value'))
                        <span class="help-block">{{ $errors->first('en_value') }}</span>
                        @endif
                    </div>
               <div class="required {{ $errors->has('kh_value') ? 'has-error' : '' }}">
                        <label for="name">{{ __('Khmer Value') }} </label>

                        {{ Form::textarea('kh_value',old('kh_value',(isset($settings))?$settings->translate('kh')['value']:""), ['class' => 'form-control','placeholder' => 'Value' ,'rows' => 5]) }}

                        @if($errors->has('kh_value'))
                        <span class="help-block">{{ $errors->first('kh_value') }}</span>
                        @endif
                    </div>
            </div>
     
        
        <div class="wojo fitted divider"></div>
        <div class="box-footer">
            <button class="wojo positive button" data-action="updateAccount1" title="Submit" type="submit"> Submit  </button>
            <a href="{{route('setting.general')}}" class="wojo negative button" title="Back">Back</a>
        </div>
        {{ Form::close() }}                
    </div>
    <div class="wojo form segment-second wojo-right">
        <div class="wojo secondary icon message"> 
            <div class="content">
                <div class="header">  <small>Important Rules </small> </div>
                <hr>
                <p class="accountmsg">For each config settings that would be added to the system, make sure it has these constant/slug:  </p>

            </div>
        </div>

        <div class="form-group">
            <div class="input text required">
                <ul>
                    <li>
                        <small class="label bg-yellow">
                            ADMIN_EMAIL 
                        </small>
                        - Will be replaced by admin email from the admin settings. 
                    </li>
                    <li>
                        <small class="label bg-yellow">
                            FROM_EMAIL 
                        </small>
                        -  Will be replaced by email from the admin settings.
                    </li>
                    <li>
                        <small class="label bg-yellow">
                            WEBSITE_OWNER  
                        </small>
                        -  Will be replaced by Owner name from admin settings.
                    </li>
                    <li>
                        <small class="label bg-yellow">
                            TELEPHONE  
                        </small>
                        -  Will be replaced by phone number from admin settings.
                    </li>
                    <li>
                        <small class="label bg-yellow">
                            ADMIN_PAGE_LIMIT  
                        </small>
                        -  Will be replaced by admin page limit from admin settings. 
                    </li>
                    <li>
                        <small class="label bg-yellow">
                            FRONT_PAGE_LIMIT  
                        </small>
                        -  Will be replaced by front page limit from admin settings.
                    </li>
                    <li>
                        <small class="label bg-yellow">
                            ADMIN_DATE_FORMAT  
                        </small>
                        - Will be replaced by admin date format from admin settings
                    </li>
                    <li>
                        <small class="label bg-yellow">
                            ADMIN_DATE_TIME_FORMAT  
                        </small>
                        - Will be replaced by admin date time format from admin settings. 
                    </li>
                    <li>
                        <small class="label bg-yellow">
                            FRONT_DATE_FORMAT  
                        </small>
                        -  Will be replaced by front date format from admin settings.
                    </li>
                    <li>
                        <small class="label bg-yellow">
                            FRONT_DATE_TIME_FORMAT   
                        </small>
                        -  Will be replaced by front date time format from admin settings. 
                    </li>
                    <li>
                        <small class="label bg-yellow">
                            DEVELOPMENT_MODE    
                        </small>
                        -  Will be replaced by debug mode from admin settings. 
                    </li>

                </ul>
            </div>
        </div>


    </div>
</div>
@endsection
