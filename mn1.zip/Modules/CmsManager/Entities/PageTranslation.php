<?php

namespace Modules\CmsManager\Entities;

use Illuminate\Database\Eloquent\Model;

class PageTranslation extends Model {

    protected $table = 'page_translations';
    public $timestamps = false;
    protected $fillable = ["locale","title", "sub_title", "short_description", "description", "meta_title", "meta_keyword", "meta_description"];

}
