<?php

namespace Modules\VehicleBadgeManager\Entities;

use Illuminate\Database\Eloquent\Model;
use \Dimsav\Translatable\Translatable;
use Cviebrock\EloquentSluggable\Sluggable;

class VehicleBadge extends Model {

    use Translatable;
    use Sluggable;

    const ACTIVE = 1;
    const IN_ACTIVE = 0;

    protected $fillable = ["slug","makes_id", "models_id", "status", 'icon'];
    public $translatedAttributes = ['name'];

    /**
     * Scope a query to only include active competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query) {
        return $query->where('status', self::ACTIVE);
    }

    /**
     * Scope a query to include given type of competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfActive($query, $type) {
        return $query->whereStatus($type);
    }

    /**
     * Get the make of the badge.
     */
    public function make() {

        return $this->belongsTo(\Modules\VehicleMakeManager\Entities\VehicleMake::class, 'makes_id', 'id');
    }

    /**
     * Get the model of the badge.
     */
    public function model() {

        return $this->belongsTo(\Modules\VehicleModelManager\Entities\VehicleModel::class, 'models_id', 'id');
    }

    /**
     * Get the series of the badge.
     */
    public function series() {

        return $this->hasMany(\Modules\VehicleModelManager\Entities\VehicleModel::class, 'badges_id', 'id');
    }
    /**
     * Get the badge translations.
     */
    public function VehicleBadgeTranslations() {

        return $this->hasMany(\Modules\VehicleBadgeManager\Entities\VehicleBadgeTranslation::class);
    }

    /**
     * Get the badge vehicles.
     */
    public function vehicles() {

        return $this->hasMany(\Modules\VehicleManager\Entities\Vehicle::class, 'badge_id', 'id');
    }
    /**
     * Get the sluggable.
     */
    public function sluggable() {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }

}
