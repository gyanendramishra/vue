<?php

namespace Modules\VehicleBadgeManager\Entities;

use Illuminate\Database\Eloquent\Model;

class VehicleBadgeTranslation extends Model {

    public $timestamps = false;
    protected $fillable = ['name'];

    /**
     * Get the comments for the blog post.
     */
    public function make() {

        return $this->belongsTo(\Modules\VehicleMakeManager\Entities\VehicleMake::class, 'makes_id', 'id');
    }

    public function model() {

        return $this->belongsTo(\Modules\VehicleModelManager\Entities\VehicleModel::class, 'models_id', 'id');
    }
    public function vehicleBadge() {

        return $this->belongsTo(\Modules\VehicleBadgeManager\Entities\VehicleBadge::class);
    }

}
