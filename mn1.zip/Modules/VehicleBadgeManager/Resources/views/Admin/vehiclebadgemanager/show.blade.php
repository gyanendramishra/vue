@extends('layouts.admin.master')
@section('title','View Vehicle Badge Detail')
@section('content')
@include('layouts.admin.flash.alert')
<section class="content-header">
    <h1>
        Manage Vehicle Badge       
    </h1>
    {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.vehiclebadgemanager.index'],['label' => 'View Vehicle Badge Detail']]]) }}
</section>

<section class="content" data-table="emailHooks">
    @include('layouts.flash.alert')
    <div class="box">
        <div class="box-header"><h3 class="box-title">{{ $vehiclebadge->name }}</h3>
            <a href="{{route('admin.vehiclebadgemanager.index')}}" class="btn btn-default pull-right" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
        </div>
        <div class="box-body">
            <table class="table table-hover table-striped">
				 <tr>
                    <th scope="row">{{ __('Make') }}</th>
                    <td>{{ $vehiclebadge->make->name }}</td>
                </tr>
				 <tr>
                    <th scope="row">{{ __('Model') }}</th>
                    <td>{{ $vehiclebadge->model->name }}</td>
                </tr>
                <tr>
                    <th scope="row">{{ __('Name') }}</th>
                    <td>{{ $vehiclebadge->name }}</td>
                </tr>
                <tr>
                    <th scope="row"><?= __('Created') ?></th>
                    <td>{{ $vehiclebadge->created_at->toFormattedDateString() }}</td>
                </tr>
                <tr>
                    <th scope="row">{{ __('Modified') }}</th>
                    <td>{{ $vehiclebadge->updated_at->toFormattedDateString() }}</td>
                </tr>
                <tr>
                    <th scope="row">{{ __('Status') }}</th>
                    <td>{{ $vehiclebadge->status ? __('Active') : __('Inactive')  }}</td>
                </tr>
            </table>           
        </div>
        <div class="box-footer">
                <a href="{{route('admin.vehiclebadgemanager.index')}}" class="btn btn-default pull-left" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
        </div>
    </div>
</section>

@endsection
