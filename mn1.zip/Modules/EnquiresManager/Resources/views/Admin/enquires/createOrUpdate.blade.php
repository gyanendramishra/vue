@extends('layouts.admin.app')
@section('title', !empty($enquires) ? 'Edit Vehicle Audio, Visual & Communication' : 'Add Vehicle Audio, Visual & Communication')
@push('styles')
    {!! Html::style('/css/migration/custom.css') !!}

@endpush
@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            {{ __( 'Manage Vehicle Audio, Visual & Communication' ) }}           
        </h1>
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.enquires.index'],['label' => !empty($enquires) ? 'Edit Vehicle Audio, Visual & Communication' : 'Add Vehicle Audio, Visual & Communication' ]]]) }}
    </section>
    <!-- Main content -->
    <section class="content">
	    @include('layouts.flash.alert')
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">{{ !empty($enquires) ? 'Edit Vehicle Audio, Visual & Communication' : 'Add Vehicle Audio, Visual & Communication' }}</h3>
                <div class="box-tools pull-right">
                    <a href="{{ route('admin.enquires.index') }}" class="btn btn-primary">Back</a>
                </div>
            </div>
            <div class="box-body">
                @if(session()->has('success'))
                <div class="alert alert-success">
                    {{ session()->get('success') }}
                </div>
                @endif
				
				@if(isset($enquires))
                    {{ Form::model($enquires, ['route' => ['admin.enquires.update', $enquires->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}
                @else
                    {{ Form::open(['route' => 'admin.enquires.store','enctype'=>'multipart/form-data']) }}
                @endif
				 <div class="nav-tabs-custom">                       
                    <div class="tab-content">
					
                    <div class="row">
                        <div class="col-md-6">

                            <div class="form-group required {{ $errors->has('name') ? 'has-error' : '' }}">
                                <label for="title">Name <span class="asterisk">*</span></label>
                                {{ Form::text('name', old('name'), ['class' => 'form-control','placeholder' => 'Name']) }}
                                @if($errors->has('name'))
                                <span class="help-block">{{ $errors->first('name') }}</span>
                                @endif
                              </div>

                             <div class="form-group required {{ $errors->has('status') ? 'has-error' : '' }}">
                                <label for="title">Status <span class="asterisk">*</span></label>
                                {{ Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control']) }}
                                @if($errors->has('status'))
                                <span class="help-block">{{ $errors->first('status') }}</span>
                                @endif
                              </div>
                        </div>

                    </div> <!-- /.row -->
					
					
 </div>
                </div>
				
 <div class="box-footer">
                        <button class="btn btn-primary btn-flat" title="Submit" type="submit"><i class="fa fa-fw fa-save"></i> Submit</button>
                        <a href="{{ route('admin.enquires.index') }}" class="btn btn-warning btn-flat" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
                    </div>
            {{ Form::close() }}
        </div>
</div>
</section>
<!-- /.content -->
</div>

@stop