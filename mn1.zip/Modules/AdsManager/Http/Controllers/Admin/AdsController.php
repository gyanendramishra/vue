<?php

namespace Modules\Adsmanager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Input;
use Modules\AdsManager\Entities\Ad;
use Modules\AdsManager\Http\Requests\AdsRequest;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use App\PageLocation;
use App\Position;
use File;

class AdsController extends Controller {

    public function index() {
        if (\Auth::user('admin')->can('listing', \Modules\AdsManager\Entities\Ad::class)) {
            $title = "Ads";
            //return view('user::Admin.pages.index', ['title' => $title]);
            return view('adsmanager::Admin.ads.index', compact('title'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $ads = Ad::with(['position', 'page_location']);
        if ($request->status != '') {
            $ads = $ads->where('status', $request->status);
        }
        if ($request->slug != '') {
            $slug = $request->slug;
            $ads = $ads->whereHas('adTranslations', function($q) use($slug) {
                $q->where('title', 'LIKE', ucfirst($slug) . '%');
                $q->orWhere('title', 'LIKE', lcfirst($slug) . '%');
                $q->orWhere('title', 'LIKE', $slug . '%');
            });
        }
        $ads = $ads->get();


        return datatables()->of($ads)
                        ->addColumn('action', function ($ad) {
                            $actions = "";
                            if (\Auth::user('admin')->can('view', \Modules\AdsManager\Entities\Ad::class)) {
                                $actions .= "<a href=\"" . route('admin.ads.show', ['id' => $ad->id]) . "\" class=\"\"><i class=\"rounded outline primary icon user profile link\"></i></a>";
                            }
                            if (\Auth::user('admin')->can('update', \Modules\AdsManager\Entities\Ad::class)) {
                                $actions .= "&nbsp;<a href=\"" . route('admin.ads.edit', ['id' => $ad->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                            }
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        if (\Auth::user('admin')->can('create', \Modules\AdsManager\Entities\Ad::class)) {
            $title = "Add Advertisement";
            $pageLocation = PageLocation::orderBy('name', 'ASC')->pluck('name', 'id')->toArray();
            $position = Position::orderBy('name', 'ASC')->pluck('name', 'id')->toArray();
            return view('adsmanager::Admin.ads.createOrUpdate', compact('title', 'pageLocation', 'position'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request) {

        $locales = config('app.locales');
        $valRule = [
            'page_location_id' => 'required',
            'position_id' => 'required',
            'status' => 'required'
        ];
        $valMessage = [
            'page_location_id.required' => ' The page location field is required.',
            'position_id.required' => ' The position field is required.',
            'status.required' => ' The status field is required.'
        ];
        foreach ($locales as $key => $value) {
            if ($key == 'en') {
                $valRule[$key . '_title'] = 'required|max:200';
                $valRule[$key . '_image_type'] = 'required';
                if ($request->get($key . '_image_type') == 1) {
                    $valRule[$key . '_image'] = 'required|mimes:jpeg,jpg,png|max:5000';
                    $valRule[$key . '_url'] = 'required|url';
                }
                if ($request->get($key . '_image_type') == 2) {
                    $valRule[$key . '_image_scripts'] = 'required';
                }
            }
        }
        foreach ($locales as $key => $value) {
            if ($key == 'en') {

                $valMessage[$key . '_title.required'] = ' The title field is required';
                $valMessage[$key . '_title.max'] = 'Sorry, you can\'t add the title more than the 200 characters';
                $valMessage[$key . '_image_type.required'] = ' The Image type field is required';
                $valMessage[$key . '_image.required'] = ' The Image field is required';
                $valMessage[$key . '_image.mimes'] = ' Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat';
                $valMessage[$key . '_image.max'] = 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB';
                $valMessage[$key . '_url.required'] = ' The url field is required';
                $valMessage[$key . '_url.url'] = 'The url format is invalid';
                $valMessage[$key . '_image_scripts.required'] = ' The Script field is required';
            }
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $article_data = array();

            foreach ($locales as $key => $value) {
                if ($key == 'en') {
                    $article_data[$key]['title'] = $request->input($key . '_title');
                    $article_data[$key]['image_type'] = $request->input($key . '_image_type');
                    $article_data[$key]['url'] = $request->input($key . '_url');
                    $article_data[$key]['image_scripts'] = $request->input($key . '_image_scripts');
                    if ($request->hasFile($key . '_image')) {
                        $image = $request->file($key . '_image');
                        $is_dest = "uploads/adsImages/";
                        if (!file_exists($is_dest)) {
                            mkdir($is_dest, 0777, true);
                        }
                        $directory = public_path($is_dest);
                        $directory = str_replace("\\", "/", $directory);
                        $file = Input::file($key . '_image');
                        $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                        $filenameOrig = time() . "-" . rand() . "." . $extension;

                        if ($image->move($directory, $filenameOrig)) {
                            $article_data[$key]['image'] = $filenameOrig;
                        }
                    }
                }
            }
            $article_data['status'] = $request->input('status');
            $article_data['page_location_id'] = $request->input('page_location_id');
            $article_data['position_id'] = $request->input('position_id');

            Ad::create($article_data);
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->getMessage());
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.ads.index')->with('success', 'Advertisement has been saved Successfully');
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show($id) {
        if (\Auth::user('admin')->can('view', \Modules\AdsManager\Entities\Ad::class)) {
            $title = "Advertisement Detail";
            $ads = Ad::findOrFail($id)->where('id', '=', $id)->with('position', 'page_location')->first();
            return view('adsmanager::Admin.ads.show', compact('title', 'ads'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id) {
        if (\Auth::user('admin')->can('update', \Modules\AdsManager\Entities\Ad::class)) {
            $title = "Add Advertisement";
            $ads = Ad::where('id', '=', $id)->first();
            $pageLocation = PageLocation::orderBy('name', 'ASC')->pluck('name', 'id')->toArray();
            $position = Position::orderBy('name', 'ASC')->pluck('name', 'id')->toArray();
            return view('adsmanager::Admin.ads.createOrUpdate', compact('title', 'ads', 'pageLocation', 'position'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id) {

        $locales = config('app.locales');
        $valRule = [
            'page_location_id' => 'required',
            'position_id' => 'required',
            'status' => 'required'
        ];
        $valMessage = [
            'page_location_id.required' => ' The page location field is required.',
            'position_id.required' => ' The position field is required.',
            'status.required' => ' The status field is required.'
        ];
        foreach ($locales as $key => $value) {
            if ($key == 'en') {
                $valRule[$key . '_title'] = 'required|max:200';
                $valRule[$key . '_image_type'] = 'required';
                if ($request->get($key . '_image_type') == 1) {
                    $valRule[$key . '_image'] = 'sometimes||mimes:jpeg,jpg,png|max:5000';
                    $valRule[$key . '_url'] = 'required|url';
                }
                if ($request->get($key . '_image_type') == 2) {
                    $valRule[$key . '_image_scripts'] = 'required';
                }
            }
        }
        foreach ($locales as $key => $value) {
            if ($key == 'en') {

                $valMessage[$key . '_title.required'] = ' The title field is required';
                $valMessage[$key . '_title.max'] = 'Sorry, you can\'t add the title more than the 200 characters';
                $valMessage[$key . '_image_type.required'] = ' The Image type field is required';
                $valMessage[$key . '_image.mimes'] = ' Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat';
                $valMessage[$key . '_image.max'] = 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB';
                $valMessage[$key . '_url.required'] = ' The url field is required';
                $valMessage[$key . '_url.url'] = 'The url format is invalid';
                $valMessage[$key . '_image_scripts.required'] = ' The Script field is required';
            }
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $article_data = array();

            foreach ($locales as $key => $value) {
                if ($key == 'en') {
                    $article_data[$key]['title'] = $request->input($key . '_title');
                    $article_data[$key]['image_type'] = $request->input($key . '_image_type');
                    $article_data[$key]['url'] = $request->input($key . '_url');
                    $article_data[$key]['image_scripts'] = $request->input($key . '_image_scripts');
                    if ($request->hasFile($key . '_image')) {

                        $image = $request->file($key . '_image');
                        $is_dest = "uploads/adsImages/";
                        if (!file_exists($is_dest)) {
                            mkdir($is_dest, 0777, true);
                        }
                        $directory = public_path($is_dest);
                        $directory = str_replace("\\", "/", $directory);
                        $file = Input::file($key . '_image');
                        $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                        $filenameOrig = time() . "-" . rand() . "." . $extension;

                        if ($image->move($directory, $filenameOrig)) {
                            $article_data[$key]['image'] = $filenameOrig;
                        }
                    }
                }
            }
            $article_data['status'] = $request->input('status');
            $article_data['page_location_id'] = $request->input('page_location_id');
            $article_data['position_id'] = $request->input('position_id');

            $ad = Ad::find($id);
            $ad->update($article_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.ads.index')->with('success', 'Advertisement has been updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id) {
        Ad::where('id', $id)->delete();
        return redirect()->route('admin.ads.index')->with('success', 'Advertisement deleted successfully.');
    }

}
