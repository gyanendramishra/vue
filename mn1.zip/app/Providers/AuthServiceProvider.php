<?php

namespace App\Providers;

use App\Policies\Frontend\VehiclePolicy;
use App\Policies\Admin\AdminUserPolicy;
use App\Policies\Admin\AdminRolePolicy;
use App\Policies\Admin\AdminStaffPolicy;
use App\Policies\Admin\InquiryPolicy;
use App\Policies\Admin\VehicleInquiryPolicy;
use App\Policies\Admin\CategoryPolicy;
use App\Policies\Admin\AdminVehiclePolicy;
use App\Policies\Admin\MakePolicy;
use App\Policies\Admin\ModelPolicy;
use App\Policies\Admin\BadgePolicy;
use App\Policies\Admin\SeriesPolicy;
use App\Policies\Admin\DriveTypePolicy;
use App\Policies\Admin\FuelTypePolicy;
use App\Policies\Admin\TransmissionPolicy;
use App\Policies\Admin\BodyTypePolicy;
use App\Policies\Admin\ColorPolicy;
use App\Policies\Admin\LifestylePolicy;
use App\Policies\Admin\FeaturesPolicy;
use App\Policies\Admin\NewsPolicy;
use App\Policies\Admin\AdsPolicy;
use App\Policies\Admin\SubscriptionPolicy;
use App\Policies\Admin\CmsPagePolicy;
use App\Policies\Admin\EmailTemplatePolicy;
use App\Policies\Admin\VehicleInspectionPolicy;
use App\Policies\Admin\VehicleReviewPolicy;
use App\Policies\Admin\DiscountCouponPolicy;
use App\Policies\Admin\BanListPolicy;
use App\Policies\Admin\FAQPolicy;
use App\Policies\Admin\SettingsPolicy;
use Modules\User\Entities\Role;
use Illuminate\Support\Facades\Gate;
use Modules\VehicleManager\Entities\Vehicle as AdminVehicle;
use Modules\VehicleManager\Entities\Vehicle;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Laravel\Passport\Passport;

class AuthServiceProvider extends ServiceProvider {

    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        'App\Model' => 'App\Policies\ModelPolicy',
        Vehicle::class => VehiclePolicy::class,
        \App\User::class => AdminUserPolicy::class,
        \Modules\StaffManager\Entities\AdminUser::class => AdminStaffPolicy::class,
        \Modules\AdminRole\Entities\AdminRole::class => AdminRolePolicy::class,        
        \Modules\CategoryManager\Entities\Category::class => CategoryPolicy::class,
        \Modules\EnquiresManager\Entities\Inquiry::class => InquiryPolicy::class,
        \Modules\VehicleMakeManager\Entities\VehicleMake::class => MakePolicy::class,
        \Modules\VehicleModelManager\Entities\VehicleModel::class => ModelPolicy::class,
        \Modules\VehicleBadgeManager\Entities\VehicleBadge::class => BadgePolicy::class,
        \Modules\VehicleSeriesManager\Entities\VehicleSeries::class => SeriesPolicy::class,
        \Modules\VehicleDriveTypesManager\Entities\VehicleDriveTypes::class => DriveTypePolicy::class,
        \Modules\VehicleFuelTypesManager\Entities\VehicleFuelTypes::class => FuelTypePolicy::class,
        \Modules\VehicleBodyStyleManager\Entities\VehicleBodyStyle::class => BodyTypePolicy::class,
        \Modules\VehicleTransmissionsManager\Entities\VehicleTransmissions::class => TransmissionPolicy::class,
        \Modules\VehicleFeatureManager\Entities\VehicleFeature::class => FeaturesPolicy::class,
        \Modules\VehicleColorsManager\Entities\VehicleColors::class => ColorPolicy::class,
        \Modules\SubscriptionManager\Entities\SubscriptionPlan::class => SubscriptionPolicy::class,
        \Modules\VehicleLifestyleManager\Entities\VehicleLifestyle::class => LifestylePolicy::class,
        \Modules\CmsManager\Entities\Page::class => CmsPagePolicy::class,
        \Modules\AdsManager\Entities\Ad::class => AdsPolicy::class,
        \App\EmailTemplate::class => EmailTemplatePolicy::class,
        \Modules\VehicleReviewsManager\Entities\VehicleReview::class => VehicleReviewPolicy::class,
        \Modules\VehicleInspectionsManager\Entities\VehicleInspection::class => VehicleInspectionPolicy::class,
        \Modules\VehicleEnquiresManager\Entities\Conversation::class => VehicleInquiryPolicy::class,
        \Modules\Faq\Entities\Faq::class => FAQPolicy::class,
        \Modules\DiscountCoupon\Entities\DiscountCoupon::class => DiscountCouponPolicy::class,
        \Modules\SettingManager\Entities\Setting::class => SettingsPolicy::class,
        \Modules\BanList\Entities\BanList::class => BanListPolicy::class,
        //Vehicle::class => AdminUserPolicy::class,
        \Modules\NewsManager\Entities\News::class => NewsPolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot() {
        $this->registerPolicies();
        Passport::routes();
        
        Gate::define('view-listing', 'App\Policies\Admin\AdminVehiclePolicy@listing');
        Gate::define('create-vehicle', 'App\Policies\Admin\AdminVehiclePolicy@createVehicle');
        Gate::define('view-vehicle', 'App\Policies\Admin\AdminVehiclePolicy@viewVehicle');
        Gate::define('update-vehicle', 'App\Policies\Admin\AdminVehiclePolicy@updateVehicle');
        Gate::define('delete-vehicle', 'App\Policies\Admin\AdminVehiclePolicy@deleteVehicle');
    }

    public function registerComposerViews() {
        \Illuminate\Support\Facades\View::composer('*', function ($view) {
            $view->with('User', Auth::guard('admin')->user());
        });

        \Illuminate\Support\Facades\View::composer('*', function ($view) {
            $action = app('request')->route() ? app('request')->route()->getAction() : '';
            if (isset($action['controller'])) {
                $controller = class_basename($action['controller']);
                list($controller, $action) = explode('@', $controller);
                $view->with(['getController' => str_replace('Controller', '', $controller), 'getAction' => $action]);
            }
        });
    }

}
