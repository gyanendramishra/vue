<?php
namespace App\Http\Controllers\Admin;


use Auth;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Storage;

class AdminUsersController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        return view('index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        return view('create');
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show()
    {
        return view('show');
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit()
    {
        return view('edit');
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request)
    {
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy()
    {
    }

    public function profile()
    {

        $user = Auth::user();
        return view('Admin.AdminUsers.profile', compact('user'));
    }

    public function UpdateProfile(Request $request)
    {

        $validatedData = $request->validate([
            'name'   => 'required|max:100',
            'email'  => 'required|email|max:100',
            'phone' => 'required|phone'
        ]);
        //Change Password
        $user = Auth::user();

        //Move Banner Image
        if ($user->profile_photo != $request->profile_photo && $request->profile_photo != "") {
            Storage::move('public/temp/' . $request->profile_photo, 'public/profile_photo/' . $request->profile_photo);
            $exists = Storage::disk('public')->exists('profile_photo/' . $user->profile_photo);
            if ($exists) {
                Storage::disk('public')->delete('profile_photo/' . $user->profile_photo);
            }

            $user->profile_photo = $request->get('profile_photo');
        }

        $user->name   = $request->get('name');
        $user->email  = $request->get('email');
        $user->phone = $request->get('phone');
        $user->save();
        return redirect()->back()->with("success", " Your account detail has been updated!");

    }

    public function storeTempImage(Request $request)
    {

        $real_path  = $request->file('file')->store('public/temp');
        $fake_path  = str_replace("public/", "", $real_path);
        $image_path = asset("storage/" . $fake_path);
        $imageArray = explode("/", $fake_path);
        $imageName  = end($imageArray);
        return json_encode(['success' => true, 'image_path' => $image_path, 'fake_path' => $fake_path, 'filename' => $imageName]);
    }

    /**
     * Show the change password form for change a new password.
     * @return Response
     */

    public function showChangePasswordForm()
    {
        return view('Admin.AdminUsers.changepassword');
    }

    public function changePassword(Request $request)
    {
        if (!(Hash::check($request->get('current-password'), Auth::user()->password))) {
            // The passwords matches
            return redirect()->back()->withInput()->with("error", "Your current password does not matches with the password you provided. Please try again.");
        }
        if (strcmp($request->get('current-password'), $request->get('new-password')) == 0) {
            //Current password and new password are same
            return redirect()->back()->withInput()->with("error", "New Password cannot be same as your current password. Please choose a different password.");
        }
        //'required', 'string', 'min:6', 'max:100'
        $validatedData = $request->validate([
            'current-password' => 'required',
            'new-password'     => 'required|string|min:8|max:100|confirmed',
        ], [
            'new-password.confirmed' => 'Your new password and Confirm New Password do not match',
            'new-password.regex'     => 'Password must be at least 6 characters long, contain at least one number, one special character and have a mixture of uppercase and lowercase letters.',
        ]);
        //Change Password
        $user           = Auth::user();
        $user->password = bcrypt($request->get('new-password'));
        $user->save();
        return redirect()->back()->with("success", "Password changed successfully !");
    }
}
