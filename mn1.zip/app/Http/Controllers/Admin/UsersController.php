<?php

namespace App\Http\Controllers\Admin;

use App\Role;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Storage;
use View;

class UsersController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       /*  if (app('request')->query('role') == 2 || app('request')->query('role') == "") {
            $labelTitle = "Editor";
        } elseif (app('request')->query('role') == 3) {
            $labelTitle = "Customer";
        } elseif (app('request')->query('role') == 4) {
            $labelTitle = "Staff";
        }
         else { */
            $labelTitle = "User";
       // }
        View::share('labelTitle', $labelTitle);



    }

    /**
     * Display a listing of the resource according to their role.
	 *@parameter role id
     * @return Response
     */
    public function index(Request $request)
    {
        //echo auth()->user()->can('access', 'view_users'); exit;
        if (auth()->user()->can('access', 'view_users') == false){
            return redirect('/admin/dashboard')->with('error', 'You don\'t have permission to access this page!');
        }

        $allowed_columns = ['id', 'name', 'email','status'];
        $sort            = in_array($request->get('sort'), $allowed_columns) ? $request->get('sort') : 'created_at';
        $order           = $request->get('direction') === 'asc' ? 'asc' : 'desc';
        $ofType          = $request->get('role') ? $request->get('role') :Config::get('constants.ROLE.BUYER');
        $users           = User::where('role_id', $ofType);

        if (Input::has('status') && Input::get('status') != "") {
            $users = $users->where('status', Input::get('status'));
        }
        if (Input::has('q') && Input::get('q') != "") {
            $users = $users->Where(function ($query) {
                $query->where('name', 'like', '%' . Input::get('q') . '%')
                    ->orWhere('email', 'like', '%' . Input::get('q') . '%')
                    ->orWhere('phone', 'like', '%' . Input::get('q') . '%');
            });
        }

        $users = $users->orderBy($sort, $order)->paginate(config('get.ADMIN_PAGE_LIMIT'));

        $roles = Role::where('id', '!=', Config::get('constants.ROLE.ADMIN'))->orderBy('id', 'asc')->pluck('title', 'id')->toArray();
        return view('Admin.users.index', compact('users', 'roles', 'ofType'));
    }

    /**
     * Show the form for creating a new user.
	 * Parameter : None
     * @return Response, show add form
     */
    public function create()
    {
        $roles = Role::where('id', '!=', Config::get('constants.ROLE.ADMIN'))->orderBy('title', 'DESC')->pluck('title', 'id')->toArray();
        return view('Admin.users.createOrUpdate', compact('roles'));
    }

    /**
     * Store a newly created resource in storage. We are managing validation as well from here
     * @param  Request $request, form all data
     * @return Response, sucess message
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name'     => 'required|min:2|max:100',
            'email'    => 'required|email|max:100|unique:users,email,' . $request->segment(3),
            'phone'    => 'required|phone',
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'role_id'  => 'required|in:2,3,4,5'
        ]);

        DB::beginTransaction();
        try {
            $pass = $request['password'];
            $request['password'] = Hash::make($request['password']);
            $request['email_verified_at'] = date("Y-m-d H:i:s");

            //$email_verified_at = date("Y-m-d H:i:s");

            $input = $request->except(['role']);
            $user = User::create($input);
            DB::commit();

            //Move Banner Image
            if ($request->profile_photo != "") {
                Storage::move('public/temp/' . $request->profile_photo, 'public/profile_photo/' . $request->profile_photo);
            }

            $token = app('auth.password.broker')->createToken($user);
            if($request->role_id == Config::get('constants.ROLE.SELLER')){
                $hooksVars['RESET_PASSWORD_URL'] = \App::make('url')->to('/admin/password/reset/'.$token);
            }
            else{
                $hooksVars['RESET_PASSWORD_URL'] = \App::make('url')->to('/password/reset/'.$token);
            }


            $hooksVars['USER_NAME'] = ucwords($user->name);
            $hooksVars['EMAIL'] = $user->email;
            $hooksVars['PASSWORD'] = $pass;
            $emailData = ['template'=>'create-account-admin', 'hooksVars'=> $hooksVars];
            \Mail::to($user->email)->send(new \App\Mail\ManuMailer($emailData));






        } catch (\Illuminate\Database\QueryException $e) {
            DB::rollBack();
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.users.index', app('request')->query())->with('success', 'User has been saved Successfully');
    }

    /**
     * Show the specified resource. according to id
     * @parameter id
	 * @return Response
     */
    public function show($id)
    {

        $user = User::find($id);
        return view('Admin.users.show', compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
	 * @parameter: id
     * @return Response
     */
    public function edit($id)
    {
        $user  = User::find($id);
        $roles = Role::where('id', '!=', Config::get('constants.ROLE.ADMIN'))->orderBy('title', 'DESC')->pluck('title', 'id')->toArray();
        return view('Admin.users.createOrUpdate', compact('user', 'roles'));
    }

    /**
     * Update the specified resource in storage(database).
     * @param  Request $request, form modified data
     * @return Response
     */
    public function update(Request $request, $id)
    {

        $validatedData = $request->validate([
            'name'     => 'required|min:2|max:100',
            'email'    => 'required|email|max:100|unique:users,email,' . $request->segment(3),
            'phone'    => 'required|phone',
            'password' => ['nullable', 'string', 'min:8', 'max:100', 'confirmed'],
            'role_id'  => 'required|in:2,3,4,5'
        ]);

        DB::beginTransaction();

        try {
            if ($request['password'] !== null) {
                $request['password'] = Hash::make($request['password']);
                $input               = $request->except(['role']);
            } else {
                $input = $request->except(['password', 'role']);
            }

            $user = User::find($id);

            //Move Banner Image
            if ($user->profile_photo != $request->profile_photo && $request->profile_photo != "") {
                Storage::move('public/temp/' . $request->profile_photo, 'public/profile_photo/' . $request->profile_photo);
                $exists = Storage::disk('public')->exists('profile_photo/' . $user->profile_photo);
                if ($exists) {
                    Storage::disk('public')->delete('profile_photo/' . $user->profile_photo);
                }
            }

            $user->fill($input);

            $user->save();


            DB::commit();



            //Send Email to  user
            $chUser =  $user->getChanges();
            if($user->role_id ==Config::get('constants.ROLE.BUYER') && isset($chUser['nick_name']) && isset($chUser['status']) && $chUser['status'] ==1){
                $hooksVars['NAME'] = ucwords($user->name);
                $hooksVars['EMAIL'] = $user->email;
                $hooksVars['NICK_NAME'] = ucwords($user->nick_name);
                $emailData = ['template'=>'account-activation-alert', 'hooksVars'=> $hooksVars];
                \Mail::to($user->email)->send(new \App\Mail\ManuMailer($emailData));
            }
            //dd($chUser['nick_name']);
        } catch (\Illuminate\Database\QueryException $e) {
            DB::rollBack();
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.users.index', app('request')->query())->with('success', 'User has been updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
	 * @ parameter id
     * @return Response
     */
    public function destroy($id)
    {


        //Workspace::where
         $Workspace = Workspace::where(function ($query) use ($id) {
            $query->where('customer_id', '=', $id)
                  ->orWhere('editor_id', '=', $id);
        })->count();

         //echo $Workspace;exit;
         if($Workspace >0 ){
            $responce = ['status' => false, 'message' => 'You can delete this user! ' . $Workspace . ' workspace on this user.'  ];

         }
         else{



        DB::beginTransaction();
        $user = User::find($id);
        //$user->roles()->detach();
        try {
            $user->delete();
            DB::commit();
            $responce = ['status' => true, 'message' => 'This user has been deleted Successfully!', 'data' => $user];
        } catch (\Exception $e) {
            DB::rollBack();
                $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        }
        return $responce;
    }
	
	/* Upload image on temparory folder 
	* @image
	* @Save image in temporary folder
	*/

    public function storeTempImage(Request $request)
    {

        //$request->validate($request, ['file' => 'image|mimes:jpeg,png,jpg,gif|max:2048']);

        $validatedData = $request->validate([
            'file' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $real_path  = $request->file('file')->store('public/temp');
        $fake_path  = str_replace("public/", "", $real_path);
        $image_path = asset("storage/" . $fake_path);
        $imageArray = explode("/", $fake_path);
        $imageName  = end($imageArray);
        return json_encode(['success' => true, 'image_path' => $image_path, 'fake_path' => $fake_path, 'filename' => $imageName]);
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function changeFlag(Request $request, $id)
    {


                //DB::beginTransaction();
        $user = User::find($id);
        //$user->roles()->detach();
        try {

            if($request->field == "is_verified"){

            if($request->status == 1){
                $email_verified_at = date("Y-m-d H:i:s");
                $msg = 'Email has been verified Successfully!';
            }
            else{
                $email_verified_at = NULL;
                $msg = 'Email has been unverified Successfully!';
            }
            $update = \DB::table('users') ->where('id', $id) ->limit(1) ->update( [ 'email_verified_at' => $email_verified_at] );

            }
            elseif($request->field == "status"){

            if($request->status == 1){
                $msg = 'User has been Active Successfully!';
            }
            else{
                $msg = 'User has been InActive Successfully!';
            }

                $update = \DB::table('users') ->where('id', $id) ->limit(1) ->update( [ 'status' => $request->status] );
            }

            $responce = ['status' => true, 'message' => $msg, 'data' => $user];
        } catch (\Exception $e) {
            //DB::rollBack();
            $responce = ['status' => false, 'message' => $e->getMessage()];
        }
        return $responce;
    }

}
