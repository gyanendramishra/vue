<?php

namespace App\Http\Controllers\Admin;

use Modules\Admin\Http\Requests\EmailTemplateRequest;
use App\EmailTemplate;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Yajra\DataTables\Utilities\Request as DatatableRequest;

class EmailTemplatesController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        if (\Auth::user('admin')->can('listing', \App\EmailTemplate::class)) {
            $title = 'Email Templates Listing';
            return view('Admin.email_templates.index', compact('title'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Feeding list of roles to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {
        $emailtemplates = Emailtemplate::query();
        if ($request->status != '') {
            $emailtemplates = $emailtemplates->where('status', $request->status);
        }
        if ($request->slug != '') {
            $slug = $request->slug;
            $emailtemplates = $emailtemplates->where(function($q) use($slug) {
                $q->where('type', 'LIKE', ucfirst($slug) . '%');
                $q->orWhere('type', 'LIKE', lcfirst($slug) . '%');
                $q->orWhere('type', 'LIKE', $slug . '%');
            });
        }
        $emailtemplates = $emailtemplates->get();


        return datatables()->of($emailtemplates)
                        ->addColumn('action', function ($emailtemplates) {
                            $actions = '';
                            if (\Auth::user('admin')->can('view', \App\EmailTemplate::class)) {
                                $actions .= "<a href=\"" . route('admin.emailtemplates.show', ['id' => $emailtemplates->id]) . "\" class=\"\"><i class=\"rounded outline primary icon user profile link\"></i></a>";
                            }
                            if (\Auth::user('admin')->can('update', \App\EmailTemplate::class)) {
                                $actions .= "&nbsp;<a href=\"" . route('admin.emailtemplates.edit', ['id' => $emailtemplates->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                            }
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        if (\Auth::user('admin')->can('create', \App\EmailTemplate::class)) {
            $title = 'Add New Email Template';
            return view('Admin.email_templates.form', compact('title'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Modules\Admin\Http\Requests\EmailTemplateRequest $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) {


        $locales = config('app.locales');
        $valRule = [
            'type' => 'required|unique:email_templates,type,' . $request->segment(3),
            'status' => 'required'
        ];

        foreach ($locales as $key => $value) {
            $valRule[$key . '_subject'] = 'required|max:255';
            $valRule[$key . '_template'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_subject.required'] = ' The subject field is required in ' . $value . ' language.';
            $valMessage[$key . '_subject.max'] = ' Sorry, you can\'t add the subject more than the 255 characters in ' . $value . ' language.';
            $valMessage[$key . '_template.required'] = ' The Template field is required in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['subject'] = $request->input($key . '_subject');
                $article_data[$key]['template'] = $request->input($key . '_template');
            }
            $article_data['status'] = $request->input('status');
            $article_data['type'] = $request->input('type');

            $EmailTemplate = EmailTemplate::create($article_data);


            if ($EmailTemplate) {
                return redirect()->route('admin.emailtemplates.index')->with('success', 'Email template has been added successfully!');
            } else {
                return redirect()->back();
            }
        } catch (Exception $ex) {
            dd($ex);
            return redirect()->back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \Modules\Admin\Entities\EmailTemplate $emailtemplate
     * @return \Illuminate\Http\Response
     */
    public function show($id) {
        if (\Auth::user('admin')->can('view', \App\EmailTemplate::class)) {
            $emailtemplate = Emailtemplate::find($id);
            $title = 'View Email Template';
            return view('Admin.email_templates.show', compact('title', 'emailtemplate'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \Modules\Admin\Entities\EmailTemplate $emailtemplate
     * @return \Illuminate\Http\Response
     */
    public function edit($id) {
        if (\Auth::user('admin')->can('update', \App\EmailTemplate::class)) {
            $row = EmailTemplate::find($id);
            $title = 'Edit Email Template';
            return view('Admin.email_templates.form', compact('title', 'row'));
        } else {
            return view('Admin.not-authorised');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Modules\Admin\Http\Requests\EmailTemplateRequest $request
     * @param  \Modules\Admin\Entities\EmailTemplate $emailtemplate
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id) {

        $locales = config('app.locales');
        $valRule = [
            'type' => 'required|unique:email_templates,type,' . $request->segment(3),
            'status' => 'required'
        ];

        foreach ($locales as $key => $value) {
            $valRule[$key . '_subject'] = 'required|max:255';
            $valRule[$key . '_template'] = 'required';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_subject.required'] = ' The subject field is required in ' . $value . ' language.';
            $valMessage[$key . '_subject.max'] = ' Sorry, you can\'t add the subject more than the 255 characters in ' . $value . ' language.';
            $valMessage[$key . '_template.required'] = ' The Template field is required in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['subject'] = $request->input($key . '_subject');
                $article_data[$key]['template'] = $request->input($key . '_template');
            }
            $article_data['status'] = $request->input('status');
            $article_data['type'] = $request->input('type');

            $EmailTemplate = EmailTemplate::findOrFail($id);
            if ($EmailTemplate->update($article_data)) {
                return redirect()->route('admin.emailtemplates.index')->with('success', 'Email template has been updated successfully!');
            } else {
                return redirect()->back();
            }
        } catch (Exception $ex) {
            return redirect()->back();
        }
    }

}
