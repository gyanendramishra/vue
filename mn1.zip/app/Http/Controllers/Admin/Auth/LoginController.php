<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use \Illuminate\Http\Request;
use Cookie;
use Socialite;
use App\User;
use Session;

//use Auth;

class LoginController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Login Controller
      |--------------------------------------------------------------------------
      |
      | This controller handles authenticating users for the application and
      | redirecting them to your home screen. The controller uses a trait
      | to conveniently provide its functionality to your applications.
      |
     */

use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/admin/dashboard';
    protected $redirectAfterLogout = '/admin/login';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {

        $this->middleware(function ($request, $next) {
            return $next($request);
        });

        $this->middleware('guest:admin')->except(['logout']);
    }

    /**
     * customize the login form.
     *
     * @return mix
     */
    public function showLoginForm(Request $request) {
        $adminckrem = [];
        if ($request->cookie('adminckrem')) {
            $adminckrem = json_decode($request->cookie('adminckrem'), true);
        }
        $title = 'Login';
        return view('Admin.auth.login', compact('title', 'adminckrem'));
    }

    /**
     * Handle a login request to the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response
     */
    public function login(Request $request) {


        $this->validateLogin($request);
        if ($this->hasTooManyLoginAttempts($request)) {

            $this->fireLockoutEvent($request);
            return $this->sendLockoutResponse($request);
        }

        if ($this->attemptLogin($request)) {

            if ($request->remember) {
                \Cookie::queue('user_login_email', $request->email);
                \Cookie::queue('user_login_password', $request->password);
                \Cookie::queue('user_login_remember', true);
            } else {

                \Cookie::queue(\Cookie::forget('user_login_email'));
                \Cookie::queue(\Cookie::forget('user_login_password'));
                \Cookie::queue('user_login_remember', false);
            }

            return $this->sendLoginResponse($request);
        }

        $this->incrementLoginAttempts($request);
        /* custom cases goes here */

        /* end custom cases */
        return $this->sendFailedLoginResponse($request);
    }

    protected function validateLogin(Request $request) {

        $rules = [
            'email' => 'required|email',
            'password' => 'required',
        ];

        $customMessages = [
             'email.required' => 'The email address  field is required.'
        ];

        $this->validate($request, $rules, $customMessages);
    }

    /**
     * Get the needed authorization credentials from the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected function credentials(Request $request) {

        $credentials = $request->only($this->username(), 'password');
        $credentials['status'] = 1;
        return $credentials;
    }

 

    protected function sendFailedLoginResponse(Request $request) {
        if (!User::where('email', $request->email)->first()) {
            return redirect()->back()
                            ->withInput($request->only($this->username(), 'remember'))
                            ->withErrors([
                                $this->username() => trans('auth.email'),
            ]);
        }

        if (!User::where('email', $request->email)->where('password', bcrypt($request->password))->first()) {
            return redirect()->back()
                            ->withInput($request->only($this->username(), 'remember'))
                            ->withErrors([
                                'password' => trans('auth.password'),
            ]);
        }
    }

    /**
     * customize the guard.
     *
     * @return object
     */
    protected function guard() {
        return Auth::guard('admin');
    }

    /**
     * customize the username.
     *
     * @return string
     */
    public function username() {
        return 'email';
    }

    /**
     * Remove user from session.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function logout(Request $request) {
        $this->guard()->logout($request);
        return redirect()
                        ->route('admin.login')
                        ->with(['alert_type' => 'success', 'alert_message' => __('auth.logged_out')]);
    }

}
