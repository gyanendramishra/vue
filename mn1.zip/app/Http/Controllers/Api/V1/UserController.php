<?php

namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Support\Facades\Auth;
use Validator;
use Aloha\Twilio\Twilio;

class UserController extends Controller {

    public $successStatus = 200;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request) {
        //$authInformation = $request->header();
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
    }

    /**
     * @desc For check cred is email or phone
     * @param Request $request
     * @return type
     */
    protected function credentials(Request $request) {
        if (is_numeric($request->get('email'))) {
            return ['phone' => $request->get('email'), 'password' => $request->get('password')];
        }
        return $request->only('email', 'password');
    }

    /**
     * @desc Create condition for check fields
     * @param Request $request
     * @return type
     */
    protected function chkusername(Request $request) {
        if (is_numeric($request->get('email'))) {
            return $cred = ['phone' => $request->email];
        } else {
            return $cred = ['email' => $request->email];
        }
    }

    /**
     * @desc login api 
     * @param Request $request
     * @return type
     */
    public function login(Request $request) {
        try {
            if (Auth::attempt([
                        (is_numeric($request->get('email'))) ? 'phone' : 'email' => $request->get('email'),
                        'password' => $request->password
                    ])) {
                $user = \Auth::user();
                $error = 0;
                // Check if user is active
                if ($user->is_otp_verified == 0) {
                    $error = 1;
                }
                // Check if user is verified
                if ($user->status == 0) {
                    $error = 2;
                }

                if ($error != 0) {
                    \Auth::logout();
                    if ($error == 1) {
                        $RandomNumber = rand(100000, 999999);
                        $account_id = env('TWILIO_SID');
                        $auth_token = env('TWILIO_TOKEN');
                        $from_phone_number = env('TWILIO_FROM');
                        $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                        \App\UserVerification::where('user_id', $user->id)->where('otp_type', 1)->delete();
                        \App\UserVerification::create([
                            'user_id' => $user->id,
                            'otp' => '123456',
                            'otp_type' => 1,
                        ]);
                        $str = '123456' . ' is your one time password (otp) for car market mobile verification';

                        $phoneNo = $user->country_code . $user->phone;

                        $twilio->message($phoneNo, $str);

                        $data['data'] = $user;
                        $data['status'] = true;
                        $data['message'] = 'Your account not verified yet.';
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                    if ($error == 2) {

                        $data['data'] = (object) [];
                        $data['status'] = FALSE;
                        $data['message'] = __('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_ACTIVATION');
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                }
                $tokenResult = $user->createToken('Personal Access Token');
                $user->api_token = $tokenResult->accessToken;
                $user->last_seen_at = date('Y-m-d H:i:s');
                $user->save();
                $user->profile_image = url('storage/'.$user->profile_image);
                $user->phone = (string) $user->phone;
                $datas = $user;
                $datas['access_token'] = $tokenResult->accessToken;
                $datas['role_id'] = $user->roles()->first()->id;
                $datas['token_type'] = 'Bearer';
                $data['data'] = $datas;
                $data['status'] = TRUE;
                $data['message'] = 'You have successfully logged in.';
                $data['code'] = 200;
                return response()->json($data);
            } else {
                // Failed login
                $data['data'] = (object) [];
                $data['status'] = FALSE;
                $data['message'] = 'Your credintial not mached.';
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {
            return response()->json([
                        'status' => FALSE,
                        'message' => $ex->getMessage(),
                        'data' => (object) [],
                            ], 401);
        }
    }

    /**
     * Register api 
     * 
     * @return \Illuminate\Http\Response 
     */
    public function register(Request $request) {

        $validator = Validator::make($request->all(), [
                    'name' => 'required',
                    'email' => 'nullable|email|max:50|unique:users,email',
                    'password' => 'required',
                    'phone' => 'required|unique:users',
                    'company_name' => 'nullable|required_if:role_id,3',
                    'address' => 'nullable|required_if:role_id,3',
        ]);
        if ($validator->fails()) {


            $data['status'] = false;
            $data['message'] = implode(' ', $validator->errors()->all());
            $data['code'] = 200;
            return response()->json($data);
        }
        try {
            $RandomNumber = rand(100000, 999999);
            $account_id = env('TWILIO_SID');
            $auth_token = env('TWILIO_TOKEN');
            $from_phone_number = env('TWILIO_FROM');
            $twilio = new Twilio($account_id, $auth_token, $from_phone_number);

            $input = $request->all();

            $input['password'] = bcrypt($input['password']);
            $input['otp'] = '123456';
            if ($request->role_id == 3) {
                $input['company_name'] = $request->company_name;
                $input['address'] = $request->address;
                $input['latitude'] = $request->latitude;
                $input['longitude'] = $request->longitude;
            }
            $user = User::create($input);

            $data1['token'] = $user->createToken('MyApp')->accessToken;
            $data1 = $user;

            if ($user) {
                $user->roles()->sync($input['role_id']);

                $conversations = \Modules\VehicleEnquiresManager\Entities\Conversation::whereHas('participants', function($q) use($user) {
                            $q->where('conversation_participants.phone', $user->phone);
                            $q->orWhere('conversation_participants.email', $user->email);
                        });

                $conversations->each(function($conversation) use($user) {

                    $conversation->participants()->detach(2);

                    $conversation->participants()->attach([
                        $user->id => [
                            'name' => $user->name,
                            'email' => $user->email,
                            'phone' => $user->phone
                        ]
                    ]);
                    $messages = $conversation->messages->where('user_id', '!=', $conversation->vehicle->user->id);

                    $conversation->messages->each(function($message) use($conversation, $user) {
                        if ($message->user_id !== $conversation->vehicle->user->id) {

                            $message->user_id = $user->id;
                            $message->save();
                        }
                    });
                });

                $userVerification = new \App\UserVerification();
                $userVerification->otp = $input['otp'];
                $userVerification->otp_type = 1;
                $user->userVerification()->save($userVerification);
                $str = '123456' . ' is your one time password (otp) for car market mobile verification';
                $phoneNo = $request->country_code . $user->phone;
                $twilio->message($phoneNo, $str);
            }
            $data['status'] = true;
            $data['message'] = 'You have register successfully! please verify your account.';
            $data['code'] = 200;
            $data['data'] = $data1;
            return response()->json($data);
        } catch (Exception $ex) {
            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * @desc For verify otp for mobile verification
     * @param Request $request
     * @return type
     */
    public function verify(Request $request) {
        try {
            if ($request->otp) {
                $userOtp = \App\User::whereHas('userVerification', function($q) use($request) {
                            $q->where('otp', $request->otp)->where('phone', $request->phone)->where('otp_type', $request->otp_type);
                        })->first();

                if ($userOtp) {

                    $to = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $userOtp->userVerification->created_at);
                    $from = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', date('Y-m-d H:i:s'));


                    $diff_in_minutes = $to->diffInMinutes($from);

                    if ($diff_in_minutes > 120) {
                        $data['data'] = (object) [];
                        $data['status'] = true;
                        $data['message'] = 'Your Otp has been expired!Please resend Otp.';
                        $data['code'] = 200;
                        return response()->json($data);
                    }


                    $userOtp->userVerification()->where('otp_type', $request->otp_type)->delete();
                    if ($request->otp_type == 1) {
                        $userOtp->update(['is_otp_verified' => 1]);

                        Auth::login($userOtp);
                        $user = Auth::user();

                        $tokenResult = $user->createToken('Personal Access Token');
                        $user->api_token = $tokenResult->accessToken;
                        $user->save();
                        $user->phone = (string) $user->phone;
                        $datas = $user;
                        $datas['access_token'] = $tokenResult->accessToken;
                        $datas['role_id'] = $user->roles()->first()->id;
                        $datas['token_type'] = 'Bearer';
                        $data['data'] = $datas;
                        $data['status'] = TRUE;
                        $data['message'] = 'You have successfully logged in.';
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                    $userOtp->profile_image = url('storage/'.$userOtp->profile_image);
                    $userOtp->phone = (string) $userOtp->phone;
                    $data['data'] = $userOtp;
                    $data['status'] = true;
                    $data['message'] = 'Your Mobile number is verified successfully.';
                    $data['code'] = 200;
                    return response()->json($data);
                } else {
                    $data['data'] = (object) [];
                    $data['status'] = false;
                    $data['message'] = 'Incorrect Otp';
                    $data['code'] = 200;
                    return response()->json($data);
                }
            } else {
                $data['data'] = (object) [];
                $data['status'] = false;
                $data['message'] = 'Incorrect Otp';
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function resendOtp(Request $request) {
        try {
            if ($request->phone) {
                $user = User::where('phone', $request->phone)->first();
                if ($user) {
                    $RandomNumber = rand(100000, 999999);
                    $account_id = env('TWILIO_SID');
                    $auth_token = env('TWILIO_TOKEN');
                    $from_phone_number = env('TWILIO_FROM');
                    $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                    \App\UserVerification::where('user_id', $user->id)->where('otp_type', $request->otp_type)->delete();

                    \App\UserVerification::updateOrCreate(
                            [
                        'user_id' => $user->id,
                        'otp_type' => $request->otp_type
                            ], [
                        'user_id' => $user->id,
                        'otp' => '123456',
                        'otp_type' => $request->otp_type,
                            ]
                    );

                    $str = '123456' . ' is your one time password (otp) for car market mobile verification';
                    $phoneNo = $user->country_code . $user->phone;
                    $twilio->message($phoneNo, $str);
                    $data['data'] = (object) [];
                    $data['status'] = true;
                    $data['message'] = 'Otp send to your mobile number.';
                    $data['code'] = 200;
                    return response()->json($data);
                } else {
                    $data['data'] = (object) [];
                    $data['status'] = false;
                    $data['message'] = 'Your Phone number is not valid';
                    $data['code'] = 200;
                    return response()->json($data);
                }
            }
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * @desc For forgot password send otp
     * @param Request $request
     */
    public function forgot(Request $request) {
        try {
            if ($request->phone) {
                $user = User::where('phone', $request->phone)->first();
                if ($user) {
                    if ($user->is_otp_verified == 0) {
                        $data['data'] = $user;
                        $data['status'] = TRUE;
                        $data['message'] = 'Your account not verified yet.';
                        $data['code'] = 105;
                        return response()->json($data);
                    }
                    // Check if user is verified
                    if ($user->status == 0) {
                        $data['data'] = (object) [];
                        $data['status'] = FALSE;
                        $data['message'] = __('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_ACTIVATION');
                        $data['code'] = 200;
                        return response()->json($data);
                    }

                    $RandomNumber = rand(100000, 999999);
                    $account_id = env('TWILIO_SID');
                    $auth_token = env('TWILIO_TOKEN');
                    $from_phone_number = env('TWILIO_FROM');
                    $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                    \App\UserVerification::where('user_id', $user->id)->delete();
                    \App\UserVerification::updateOrCreate(
                            [
                        'user_id' => $user->id,
                        'otp_type' => 2
                            ], [
                        'user_id' => $user->id,
                        'otp' => '123456',
                        'otp_type' => 2,
                            ]
                    );

                    $str = '123456' . ' is your one time password (otp) for car market mobile verification';
                    $phoneNo = $user->country_code . $user->phone;
                    $twilio->message($phoneNo, $str);
                    $data['data'] = (object) [];
                    $data['status'] = true;
                    $data['message'] = 'Forgot password otp send to your registerd mobile number.';
                    $data['code'] = 200;
                    return response()->json($data);
                } else {
                    $data['data'] = (object) [];
                    $data['status'] = false;
                    $data['message'] = 'Your Phone number is not valid';
                    $data['code'] = 200;
                    return response()->json($data);
                }
            }
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * @desc for change password
     * @param Request $request
     * @return type
     */
    public function resetPassword(Request $request) {
        try {
            if ($request->id) {
                $user = \App\User::where('id', $request->id)->first();
                if ($user) {
                    $user->update(['password' => bcrypt($request->password)]);
                    $data['data'] = (object) [];
                    $data['status'] = true;
                    $data['message'] = 'Your password chnage successfully.';
                    $data['code'] = 200;
                    return response()->json($data);
                } else {
                    $data['data'] = (object) [];
                    $data['status'] = false;
                    $data['message'] = 'Oops!something went wrong.';
                    $data['code'] = 200;
                    return response()->json($data);
                }
            } else {
                $data['data'] = (object) [];
                $data['status'] = false;
                $data['message'] = 'Oops!something went wrong.';
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {
            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

    /**
     * Social login via app
     * @param Request $request
     * @return type
     */
    public function socialLogin(Request $request) {
        try {

            if (($request->has('token') && !empty($request->token)) && ($request->has('provider') && !empty($request->provider))) {

                if ($request->get('provider') == 'google') {
                    $providerId = 'google_id';
                }
                if ($request->get('provider') == 'facebook') {
                    $providerId = 'facebook_id';
                }
                $user = User::where($providerId, $request->token)->first();

                if (count($user) > 0) {
                    Auth::guard()->login($user);
                    $user = \Auth::user();
                    if ($user->status == 0) {
                        $data['data'] = (object) [];
                        $data['status'] = FALSE;
                        $data['message'] = __('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_ACTIVATION');
                        $data['code'] = 200;
                        return response()->json($data);
                    }
                    $tokenResult = $user->createToken('Personal Access Token');
                    $data = $user;
                    $user->api_token = $tokenResult->accessToken;
                    $user->save();
                    $data['access_token'] = $tokenResult->accessToken;
                    $data['role_id'] = $user->roles()->first()->id;
                    $data['token_type'] = 'Bearer';
                    $data['message'] = 'You have successfully logged in.';
                    return response()->json([
                                'status' => TRUE,
                                'data' => $data,
                                'code' => 200,
                    ]);
                } else {
                    if ($request->has('phone') && !empty($request->phone)) {
                        $user = User::where('phone', $request->phone)->first();
                        if (count($user) > 0) {
                            Auth::guard()->login($user);
                            $user = \Auth::user();
                            if ($user->status == 0) {
                                $data['data'] = (object) [];
                                $data['status'] = FALSE;
                                $data['message'] = __('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_ACTIVATION');
                                $data['code'] = 200;
                                return response()->json($data);
                            }
                            $tokenResult = $user->createToken('Personal Access Token');
                            $data = $user;
                            $user->api_token = $tokenResult->accessToken;
                            $user->save();
                            $data['access_token'] = $tokenResult->accessToken;
                            $data['role_id'] = $user->roles()->first()->id;
                            $data['token_type'] = 'Bearer';
                            $data['message'] = 'You have successfully logged in.';
                            return response()->json([
                                        'status' => TRUE,
                                        'data' => $data,
                                        'code' => 200,
                            ]);
                        } else {
                            $user = new User();
                            if ($request->provider == 'facebook') {
                                $user->facebook_id = $request->token;
                            }
                            if ($request->provider == 'google') {
                                $user->google_id = $request->token;
                            }
                            $user->name = $request->name ?? '';
                            $user->phone = $request->phone ?? '';
                            $user->email = $request->email ?? '';
                            $user->status = 1;
                            $user->is_otp_verified = 1;
                            $user->save();
                            // attach user role to user
                            $user->roles()->attach(2);
                            // Commit db

                            Auth::guard()->login($user);
                            $user = \Auth::user();
                            $tokenResult = $user->createToken('Personal Access Token');
                            $data = $user;
                            $user->api_token = $tokenResult->accessToken;
                            $user->save();
                            $data['access_token'] = $tokenResult->accessToken;
                            $data['role_id'] = $user->roles()->first()->id;
                            $data['token_type'] = 'Bearer';
                            $data['message'] = 'You have successfully logged in.';
                            return response()->json([
                                        'status' => TRUE,
                                        'data' => $data,
                                        'code' => 200,
                            ]);
                        }
                    } else {
                        $data['data'] = (object) [];
                        $data['status'] = false;
                        $data['message'] = "Phone number not found.";
                        $data['code'] = 106;
                        return response()->json($data);
                    }
                }
            } else {

                $data['data'] = (object) [];
                $data['status'] = false;
                $data['message'] = "Something went wrong.";
                $data['code'] = 200;
                return response()->json($data);
            }
        } catch (Exception $ex) {

            $data['data'] = (object) [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 200;
            return response()->json($data);
        }
    }

}
