<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\UserRepository;

class DashboardController extends Controller {

     /**
     * User repository.
     *
     * @var string
     */
    private $userRepository;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        UserRepository $userRepository
    ){
        $this->userRepository = $userRepository;
    }
    
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request) {
        $listingCount = $this->userRepository->listingCount($request->user('user'));
        $featuredCount = $this->userRepository->featuredCount($request->user('user'));
        $onSaleCount = $this->userRepository->onSaleCount($request->user('user'));
        $untilSoldCount = $this->userRepository->untilSoldCount($request->user('user'));
        $favouriteCount = $this->userRepository->favouriteCount($request->user('user'));
        $vehicleInquiriesCount = $this->userRepository->vehicleInquiriesCount($request->user('user'));

        return view('frontend.user.dashboard', compact(
            'listingCount',
            'featuredCount',
            'onSaleCount',
            'untilSoldCount',
            'favouriteCount',
            'vehicleInquiriesCount'
        ));
    }

}
