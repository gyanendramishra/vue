<?php

namespace App\Http\Controllers\Frontend\Api;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\VehicleRepository;
use Modules\VehicleManager\Entities\Vehicle;
use Laravel\Cashier\Exceptions\IncompletePayment;

class ManageSubscriptionController extends Controller {

    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(VehicleRepository $vehicleRepository) {
        $this->vehicleRepository = $vehicleRepository;
    }

    /**
     * Creates an intent for payment so we can capture the payment
     * method for the user. 
     * 
     * @param Request $request The request data from the user.
     */
    public function getSetupIntent( Request $request ){
        $user = \Auth::guard('user')->user();
        if($user){
            return $user->createSetupIntent();
        }
        return '';
    }

    /**
     * Subscribe user to plan.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function subscribeToPlan(Request $request){
        try {
            $user = $request->user('user');

            $planTitle = $request->subscription_plan_title;
            $planId = $request->subscription_plan_id;
            $paymentMethodId = $request->payment_method_id;
            try {
                if(!$user->subscribed($planTitle) ){
                    $user->newSubscription($planTitle, $planId)
                        ->create($request->payment_method_id);
                }else{
                    $user->subscription($planTitle)->swap($planId);
                }
                return response()->json([
                    "status" => "success",
                    "message" => __('Subscribe to plan.')
                        ], 200);
            } catch (IncompletePayment $exception) {
                return response()->json([
                        "status" => "incomplete",
                        "url" => route('cashier.payment', [$exception->payment->id, 'redirect' => route('frontend.vehicle.thank.you', $request->vehicle_slug)]),
                        "message" => __('Subscribe to plan.')
                    ], 200);
            }     
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Adds a payment method to the current user. 
     * 
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response.
     */
    public function savePaymentMethods(Request $request){
        $user = \Auth::guard('user')->user();
        $paymentMethodID = $request->get('payment_method');

        if( $user->stripe_id == null ){
            $user->createAsStripeCustomer();
        }

        $user->addPaymentMethod( $paymentMethodID );
        $user->updateDefaultPaymentMethod( $paymentMethodID );
        
        return response()->json( null, 204 );        
    }

    /**
     * Returns the payment methods the user has saved
     * 
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getPaymentMethods( Request $request ){
        $user = \Auth::guard('user')->user();
        $methods = array();
        if( $user->hasPaymentMethod() ){
            foreach( $user->paymentMethods() as $method ){
                array_push( $methods, [
                    'id' => $method->id,
                    'brand' => $method->card->brand,
                    'last_four' => $method->card->last4,
                    'exp_month' => $method->card->exp_month,
                    'exp_year' => $method->card->exp_year,
                ] );
            }
        }
        return response()->json( $methods );
    }

    /**
     * Removes a payment method for the current user.
     * 
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function removePaymentMethod( Request $request ){
        $user = \Auth::guard('user')->user();
        $paymentMethodID = $request->get('id');
        $paymentMethods = $user->paymentMethods();
        foreach( $paymentMethods as $method ){
            if( $method->id == $paymentMethodID ){
                $method->delete();
                break;
            }
        }
        return response()->json( null, 204 );
    }

}
