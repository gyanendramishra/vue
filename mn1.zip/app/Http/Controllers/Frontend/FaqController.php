<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Modules\Faq\Entities\Faq;
use Illuminate\Routing\Controller;

class FaqController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $faqs = Faq::select('id')
                    ->with('translations:id,faq_id,question,answer,locale')
                    ->orderBy('id', 'DESC')
                    ->take(20)
                    ->get();
        return view('frontend.faq', compact('faqs'));
    }
}
