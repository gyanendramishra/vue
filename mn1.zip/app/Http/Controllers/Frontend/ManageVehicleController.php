<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\UserRepository;
use App\Repositories\VehicleRepository;
use Modules\VehicleManager\Entities\Vehicle;
use App\Mail\Frontend\VehicleAddedMailToAdmin;
use App\Mail\Frontend\VehicleAddedMailToUser;
use Modules\SubscriptionManager\Entities\SubscriptionPlan;

class ManageVehicleController extends Controller {

    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        VehicleRepository $vehicleRepository,
        UserRepository $userRepository
    ) {
        $this->vehicleRepository = $vehicleRepository;
        $this->userRepository = $userRepository;
    }

    /**
     * Display a listing of the my ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function getMyVehicles(Request $request) {
        if($request->ajax()){
            try {
                $vehicles = $this->userRepository->getMyVehicle();
                return response()->json([
                        "status"=> "success",
                        "data"=> $vehicles
                    ], 200);
            } catch (\Exception $e) {
                return response()->json([
                    "status"=>"error",
                    "message"=>__('frontend.OOPS')
                ], 200);
            }
        }else{
            try {
                $vehicles = $this->userRepository->getMyVehicle();
                return view('frontend.user.manage-ad.ads', compact('vehicles'));
            } catch (\Exception $e) {
                return redirect()
                            ->route('frontend.dashboard');
            }
        }
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function createVehicle(Request $request, $slug = null) {
        $user = $request->user('user');
        $hasActiveSubscription = true;
        if ($user->can('create', Vehicle::class)) {
            $fuelTypes = $this->vehicleRepository->getAllFuelType();
            $transmissions = $this->vehicleRepository->getAllTransmissions();
            $driveTypes = $this->vehicleRepository->getDriveTypes();
            return view('frontend.user.manage-ad.general_info', compact( 
                'fuelTypes', 
                'transmissions', 
                'driveTypes'
            ));
        }else{
            abort(401);
        }
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function saveVehicleGeneral(Request $request, $slug) {
        $user = $request->user('user');
        $vehicle = $this->vehicleRepository->getUserVehicleWithGeneralBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        if ($user->can('update', $vehicle)) {
            $fuelTypes = $this->vehicleRepository->getAllFuelType();
            $transmissions = $this->vehicleRepository->getAllTransmissions();
            $driveTypes = $this->vehicleRepository->getDriveTypes();
            $models = $this->vehicleRepository->getMakeModelById($vehicle->makes_id);
            $badges = $this->vehicleRepository->getModelBadgeById($vehicle->models_id);
            $series = $this->vehicleRepository->getBadgeSeriesById($vehicle->badge_id);
            return view('frontend.user.manage-ad.general_info', compact(
                'fuelTypes', 
                'transmissions', 
                'driveTypes',
                'models',
                'badges',
                'series',
                'vehicle'
            ));
        }else{
            abort(401);
        }
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function saveVehicleFeatures(Request $request, $slug) {
        $user = $request->user('user');
        $vehicle = $this->vehicleRepository->getUserVehicleWithFeaturesBySlug($slug);
        if (!$vehicle) {
            abort(404);
            exit();
        }
        if ($user->can('update', $vehicle)) {
            $features = $this->vehicleRepository->getAllFeatures();
            return view('frontend.user.manage-ad.features', compact('features', 'vehicle'));
        }else{
            abort(401);
            exit();
        }
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function saveVehicleDetails(Request $request, $slug) {
        $user = $request->user('user');
        $vehicle = $this->vehicleRepository->getUserVehicleWithDetailsBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        if ($user->can('update', $vehicle)) {
            $colors = $this->vehicleRepository->getAllColors();
            $lifestyles = $this->vehicleRepository->getAllLifestyles();
            return view('frontend.user.manage-ad.details', compact('vehicle', 'colors', 'lifestyles'));
        }else{
            abort(401);
        }
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function saveVehiclePhotos(Request $request, $slug) {
        $user = $request->user('user');
        $vehicle = $this->vehicleRepository->getUserVehicleWithPhotosBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        if ($user->can('update', $vehicle)) {
            return view('frontend.user.manage-ad.photos', compact('vehicle'));
        }else{
            abort(401);
        }
    }

    /**
     * Show the preview form of ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function vehiclePreview(Request $request, $slug) {
        $user = $request->user('user');
        $vehicle = $this->vehicleRepository->getUserVehicleWithPreviewBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        if ($user->can('update', $vehicle)) {
            return view('frontend.user.manage-ad.preview', compact('vehicle'));
        }else{
            abort(401);
        }
    }

    /**
     * Show the payment form of ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function vehicleComplete(Request $request, $slug) {
        $user = $request->user('user');
        $vehicle = Vehicle::select('id', 'user_id', 'steps', 'slug')
            ->where('user_id', $user->id)
            ->where('slug', $slug)
            ->first();

        if (!$vehicle) {
            abort(404);
        }
        if ($user->can('update', $vehicle)) {
            $userSubscriptions = $user->subscriptions;
            if($userSubscriptions->isNotEmpty()){
                $currentSubscription = $userSubscriptions->last();
                if($user->subscribed($currentSubscription->name)){
                    return redirect()->route('frontend.vehicle.thank.you', $vehicle->slug);
                }
            }
            $planHistories = $user->planHistories;
            if($planHistories->isNotEmpty()){
                $planHistory = $planHistories->last();
                if($planHistory->plan->plan_type === 'Paid'){
                    return redirect()->route('frontend.vehicle.subscribe.n.pay', $vehicle->slug);
                }else{
                    return redirect()->route('frontend.vehicle.thank.you', $vehicle->slug); 
                }
            }
        }else{
            abort(401);
        }
    }
    /**
     * Show the preview form of ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function vehicleThankYou(Request $request, $slug) {
        $user = $request->user('user');
        $vehicle = Vehicle::select('id', 'user_id', 'title', 'steps', 'status', 'slug')
                ->where('user_id', $user->id)
                ->where('slug', $slug)
                ->first();
        if (!$vehicle) {
            abort(404);
        }
        if ($user->can('update', $vehicle)) {
            // save detail
            if($vehicle->steps == 4){
                $vehicle->steps = 5;
                $vehicle->save();

                // Send vehicle added mail to admin
                if (!empty(config('get.ADMIN_EMAIL'))) {
                    //\Mail::to(config('get.ADMIN_EMAIL'))->send(new VehicleAddedMailToAdmin($vehicle));
                }
                // Send vehicle added mail to user
                if ($vehicle->user->email) {
                    //\Mail::to($vehicle->user->email)->send(new VehicleAddedMailToUser($vehicle));
                }
            }
            return view('frontend.user.manage-ad.thank_you', compact('vehicle'));
        }else{
            abort(401);
        }
    }

}
