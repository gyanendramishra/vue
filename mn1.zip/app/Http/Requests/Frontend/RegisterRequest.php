<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class RegisterRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'name' => 'bail|required|max:50',
            'phone' => 'bail|required|digits_between:4,16|unique:users,phone',
            'email' => 'nullable|email|max:50|unique:users,email',
            'password' => 'bail|required|confirmed|min:8|max:12',
            'company_name' => 'nullable|required_if:role_id,3',
            'address' => 'nullable|required_if:role_id,3',
        ];
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages() {
        return [
            'phone.unique' => 'The phone has already been taken, Please login.',
            'email.unique' => 'The email has already been taken, Please login.',
            'company_name.required_if' => 'The company name field is required.',
        ];
    }

}
