<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPlanHistory extends Model {

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['user_id', 'subscription_plan_id'];

    /**
     * Get the user that owns the plan history.
     */
    public function user()
    {
        return $this->belongsTo(\App\User::class, 'user_id');
    }

    /**
     * Get the subscription plan that owns the plan history.
     */
    public function plan()
    {
        return $this->belongsTo(\Modules\SubscriptionManager\Entities\SubscriptionPlan::class, 'subscription_plan_id');
    }

}
