<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Modules\User\Entities\Role;
use App\Notifications\ResetPasswordNotification;
use App\Notifications\FrontResetPasswordNotification;
use Laravel\Passport\HasApiTokens;
use Laravel\Cashier\Billable;

class User extends Authenticatable {

    use HasApiTokens,
        Notifiable,
        Billable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'email_verified_at', 'api_token', 'is_otp_verified', 'country_code', 'facebook_id', 'remember_token', 'is_email_verified', 'google_id', 'phone', 'address', 'photo', 'status', 'verify_email_token', 'city', 'latitude', 'longitude', 'state', 'postcode', 'profile_image', 'dealer_license', 'abn', 'acn', 'website_url', 'google_frame'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * The attributes that should have default values.
     *
     * @var array
     */
    protected $attributes = [
        'status' => 1,
    ];

    /**
     * Defining date fields.
     *
     * @var array
     */
    protected $dates = [
        'trial_ends_at'
    ];

    /**
     * Get the roles that associated with the user.
     */
    public function roles() {
        return $this->belongsToMany('Modules\User\Entities\Role');
    }

    /**
     * Set the reset password notification for user.
     */
    public function sendPasswordResetNotification($token) {
        $this->notify(new ResetPasswordNotification($token));
    }

    /**
     * CHECK IF USER HAS GIVEN ROLE.
     */
    public function hasRole($role) {

        return $this->roles()->where('name', $role)->exists();
    }

    /**
     * Set the reset password notification for user.
     */
    /* public function sendPasswordResetNotification($token) {

      $this->notify(new FrontResetPasswordNotification($token));
      } */

    public function isRole($roleName) {
        foreach ($this->roles()->get() as $role) {
            if ($role->slug == $roleName) {
                return true;
            }
        }

        return false;
    }

    public function role() {
        if (isset($this->roles->first()->slug)) {
            return $this->roles->first()->slug;
        } else {
            return '';
        }
    }

    public function userVerification() {
        return $this->hasOne('\App\UserVerification');
    }

    public function favouriteVehicles() {
        return $this->belongsToMany('Modules\VehicleManager\Entities\Vehicle', 'user_vehicle', 'user_id', 'vehicle_id')->withPivot('is_favourite');
    }

    public function vehicles() {
        return $this->hasMany('Modules\VehicleManager\Entities\Vehicle');
    }

    public function getJWTIdentifier() {
        return $this->getKey();
    }

    public function getJWTCustomClaims() {
        return [];
    }

    public function vehicleEnquiries() {
        return $this->hasManyThrough(
                        '\Modules\VehicleEnquiresManager\Entities\VehicleEnquiry', '\Modules\VehicleManager\Entities\Vehicle', 'user_id', // Foreign key on users table...
                        'vehicle_id', // Foreign key on posts table...
                        'id', // Local key on countries table...
                        'id' // Local key on users table...
        );
    }

    /**
     * Get the participants that belongs to conversation.
     */
    public function conversations() {
        return $this->belongsToMany(\Modules\VehicleEnquiresManager\Entities\Conversation::class, 'conversation_participants', 'user_id', 'conversation_id')
                        ->withPivot('name', 'email', 'phone');
    }

    /**
     * Get the user plan history.
     */
    public function planHistories() {
        return $this->hasMany(\App\UserPlanHistory::class, 'user_id');
    }


    public function userFeaturedVehicles() {
        return $this->hasMany(\Modules\VehicleManager\Entities\UserFeaturedVehicle::class);
    }

    public function userOnsaleVehicles() {
        return $this->hasMany(\Modules\VehicleManager\Entities\UserOnsaleVehicle::class);
    }

    public function userUntilsoldVehicles() {
        return $this->hasMany(\Modules\VehicleManager\Entities\UserUntilsoldVehicle::class);
    }

}
