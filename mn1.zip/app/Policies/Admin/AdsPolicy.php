<?php

namespace App\Policies\Admin;

use Modules\StaffManager\Entities\AdminUser;
use Illuminate\Auth\Access\HandlesAuthorization;

class AdsPolicy
{
    use HandlesAuthorization;

    public function before($user, $ability) {
        if (\Auth::user('admin')->adminRoleUsers()->first()->slug == 'admin') {
            return true;
        }
    }

    /**
     * Determine whether the user can view any categories.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function viewAny(User $user) {
        //
    }

    public function listing(AdminUser $adminUser) {
        $hasPermission = $adminUser->whereHas('adminRoleUsers', function($q) {
                    $q->whereHas('adminRolePermissions', function($q) {
                        $q->where('module', 'Ads');
                        $q->where('name', 'Listing');
                    });
                })->exists();
        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can view the category.
     *
     * @param  \App\User  $user
     * @param  \App\Category  $category
     * @return mixed
     */
    public function view(AdminUser $adminUser) {
        $hasPermission = $adminUser->whereHas('adminRoleUsers', function($q) {
                    $q->whereHas('adminRolePermissions', function($q) {
                        $q->where('module', 'Ads');
                        $q->where('name', 'View');
                    });
                })->exists();
        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can create categories.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function create(AdminUser $adminUser) {
        $hasPermission = $adminUser->whereHas('adminRoleUsers', function($q) {
                    $q->whereHas('adminRolePermissions', function($q) {
                        $q->where('module', 'Ads');
                        $q->where('name', 'Add');
                    });
                })->exists();
        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can update the category.
     *
     * @param  \App\User  $user
     * @param  \App\Category  $category
     * @return mixed
     */
    public function update(AdminUser $adminUser) {
        $hasPermission = $adminUser->whereHas('adminRoleUsers', function($q) {
                    $q->whereHas('adminRolePermissions', function($q) {
                        $q->where('module', 'Ads');
                        $q->where('name', 'Edit');
                    });
                })->exists();
        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can delete the category.
     *
     * @param  \App\User  $user
     * @param  \App\Category  $category
     * @return mixed
     */
    public function delete(AdminUser $adminUser) {
        $hasPermission = $adminUser->whereHas('adminRoleUsers', function($q) {
                    $q->whereHas('adminRolePermissions', function($q) {
                        $q->where('module', 'Ads');
                        $q->where('name', 'Delete');
                    });
                })->exists();
        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can restore the category.
     *
     * @param  \App\User  $user
     * @param  \App\Category  $category
     * @return mixed
     */
    public function restore(AdminUser $adminUser) {
        //
    }

    /**
     * Determine whether the user can permanently delete the category.
     *
     * @param  \App\User  $user
     * @param  \App\Category  $category
     * @return mixed
     */
    public function forceDelete(AdminUser $adminUser) {
        //
    }
}
