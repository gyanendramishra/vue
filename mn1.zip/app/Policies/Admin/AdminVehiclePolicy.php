<?php

namespace App\Policies\Admin;

use Modules\StaffManager\Entities\AdminUser;
use Illuminate\Auth\Access\HandlesAuthorization;

class AdminVehiclePolicy {

    use HandlesAuthorization;

    public function before($user, $ability) {
        if (\Auth::user('admin')->adminRoleUsers()->first()->slug == 'admin') {
            return true;
        }
    }

   

    public function listing(AdminUser $adminUser) {
        $hasPermission = $adminUser->whereHas('adminRoleUsers', function($q) {
                    $q->whereHas('adminRolePermissions', function($q) {
                        $q->where('module', 'Vehicle');
                        $q->where('name', 'Listing');
                    });
                })->exists();
        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can view the vehicle.
     *
     * @param  \App\User  $user
     * @param  \App\vehicle  $vehicle
     * @return mixed
     */
    public function viewVehicle(AdminUser $adminUser) {
        $hasPermission = $adminUser->whereHas('adminRoleUsers', function($q) {
                    $q->whereHas('adminRolePermissions', function($q) {
                        $q->where('module', 'Vehicle');
                        $q->where('name', 'View');
                    });
                })->exists();
        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can create vehicles.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function createVehicle(AdminUser $adminUser) {
        $hasPermission = $adminUser->whereHas('adminRoleUsers', function($q) {
                    $q->whereHas('adminRolePermissions', function($q) {
                        $q->where('module', 'Vehicle');
                        $q->where('name', 'Add');
                    });
                })->exists();
        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can update the vehicle.
     *
     * @param  \App\User  $user
     * @param  \App\vehicle  $vehicle
     * @return mixed
     */
    public function updateVehicle(AdminUser $adminUser) {
        $hasPermission = $adminUser->whereHas('adminRoleUsers', function($q) {
                    $q->whereHas('adminRolePermissions', function($q) {
                        $q->where('module', 'Vehicle');
                        $q->where('name', 'Edit');
                    });
                })->exists();
        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can delete the vehicle.
     *
     * @param  \App\User  $user
     * @param  \App\vehicle  $vehicle
     * @return mixed
     */
    public function deleteVehicle(AdminUser $adminUser) {
        $hasPermission = $adminUser->whereHas('adminRoleUsers', function($q) {
                    $q->whereHas('adminRolePermissions', function($q) {
                        $q->where('module', 'Vehicle');
                        $q->where('name', 'Delete');
                    });
                })->exists();
        if ($hasPermission) {
            return true;
        }
    }

    /**
     * Determine whether the user can restore the vehicle.
     *
     * @param  \App\User  $user
     * @param  \App\vehicle  $vehicle
     * @return mixed
     */
    public function restore(User $user, vehicle $vehicle) {
        //
    }

    /**
     * Determine whether the user can permanently delete the vehicle.
     *
     * @param  \App\User  $user
     * @param  \App\vehicle  $vehicle
     * @return mixed
     */
    public function forceDelete(User $user, vehicle $vehicle) {
        //
    }

}
