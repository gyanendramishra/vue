<?php
namespace App\Repositories;

use Illuminate\Http\Request;
use Modules\VehicleManager\Entities\Vehicle;
use App\Repositories\Interfaces\ConversationInterface;
use Modules\VehicleEnquiresManager\Entities\Conversation;
use Modules\VehicleEnquiresManager\Entities\ConversationMessage;

class ConversationRepository implements ConversationInterface {
    
    /* Get all conversations */
    public function getAllConversations(){
        return Conversation::first();
    }

    /* Get user all conversations */
    public function getUserAllConversations($userId, $page = 1){
        $limit = 20;
        $offset = ($page - 1) * $limit;
        return  Conversation::select('id', 'vehicle_id', 'title')
                    ->whereHas('participants', function($q) use($userId){
                        $q->where('user_id', $userId);
                    })
                    ->with([
                        'vehicle:id,title,price,slug',
                        'participants'=> function($q) use($userId){
                            $q->select('users.id', 'users.name', 'users.email', 'users.phone', 'users.profile_image')
                                ->where('user_id', '!=', $userId);
                        }
                    ]) 
                    ->selectRaw("conversations.*, (SELECT MAX(created_at) from conversation_messages WHERE conversation_messages.conversation_id=conversations.id) as latest_message_on")
                    ->orderBy("latest_message_on", "DESC")
                    ->skip($offset)
                    ->take($limit)
                    ->get();
    }

    /* Get conversation messages */
    public function getConversationMessages($conversationId, $page = 1){
        $limit = 20;
        $offset = ($page - 1) * $limit;
        return ConversationMessage::select('id', 'conversation_id', 'user_id', 'content', 'created_at')
                    ->where('conversation_id', $conversationId)
                    ->with('user:id,name,profile_image')
                    ->orderBy('id', 'DESC')
                    ->skip($offset)
                    ->take($limit)
                    ->get();
    }

    /* Get message by message id */
    public function getMessageById($messageId){
        return ConversationMessage::select('id', 'user_id', 'content', 'created_at')
                    ->where('id', $messageId)
                    ->with('user:id,name,profile_image')
                    ->first();
    }

    /* Get vehicle all conversations */
    public function getVehicleConversations($vehicleId, $userId, $page = 1){
        $limit = 20;
        $offset = ($page - 1) * $limit;
        return Conversation::select('id', 'vehicle_id', 'title')
                    ->where('vehicle_id', $vehicleId)
                    ->with([
                        'vehicle:id,title,price,slug',
                        'participants'=> function($q) use($userId){
                            $q->select('users.id', 'users.name', 'users.email', 'users.phone', 'users.profile_image')
                                ->where('user_id', '!=', $userId);
                        }
                    ])
                    ->selectRaw("conversations.*, (SELECT MAX(created_at) from conversation_messages WHERE conversation_messages.conversation_id=conversations.id) as latest_message_on")
                    ->orderBy("latest_message_on", "DESC")
                    ->skip($offset)
                    ->take($limit)
                    ->get();
    }

    /* Get the vehicles where user is participant */
    public function getConversationParticipantionVehicles($user){
        return Vehicle::select('id', 'title', 'slug')
            ->withCount('conversations')
            ->whereHas('conversations', function($q) use($user){
                $q->whereHas('participants', function($q) use($user){
                    $q->where('user_id', $user->id);
                });
            })
            ->get();
    }

    /* conversation for user or guest user */
    public function conversationForVehicleAndUser($vehicleId, $userId, $options){
        $user = \App\User::find($userId);
        if($user->hasRole('Guest')){
            return Conversation::where('vehicle_id', $vehicleId)
                        ->whereHas('participants', function($q) use($userId, $options){
                            $q->where('user_id', $userId);
                            $q->where('conversation_participants.phone', $options['phone']);
                            $q->orWhere('conversation_participants.email', $options['email']);
                        })->first();
        }else{
            return Conversation::where('vehicle_id', $vehicleId)
                    ->whereHas('participants', function($q) use($userId){
                        $q->where('user_id', $userId);
                    })->first();
        }
    }

}
