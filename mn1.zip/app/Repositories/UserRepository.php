<?php

namespace App\Repositories;

use Illuminate\Http\Request;
use App\Repositories\SubscriptionRepository;
use App\Repositories\Interfaces\UserInterface;
use Modules\VehicleManager\Entities\Vehicle;

class UserRepository implements UserInterface {
    
    /* Get user saved vehicles */
    public function savedVehicle($user) {
        return  $user->favouriteVehicles()
                    ->where('is_favourite', 1)
                    ->select(
                        'id', 
                        'category_id', 
                        'makes_id', 
                        'models_id', 
                        'badge_id', 
                        'body_styles_id',
                        'fuel_types_id',
                        'series_id',
                        'transmissions_id',
                        'title',
                        'role',
                        'odometer',
                        'price',
                        'discount_price',
                        'address',
                        'is_featured',
                        'is_inspected',
                        'is_masked_price',
                        'initial_masking_digits',
                        'slug'
                    )
                    ->with([
                        'main_image:id,vehicle_id,image,caption',
                        'transmissions:id',
                        'transmissions.translations:id,vehicle_transmissions_id,name,locale',
                        'bodystyle:id',
                        'bodystyle.translations:id,vehicle_body_style_id,locale,name',
                        'fuel_type:id',
                        'fuel_type.translations:id,vehicle_fuel_types_id,locale,name',
                    ])
                    ->approved()
                    ->orderBy('id', 'DESC')
                    ->paginate(10);
    }

    /* Get user vehicles */
    public function vehicles($user) {
        return  $user->vehicles()
                    ->select(
                        'id', 
                        'category_id', 
                        'makes_id', 
                        'models_id', 
                        'badge_id', 
                        'body_styles_id',
                        'fuel_types_id',
                        'series_id',
                        'transmissions_id',
                        'title',
                        'role',
                        'odometer',
                        'price',
                        'discount_price',
                        'address',
                        'is_approved',
                        'is_featured',
                        'is_on_sale',
                        'is_until_sold',
                        'is_sold',
                        'is_inspected',
                        'is_masked_price',
                        'initial_masking_digits',
                        'slug'
                    )
                    ->with([
                        'main_image:id,vehicle_id,image,caption',
                        'favouriteUsers:is_favourite',
                        'category:id',
                        'category.translations:id,category_id,name,locale',
                        'make:id',
                        'make.translations:id,vehicle_make_id,name,locale',
                        'model:id,makes_id',
                        'model.translations:id,vehicle_model_id,name,locale',
                        'badge:id,models_id',
                        'badge.translations:id,vehicle_badge_id,name,locale',
                        'series:id,badges_id',
                        'series.translations:id,vehicle_series_id,name,locale',
                        'transmissions:id',
                        'transmissions.translations:id,vehicle_transmissions_id,name,locale',
                        'bodystyle:id',
                        'bodystyle.translations:id,vehicle_body_style_id,locale,name',
                        'fuel_type:id',
                        'fuel_type.translations:id,vehicle_fuel_types_id,locale,name'
                        
                    ])
                    ->orderBy('id', 'DESC')
                    ->paginate(10);
    }

    /**
     * Get user vehicles listing count
     */
    public function listingCount($user){
        return $user->vehicles->count();
    }

    
    /**
     * Get user featured vehicles listing count
     */
    public function featuredCount($user){
        return $user->vehicles->where('is_featured', 1)->count();
    }

    /**
     * Get user on sale vehicles count
     */
    public function onSaleCount($user){
        return $user->vehicles->where('is_on_sale', 1)->count();
    }

    /**
     * Get user until sold vehicles count
     */
    public function untilSoldCount($user){
        return $user->vehicles->where('is_until_sold', 1)->count();
    }
    
    /**
     * Get user sold vehicles count
     */
    public function soldCount($user){
        return $user->vehicles->where('is_sold', 1)->count();
    }

    /**
     * Get user favourite vehicles count
     */
    public function favouriteCount($user) {
        return $user->favouriteVehicles()->approved()->count();
    }

    /**
     * Get user vehicles inquiries count
     */
    public function vehicleInquiriesCount($user) {
        return $user->conversations()->count();
    }

}
