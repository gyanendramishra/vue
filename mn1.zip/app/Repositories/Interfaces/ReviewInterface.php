<?php
namespace App\Repositories\Interfaces;

interface ReviewInterface {
    
    public function getAllVehicles();

    public function getHomeReviews();

    public function getVehicleReviews($vehicleId);

}
