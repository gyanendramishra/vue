<?php
namespace App\Repositories\Interfaces\Admin;

interface StripeInterface {
    
    public function createPlan($subscription);
   

}
