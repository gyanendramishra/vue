<?php

namespace App\Repositories\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use App\Repositories\Interfaces\Admin\StripeInterface;

class StripeRepository implements StripeInterface {

    public function createPlan($subscription) {
        dd($subscription);
    }

}
