<?php
namespace App\Repositories;

use Illuminate\Http\Request;
use Modules\NewsManager\Entities\News;
use App\Repositories\Interfaces\NewsInterface;

class NewsRepository implements NewsInterface {
    

    /* Get news */
    public function getAllNews(){
        return News::select('id', 'news_type', 'image', 'video', 'start_date', 'end_date', 'slug')
                    ->with('translations:id,news_id,locale,title,excerpt')
                    ->whereDate('start_date', '<=', \Carbon\Carbon::now())
                    ->whereDate('end_date', '>=', \Carbon\Carbon::now())
                    ->active()
                    ->orderBy('id', 'DESC')
                    ->paginate(15);
    }

    /* Get home news */
    public function getHomeNews(){
        return News::select('id', 'news_type', 'image', 'video', 'start_date', 'end_date', 'slug')
                    ->with('translations:id,news_id,locale,title,excerpt')
                    ->whereDate('start_date', '<=', \Carbon\Carbon::now())
                    ->whereDate('end_date', '>=', \Carbon\Carbon::now())
                    ->active()
                    ->take(20)
                    ->inRandomOrder()
                    ->get();
    }

    /* Get news by slug */
    public function getNewsBySlug($slug){
        return News::select('id', 'news_type', 'image', 'video', 'start_date', 'end_date')
                    ->with('translations:id,news_id,locale,title,description')
                    ->whereDate('start_date', '<=', \Carbon\Carbon::now())
                    ->whereDate('end_date', '>=', \Carbon\Carbon::now())
                    ->whereSlug($slug)
                    ->active()
                    ->first();
    }

}
