<?php
namespace App\Repositories;

use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Modules\VehicleManager\Entities\Vehicle;
use App\Repositories\Interfaces\ReviewInterface;
use Modules\VehicleReviewsManager\Entities\VehicleReview;

class ReviewRepository implements ReviewInterface {
    

    /* Get home ad's */
    public function getAllVehicles(){
        return Vehicle::select(
                        'id',
                        'title',
                        'slug'
                    )
                    ->approved()
                    // ->withCount(['vehicleReviews as avg_reviews'=> function($q){
                    //     $q->select(\DB::raw('avg(rating)'));
                    // }])
                    //->orderBy('avg_reviews', 'DESC')
                    ->has('vehicleReviews')
                    ->with('main_image:id,vehicle_id,image,caption')
                    ->withCount(['vehicleReviews'=> function($q){
                        $q->active()->with('user:id,name');
                    }])
                    ->orderBy('vehicle_reviews_count', 'DESC')
                    ->paginate(15);
    }

    /* Get home reviews */
    public function getHomeReviews(){
        return Vehicle::select(
                    'id',
                    'title',
                    'slug'
                )
                ->approved()
                ->has('vehicleReviews')
                ->with('main_image:id,vehicle_id,image,caption')
                ->withCount(['vehicleReviews'=> function($q){
                    $q->active()->with('user:id,name');
                }])
                ->take(20)
                ->inRandomOrder()
                ->get();
    }

    /* Get vehicle reviews */
    public function getVehicleReviews($vehicleId){
        return VehicleReview::select(
                'id',
                'user_id',
                'vehicle_id',
                'title',
                'rating',
                'review',
                'created_at'
            )
            ->active()
            ->where('vehicle_id', $vehicleId)
            ->with('user:id,name')
            ->orderBy('id', 'desc')
            ->paginate(10);
    }

}
