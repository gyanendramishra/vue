<?php

namespace App\Repositories;

use Illuminate\Http\Request;
use \Illuminate\Database\Eloquent\Collection;
use App\Repositories\Interfaces\SubscriptionInterface;
use Modules\SubscriptionManager\Entities\SubscriptionPlan;

class SubscriptionRepository implements SubscriptionInterface {
    /* Get subscription plans for user */
    public function getSubscriptionPlansAsPerUserRoles($roles) {
        $userRoles = [];
        if($roles->isNotEmpty()){
            foreach($roles as $role){
                $userRoles[] = $role;
            }
            return SubscriptionPlan::select(
                'id', 
                'duration', 
                'duration_type', 
                'price',
                'total_on_sale_count',
                'total_featured_count',
                'total_listing_count',
                'count_of_until_sold',
                'slug'
            )
            ->whereIn('user_type', $userRoles)
            ->active()
            ->with([
                'translations:id,subscription_plan_id,locale,title,description',
            ])
            ->get();
        }
        return Collection::make(new SubscriptionPlan);
    }
    
    /* Get subscription plan detail by subscription plan id */
    public static function getSubscriptionPlanDetailPlanById($subscriptionPlanId){
        return SubscriptionPlan::select(
            'id',
            'stripe_id',
            'plan_title',
            'plan_type',
            'price',
            'duration',
            'duration_type',
            'total_on_sale_count',
            'total_featured_count',
            'total_listing_count',
            'count_of_until_sold'
        )
        ->where('stripe_id', $subscriptionPlanId)
        ->active()
        ->with([
            'translations:id,subscription_plan_id,locale,title,description',
        ])
        ->first();
    }

}
