<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RegisterRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'=>'bail|required|max:255',
            'email'=>'bail|required|regex:/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/|max:255',
            'password'=> 'bail|required|min:6|max:12',
            'confirm_password'=> 'same:password',
            'mobile'=>'bail|required|numeric|regex:/^([0-9\s\-\+\(\)]*)$/|digits_between:4,16',
            'profile_photo_file'=> 'bail|required|image|mimes:jpg,png,jpeg',
            'accept'=>'bail|required'
        ];
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'accept.required' => 'Please check terms and condition box.',
            'profile_photo_file.required' => 'The profile photo field is required.',
            'profile_photo_file.image' => 'The profile photo must be an image. ',
            'profile_photo_file.mimes' => 'The profile photo must be jpg,png,jpeg.',
        ];
    }
}
