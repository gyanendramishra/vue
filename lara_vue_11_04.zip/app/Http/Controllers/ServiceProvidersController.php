<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\CategoryService;
use App\Services\BookingService;
use App\Services\MyServiceService;

class ServiceProvidersController extends Controller
{
    /**
     * Show the service providers.
     *
     * @param Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request, $slug = null){
        $filters = $request->all();
        $filters = [
            "page" => 1,
            "keyword" => $request->keyword,
            "min_price" => $request->min_price,
            "max_price" => $request->max_price,
            "availability" => $request->availability,
            "rating" => $request->rating,
            "limit" => 12
        ];
        if($request->method() == "POST"){
            $filters["category_id"] = ($request->has('category_id'))?$request->category_id:[];
        }else{
            $slug_array = explode('-', $slug);
            $categoryId = last($slug_array);
            $filters["category_id"] = [$categoryId];
        }

        return view('service_provider.index', compact('filters'));
    }

    /**
     * Filter the service provider.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\CategoryService $service
     * @return \Illuminate\Http\Response
     */
    public function filterServiceProviders(Request $request, CategoryService $service){
        try{
            $response = $service->getServiceProvidersService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Get the service detail .
     *
     * @param Illuminate\Http\Request $request
     * @param string $slug
     * @return \Illuminate\Http\Response
     */
    public function getServiceDetail(Request $request, $slug){
        $slug_array = explode('-', $slug);
        $serviceId = last($slug_array);
        $isLoggedIn = 'false';
        if($request->session()->has('auth_user')){
            $isLoggedIn = 'true';
        }
        return view('service_provider.service_detail', compact('serviceId', 'isLoggedIn'));
    }

    /**
     * Get the service detail data .
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\BookingService $service
     * @return \Illuminate\Http\Response
     */
    public function getServiceDetailData(Request $request, MyServiceService $service){
        try{
            $response = $service->getServiceDetail($request->only('id'));
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Get the categories provider.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\CategoryService $service
     * @return \Illuminate\Http\Response
     */
    public function getCategories(Request $request, CategoryService $service){
        try{
            $response = $service->getFilterCategoriesService();
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

}
