<template>
    <div>
        <loader-component :loading="loading"></loader-component>
        <div class="formBox editProfileForm">
            <div class="formBoxInner">
                <div class="dashbord-sec">
                    <div class="uploaded-img-banner" v-if="service.full_image_path">
                        <img :src="service.full_image_path" alt="">
                    </div>
                    <form @submit.prevent="addService">
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Job Title 
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Job Title" name="title" v-model="service.title" v-validate="'required|max:255'" data-vv-as="title">
                                <div v-if="errors.has('title')" class="text-danger">
                                    {{ errors.first('title') }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Select Service 
                                    <span class="red-color">*</span>
                                </label>
                                <select name="parent_service_id" v-model="service.parent_id" v-on:change="getSubCategories()" v-validate="'required'" data-vv-as="service">
                                    <option disabled value="">Select Service</option>
                                    <option v-for="parentCategory in parentCategories" :value="parentCategory.id">{{ parentCategory.title }}</option>
                                </select>
                                <div v-if="errors.has('parent_service_id')" class="text-danger">
                                    {{ errors.first('parent_service_id') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Select Service Category 
                                    <span class="red-color">*</span>
                                </label>
                                <select name="category_id" v-model="service.category_id" v-validate="'required'" data-vv-as="service category">
                                    <option disabled value="">Select Service Category</option>
                                    <option v-for="subCategory in SubCategories" :value="subCategory.id">{{ subCategory.title }}</option>
                                </select>
                                <div v-if="errors.has('category_id')" class="text-danger">
                                    {{ errors.first('category_id') }}
                                </div>
                            </div>
                            <div class="form-group last-input">
                                <label>
                                    Address 
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Address" name="address" ref="address" @click="populateModal" v-model="service.address" v-validate="'required'" data-vv-as="address">
                                <input type="hidden" placeholder="Address" name="latitude" v-model="service.latitude">
                                <input type="hidden" placeholder="Address" name="longitude"  v-model="service.longitude" lazy>
                                <div v-if="errors.has('address')" class="text-danger">
                                    {{ errors.first('address') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Min Amount ($)
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" name="price" placeholder="" v-model="service.price" v-validate="'required|numeric|max:8'" data-vv-as="min amount">
                                <div v-if="errors.has('price')" class="text-danger">
                                    {{ errors.first('price') }}
                                </div>
                            </div>
                            <div class="form-group" v-if="service.full_image_path">
                                <label>Choose Banner image </label>
                                <input type="file" placeholder="" ref="image_file" v-validate="'image|ext:jpeg,jpg,png'" data-vv-name="image_file" data-vv-as="banner image" v-on:change="handleFileUpload()" key="image_file">
                                <div v-if="errors.has('image_file')" class="text-danger">
                                    {{ errors.first('image_file') }}
                                </div>
                            </div>
                            <div class="form-group" v-else>
                                <label>Choose Banner image <span class="red-color">*</span></label>
                                <input type="file" placeholder="" ref="image_file" v-validate="'required|image|ext:jpeg,jpg,png'" data-vv-name="image_file" data-vv-as="banner image" v-on:change="handleFileUpload()" key="image_file">
                                <div v-if="errors.has('image_file')" class="text-danger">
                                    {{ errors.first('image_file') }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row full-input-box">
                            <div class="form-group">
                                <label>
                                    Description 
                                    <span class="red-color">*</span>
                                </label>
                                <textarea name="description" v-model="service.description" v-validate="'required'" data-vv-as="description"></textarea>
                                <div v-if="errors.has('description')" class="text-danger">
                                    {{ errors.first('description') }}
                                </div>
                            </div>
                        </div>
                        <div class="full-btn-col">
                            <input type="submit" value="Submit" :disabled="errors.any()">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal my-popup address-field-map-model" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Select your address</h4>
                    </div>
                    <div class="modal-body" ref="address_field_google_map"></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Use this location</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import GoogleMapsLoader from 'google-maps'
    import VeeValidate from 'vee-validate';
    import mixin from '../../mixin/mixin.js';
    import LoaderComponent from "../LoaderComponent.vue";
    GoogleMapsLoader.KEY = 'AIzaSyDViIP3wUAOLAGs1fWCak4PnQuGw4YnSZQ';
    Vue.use(VeeValidate);
    export default {
        name: "my-service-component",
        mixins: [mixin],
        components:{
            LoaderComponent
        },
        props:['isAccountVerified'],
        data: function () {
            return {
                service:{},
                loading: false,
                parentCategories: {},
                SubCategories: {}
            }
        },
        methods: {
            addService() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        let formData = new FormData();
                        if(this.service.id){
                            formData.append('id', this.service.id);
                        }
                        formData.append('title', this.service.title);
                        formData.append('parent_service_id', this.service.parent_id);
                        formData.append('category_id', this.service.category_id);
                        formData.append('address', this.service.address);
                        formData.append('latitude', this.service.latitude);
                        formData.append('longitude', this.service.longitude);
                        formData.append('price', this.service.price);
                        formData.append('description', this.service.description);
                        if(this.service.image_file){
                            formData.append('image_file', this.service.image_file);
                        }

                        axios.post('/my-service/add-update', formData, {
                            headers:{
                                'Content-Type': 'multipart/form-data'
                            }
                        }).then(response => {
                            if(response.data.status === true){
                                flash(response.data.message, 'success');
                                if(this.isAccountVerified === true){
                                    window.location = '/payment';
                                }else{
                                    window.location = '/my-service';
                                }
                            }else{
                                this.authorize(response);
                            }
                            this.loading = false;
                        }).catch(error => {
                            this.loading = false;
                            console.log(error);
                        });
                    }else{
                        this.loading = false;
                    }
                });
            },
            getMyService() {
                this.loading = true;
                axios.get('/my-service/get').then(response => {
                    if(response.data.status === true){
                        let data = response.data.data;
                        if(data.title){
                            this.service = data;
                        }
                        this.parentCategories = data.main_category;
                        this.SubCategories = data.sub_category;
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },

            getSubCategories() {
                this.loading = true;
                axios.post('/listing/get-sub-categories', {parent_id: this.service.parent_id}).then(response => {
                    if(response.data.status === true){
                        this.SubCategories = response.data.data.categories;
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },

            /*
                Handles a change on the file upload
            */
            handleFileUpload(){
                this.service.image_file = this.$refs.image_file.files[0];
            },

            populateModal() {
                $('.modal').modal('show');
            }

        },
        beforeMount () {
            this.service = {
                title: "",
                parent_id: "",
                category_id: "",
                address: "",
                latitude: "",
                longitude: "",
                price: "",
                image_file: "",
                description: "",
            };
        },
        mounted: function () {
            alert(this.isAccountVerified);
            this.getMyService();
            var vm = this;
            GoogleMapsLoader.load(function(google) {
                let geocoder = new google.maps.Geocoder();
                let infowindow = new google.maps.InfoWindow();
                let myLatlng = new google.maps.LatLng(26.9124,75.7873);
                let map = new google.maps.Map(vm.$refs.address_field_google_map, {
                    zoom: 15,
                    center: myLatlng,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                });

                var marker = new google.maps.Marker(
                    {
                        position: myLatlng,
                        map: map,
                        draggable:true
                    }
                );
                
                if(vm.service.id === ""){
                    geocoder.geocode({'latLng': myLatlng }, function(results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[0]) {
                                vm.service.latitude = marker.position.lat().toFixed(6);
                                vm.service.longitude = marker.position.lng().toFixed(6);
                                vm.service.address = results[0].formatted_address;
                                vm.$refs.address.value = results[0].formatted_address;

                                infowindow.setContent(results[0].formatted_address);
                                infowindow.open(map, marker);
                            }
                        }       
                    });
                }
            
                google.maps.event.addListener(
                    marker,
                    'dragend',
                    function() {
                        geocoder.geocode({'latLng': marker.getPosition()}, function(results, status) {
                            if (status == google.maps.GeocoderStatus.OK) {
                                if (results[0]) {
                                    vm.service.latitude = marker.position.lat().toFixed(6);
                                    vm.service.longitude = marker.position.lng().toFixed(6);
                                    vm.service.address = results[0].formatted_address;
                                    vm.$refs.address.value = results[0].formatted_address;
                                    infowindow.setContent(results[0].formatted_address);
                                    infowindow.open(map, marker);
                                }
                            }
                        });
                });  
            });
        }
        
    }
</script>
<style scoped>
    .address-field-map-model .modal-body {
        width: 100%;
        height: 400px;
    }
</style>

