<template>
  <div class="how-it-works-sec">
    <div class="container">
        <div class="titleSec">
            <h2>How it works</h2>
        </div>
        <div class="flip-content-sec">
            <div class="container">
                <div class="row">
                    <div class="col-md-7">
                        <div class="flip-content-img-col">
                            <img src="/images/how_it_works_img01.jpg" alt="" />
                            <div class="works-icon-col">
                                <img src="/images/how_it_works_icon01.png" alt="" />
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="flip-content-col padd-left-30">
                            <div class="works-no-col">
                                <h2>01</h2>
                            </div>
                            <p>
                                Sign up and tell us all the services you can provide virtually
                                or in person on demand.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row how-it-works-2">
                    <div class="col-md-7 order-md-2">
                        <div class="flip-content-img-col">
                            <img src="/images/how_it_works_img02.jpg" alt="" />
                            <div class="works-icon-col">
                                <img src="/images/how_it_works_icon02.png" alt="" />
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5 order-1">
                        <div class="flip-content-col padd-right-30">
                            <div class="works-no-col">
                                <h2>02</h2>
                            </div>
                            <p>
                                Receive an alert and tell the client when you can do the job
                                and how much it will cost.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-7">
                        <div class="flip-content-img-col">
                            <img src="/images/how_it_works_img03.jpg" alt="" />
                            <div class="works-icon-col">
                                <img src="/images/how_it_works_icon03.png" alt="" />
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="flip-content-col padd-left-30">
                            <div class="works-no-col">
                                <h2>03</h2>
                            </div>
                            <p>
                                Complete the job and instantly get paid through our automated
                                payment system.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
<script>
export default {
  name: "how-it-works"
};
</script>
