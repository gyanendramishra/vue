<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">     
                <div class="review-page">
                    <div class="inner-page-sec-title">
                        <h3>Customer Reviews</h3>
                    </div>
                    <div v-if="results.reviews.length > 0">
                        <div class="review-col" v-for="review in results.reviews">
                            <div class="review-icon-col">
                                <img :src="review.full_image_path" alt="">
                            </div>
                            <div class="review-text-col">
                                <h4>{{ review.title }}</h4>
                                <div class="rating-icon-col">
                                    <i class="fa fa-star"></i> {{ review.rate | formatNumber }}
                                </div>
                                <p>{{ review.comment }}</p>
                                <div class="review-post-by">
                                    By <span>{{ review.name }}</span>
                                </div>
                                <div class="review-date">
                                    Posted on {{ review.dateTime | formatDate }}
                                </div>
                            </div>
                        </div>
                        <div class="pro-pagination">
                            <div class="pager-result"> {{ results.total_count }} Items found</div>
                            <div class="pager" v-if="results.last_page > 1">
                                <ul>
                                    <li class="pager-arrow" :disabled="filters.page === 1">
                                        <a href="javascript:;" v-on:click="paginate((filters.page - 1))">
                                            <i class="fa fa-angle-left"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:;" v-on:click="paginate(1)">
                                            1
                                        </a>
                                    </li>
                                    <li v-if="results.last_page >= 2">
                                        <a href="javascript:;" v-on:click="paginate(2)">
                                            2
                                        </a>
                                    </li>
                                    <li v-if="results.last_page >= 3">
                                        <a href="javascript:;" v-on:click="paginate(3)">
                                            3
                                        </a>
                                    </li>
                                    <li v-if="results.last_page >= 4">
                                        <a href="javascript:;" v-on:click="paginate(4)">
                                            4
                                        </a>
                                    </li>
                                    <li class="pager-arrow" :disabled="filters.page === results.last_page">
                                        <a href="javascript:;" v-on:click="paginate((filters.page + 1))">
                                            <i class="fa fa-angle-right"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div v-else>
                        <div class="booking-row">
                            <div class="booking-row-inner">
                                <p>Sorry we have not found any reviews of you.</p>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import moment from "moment";
    import VeeValidate from 'vee-validate';
    import mixin from '../../mixin/mixin.js';
    import LoaderComponent from "../LoaderComponent.vue";
    Vue.use(VeeValidate);
    export default {
        name: "my-review-component",
        mixins: [mixin],
        components:{
            LoaderComponent
        },
        data: function () {
            return {
                loading: false,
                results:{
                    reviews:{}
                },
                filters: {
                    page: 1,
                    account_type_id : 1,
                    limit: 10
                }
            }
        },
        filters: {
            formatDate : function(date){
                return moment(date, 'YYYY-MM-DD H:i:s').format('DD MMM YYYY h:mm a');
            },
            formatNumber(value) {
                return (value/1).toFixed(2);
            },
        },
        created: function(){
            this.getReviews();
        },
        methods: {
            getReviews() {
                this.loading = true;
                axios.post('/my-reviews/get', this.filters).then(response => {
                    if(response.data.status === true){
                        this.results = response.data.data;
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            paginate(page) {
                if((page <= this.results.last_page) && (page >= 1)){
                    this.filters.page = page;
                    this.getReviews();
                }
            }
        }
    }
</script>

