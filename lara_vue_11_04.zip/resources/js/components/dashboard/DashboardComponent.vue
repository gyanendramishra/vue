<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div class="row">
                    <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter">
                        <div class="infoItem">
                            <span class="number-label">{{ dashboard.booking_count }}</span>
                            <i class="infoIcon">
                                <img src="/images/booking_dashboard_icon.png">
                            </i>
                            <h3>Booking</h3>
                            <a class="btn btn-sm btn-white" href="/booking">
                                View More
                            </a> 
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter" v-show="account_type_id === 1">
                        <div class="infoItem">
                            <span class="number-label">{{ (dashboard.is_complete === true)?'live':'pending' }}</span>
                            <i class="infoIcon">
                                <img src="/images/services_dashboard_icon.png">
                            </i>
                            <h3>Services</h3>
                            <a class="btn btn-sm btn-white" href="/my-service">
                                View More
                            </a> 
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter" v-show="account_type_id === 1">
                        <div class="infoItem">
                            <span class="number-label">${{ dashboard.earning_count }}</span>
                            <i class="infoIcon">
                                <img src="/images/earning_dashboard_icon.png">
                            </i>
                            <h3>Earning</h3>
                            <a class="btn btn-sm btn-white" href="/my-earnings">
                                View More
                            </a> 
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter">
                        <div class="infoItem"> 
                            <i class="infoIcon">
                                <img src="/images/profile_dashboard_icon.png">
                            </i>
                            <h3>Profile</h3>
                            <a class="btn btn-sm btn-white" href="/my-profile">
                                View More
                            </a> 
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter" v-show="account_type_id === 1">
                        <div class="infoItem"> 
                            <span class="number-label" v-if="dashboard.account_status === 'verified'">
                                verified
                            </span> 
                            <i class="infoIcon">
                                <img src="/images/payment_dashboard_icon.png">
                            </i>
                            <h3>Payment</h3>
                            <a class="btn btn-sm btn-white" href="/payment">
                                View More
                            </a> 
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-4 dashInfoOuter" v-show="account_type_id === 1">
                        <div class="infoItem">
                            <span class="number-label">{{ dashboard.review_count }}</span> 
                            <i class="infoIcon">
                                <img src="/images/reviews_dashboard_icon.png">
                            </i>
                            <h3>Reviews</h3>
                            <a class="btn btn-sm btn-white" href="/my-reviews">
                                View More
                            </a> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import mixin from '../../mixin/mixin.js';
    import LoaderComponent from "../LoaderComponent.vue";
    export default {
        name: "dashboard-component",
        components:{
            LoaderComponent
        },
        mixins: [mixin],
        props: ["isServiceProvider"],
        data: function () {
            return {
                dashboard:{},
                loading: false,
                account_type_id : 1
            }
        },
        created: function(){
            this.loading = true;
            if(this.isServiceProvider === true){
                this.account_type_id = 1;
            }else{
                this.account_type_id = 2;
            }
            this.getDashboard();
        },
        methods: {
            getDashboard() {
                this.loading = true;
                axios.post('/dashboard/get', {
                    account_type_id:this.account_type_id
                }).then(response => {
                    if(response.data.status === true){
                        this.dashboard = response.data.data;
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            }
        }
    }
</script>

