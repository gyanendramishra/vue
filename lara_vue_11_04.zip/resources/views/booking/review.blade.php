@extends('layouts.dashboard')
@section('page_header_title', 'Booking Review')
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
      	<a href="{{ route('user.booking') }}">
	      	Booking
	    </a>
    </li>
    <li>
        Review
    </li>
@endsection

@section('dashboard_content')
  	<booking-review-component :booking-id='{{ $bookingId }}'></booking-review-component>
@endsection

