<?php

return [

    "email_templates"=>[
        "Welcome email to master",
        "Welcome email to user",
    ],

    "model_status"=>[
        "Un-published",
        "Published",
    ],

];
