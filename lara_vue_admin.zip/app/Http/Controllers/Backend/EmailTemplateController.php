<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Models\EmailTemplate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Backend\EmailTemplateRequest;

class EmailTemplateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $filters = $request->all();
        $query = EmailTemplate::query();

        $query->when($request->query('name'), function ($q) use($filters) {
            $q->where("name", $filters['name']);
        });

        $query->when($request->query('keyword'), function ($q) use($filters) {
            $q->where("subject", 'like', "%{$filters['keyword']}%");
        });

        $query->when(($request->query('sort_by') && $request->query('sort_as')), function ($q) use($filters) {
            $q->orderBy($filters['sort_by'], $filters['sort_as']);
        });

        $emailTemplates = $query->paginate(EmailTemplate::PER_PAGE);

        $emailTemplates->appends($filters)->render();

        $title = "email templates:: list";

        return view('backend.email-templates.index', compact('title', 'emailTemplates', 'filters'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = "email templates::create";
        return view('backend.email-templates.create', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Backend\EmailTemplateRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(EmailTemplateRequest $request)
    {
        \DB::beginTransaction();
        try {
            $emailTemplate = new EmailTemplate($request->all());
            if($emailTemplate->save()){
                \DB::commit();
                return redirect()
                        ->route('admin.email-templates.index')
                        ->withFlashSuccess(__('admin.RECORD CREATED', ['module'=>'Email template']));
            }else{
                return redirect()
                        ->route('admin.email-templates.index')
                        ->withFlashError(__('admin.RECORD NOT CREATED', ['module'=>'Email template']));
            }
        } catch (\Exception $e) {
            \DB::rollBack();
            return redirect()
                    ->route('admin.email-templates.index')
                    ->withFlashError(__('admin.OOPS'));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  EmailTemplate $emailTemplate
     * @return \Illuminate\Http\Response
     */
    public function show(EmailTemplate $emailTemplate)
    {
        $title = "users::preview";
        return view('backend.email-templates.preview', compact('title', 'emailTemplate'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  EmailTemplate $emailTemplate
     * @return \Illuminate\Http\Response
     */
    public function edit(EmailTemplate $emailTemplate)
    {
        $title = "email templates::edit";
        return view('backend.email-templates.edit', compact('title', 'emailTemplate'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Backend\EmailTemplateRequest  $request
     * @param  EmailTemplate $emailTemplate
     * @return \Illuminate\Http\Response
     */
    public function update(EmailTemplateRequest $request, EmailTemplate $emailTemplate)
    {
        \DB::beginTransaction();
        try {
            if($emailTemplate->update($request->all())){
                \DB::commit();
                return redirect()
                        ->route('admin.email-templates.index')
                        ->withFlashSuccess(__('admin.RECORD UPDATED', ['module'=>'Email template']));
            }else{
                return redirect()
                        ->route('admin.email-templates.index')
                        ->withFlashError(__('admin.RECORD NOT UPDATED', ['module'=>'Email template']));
            }
        } catch (\Exception $e) {
            \DB::rollBack();
            return redirect()
                    ->route('admin.email-templates.index')
                    ->withFlashError(__('admin.OOPS'));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  EmailTemplate $emailTemplate
     * @return \Illuminate\Http\Response
     */
    public function destroy(EmailTemplate $emailTemplate)
    {
        try {
            if($emailTemplate->delete()){
                return redirect()
                        ->route('admin.email-templates.index')
                        ->withFlashSuccess(__('admin.RECORD DELETED', ['module'=>'Email template']));
            }else{
                return redirect()
                        ->route('admin.email-templates.index')
                        ->withFlashError(__('admin.RECORD NOT DELETED', ['module'=>'Email template']));
            }  
        } catch (\Exception $e) {
            return redirect()
                    ->route('admin.email-templates.index')
                    ->withFlashError(__('admin.OOPS'));
        }
    }
}
