<?php

namespace App\Http\Controllers\Backend;

use App\Models\User;
use Illuminate\Http\Request;
use App\Mail\ResetUserPasswordMail;
use App\Http\Controllers\Controller;
use App\Http\Requests\Backend\UserRequest;
use Symfony\Component\HttpFoundation\ParameterBag;

class UserController extends Controller
{
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $filters = $request->all();
        $query = User::whereHas('roles', function($query){
            $query->where('name', "!=", "Administrator");
        });

        if($request->query('role')){
            $role = $request->query('role');
            $query = User::whereHas('roles', function($query) use($role){
                $query->where('name', $role);
                $query->where('name', "!=", "Administrator");
            });      
        }

        if($request->query('keyword')){
            $keyword = $request->query('keyword');
            $query = User::where(function ($query) use ($keyword) {
                $query->where("first_name", 'like', "%{$keyword}%");
                $query->orWhere("last_name", 'like', "%{$keyword}%");
            });
        }
        if($request->query('status')){
            $status = $request->query('status');
            $query = $query->ofStatus($status);
        }

        if($request->query('sort_by') && $request->query('sort_as')){
            $column = $request->query('sort_by');
            $order = $request->query('sort_as');

            $query = $query->orderBy($column, $order);
        }
        $users = $query->paginate(USER::PER_PAGE);

        $users->appends($filters)->render();

        $title = "users:: list";
        return view('backend.users.index', compact('title', 'users', 'filters'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = "users::form";
        return view('backend.users.create', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UserRequest $request)
    {
        \DB::beginTransaction();
        try {
            $request->request->add(['ip_address'=> $request->ip()]);
            $user = new User($request->all());
            if($user->save()){
                \DB::commit();
                $token = app('auth.password.broker')->createToken($user);
                try{
                    \Mail::to($user->email)->send(new ResetUserPasswordMail($user, $token));

                }catch(\Exception $e){
                    return redirect()
                            ->route('admin.users.index')
                            ->withFlashWarning(__('admin.CREATED SMTP ERROR', ['module'=>'User']));
                }
                return redirect()
                        ->route('admin.users.index')
                        ->withFlashSuccess(__('admin.RECORD CREATED', ['module'=>'User']));
            }else{
                return redirect()
                        ->route('admin.users.index')
                        ->withFlashError(__('admin.RECORD NOT CREATED', ['module'=>'User']));
            }
        } catch (\Exception $e) {
            \DB::rollBack();
            return redirect()
                    ->route('admin.users.index')
                    ->withFlashError(__('admin.OOPS'));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        $title = "users::form";
        return view('backend.users.edit', compact('title', 'user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UserRequest $request, User $user)
    {
        \DB::beginTransaction();
        try {
            if($user->update($request->all())){
                \DB::commit();
                return redirect()
                        ->route('admin.users.index')
                        ->withFlashSuccess(__('admin.RECORD UPDATED', ['module'=>'User']));
            }else{
                return redirect()
                        ->route('admin.users.index')
                        ->withFlashError(__('admin.RECORD NOT UPDATED', ['module'=>'User']));
            }
        } catch (\Exception $e) {
            \DB::rollBack();
            return redirect()
                    ->route('admin.users.index')
                    ->withFlashError(__('admin.OOPS'));
        }
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        try {
            if($user->delete()){
                return redirect()
                        ->route('admin.users.index')
                        ->withFlashSuccess(__('admin.RECORD DELETED', ['module'=>'User']));
            }else{
                return redirect()
                        ->route('admin.users.index')
                        ->withFlashError(__('admin.RECORD NOT DELETED', ['module'=>'User']));
            }  
        } catch (\Exception $e) {
            return redirect()
                    ->route('admin.users.index')
                    ->withFlashError(__('admin.OOPS'));
        }
    }
}
