<?php

namespace App\Http\Controllers\Backend;

use App\Models\Page;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Backend\PageRequest;

class PageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $filters = $request->all();
        $query = Page::query();

        $query->when($request->query('keyword'), function ($q) use($filters) {
            $q->where("title", 'like', "%{$filters['keyword']}%");
            $q->orWhere("slug", 'like', "%{$filters['keyword']}%");
        });

        $query->when($request->query('status'), function ($q) use($filters) {
            $q->where("is_published", $filters['status']);
        });

        $query->when(($request->query('sort_by') && $request->query('sort_as')), function ($q) use($filters) {
            $q->orderBy($filters['sort_by'], $filters['sort_as']);
        });

        $pages = $query->paginate(Page::PER_PAGE);

        $pages->appends($filters)->render();

        $title = "cms pages:: list";

        return view('backend.pages.index', compact('title', 'pages', 'filters'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = "cms pages::create";
        return view('backend.pages.create', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Backend\PageRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PageRequest $request)
    {
        \DB::beginTransaction();
        try {
            $request->request->add(['slug'=> str_slug($request->title)]);
            $page = new Page($request->all());
            if($page->save()){
                \DB::commit();
                return redirect()
                        ->route('admin.pages.index')
                        ->withFlashSuccess(__('admin.RECORD CREATED', ['module'=>'Cms page']));
            }else{
                return redirect()
                        ->route('admin.pages.index')
                        ->withFlashError(__('admin.RECORD NOT CREATED', ['module'=>'Cms page']));
            }
        } catch (\Exception $e) {
            \DB::rollBack();
            dd($e);
            return redirect()
                    ->route('admin.pages.index')
                    ->withFlashError(__('admin.OOPS'));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  Page $page
     * @return \Illuminate\Http\Response
     */
    public function show(Page $page)
    {
        $title = "cms page::preview";
        return view('backend.pages.preview', compact('title', 'page'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  Page $page
     * @return \Illuminate\Http\Response
     */
    public function edit(Page $page)
    {
        $title = "cms page::edit";
        return view('backend.pages.edit', compact('title', 'page'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Backend\PageRequest  $request
     * @param  Page $page
     * @return \Illuminate\Http\Response
     */
    public function update(PageRequest $request, Page $page)
    {
        \DB::beginTransaction();
        try {
            if($page->update($request->all())){
                \DB::commit();
                if($page->wasChanged('title')){
                    $page->slug = str_slug($page->title);
                    $page->save();
                }
                return redirect()
                        ->route('admin.pages.index')
                        ->withFlashSuccess(__('admin.RECORD UPDATED', ['module'=>'Cms page']));
            }else{
                return redirect()
                        ->route('admin.pages.index')
                        ->withFlashError(__('admin.RECORD NOT UPDATED', ['module'=>'Cms page']));
            }
        } catch (\Exception $e) {
            \DB::rollBack();
            return redirect()
                    ->route('admin.pages.index')
                    ->withFlashError(__('admin.OOPS'));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Page $page
     * @return \Illuminate\Http\Response
     */
    public function destroy(Page $page)
    {
        try {
            if($page->delete()){
                return redirect()
                        ->route('admin.pages.index')
                        ->withFlashSuccess(__('admin.RECORD DELETED', ['module'=>'Cms page']));
            }else{
                return redirect()
                        ->route('admin.pages.index')
                        ->withFlashError(__('admin.RECORD NOT DELETED', ['module'=>'Cms page']));
            }  
        } catch (\Exception $e) {
            return redirect()
                    ->route('admin.pages.index')
                    ->withFlashError(__('admin.OOPS'));
        }
    }
}
