<?php

namespace App\Http\Views\Composers;

use Illuminate\View\View;
use Illuminate\Support\Facades\Auth;

class AdminUserComposer
{

    /**
     * The user.
     *
     * @var User
     */
    protected $user;

    /**
     * Create a new user composer.
     *
     * @return void
     */
    public function __construct()
    {
        $this->user = Auth::guard('admin')->user();
    }
    /**
     * Bind data to the view.
     *
     * @param  View  $view
     * @return void
     */
    public function compose(View $view)
    {
        $view->with('loggedinUser', $this->user);
    }
}