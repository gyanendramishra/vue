<?php

namespace App\Http\Requests\Backend;

use App\Models\EmailTemplate;
use Illuminate\Foundation\Http\FormRequest;

class EmailTemplateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('admin')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $emailTemplate = $this->email_template;
        switch ($this->method()) {
            case 'GET':{
                return [];
            }
            case 'DELETE': {
                    return [];
                }
            case 'POST': {
                    return [
                        'name' =>'bail|required|string|max:150|unique:email_templates,name',
                        'subject' =>'bail|required|string|max:150',
                        'body' =>'bail|required|string'
                    ];
                }
            case 'PUT':
            case 'PATCH': {
                    return [
                        'subject' =>'bail|required|string|max:150|unique:email_templates,name,'.$emailTemplate->id.',id',
                        'body' =>'bail|required|string'
                    ];
                }
            default:break;
        }
    }
}
