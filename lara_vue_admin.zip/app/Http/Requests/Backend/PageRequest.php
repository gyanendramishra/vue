<?php

namespace App\Http\Requests\Backend;

use App\Models\Page;
use Illuminate\Foundation\Http\FormRequest;

class PageRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('admin')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $page = $this->page;
        switch ($this->method()) {
            case 'GET':{
                return [];
            }
            case 'DELETE': {
                    return [];
                }
            case 'POST': {
                    return [
                        'title' =>'bail|required|string|max:150|unique:pages,title',
                        'sub_title' =>'bail|nullable|string|max:150',
                        'excerpt' =>'bail|required|string|max:150',
                        'description' =>'bail|required',
                        'meta_title' =>'bail|nullable|string|max:150',
                        'meta_keyword' =>'bail|nullable|string|max:150',
                        'meta_description' =>'bail|nullable|string'
                    ];
                }
            case 'PUT':
            case 'PATCH': {
                    return [
                        'title' =>'bail|required|string|max:150|unique:pages,title,'.$page->id.',id',
                        'sub_title' =>'bail|nullable|string|max:150',
                        'excerpt' =>'bail|required|string|max:150',
                        'description' =>'bail|required',
                        'meta_title' =>'bail|nullable|string|max:150',
                        'meta_keyword' =>'bail|nullable|string|max:150',
                        'meta_description' =>'bail|nullable|string'
                    ];
                }
            default:break;
        }
    }
}
