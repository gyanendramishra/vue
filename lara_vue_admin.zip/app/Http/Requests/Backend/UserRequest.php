<?php

namespace App\Http\Requests\Backend;

use App\Models\User;
use Illuminate\Foundation\Http\FormRequest;

class UserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('admin')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $user = $this->user;
        switch ($this->method()) {
            case 'GET':{
                return [];
            }
            case 'DELETE': {
                    return [];
                }
            case 'POST': {
                    return [
                        'first_name' =>'bail|required|max:150',
                        'last_name' =>'bail|required|max:150',
                        'email' =>'bail|required|max:150|unique:users,email',
                    ];
                }
            case 'PUT':
            case 'PATCH': {
                    return [
                        'first_name' =>'bail|required|max:150',
                        'last_name' =>'bail|required|max:150',
                        'email' =>'bail|required|max:150|unique:users,email,'.$user->id.',id',
                    ];
                }
            default:break;
        }
    }
}
