<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

/* Backend routes */
Route::group(['namespace'=>'Backend', 'prefix'=>'admin', 'as'=>'admin.'],function () {

	Route::get('/', function(){
		return redirect()->route('admin.login');
	});
	
	Auth::routes(['register'=> false]);

	/* Auth route group */
	Route::group(['middleware'=> 'auth:admin'], function(){

		/* Dashboard */
		Route::get('/dashboard', 'DashboardController')->name('dashboard');

		/* Profile */
		Route::match(['GET', 'POST'], 'profile', 'ProfileController')->name('profile');

		## Users manager route
		Route::resources([
		    'users' => 'UserController'
		]);

		## Email templates manager route
		Route::resources([
		    'email-templates' => 'EmailTemplateController'
		]);

		## Cms pages manager route
		Route::resources([
		    'pages' => 'PageController'
		]);

	});
});
