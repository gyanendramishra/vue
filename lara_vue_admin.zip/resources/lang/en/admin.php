<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Admin Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'OOPS'=> 'Somthing went wrong. Please try again later.',
    'RECORD CREATED'=> ':module record has been saved.',
    'RECORD UPDATED'=> ':module record has been updated.',
    'RECORD DELETED'=> ':module record has been deleted.',
    'RECORD NOT CREATED'=> ':module record hasn\'t been saved.',
    'RECORD NOT UPDATED'=> ':module record hasn\'t been updated.',
    'RECORD NOT DELETED'=> ':module record hasn\'t been deleted.',

    'CREATED SMTP ERROR'=> ':module record has been saved. Problem in SMTP configration.'

];
