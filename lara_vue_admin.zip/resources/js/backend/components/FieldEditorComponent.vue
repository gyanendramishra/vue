<template>
    <div>
        <ckeditor :editor="editor" tag-name="textarea" :value="editorData" :name="fieldName" :placeholder="fieldPlaceholder"></ckeditor>
    </div>
</template>
<script>
    import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
    import CKEditor from '@ckeditor/ckeditor5-vue';
    Vue.use( CKEditor );

    export default {
        name:"field-editor-component",
        props:["fieldName", "fieldData", "fieldPlaceholder"],
        data() {
            return {
                editor: ClassicEditor,
                editorData: '',
                editorConfig: {
                    toolbar: {
                        items: [
                            'bold',
                            'italic',
                            'link',
                            'undo',
                            'redo'
                        ]
                    }
                }
            };
        },
        mounted(){
            if(this.fieldData){
                this.editorData = this.fieldData;
            }
        },
        methods: {
        }
    }
</script>
