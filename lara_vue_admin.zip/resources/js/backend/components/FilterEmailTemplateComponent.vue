<template>
    <form method="GET" :action="action" @submit.prevent="filterData()" ref="filter_user_form">    
        <div v-if="filters">
            <input type="hidden" v-for="(filter, key) in filters" :value="filter" :name="key">
        </div>
        <div class="box box-info">
            <div class="box-body table-responsive">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Name</label>
                                <select name="name" class="form-control" v-model="formData.name">
                                    <option value="">All</option>
                                    <option v-if="templateName.length > 0" v-for="tn in templateName" :value="tn">{{ tn }}</option>
                                </select>                        
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Keyword</label>
                                <div class="input text">
                                    <input type="text" name="keyword" class="form-control input-small" placeholder="Keyword e.g: name, subject" v-model="formData.keyword">
                                </div>                        
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <button type="submit" class="btn btn-success" title="Filter">
                                    <i class="fa fa-filter"></i> Filter
                                </button> 
                                <a :href="action" class="btn btn-warning" title="Reset">
                                    <i class="fa fa-fw fa-refresh"></i> Reset
                                </a>                        
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</template>
<script>
    export default {
        name:"filter-action-component",
        props:["action", "filters", "templateName"],
        data() {
            return {
                token: window.Laravel.csrfToken,
                formData:{
                    keyword:"",
                    name: ""
                }
            }
        },
        created(){
            if(this.filters.hasOwnProperty('keyword')){
                if(this.filters.keyword !== null){
                    this.formData.keyword = this.filters.keyword;
                }
                delete this.filters.keyword;
            }
            if(this.filters.hasOwnProperty('name')){
                if(this.filters.name !== null){
                    this.formData.name = this.filters.name;
                }
                delete this.filters.name;
            }
        },
        methods: {
            filterData(){
                $(this.$refs.filter_user_form).submit();
            }
        }
    }
</script>
