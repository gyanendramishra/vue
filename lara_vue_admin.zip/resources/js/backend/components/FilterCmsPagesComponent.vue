<template>
    <form method="GET" :action="action" @submit.prevent="filterData()" ref="filter_user_form">    
        <div v-if="filters">
            <input type="hidden" v-for="(filter, key) in filters" :value="filter" :name="key">
        </div>
        <div class="box box-info">
            <div class="box-body table-responsive">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control" v-model="formData.status">
                                    <option value="">All</option>
                                    <option v-if="cmsStatus.length > 0" v-for="(cs, index) in cmsStatus" :value="index">{{ cs }}</option>
                                </select>                        
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Keyword</label>
                                <div class="input text">
                                    <input type="text" name="keyword" class="form-control input-small" placeholder="Keyword e.g: title, slug" v-model="formData.keyword">
                                </div>                        
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <button type="submit" class="btn btn-success" title="Filter">
                                    <i class="fa fa-filter"></i> Filter
                                </button> 
                                <a :href="action" class="btn btn-warning" title="Reset">
                                    <i class="fa fa-fw fa-refresh"></i> Reset
                                </a>                        
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</template>
<script>
    export default {
        name:"filter-action-component",
        props:["action", "filters", "cmsStatus"],
        data() {
            return {
                token: window.Laravel.csrfToken,
                formData:{
                    keyword:"",
                    status: ""
                }
            }
        },
        created(){
            if(this.filters.hasOwnProperty('keyword')){
                if(this.filters.keyword !== null){
                    this.formData.keyword = this.filters.keyword;
                }
                delete this.filters.keyword;
            }
            if(this.filters.hasOwnProperty('status')){
                if(this.filters.status !== null){
                    this.formData.status = this.filters.status;
                }
                delete this.filters.status;
            }
        },
        methods: {
            filterData(){
                $(this.$refs.filter_user_form).submit();
            }
        }
    }
</script>
