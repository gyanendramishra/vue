<template>
    <form method="POST" :action="action" @submit.prevent="deleteData(label)" ref="delete_model_form">
        <input type="hidden" name="_method" value="DELETE">
        <input type="hidden" name="_token" :value="token">
        <button type="submit" class="btn btn-danger btn-xs">
            <i class="fa fa-trash"></i>
        </button>
    </form>
</template>

<script>
    import bootbox from "bootbox";
    export default {
        name:"delete-action-component",
        props:["action", "label"],
        data() {
            return {
                token: window.Laravel.csrfToken
            }
        },
        methods: {
            deleteData(label){
                let vm = this;
                bootbox.confirm("Are you sure you want to delete "+label+" ?", function(result){
                    if(result){
                        $(vm.$refs.delete_model_form).submit();
                    }
                });
            }
        }
    }
</script>
