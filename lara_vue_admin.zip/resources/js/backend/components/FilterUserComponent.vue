<template>
    <form method="GET" :action="action" @submit.prevent="filterData()" ref="filter_user_form">    
        <div v-if="filters">
            <input type="hidden" v-for="(filter, key) in filters" :value="filter" :name="key">
        </div>
        <div class="box box-info">
            <div class="box-body table-responsive">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Role</label>
                                <select name="role" class="form-control" v-model="formData.role">
                                    <option value="">All</option>
                                    <option value="Supervisor">Supervisor</option>
                                    <option value="Job Provider">Job Provider</option>
                                    <option value="Job Seeker">Job Seeker</option>
                                </select>                        
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control" v-model="formData.status">
                                    <option value="">All</option>
                                    <option value="V">Verified</option>
                                    <option value="UV">Un-verified</option>
                                    <option value="B">Blocked</option>
                                </select>                        
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Keyword</label>
                                <div class="input text">
                                    <input type="text" name="keyword" class="form-control input-small" placeholder="Keyword e.g: name, email" v-model="formData.keyword">
                                </div>                        
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <button type="submit" class="btn btn-success" title="Filter">
                                    <i class="fa fa-filter"></i> Filter
                                </button> 
                                <a :href="action" class="btn btn-warning" title="Reset">
                                    <i class="fa fa-fw fa-refresh"></i> Reset
                                </a>                        
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</template>
<script>
    export default {
        name:"filter-action-component",
        props:["action", "filters"],
        data() {
            return {
                token: window.Laravel.csrfToken,
                formData:{
                    keyword:"",
                    status:"",
                    role: ""
                }
            }
        },
        created(){
            if(this.filters.hasOwnProperty('keyword')){
                this.formData.keyword = this.filters.keyword;
                delete this.filters.keyword;
            }
            if(this.filters.hasOwnProperty('status')){
                this.formData.status = this.filters.status;
                delete this.filters.status;
            }
            if(this.filters.hasOwnProperty('role')){
                this.formData.role = this.filters.role;
                delete this.filters.role;
            }
        },
        methods: {
            filterData(){
                $(this.$refs.filter_user_form).submit();
            }
        }
    }
</script>
