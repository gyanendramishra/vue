@extends('backend.layouts.app')
@section('title', $title)
@section('content')
	<section class="content-header">
		<h1>
		    Manage cms pages
		    <small>Here you can manage cms pages.</small>
		</h1>
		<ol class="breadcrumb">
		    <li>
		    	<a href="{{ route('admin.dashboard') }}">
		    		<i class="fa fa-dashboard"></i> Dashboard
		    	</a>
		    </li>
		    <li class="active">Cms pages</li>
		</ol>
	</section>
	<!-- Main content -->
	<section class="content">
		<filter-cms-pages-component 
			action="{{ route('admin.pages.index')  }}" 
			:filters='@json($filters)'
			:cms-status='@json(config("settings.model_status"))'
		></filter-cms-pages-component>
	  	<div class="box">
            <div class="box-header with-border">
              	<h3 class="box-title">
              		<span class="caption-subject font-green bold uppercase">Cms pages</span>
              	</h3>
              	<div class="box-tools">
	                <a href="{{ route('admin.pages.create') }}" class="btn btn-success btn-sm" title="Add new cms page">Add new</a>
	            </div>
            </div>
            <div class="box-body table-responsive">
        		<table class="table table-bordered datatable">
        			@if($pages->count() > 0)
		            	<tr>
			              	<th width="10%">
			              		@php
			              			$sortAs = 'desc';
			              			if((data_get($filters, 'sort_by') == 'id')){
			              				if(data_get($filters, 'sort_as') == 'asc'){
			              					$sortAs = 'desc';
			              				}else{
			              					$sortAs = 'asc';
			              				}
			              			}
			              		@endphp
			              		<a href="{{ route('admin.pages.index', array_unique(array_merge($filters, ['sort_by'=>'id', 'sort_as'=> $sortAs]), SORT_REGULAR)) }}">
					              	#Id <i class="fa fa-sort-numeric-{{ ($sortAs == 'desc')?'asc':'desc' }}" aria-hidden="true"></i>
					            </a>
				            </th>
				            <th width="20%">
			              		@php
			              			$sortAs = 'desc';
			              			if((data_get($filters, 'sort_by') == 'title')){
			              				if(data_get($filters, 'sort_as') == 'asc'){
			              					$sortAs = 'desc';
			              				}else{
			              					$sortAs = 'asc';
			              				}
			              			}
			              		@endphp
			              		<a href="{{ route('admin.pages.index', array_unique(array_merge($filters, ['sort_by'=>'title', 'sort_as'=>$sortAs]), SORT_REGULAR)) }}">
					              	Title <i class="fa fa-sort-alpha-{{ ($sortAs == 'desc')?'asc':'desc' }}"></i>
					            </a>
			              	</th>
				            <th width="20%">
			              		@php
			              			$sortAs = 'desc';
			              			if((data_get($filters, 'sort_by') == 'slug')){
			              				if(data_get($filters, 'sort_as') == 'asc'){
			              					$sortAs = 'desc';
			              				}else{
			              					$sortAs = 'asc';
			              				}
			              			}
			              		@endphp
			              		<a href="{{ route('admin.pages.index', array_unique(array_merge($filters, ['sort_by'=>'slug', 'sort_as'=>$sortAs]), SORT_REGULAR)) }}">
					              	Slug <i class="fa fa-sort-alpha-{{ ($sortAs == 'desc')?'asc':'desc' }}"></i>
					            </a>
			              	</th>
			              	<th width="20%">
			              		@php
			              			$sortAs = 'desc';
			              			if((data_get($filters, 'sort_by') == 'excerpt')){
			              				if(data_get($filters, 'sort_as') == 'asc'){
			              					$sortAs = 'desc';
			              				}else{
			              					$sortAs = 'asc';
			              				}
			              			}
			              		@endphp
			              		<a href="{{ route('admin.pages.index', array_unique(array_merge($filters, ['sort_by'=>'excerpt', 'sort_as'=>$sortAs]), SORT_REGULAR)) }}">
					              	Excerpt <i class="fa fa-sort-alpha-{{ ($sortAs == 'desc')?'asc':'desc' }}"></i>
					            </a>
			              	</th>
			              	<th width="20%">
			              		@php
			              			$sortAs = 'desc';
			              			if((data_get($filters, 'sort_by') == 'created_at')){
			              				if(data_get($filters, 'sort_as') == 'asc'){
			              					$sortAs = 'desc';
			              				}else{
			              					$sortAs = 'asc';
			              				}
			              			}
			              		@endphp
			              		<a href="{{ route('admin.pages.index', array_unique(array_merge($filters, ['sort_by'=>'created_at', 'sort_as'=>$sortAs]), SORT_REGULAR)) }}">
					              	Created At <i class="fa fa-sort-numeric-{{ ($sortAs == 'desc')?'asc':'desc' }}"></i>
					            </a>
			              	</th>
			              	<th width="10%">Action</th>
			            </tr>
		          		@foreach($pages as $page)
		          			<tr>
				              	<td>{{ $loop->iteration }}</td>
				              	<td>{{ \Str::limit($page->title, 20, ' (...)') }}</td>
				              	<td>{{ \Str::limit($page->slug, 20, ' (...)') }}</td>
				              	<td>{{ \Str::limit($page->excerpt, 20, ' (...)') }}</td>
				              	<td>{{ $page->created_at }}</td>
				              	<td>
				                	<a class="btn btn-primary btn-xs" href="{{ route('admin.pages.edit', $page->id) }}" title="Edit cms page">
				                		<i class="fa fa-edit"></i>
				                	</a>
				                	<a class="btn btn-warning btn-xs" href="{{ route('admin.pages.show', $page->id) }}" title="Preview cms page">
				                		<i class="fa fa-eye"></i>
				                	</a>
				              	</td>
				            </tr>
		          		@endforeach
		          	@else
		          		<tr>
			              	<td colspan="4">
			                	<p>No cms pages exists yet!</p>
			              	</td>
			            </tr>
		          	@endif
	          	</table>
            </div>
            <div class="box-footer clearfix">
            	{{ $pages->links() }}
            </div>
        </div>
	</section>
@endsection
