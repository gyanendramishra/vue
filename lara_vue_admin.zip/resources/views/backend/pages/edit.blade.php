@extends('backend.layouts.app')
@section('title', $title)
@section('content')
    <section class="content-header">
		<h1>
		    Manage cms pages
		    <small>Here you can edit cms pages.</small>
		</h1>
		<ol class="breadcrumb">
		    <li>
		    	<a href="{{ route('admin.dashboard') }}">
		    		<i class="fa fa-dashboard"></i> Dashboard
		    	</a>
		    </li>
		    <li>
		    	<a href="{{ route('admin.pages.index') }}">
		    		<i class="fa fa-file-text-o"></i> Cms Pages
		    	</a>
		    </li>
		    <li class="active">
			    <i class="fa fa-pencil-square-o"></i> Edit
			</li>
		</ol>
	</section>
	<!-- Main content -->
	<section class="content">
	  	<div class="box">
            <div class="box-body">
        		<form method="POST" action="{{ route('admin.pages.update', $page->id) }}">
		      		@method('PATCH')
			      	@csrf
                    <div class="form-group {{ $errors->has('title') ? ' has-error' : '' }}">
                      	<label for="title">
                      		Title 
                      		<span class="required">*</span>
                      	</label>
                      	<input type="text" class="form-control" name="title" id="title" placeholder="Title" title="title" value="{{ old('title')?old('title'):$page->title }}">
                      	@if($errors->has('title'))
                      		<div class="help-block">
	                      		{{ $errors->first('title') }}
	                      	</div>
                      	@endif
                    </div>
                    <div class="form-group {{ $errors->has('sub_title') ? ' has-error' : '' }}">
                      	<label for="sub_title">
                      		Sub title
                      	</label>
                      	<input type="text" class="form-control" name="sub_title" id="sub_title" placeholder="Sub title" title="sub_title" value="{{ old('sub_title')?old('sub_title'):$page->sub_title }}">
                      	@if($errors->has('sub_title'))
                      		<div class="help-block">
	                      		{{ $errors->first('sub_title') }}
	                      	</div>
                      	@endif
                    </div>
                    <div class="form-group {{ $errors->has('excerpt') ? ' has-error' : '' }}">
                      	<label for="excerpt">
                      		Excerpt
                      	</label>
                      	<input type="text" class="form-control" name="excerpt" id="excerpt" placeholder="Excerpt" value="{{ old('excerpt')?old('excerpt'):$page->excerpt }}">
                      	@if($errors->has('excerpt'))
                      		<div class="help-block">
	                      		{{ $errors->first('excerpt') }}
	                      	</div>
                      	@endif
                    </div>
                    <div class="form-group {{ $errors->has('description') ? ' has-error' : '' }}">
                      	<label for="description">
	                      	Description
	                      	<span class="required">*</span>
	                    </label>
	                    <field-editor-component 
	                    	field-name="description" 
	                    	field-data="{{ old('description')?old('description'):$page->description }}"
	                    	field-placeholder="Description"
	                    >	
	                    </field-editor-component>
                      	@if($errors->has('description'))
                      		<div class="help-block">
	                      		{{ $errors->first('description') }}
	                      	</div>
                      	@endif
                    </div>
                    <div class="form-group {{ $errors->has('meta_title') ? ' has-error' : '' }}">
                      	<label for="meta_title">
                      		Meta title
                      	</label>
                      	<input type="text" class="form-control" name="meta_title" id="meta_title" placeholder="Meta title" value="{{ old('meta_title')?old('meta_title'):$page->meta_title }}">
                      	@if($errors->has('meta_title'))
                      		<div class="help-block">
	                      		{{ $errors->first('meta_title') }}
	                      	</div>
                      	@endif
                    </div>
                    <div class="form-group {{ $errors->has('meta_keyword') ? ' has-error' : '' }}">
                      	<label for="meta_keyword">
                      		Meta keyword
                      	</label>
                      	<input type="text" class="form-control" name="meta_keyword" id="meta_keyword" placeholder="Meta keyword" value="{{ old('meta_keyword')?old('meta_keyword'):$page->meta_keyword }}">
                      	@if($errors->has('meta_keyword'))
                      		<div class="help-block">
	                      		{{ $errors->first('meta_keyword') }}
	                      	</div>
                      	@endif
                    </div>
                    <div class="form-group {{ $errors->has('meta_description') ? ' has-error' : '' }}">
                      	<label for="meta_description">
                      		Meta description
                      	</label>
                      	<textarea class="form-control" name="meta_description" id="meta_description" placeholder="Meta description">{{ old('meta_description')?old('meta_description'):$page->meta_description }}</textarea>
                      	@if($errors->has('meta_description'))
                      		<div class="help-block">
	                      		{{ $errors->first('meta_description') }}
	                      	</div>
                      	@endif
                    </div>
                    <button type="submit" class="btn btn-success btn-sm">Submit</button>
                    <a class="btn btn-default btn-sm" href="{{ route('admin.pages.index') }}">Cancel</a>
              	</form>
            </div>
        </div>
	</section>
@endsection
