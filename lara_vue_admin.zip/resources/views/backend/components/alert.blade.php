<div class="alert alert-{{ $type }}">
	<h6 class="alert-heading">{{ $title }}</h6>
	{{ $slot }}
</div>