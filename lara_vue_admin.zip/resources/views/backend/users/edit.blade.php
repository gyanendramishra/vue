@extends('backend.layouts.app')
@section('title', $title)
@section('content')
    <section class="content-header">
		<h1>
		    Manage Users
		    <small>Here you can add edit user.</small>
		</h1>
		<ol class="breadcrumb">
		    <li>
		    	<a href="{{ route('admin.dashboard') }}">
		    		<i class="fa fa-dashboard"></i> Dashboard
		    	</a>
		    </li>
		    <li>
		    	<a href="{{ route('admin.users.index') }}">
		    		<i class="fa fa-users"></i> Users
		    	</a>
		    </li>
		    <li class="active">Edit user</li>
		</ol>
	</section>
	<!-- Main content -->
	<section class="content">
	  	<div class="box">
            <div class="box-header with-border">
              	<h3 class="box-title">
              		Edit User {{ $user->full_name }}
              	</h3>
            </div>
            <div class="box-body">
        		<form method="POST" action="{{ route('admin.users.update', $user->id) }}">
		      		@method('PATCH')
			      	@csrf
                    <div class="form-group {{ $errors->has('first_name') ? ' has-error' : '' }}">
                      	<label for="first_name">First name</label>
                      	<input type="text" class="form-control {{ $errors->has('first_name')?'is-invalid':'' }}" id="first_name" placeholder="First name" name="first_name" value="{{ old('first_name')?old('first_name'):$user->first_name }}">
                      	@if($errors->has('first_name'))
                      		<div class="help-block">
	                      		{{ $errors->first('first_name') }}
	                      	</div>
                      	@endif
                    </div>
                    <div class="form-group {{ $errors->has('last_name') ? ' has-error' : '' }}">
                      	<label for="last_name">Last name</label>
                      	<input type="text" class="form-control {{ $errors->has('last_name')?'is-invalid':'' }}" id="last_name" placeholder="Last name" name="last_name" value="{{ old('last_name')?old('last_name'):$user->last_name }}">
                      	@if($errors->has('last_name'))
                      		<div class="help-block">
	                      		{{ $errors->first('last_name') }}
	                      	</div>
                      	@endif
                    </div>
                    <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                      	<label for="email">Email address</label>
                      	<input type="email" class="form-control" id="email" placeholder="Email" name="email" value="{{ old('email')?old('email'):$user->email }}">
                      	@if($errors->has('email'))
                      		<div class="help-block">
	                      		{{ $errors->first('email') }}
	                      	</div>
                      	@endif
                    </div>
                    <button type="submit" class="btn btn-success btn-sm">Submit</button>
                    <a class="btn btn-default btn-sm" href="{{ route('admin.users.index') }}">Cancel</a>
              	</form>
            </div>
        </div>
	</section>
@endsection
