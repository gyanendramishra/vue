@extends('backend.layouts.app')
@section('title', $title)
@section('content')
	<section class="content-header">
		<h1>
		    Manage Users
		    <small>Here you can manage your users.</small>
		</h1>
		<ol class="breadcrumb">
		    <li>
		    	<a href="{{ route('admin.dashboard') }}">
		    		<i class="fa fa-dashboard"></i> Dashboard
		    	</a>
		    </li>
		    <li class="active">Users</li>
		</ol>
	</section>
	<!-- Main content -->
	<section class="content">
		<filter-user-component 
			action="{{ route('admin.users.index')  }}" 
			:filters='@json($filters)'
		></filter-user-component>
	  	<div class="box">
            <div class="box-header with-border">
              	<h3 class="box-title">
              		<span class="caption-subject font-green bold uppercase">Users</span>
              	</h3>
              	<div class="box-tools">
	                <a href="{{ route('admin.users.create') }}" class="btn btn-primary btn-sm" title="Add new user">Add new</a>
	            </div>
            </div>
            <div class="box-body table-responsive">
        		<table class="table table-bordered datatable">
        			@if($users->count() > 0)
		            	<tr>
			              	<th width="10%">
			              		@php
			              			$sortAs = 'desc';
			              			if((data_get($filters, 'sort_by') == 'id')){
			              				if(data_get($filters, 'sort_as') == 'asc'){
			              					$sortAs = 'desc';
			              				}else{
			              					$sortAs = 'asc';
			              				}
			              			}
			              		@endphp
			              		<a href="{{ route('admin.users.index', array_unique(array_merge($filters, ['sort_by'=>'id', 'sort_as'=> $sortAs]), SORT_REGULAR)) }}">
					              	#Id <i class="fa fa-sort-numeric-{{ ($sortAs == 'desc')?'asc':'desc' }}" aria-hidden="true"></i>
					            </a>
				            </th>
				            <th width="15%">
			              		Avatar
			              	</th>
			              	<th width="25%">
			              		@php
			              			$sortAs = 'desc';
			              			if((data_get($filters, 'sort_by') == 'first_name')){
			              				if(data_get($filters, 'sort_as') == 'asc'){
			              					$sortAs = 'desc';
			              				}else{
			              					$sortAs = 'asc';
			              				}
			              			}
			              		@endphp
			              		<a href="{{ route('admin.users.index', array_unique(array_merge($filters, ['sort_by'=>'first_name', 'sort_as'=>$sortAs]), SORT_REGULAR)) }}">
					              	Name <i class="fa fa-sort-alpha-{{ ($sortAs == 'desc')?'asc':'desc' }}"></i>
					            </a>
			              	</th>
			              	<th width="30%">
			              		@php
			              			$sortAs = 'desc';
			              			if((data_get($filters, 'sort_by') == 'email')){
			              				if(data_get($filters, 'sort_as') == 'asc'){
			              					$sortAs = 'desc';
			              				}else{
			              					$sortAs = 'asc';
			              				}
			              			}
			              		@endphp
			              		<a href="{{ route('admin.users.index', array_unique(array_merge($filters, ['sort_by'=>'email', 'sort_as'=>$sortAs]), SORT_REGULAR)) }}">
					              	Email <i class="fa fa-sort-alpha-{{ ($sortAs == 'desc')?'asc':'desc' }}"></i>
					            </a>
			              	</th>
			              	<th width="10%">
			              		Role
			              	</th>
			              	<th width="10%">Action</th>
			            </tr>
		          		@foreach($users as $user)
		          			<tr>
				              	<td>{{ $loop->iteration }}</td>
				              	<td></td>
				              	<td>{{ $user->full_name }}</td>
				              	<td>{{ $user->email }}</td>
				              	<td>{{ $user->roles->implode('name', ', ') }}</td>
				              	<td>
				                	<a class="btn btn-warning btn-xs" href="{{ route('admin.users.edit', $user->id) }}">
				                		<i class="fa fa-edit"></i>
				                	</a>
				                	<delete-action-component
				                		action="{{ route('admin.users.destroy', $user->id) }}" 
				                		label= "{{ $user->full_name }}"
				                	></delete-action-component>
				              	</td>
				            </tr>
		          		@endforeach
		          	@else
		          		<tr>
			              	<td colspan="4">
			                	<p>No users exists yet!</p>
			              	</td>
			            </tr>
		          	@endif
	          	</table>
            </div>
            <div class="box-footer clearfix">
            	{{ $users->links() }}
            </div>
        </div>
	</section>
@endsection
