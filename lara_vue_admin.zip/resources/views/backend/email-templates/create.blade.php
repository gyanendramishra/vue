@extends('backend.layouts.app')
@section('title', $title)
@section('content')
    <section class="content-header">
		<h1>
		    Manage email templates
		    <small>Here you can add email template.</small>
		</h1>
		<ol class="breadcrumb">
		    <li>
		    	<a href="{{ route('admin.dashboard') }}">
		    		<i class="fa fa-dashboard"></i> Dashboard
		    	</a>
		    </li>
		    <li>
		    	<a href="{{ route('admin.email-templates.index') }}">
		    		<i class="fa fa-file-text-o"></i> Email templates
		    	</a>
		    </li>
		    <li class="active">
			    <i class="fa fa-plus"></i> Add
			</li>
		</ol>
	</section>
	<!-- Main content -->
	<section class="content">
	  	<div class="box">
            
            <div class="box-body">
        		<form method="POST" action="{{ route('admin.email-templates.store') }}">
		      		@csrf
		      		<div class="form-group {{ $errors->has('name') ? ' has-error' : '' }}">
                      	<label for="name">
                      		Name 
                      		<span class="required">*</span>
                      	</label>
                      	<input type="text" class="form-control" name="name" id="name" placeholder="Name" value="{{ old('name') }}">
                      	@if($errors->has('name'))
                      		<div class="help-block">
	                      		{{ $errors->first('name') }}
	                      	</div>
                      	@endif
                    </div>
                    <div class="form-group {{ $errors->has('subject') ? ' has-error' : '' }}">
                      	<label for="subject">
                      		Subject 
                      		<span class="required">*</span>
                      	</label>
                      	<input type="text" class="form-control" name="subject" id="subject" placeholder="Subject"  value="{{ old('subject') }}">
                      	@if($errors->has('subject'))
                      		<div class="help-block">
	                      		{{ $errors->first('subject') }}
	                      	</div>
                      	@endif
                    </div>
                    <div class="form-group {{ $errors->has('body') ? ' has-error' : '' }}">
                      	<label for="body">
	                      	Body
	                      	<span class="required">*</span>
	                    </label>
	                    <field-editor-component 
	                    	field-name="body" 
	                    	field-data="{{ old('body') }}" 
	                    	field-placeholder="Message body" 
	                    >
	                    </field-editor-component>
                      	@if($errors->has('body'))
                      		<div class="help-block">
	                      		{{ $errors->first('body') }}
	                      	</div>
                      	@endif
                    </div>
                    <button type="submit" class="btn btn-success btn-sm">Submit</button>
                    <a class="btn btn-default btn-sm" href="{{ route('admin.email-templates.index') }}">Cancel</a>
              	</form>
            </div>
        </div>
	</section>
@endsection
