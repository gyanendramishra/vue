@extends('backend.layouts.app')
@section('title', $title)
@section('content')
	<section class="content-header">
		<h1>
		    Manage email templates
		    <small>Here you can manage email templates.</small>
		</h1>
		<ol class="breadcrumb">
		    <li>
		    	<a href="{{ route('admin.dashboard') }}">
		    		<i class="fa fa-dashboard"></i> Dashboard
		    	</a>
		    </li>
		    <li class="active">Email templates</li>
		</ol>
	</section>
	<!-- Main content -->
	<section class="content">
		<filter-email-template-component 
			action="{{ route('admin.email-templates.index')  }}" 
			:filters='@json($filters)'
			:template-name='@json(config("settings.email_templates"))'
		></filter-email-template-component>
	  	<div class="box">
            <div class="box-header with-border">
              	<h3 class="box-title">
              		<span class="caption-subject font-green bold uppercase">Email templates</span>
              	</h3>
              	<div class="box-tools">
	                <a href="{{ route('admin.email-templates.create') }}" class="btn btn-success btn-sm" title="Add new email template">Add new</a>
	            </div>
            </div>
            <div class="box-body table-responsive">
        		<table class="table table-bordered datatable">
        			@if($emailTemplates->count() > 0)
		            	<tr>
			              	<th width="10%">
			              		@php
			              			$sortAs = 'desc';
			              			if((data_get($filters, 'sort_by') == 'id')){
			              				if(data_get($filters, 'sort_as') == 'asc'){
			              					$sortAs = 'desc';
			              				}else{
			              					$sortAs = 'asc';
			              				}
			              			}
			              		@endphp
			              		<a href="{{ route('admin.email-templates.index', array_unique(array_merge($filters, ['sort_by'=>'id', 'sort_as'=> $sortAs]), SORT_REGULAR)) }}">
					              	#Id <i class="fa fa-sort-numeric-{{ ($sortAs == 'desc')?'asc':'desc' }}" aria-hidden="true"></i>
					            </a>
				            </th>
				            <th width="30%">
			              		@php
			              			$sortAs = 'desc';
			              			if((data_get($filters, 'sort_by') == 'name')){
			              				if(data_get($filters, 'sort_as') == 'asc'){
			              					$sortAs = 'desc';
			              				}else{
			              					$sortAs = 'asc';
			              				}
			              			}
			              		@endphp
			              		<a href="{{ route('admin.email-templates.index', array_unique(array_merge($filters, ['sort_by'=>'name', 'sort_as'=>$sortAs]), SORT_REGULAR)) }}">
					              	Name <i class="fa fa-sort-alpha-{{ ($sortAs == 'desc')?'asc':'desc' }}"></i>
					            </a>
			              	</th>
			              	<th width="30%">
			              		@php
			              			$sortAs = 'desc';
			              			if((data_get($filters, 'sort_by') == 'subject')){
			              				if(data_get($filters, 'sort_as') == 'asc'){
			              					$sortAs = 'desc';
			              				}else{
			              					$sortAs = 'asc';
			              				}
			              			}
			              		@endphp
			              		<a href="{{ route('admin.email-templates.index', array_unique(array_merge($filters, ['sort_by'=>'subject', 'sort_as'=>$sortAs]), SORT_REGULAR)) }}">
					              	Subject <i class="fa fa-sort-alpha-{{ ($sortAs == 'desc')?'asc':'desc' }}"></i>
					            </a>
			              	</th>
			              	<th width="20%">
			              		@php
			              			$sortAs = 'desc';
			              			if((data_get($filters, 'sort_by') == 'created_at')){
			              				if(data_get($filters, 'sort_as') == 'asc'){
			              					$sortAs = 'desc';
			              				}else{
			              					$sortAs = 'asc';
			              				}
			              			}
			              		@endphp
			              		<a href="{{ route('admin.email-templates.index', array_unique(array_merge($filters, ['sort_by'=>'created_at', 'sort_as'=>$sortAs]), SORT_REGULAR)) }}">
					              	Created At <i class="fa fa-sort-numeric-{{ ($sortAs == 'desc')?'asc':'desc' }}"></i>
					            </a>
			              	</th>
			              	<th width="10%">Action</th>
			            </tr>
		          		@foreach($emailTemplates as $emailTemplate)
		          			<tr>
				              	<td>{{ $loop->iteration }}</td>
				              	<td>{{ \Str::limit($emailTemplate->name, 20, ' (...)') }}</td>
				              	<td>{{ \Str::limit($emailTemplate->subject, 20, ' (...)') }}</td>
				              	<td>{{ $emailTemplate->created_at }}</td>
				              	<td>
				                	<a class="btn btn-primary btn-xs" href="{{ route('admin.email-templates.edit', $emailTemplate->id) }}" title="Edit email template">
				                		<i class="fa fa-edit"></i>
				                	</a>
				                	<a class="btn btn-warning btn-xs" href="{{ route('admin.email-templates.show', $emailTemplate->id) }}" title="Preview email template">
				                		<i class="fa fa-eye"></i>
				                	</a>
				              	</td>
				            </tr>
		          		@endforeach
		          	@else
		          		<tr>
			              	<td colspan="4">
			                	<p>No email templates exists yet!</p>
			              	</td>
			            </tr>
		          	@endif
	          	</table>
            </div>
            <div class="box-footer clearfix">
            	{{ $emailTemplates->links() }}
            </div>
        </div>
	</section>
@endsection
