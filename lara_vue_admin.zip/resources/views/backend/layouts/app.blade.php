<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!-- Title -->
    <title>{{ config('app.name', 'Admin') }} @yield('title')</title>

    <!-- Styles -->
    <link href="{{ mix('css/backend.css') }}" rel="stylesheet">
</head>
<body class="hold-transition skin-blue sidebar-mini">
    <div id="app" class="wrapper">
        <header class="main-header">
            <!-- Header -->
                @include('backend.partials.navbar')
            <!-- Header -->
        </header>
        <aside class="main-sidebar">
            <section class="sidebar">
                <!-- Sidebar -->
                    @include('backend.partials.sidebar')
                <!-- Sidebar -->
            </section>
        </aside>

        <div class="content-wrapper">
            <!-- Yield content -->
            <!-- Alert component -->
            @if(\Session::has('flash_success'))
                @component('backend.components.alert', ['type' => 'success'])
                    @slot('title')
                        Success!
                    @endslot
                    {{ session('flash_success') }}
                @endcomponent
            @elseif(\Session::has('flash_error'))
                @component('backend.components.alert', ['type' => 'danger'])
                    @slot('title')
                        Error!
                    @endslot
                    {{ session('flash_error') }}
                @endcomponent
            @elseif(\Session::has('flash_warning'))
                @component('backend.components.alert', ['type' => 'warning'])
                    @slot('title')
                        Warning!
                    @endslot
                    {{ session('flash_warning') }}
                @endcomponent
            @else
            @endif
            <!-- End Alert Component -->
            
            @yield('content')

            <!-- End yield content -->
        </div>

        <footer class="main-footer">
            <!-- Footer -->
            @include('backend.partials.footer')
            <!-- Footer -->
        </footer>
    </div>
    <!-- Scripts -->
    <script async src="{{ mix('js/backend.js') }}"></script>
</body>
</html>
