@extends('backend.layouts.guest')

@section('content')
    <p class="login-box-msg">{{ __('Reset Password') }}</p>
    <form method="POST" action="{{ route('admin.password.email') }}">
        @csrf
        @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
        @endif
        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
            <label class="label">{{ __('E-Mail Address') }}</label>
            <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}">
            @if ($errors->has('email'))
                <span class="help-block">
                    <strong>{{ $errors->first('email') }}</strong>
                </span>>
            @endif
        </div>
        <div class="form-group">
            <button class="btn btn-primary btn-block">{{ __('Send Password Reset Link') }}</button>
        </div>
    </form>
@endsection
