<!-- Sidebar user panel -->
<div class="user-panel">
    <div class="pull-left image">
      	<img src="{{ asset('img/backend/avatar.png') }}" class="img-circle" alt="User Image">
    </div>
    <div class="pull-left info">
      	<p>{{ $loggedinUser->full_name }}</p>
      	<a href="javascript:;"><i class="fa fa-circle text-success"></i> Online</a>
    </div>
</div>
<!-- search form -->
<form action="javascript:;" method="get" class="sidebar-form">
    <div class="input-group">
      	<input type="text" name="q" class="form-control" placeholder="Search...">
      	<span class="input-group-btn">
            <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
            </button>
        </span>
    </div>
</form>
<!-- /.search form -->
<!-- sidebar menu: : style can be found in sidebar.less -->
<ul class="sidebar-menu" data-widget="tree">
    <li class="header">MAIN NAVIGATION</li>
    <li class="{{ (request()->is('admin/dashboard*'))?'active':'' }}">
        <a href="{{ route('admin.dashboard') }}">
            <i class="fa fa-dashboard"></i> 
            <span>Dashboard</span>
        </a>
    </li>
    <li class="treeview {{ (request()->is('admin/users*'))?'active':'' }}">
	    <a href="javascript:;">
	        <i class="fa fa-users"></i>
	        <span>Users manager</span>
	        <span class="pull-right-container">
	          	<i class="fa fa-angle-left pull-right"></i>
	        </span>
	    </a>
        <ul class="treeview-menu">
            <li>
            	<a href="{{ route('admin.users.index', ['sort_by'=>'id', 'sort_as'=>'desc']) }}">
            		<i class="fa fa-circle-o"></i> Users
            	</a>
            </li>
            <li>
            	<a href="{{ route('admin.users.index') }}">
            		<i class="fa fa-circle-o"></i> Roles
            	</a>
            </li>
            <li>
            	<a href="{{ route('admin.users.index') }}">
            		<i class="fa fa-circle-o"></i> Permissions
            	</a>
            </li>
        </ul>
    </li>
    <li class="{{ (request()->is('admin/pages*'))?'active':'' }}">
	    <a href="{{ route('admin.pages.index') }}">
	        <i class="fa fa-file-code-o"></i>
	        <span>Cms pages manager</span>
	    </a>
    </li>
    <li class="{{ (request()->is('admin/email-templates*'))?'active':'' }}">
	    <a href="{{ route('admin.email-templates.index') }}">
	        <i class="fa fa-file-text-o"></i>
	        <span>Email templates manager</span>
	    </a>
    </li>
</ul>