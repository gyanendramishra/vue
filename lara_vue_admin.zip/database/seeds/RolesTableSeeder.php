<?php

use Illuminate\Database\Seeder;

class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'id' => 1, 
                'name' => 'Administrator', 
                'description' => 'Can create other users and full access of admin panel'
            ],
            [
                'id' => 2, 
                'name' => 'Supervisor',
                'description' => 'Can manage assigned jobs'
            ],
            [
                'id' => 3, 
                'name' => 'Job Provider',
                'description' => 'Can provide the jobs'
            ],
            [
                'id' => 4, 
                'name' => 'Job Seeker',
                'description' => 'Can apply for jobs'
            ],
        ];

        foreach ($items as $item) {
            \App\Models\Role::create($item);
        }
    }
}
