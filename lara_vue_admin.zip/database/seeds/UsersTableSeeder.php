<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            [
                'first_name' => 'Gyanendra',
                'last_name' => 'Mishra',
                'email'=> 'gyanendra.kumar@dotsquares.com',
                'status'=> 'V',
                'password' => bcrypt('Champ@123'),
                'email_verified_at' => now(),
            ],

            [
                'first_name' => 'Mayank',
                'last_name' => 'Mishra',
                'email'=> 'mayank.mishra@dotsquares.com',
                'status'=> 'V',
                'password' => bcrypt('Champ@123'),
                'email_verified_at' => now(),
            ],

        ];

        foreach ($items as $key => $value) {
            \App\Models\User::create($value);
        }
    }
}
