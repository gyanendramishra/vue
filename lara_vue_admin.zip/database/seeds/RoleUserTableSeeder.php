<?php

use Illuminate\Database\Seeder;

class RoleUserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            1 => [
                'roles' => [1]
            ],
            2 => [
                'roles' => [2]
            ],
        ];

        foreach ($items as $id => $item) {
            $user = \App\Models\User::find($id);

            foreach ($item as $key => $ids) {
                $user->{$key}()->sync($ids);
            }
        }
    }
}
