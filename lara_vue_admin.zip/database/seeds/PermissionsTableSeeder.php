<?php

use Illuminate\Database\Seeder;

class PermissionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            
            [
                'id' => 1, 
                'name' => 'user_management_access',
                'description'=> 'Can manage users'
            ],
            [
                'id' => 2, 
                'name' => 'permission_access',
                'description'=> 'Can access permissions'
            ],
            [
                'id' => 3, 
                'name' => 'permission_create',
                'description'=> 'Can create permissions'
            ],
            [
                'id' => 4, 
                'name' => 'permission_edit',
                'description'=> 'Can edit permissions'
            ],
            [
                'id' => 5, 
                'name' => 'permission_view',
                'description'=> 'Can view permissions'
            ],
            [
                'id' => 6, 
                'name' => 'permission_delete',
                'description'=> 'Can delete permissions'
            ],
            [
                'id' => 7, 
                'name' => 'role_access',
                'description'=> 'Can access roles'
            ],
            [
                'id' => 8, 
                'name' => 'role_create',
                'description'=> 'Can create roles'
            ],
            [
                'id' => 9, 
                'name' => 'role_edit',
                'description'=> 'Can edit roles'
            ],
            [
                'id' => 10, 
                'name' => 'role_view',
                'description'=> 'Can view roles'
            ],
            [
                'id' => 11, 
                'name' => 'role_delete',
                'description'=> 'Can delete roles'
            ],
            [
                'id' => 12, 
                'name' => 'user_access',
                'description'=> 'Can access users'
            ],
            [
                'id' => 13, 
                'name' => 'user_create',
                'description'=> 'Can create users'
            ],
            [
                'id' => 14, 
                'name' => 'user_edit',
                'description'=> 'Can edit users'
            ],
            [
                'id' => 15, 
                'name' => 'user_view',
                'description'=> 'Can view users'
            ],
            [
                'id' => 16, 
                'name' => 'user_delete',
                'description'=> 'Can delete users'
            ],
            [
                'id' => 17, 
                'name' => 'setting_access',
                'description'=> 'Can access settings'
            ],
            [
                'id' => 18, 
                'name' => 'email_template_access',
                'description'=> 'Can access email templates',
            ],
            [
                'id' => 19, 
                'name' => 'email_template_create',
                'description'=> 'Can create email templates'
            ],
            [
                'id' => 20, 
                'name' => 'email_template_edit',
                'description'=> 'Can edit email templates'
            ],
            [
                'id' => 21, 
                'name' => 'email_template_view',
                'description'=> 'Can view email templates'
            ],
            [
                'id' => 22, 
                'name' => 'email_template_delete',
                'description'=> 'Can delete email templates'
            ],

        ];

        foreach ($items as $item) {
            \App\Models\Permission::create($item);
        }
    }
}
