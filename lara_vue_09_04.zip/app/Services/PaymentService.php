<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class PaymentService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/stripes/';

    /**
     * Add payment account detail.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function getAccountService() {
        $uri = 'api/users/accountDetail';
        return $this->getServiceRequest($uri);
    }

    /**
     * Update payment account detail.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function addUpdatePaymentAccountService($data) {
        $uri = $this->base_uri;
        $uri .= 'updateAccount';
        return $this->postFileRequest($uri, $data);
    }

    /**
     * Make invoice payment.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function makeInvoicePaymentService($data) {
        $uri = $this->base_uri;
        $uri .= 'makePayment';
        return $this->postServiceRequest($uri, $data);
    }

}