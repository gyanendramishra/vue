<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class CategoryService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/categories/';

    /**
     * Get the parent service categories.
     *
     * @return Illuminate\Http\Response
     */
    public function getParentCategoryService() {
        $uri = $this->base_uri;
        $uri .= 'mainlisting';

        return $this->getServiceRequest($uri);
    }

    /**
     * Get the sub service categories.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function getSubCategoryService($data) {
        $uri = $this->base_uri;
        $uri .= 'sublisting';

        return $this->postServiceRequest($uri, $data);
    }

    /**
     * Get filter categories.
     *
     * @return Illuminate\Http\Response
     */
    public function getFilterCategoriesService() {
        $uri = $this->base_uri;
        $uri .= 'filterlisting';

        return $this->getServiceRequest($uri);
    }

    /**
     * Get the service providers.
     *
     * @param array $filter
     * @return Illuminate\Http\Response
     */
    public function getServiceProvidersService($filter) {
        $uri = $this->base_uri;
        $uri .= 'getServiceProvider'; 
        return $this->postServiceRequest($uri, $filter);
    }
}