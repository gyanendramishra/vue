<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class OperationalTimesService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/users/';


    /**
     * Get the user operational hours.
     *
     * @return Illuminate\Http\Response
     */
    public function getOperationalTimesService() {
        $uri = $this->base_uri;
        $uri .= 'opening_days'; 
        return $this->getServiceRequest($uri);
    }

    /**
     * Update the user operational hours.
     *
     * @param  array  $data
     * @return Illuminate\Http\Response
     */
    public function updateOperationalTimesService(array $data) {
        $uri = $this->base_uri;
        $uri .= 'opening_days'; 
        return $this->postServiceRequest($uri, $data);
    }

    

}