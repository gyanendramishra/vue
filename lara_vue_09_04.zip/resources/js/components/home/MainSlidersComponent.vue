<template>
    <div class="sliderWrap global-slider-controls">
        <div id="home-slider">
            <div class="item fill" v-for="slider in sliders" :style="{ backgroundImage: 'url('+ slider +')' }"></div>
        </div>
        <div class="top-booking-form-sec">
            <div class="container">
                <div class="booking-title-col">
                    <div class="booking-title-col-inner">
                        <h2>Offering <span>easy</span></h2>
                        <p>
                            to-book services, in person or<br />
                            virtually on demand.
                        </p>
                    </div>
                </div>
                <search-service-providers-component></search-service-providers-component>
            </div>
        </div>
    </div>
</template>
<script>
import SearchServiceProvidersComponent from "./SearchServiceProvidersComponent.vue";
//import 'owl.carousel/dist/assets/owlcarouseltheme.css';
import 'owl.carousel';
export default {
    name: "main-sliders-component",
    components:{
        SearchServiceProvidersComponent
    },
    data() {
        return {
            sliders: ["/images/slide_01.jpg", "/images/slide_01.jpg", "/images/slide_01.jpg"]
        };
    },
    mounted: function(){
        Vue.nextTick(function(){
            window.$("#home-slider").owlCarousel({
                loop:true,
                margin:0,
                nav:true,
                dots:false,
                autoplay:true,
                responsive:{
                    0:{
                        items:1 
                    },
                    767:{
                        items:1
                    },
                    1024:{
                        items:1
                    }
                    
                }
            });
        }.bind(this));
    }
};

</script>
