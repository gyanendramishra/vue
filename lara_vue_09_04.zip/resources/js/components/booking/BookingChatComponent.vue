<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div class="chat-booking-page">
                    <div class="right-chat-screen">
                        <div class="chat_area">
                            <p v-if="messages.length == 0">No messages yet!</p>
                            <ul class="list-unstyled">
                                <div v-for="message in messages">
                                    <li class="left clearfix" v-if="message.receiver.id === loggedinUserId">
                                        <span class="chat-img1 pull-left">
                                            <img src="/images/top_category_img01.jpg" alt="User Avatar">
                                        </span>
                                        <div class="chat-body1 clearfix">
                                            <div class="chat-user-name-left">{{ message.receiver.displayName }}</div>
                                            <div class="chatarea-col">{{ message.data.text }}</div>
                                            <div class="chat_time pull-right">{{ message.sentDate }}</div>
                                        </div>
                                    </li>
                                    <li class="left clearfix admin_chat" v-if="message.sender.id === loggedinUserId">
                                        <span class="chat-img1 pull-right">
                                            <img src="/images/top_category_img03.jpg" alt="User Avatar">
                                        </span>
                                        <div class="chat-body1 clearfix">
                                            <div class="chat-user-name-right">{{ message.sender.displayName }}</div>
                                            <div class="chatarea-col">{{ message.data.text }}</div>
                                            <div class="chat_time pull-left">{{ message.sentDate }}</div>
                                        </div>
                                    </li>
                                </div>
                            </ul>
                        </div>
                        <form @submit.prevent="createMessage">
                            <div class="chatting-text-box">
                                <textarea v-model="newMessage"></textarea>
                            </div>
                            <div class="chatting-sms-btn-sec">
                                <div class="browse-btn">BROWSE <input type="file" /></div>
                                <button class="btn btn-sm btn-yellow" type="submit">SEND MESSAGE</button>          
                            </div>
                        </form>
                    </div>
                </div>  
            </div>
        </div>
    </div>
</template>
<script>
    import fire from '../../firebase/init';
    import moment from "moment";
    import LoaderComponent from "../LoaderComponent.vue";
    export default {
        name: "booking-chat-component",
        components:{
            LoaderComponent
        },
        props:["bookingId", "loggedinUserId"],
        data: function () {
            return {
                loading: false,
                booking: {},
                messages: [],
                newMessage: ""
            }
        },
        created: function(){
            this.loading = true;
            this.getBooking();
        },
        filters: {
            prepareSlug (str, id) {
                if(!str) return "";
                return str.toLowerCase().replace(/ /g, '-')+"-"+id;
            }
        },
        methods: {
            getBooking() {
                this.loading = true;
                axios.post('/booking/get/data', {
                    id: this.bookingId
                }).then(response => {
                    if(response.data.status === true){
                        this.booking = response.data.data;
                        this.getMessages();
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            createMessage () {
                this.loading = true;
                if (this.newMessage) {
                    fire.database().ref('conversation').child(this.booking.id).child('chat').push({
                        data:{
                            text: this.newMessage
                        },
                        isRead: false,
                        receiver: {
                            displayName: (this.booking.is_customer) ? this.booking.provider_name : this.booking.user_name,
                            id: (this.booking.is_customer) ? this.booking.provider_id : this.booking.user_id
                        },
                        sender: {
                            displayName: (this.booking.is_customer) ? this.booking.user_name : this.booking.provider_name,
                            id: (this.booking.is_customer) ? this.booking.user_id : this.booking.provider_id
                        },
                        sentDate: Date.now()
                    });
                    /*.push({
                        conversationId: this.booking.id,
                        id: this.booking.id,
                        pushToken: this.booking.second_person_fcm_token
                    })*/
                    this.loading = false;
                    this.newMessage = null;
                } else {
                    this.loading = false;
                    flash("A message must be entered!", "error");
                }
            },
            getMessages(){
                this.loading = true;
                alert(this.loggedinUserId);
                let ref = fire.database().ref('conversation');
                ref.child(this.booking.id).child('chat').on('value', snapshot => {
                    let data = snapshot.val();
                    this.messages = [];
                    if(data){
                        Object.keys(data).forEach(key => {
                            this.messages.push(data[key]);
                        });
                    }
                    console.log(this.messages);
                    this.loading = false;
                });
            }
        }
    }
</script>
