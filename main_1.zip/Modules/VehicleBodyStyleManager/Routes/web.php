<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('admin')->middleware('auth:admin')->namespace('Admin')->as('admin.')->group(function() {
   
	Route::get('vehiclebodystylemanager/ajax/list', 'VehicleBodyStyleManagerController@ajaxList')->name('vehiclebodystylemanager.ajax.list');
	Route::get('vehiclebodystylemanager/delete/{id}', 'VehicleBodyStyleManagerController@destroy')->name('vehiclebodystylemanager.delete');
	Route::resources([
        'vehiclebodystylemanager' => 'VehicleBodyStyleManagerController',
    ]);
        Route::post('importbodyStyle', 'VehicleBodyStyleManagerController@importData')->name('bodyStyle.import.file');
});

