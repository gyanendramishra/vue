@extends('layouts.admin.master')
@section('title','View Vehicle Audio, Visual & Communication  Detail')
@section('content')
@include('layouts.admin.flash.alert')
<section class="content-header">
    <h1>
        Manage Vehicle Audio, Visual & Communication        
    </h1>
    {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.vehicleaudiocommunication.index'],['label' => 'View Vehicle Audio, Visual & Communication  Detail']]]) }}
</section>

<section class="content" data-table="emailHooks">
    @include('layouts.flash.alert')
    <div class="box">
        <div class="box-header"><h3 class="box-title">{{ $vehicleaudiocommunication->name }}</h3>
            <a href="{{route('admin.vehicleaudiocommunication.index')}}" class="btn btn-default pull-right" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
        </div>
        <div class="box-body">
            <table class="table table-hover table-striped">
                <tr>
                    <th scope="row">{{ __('Name') }}</th>
                    <td>{{ $vehicleaudiocommunication->name }}</td>
                </tr>
                <tr>
                    <th scope="row"><?= __('Created') ?></th>
                    <td>{{ $vehicleaudiocommunication->created_at->toFormattedDateString() }}</td>
                </tr>
                <tr>
                    <th scope="row">{{ __('Modified') }}</th>
                    <td>{{ $vehicleaudiocommunication->updated_at->toFormattedDateString() }}</td>
                </tr>
                <tr>
                    <th scope="row">{{ __('Status') }}</th>
                    <td>{{ $vehicleaudiocommunication->status ? __('Active') : __('Inactive')  }}</td>
                </tr>
            </table>           
        </div>
        <div class="box-footer">
                <a href="{{route('admin.vehicleaudiocommunication.index')}}" class="btn btn-default pull-left" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
        </div>
    </div>
</section>

@endsection
