<?php

return [
    'name' => 'VehicleAudioCommunicationManager'
];
