<?php

namespace Modules\VehicleEngineCapacityManager\Entities;

use Illuminate\Database\Eloquent\Model;
use \Dimsav\Translatable\Translatable;

class VehicleEngineCapacity extends Model {

    public $translatedAttributes = ['name'];

    use Translatable;

    protected $fillable = ["status", 'icon'];

  
}
