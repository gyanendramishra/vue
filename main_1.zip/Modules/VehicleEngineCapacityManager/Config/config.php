<?php

return [
    'name' => 'VehicleEngineCapacityManager'
];
