@extends('layouts.admin.app')
@section('title', !empty($vehicleenginecapacity) ? 'Edit Vehicle Engine Capacity' : 'Add Vehicle Engine Capacity')
@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            {{ __( 'Manage Vehicle Engine Capacity' ) }}           
        </h1>
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.vehicleenginecapacitymanager.index'],['label' => !empty($vehicleenginecapacity) ? 'Edit Vehicle Engine Capacity' : 'Add New Vehicle Engine Capacity' ]]]) }}
    </section>
    <!-- Main content -->
    <section class="content">
         @include('layouts.flash.alert')
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">{{ !empty($vehicleenginecapacity) ? 'Edit Vehicle Engine Capacity' : 'Add Vehicle Engine Capacity' }}</h3>
                <div class="box-tools pull-right">
                    <a href="{{ route('admin.vehicleenginecapacitymanager.index') }}" class="btn btn-primary">Back</a>
                </div>
            </div>
            <div class="box-body">
                @if(session()->has('success'))
                <div class="alert alert-success">
                    {{ session()->get('success') }}
                </div>
                @endif

                @if(isset($vehicleenginecapacity))
                {{ Form::model($vehicleenginecapacity, ['route' => ['admin.vehicleenginecapacitymanager.update', $vehicleenginecapacity->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}
                @else
                {{ Form::open(['route' => 'admin.vehicleenginecapacitymanager.store','enctype'=>'multipart/form-data']) }}
                @endif
                <div class="nav-tabs-custom">    
                    
                    
                    @php
                    $locales = config('app.locales');
                    @endphp
                    <ul class="nav nav-tabs">
                        @foreach($locales as $key=>$val)
                        <li class="{{ ($key=='en')?'active':'' }}"><a data-toggle="tab" href="#{{ $key.'_tab' }}" class="{{ ($key=='en')?'active show':'' }}">{{ $val }}</a></li>
                        @endforeach
                    </ul>
                    <div>&nbsp;</div>

                    <div class="tab-content">
                        @foreach($locales as $key=>$val)

                        <div id="{{ $key.'_tab' }}" class="tab-pane  {{ ($key=='en')?'fade in active':'' }}">



                            <div class="row">

                                <div class="col-xs-6">

                                    <div class="form-group required {{ $errors->has($key.'_name') ? 'has-error' : '' }}">
                                        <label for="title">Name <span class="asterisk">*</span></label>
                                        {{ Form::text($key.'_name',old($key.'_name', (isset($vehicleenginecapacity))?$vehicleenginecapacity->translate($key)['name']:"") , ['class' => 'form-control','placeholder' => 'Name']) }}
                                        @if($errors->has($key.'_name'))
                                        <span class="help-block">{{ $errors->first($key.'_name') }}</span>
                                        @endif
                                    </div>

                                </div>

                            </div>


                        </div>
                        @endforeach

                        <div class="row">
                            <div class="col-md-6">


                                <div class="form-group required {{ $errors->has('status') ? 'has-error' : '' }}">
                                    <label for="title">Status <span class="asterisk">*</span></label>
                                    {{ Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control']) }}
                                    @if($errors->has('status'))
                                    <span class="help-block">{{ $errors->first('status') }}</span>
                                    @endif
                                </div>

                                <!-- <div class="form-group {{ $errors->has('icon') ? 'has-error' : '' }}">
                                    <label for="title">Icon </label>
                                    {{Form::file('icon')}}
                                     @if($errors->has('icon'))
                                    <span class="help-block">{{ $errors->first('icon') }}</span>
                                    @endif
                                </div>
                                @php
                                $filepath = '/uploads/engineCapacity/';
                                @endphp
                                @if(!empty($vehicleenginecapacity->icon) && file_exists(public_path() . $filepath . $vehicleenginecapacity->icon))
                                <?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url($filepath . $vehicleenginecapacity->icon), '150', '60', '100'); ?>
                                <div class="form-group">
                                    <img src="{{$imageurl}}">
                                </div>
                                @endif -->
                            </div>

                        </div> <!-- /.row -->


                    </div>

                    
                    
                    
                </div>

                <div class="box-footer">
                    <button class="btn btn-primary btn-flat" title="Submit" type="submit"><i class="fa fa-fw fa-save"></i> Submit</button>
                    <a href="{{ route('admin.vehicleenginecapacitymanager.index') }}" class="btn btn-warning btn-flat" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                </div>
                {{ Form::close() }}
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>

@stop