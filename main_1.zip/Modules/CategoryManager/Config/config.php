<?php

return [
    'name' => 'CategoryManager'
];
