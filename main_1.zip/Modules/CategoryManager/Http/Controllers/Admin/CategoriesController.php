<?php

namespace Modules\CategoryManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Input;
use Modules\CategoryManager\Entities\Category;
use Modules\CategoryManager\Http\Requests\CategoryRequest;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use File;

class CategoriesController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        $title = "Category";
        return view('categorymanager::Admin.categories.index', compact('title'));
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {

        $categories = Category::get();

        if ($request->status != '') {
            $categories = $categories->where('status', $request->status);
        }

        return datatables()->of($categories)
                        ->addColumn('action', function ($categories) {
                            $actions = "";
                            // $actions .= "<a href=\"" . route('admin.categories.show', ['id' => $category->id]) . "\" class=\"btn btn-xs btn-primary btn-flat info-btn\"><i class=\"glyphicon glyphicon-eye-open\"></i> View</a>";
                            $actions .= "<a href=\"" . route('admin.categories.edit', ['id' => $categories->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        return view('categorymanager::Admin.categories.createOrUpdate');
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request) {
        $locales = config('app.locales');
         $valRule = [
            'icon' => 'sometimes|mimes:jpeg,jpg,png|max:5000'
        ];
        $valMessage = [
            'icon.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
          'icon.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
        ];
        foreach ($locales as $key => $value) {
            $valRule[$key . '_name'] = 'required|max:200|unique:category_translations,name|unique_space_check:category_translations,name';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_name.required'] = ' The name field is required in '. $value .' language.';
            $valMessage[$key . '_name.max'] = ' Sorry, you can\'t add the name more than the 200 characters in '. $value .' language.';
            $valMessage[$key . '_name.unique'] = ' Name must be unique in '. $value .' language.';
            $valMessage[$key . '_name.unique_space_check'] = ' Name must be unique in '. $value .' language.';
        }

        $valRule['en_name'] = 'required|string|regex:/^[\pL\pN\s\-\_]+$/u|max:200|unique:category_translations,name|unique_space_check:category_translations,name';

        $validatedData = $request->validate($valRule, $valMessage);

        try {
             $category_data = array();

            foreach ($locales as $key => $value) {
                $category_data[$key]['name'] = $request->input($key . '_name');
            }
            $category_data['status'] = $request->input('status');

            if ($request->hasFile('icon')) {

                $image = $request->file('icon');
                $is_dest = "uploads/categoryImages/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('icon');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $category_data['icon'] = $filenameOrig;
                }
            }

            Category::create($category_data);

            

            return redirect()->route('admin.categories.index')->with('success', 'Category has been saved Successfully');
        } catch (\Illuminate\Database\QueryException $e) {
           

            return back()->withError($e->getMessage())->withInput();
        }
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show(Category $category) {
        return view('categorymanager::Admin.category.show', compact('category'));
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id) {
        $category = Category::find($id);
        return view('categorymanager::Admin.categories.createOrUpdate', compact('category'));
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id) {
        $locales = config('app.locales');
         $valRule = [
            'icon' => 'sometimes|mimes:jpeg,jpg,png|max:5000'
        ];
        $valMessage = [
          'icon.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
          'icon.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
        ];
        foreach ($locales as $key => $value) {
            $valRule[$key . '_name'] = 'required|max:200|unique:category_translations,name,' . $request->segment(3).',category_id|unique_space_check:category_translations,name,'. $request->segment(3).',category_id';
        }

        $valRule['en_name'] = 'required|string|regex:/^[\pL\pN\s\-\_]+$/u|max:200|unique:category_translations,name,' . $request->segment(3).',category_id|unique_space_check:category_translations,name,'. $request->segment(3).',category_id';

        foreach ($locales as $key => $value) {
             $valMessage[$key . '_name.required'] = ' The name field is required in '. $value .' language.';
            $valMessage[$key . '_name.max'] = ' Sorry, you can\'t add the name more than the 200 characters in '. $value .' language.';
            $valMessage[$key . '_name.unique'] = ' Name must be unique in '. $value .' language.';
            $valMessage[$key . '_name.unique_space_check'] = ' Name must be unique in '. $value .' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);
         
        try {
           $category_data = array();

            foreach ($locales as $key => $value) {
                $category_data[$key]['name'] = $request->input($key . '_name');
            }
            $category_data['status'] = $request->input('status');

            if ($request->hasFile('icon')) {

                $image = $request->file('icon');
                $is_dest = "uploads/categoryImages/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('icon');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $category_data['icon'] = $filenameOrig;
                }
            }

            $Category = Category::find($id);

            $Category->update($category_data);

           
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.categories.index')->with('success', 'Category has been updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy() {
        
    }

}
