<?php

namespace Modules\CategoryManager\Entities;

use Illuminate\Database\Eloquent\Model;

class CategoryTranslation extends Model {

    public $timestamps = false;
    protected $fillable = ['name'];

    /**
     * Get the comments for the blog post.
     */
    public function category() {

        return $this->belongsTo(\Modules\CategoryManager\Entities\Category::class);
    }

}
