@extends('layouts.admin.app')
@section('title', !empty($category) ? 'Edit Category' : 'Add Category')

@push('styles')
    {!! Html::style('/css/migration/custom.css') !!}

@endpush

@section('content')
<div class="wojo-grid">
    <div class="wojo form segment">
      <div class="wojo secondary icon message"> 
        <div class="content">
          <div class="header"> <small>Edit Category</small> <span style="float: right;"><small><a href="{{ route('admin.categories.index') }}">Back</a></small></span></div>
          
        </div>
      </div>
      <div class="wojo secondary message">
            <ul class="wojo tabs fixed clearfix">
                <li><a data-tab="#en_tab">English</a></li>
                <li><a data-tab="#kh_tab">Khmer</a></li>

            </ul>

        
      
        @if(isset($category->id) && $category->id!='') 

            {{ Form::model($category, ['route' => ['admin.categories.update', $category->id], 'method' => 'patch','files' => true,'id'=>'wojo_form','name'=>'wojo_form']) }}
         
         @else

            {{ Form::open(['route' => 'admin.categories.store','files' => true,'id'=>'wojo_form','name'=>'wojo_form']) }}

            

         @endif
         
         @php
            $locales = config('app.locales');
         @endphp
         <div class="container">
            @include('layouts.flash.alert')
            @foreach($locales as $key=>$val)

                <div id="{{ $key.'_tab' }}" class="wojo tab item " style="{{ ($key=='en')?'display: block;':'' }}">
                    <div class="two fields">
                        <div class="field col-sm-12">
                            <label for="name">{{ __('Name') }} </label>
                            
                                
                                {{ Form::text($key.'_name',old($key.'_name', (isset($category))?$category->translate($key)['name']:"") , ['class' => '','placeholder' => 'Name']) }}

                                @if($errors->has($key.'_name'))

                                    <span class="help-block">{{ $errors->first($key.'_name') }}</span>

                                @endif
                             
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        
        
        
        <div class="container">
                        <div class="two fields">
                            <div class="field">
                                <label for="status">{{ __('Status') }} </label>

                                {{ Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => '']) }}
                            </div>
                        </div>

                        <div class="two fields">
                            <div class="field">
                                <label for="status">{{ __('Image') }} </label>
                                

                                @if($errors->has('icon'))
                                    <span class="help-block">{{ $errors->first('icon') }}</span>
                                @endif



                                @php

                                    if(isset($category->icon) &&  $category->icon!='') {

                                        $path=public_path('uploads/categoryImages/'.$category->icon);

                                    } else {

                                        $path='';
                                    }
                                @endphp
                                
                                @if(file_exists($path))

                                    {{ Form::hidden('old_img',$category->icon) }}

                                    <input type="file" name="image" data-type="image" data-exist="{{ URL::asset('/uploads/categoryImages/'.$category->icon) }}" accept="image/png, image/jpeg">

                                @else

                                    <input type="file" name="image" data-type="image" data-exist="{{ URL::asset('/images/migration/no-image.png') }}" accept="image/png, image/jpeg">

                                @endif

                            </div>
                        </div>
                        <div class="wojo fitted divider"></div>
                        <div class="wojo footer">
                            <button type="submit" data-action="updateAccount1" name="dosubmit1" class="wojo positive button">Submit</button>
                        </div>
                    </div>
     {{ Form::close() }}
  </div>
    </div>
  </div>


@stop