<?php

return [
    'name' => 'VehicleColorsManager'
];
