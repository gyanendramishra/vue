<?php

namespace Modules\VehicleColorsManager\Entities;

use Illuminate\Database\Eloquent\Model;

class VehicleColorsTranslation extends Model {

    protected $fillable = ["name"];
    public $timestamps = false;


}
