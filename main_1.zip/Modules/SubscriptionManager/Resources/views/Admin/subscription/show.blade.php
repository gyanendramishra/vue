@extends('layouts.admin.app')
@section('title','View Subscription Detail')
@section('content')
<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
    {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.subscription.index'],['label' => 'View Subscription Detail']]]) }}
    </div>
  </div>

<div class="wojo-grid">


    <div class="wojo form segment">

    

    <table class="wojo two column table">
          <thead>
             <tr class="viewheading">
              <td colspan="2"> <span><strong> {{ __('Manage Subscription')}} </strong></span></td>
              <td> <a style="float:right;" href="{{route('admin.subscription.index')}}" class="btn btn-primary"><span>Back</span></a></td>
            </tr>

          </thead>
      @php $locales = config('app.locales');@endphp
        @foreach($locales as $key=>$val)
            <table class="wojo two column table">
                <thead>
                    <tr>
                         <th  colspan="2">{{  $val }} </th>

                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td>{{ __('Title') }}</td>
                        <td>{{ $subscription->translate($key)['title'] }}</td>
                    </tr>

                    <tr>
                        <td>{{ __('Description') }}</td>
                        <td>{{ $subscription->translate($key)['description'] }}</td>
                    </tr>
                </tbody>
            </table>
        @endforeach
        <table class="wojo two column table">
          <thead>
            <tr>
              <td  colspan="2"> <strong> {{ __( 'General Details' ) }} </strong> </th>
             
            </tr>
          </thead>
          <tbody>
             
          <tr>
                        <td><strong>{{ __('Period') }}</strong></td>
                        <td>{{ $subscription->period.' '.$subscription->period_type }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Is private') }}</strong></td>
                        <td>{{ $subscription->is_private==1?'Yes':'No' }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Is featured') }}</strong></td>
                        <td>{{ $subscription->is_featured==1?'Yes':'No' }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Listings') }}</strong></td>
                        <td>{{ $subscription->listings }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Price') }}</strong></td>
                        <td>{{ $subscription->price }}</td>
                    </tr>

                    <tr>
                        <td><strong><?= __('Created') ?></strong></td>
                        <td>{{ $subscription->created_at->toFormattedDateString() }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Modified') }}</strong></td>
                        <td>{{ $subscription->updated_at->toFormattedDateString() }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Status') }}</strong></td>
                        <td>{{ $subscription->status ? __('Active') : __('Inactive')  }}</td>
                    </tr>
                    @if(!empty($subscription->image))
                    <tr>
                        <th>{{ __('Image') }}</th>
                        @php
                        $filepath = '/uploads/subscriptionImages/';
                        @endphp
                        @if(!empty($subscription->image) && file_exists(public_path() . $filepath . $subscription->image))
                        <?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url($filepath . $subscription->image), '500', '200', '100'); ?>
                        <td>
                            <img src="{{$imageurl}}">
                        </td>
                        @endif

                    </tr>
                    @endif
                   
            
          </tbody>
        </table>
       
      
      
    
    </div>
  </div>


@stop