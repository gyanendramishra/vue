@extends('layouts.admin.app')
@section('title', !empty($ads) ? 'Edit Subscription' : 'Add Subscription')
@section('content')

<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
    {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.subscription.index'],['label' => !empty($ads) ? 'Edit Subscription' : 'Add Subscription' ]]]) }}
    </div>
  </div>
   
  <div class="wojo-grid">

    
    @if(session()->has('success'))
        <div class="alert alert-success">
            {{ session()->get('success') }}
        </div>
    @endif

    <div class="wojo form segment">
      <div class="wojo secondary icon message"> 
        <div class="content">
          <div class="header">  {{ !empty($subscription) ? 'Edit Subscription' : 'Add Subscription' }} </div>
          <!-- <p>Here you can edit your vehicle make </p> -->
        </div>
      </div>

        @if(session()->has('success'))
            <div class="alert alert-success">
                {{ session()->get('success') }}
            </div>
        @endif

        @if(isset($subscription))
        
            {{ Form::model($subscription, ['route' => ['admin.subscription.update', $subscription->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}
        
        @else
            {{ Form::open(['route' => 'admin.subscription.store','enctype'=>'multipart/form-data']) }}
        
        @endif

        @php

            $locales = config('app.locales');

        @endphp
        
        @include('layouts.flash.alert')
        
        <div class="wojo secondary message">

            <ul class="wojo tabs fixed clearfix">
                @foreach($locales as $key=>$val)
                    <li class="{{ ($key=='en')?'active':'' }}">
                        <a data-tab="#{{ $key.'_tab' }}" class="{{ ($key=='en')?'active show':'' }}">
                            {{ $val }}
                        </a>
                    </li>
                @endforeach
            </ul>

            <div class="two fields">
                <div class="field required {{ $errors->has('user_type') ? 'has-error' : '' }}">
                    <label for="name">{{ __('User Type') }} </label>
                    
                    {{ Form::select('user_type', Config::get('constants.USERTYPE'), old('user_type'), ['class' => 'form-control', 'placeholder' => 'Select User Type']) }}

                    @if($errors->has('user_type'))
                        <span class="help-block">{{ $errors->first('user_type') }}</span>
                    @endif
                </div>
            </div>

                @foreach($locales as $key=>$val)
                    <div id="{{ $key.'_tab' }}" class="wojo tab item " style="{{ ($key=='en')?'display: block;':'' }}">
                        <div class="two fields">
                            <div class="field required {{ $errors->has($key.'_name') ? 'has-error' : '' }}">
                                    <label for="name">{{ __('Title') }} </label>

                                   {{ Form::text($key.'_title',old($key.'_title', (isset($subscription))?$subscription->translate($key)['title']:"") , ['class' => 'form-control','placeholder' => 'Title']) }}

                                     @if($errors->has($key.'_title'))
                                        <span class="help-block">{{ $errors->first($key.'_title') }}</span>
                                    @endif
                                
                            </div>
                        </div>
                        <div class="two fields required {{ $errors->has($key.'_name') ? 'has-error' : '' }}">
                            
                               
                                    <label for="name">{{ __('Description') }} </label>
                                    {{ Form::textarea($key.'_description',old($key.'_description', (isset($subscription))?$subscription->translate($key)['description']:"") , ['class' => 'form-control','id'=>'editor1_'.$key,'Description' => 'Description']) }}

                                    @if($errors->has($key.'_description'))
                                            <span class="help-block">{{ $errors->first($key.'_description') }}</span>
                                    @endif
                                
                            

                        </div>
                    </div>
                @endforeach
                
             <div class="two fields">

                <div class="field required {{ $errors->has('total_listing_count') ? 'has-error' : '' }}">
                    <label for="name">{{ __('Listing') }} <span class="asterisk">*</span> </label>
                    
                    {{ Form::number('total_listing_count', old('total_listing_count'), ['class' => 'form-control','placeholder' => 'Listing']) }}

                    @if($errors->has('total_listing_count'))
                        <span class="help-block">{{ $errors->first('total_listing_count') }}</span>
                    @endif
                </div>

                <div class="field required {{ $errors->has('user_type') ? 'has-error' : '' }}">
                    <label for="name">{{ __('Featured Listing') }} <span class="asterisk">*</span></label>
                    
                    {{ Form::number('total_featured_count', old('total_featured_count'), ['class' => 'form-control','placeholder' => 'Featured Listing']) }}

                    @if($errors->has('total_featured_count'))
                        <span class="help-block">{{ $errors->first('total_featured_count') }}</span>
                    @endif
                </div>
            </div>

            <div class="two fields">

                <div class="field required {{ $errors->has('total_on_sale_count') ? 'has-error' : '' }}">
                    <label for="name">{{ __('On Sale Listing') }} <span class="asterisk">*</span> </label>
                    
                    {{ Form::number('total_on_sale_count', old('total_on_sale_count'), ['class' => 'form-control','placeholder' => 'On Sale Listing']) }}

                    @if($errors->has('total_on_sale_count'))
                        <span class="help-block">{{ $errors->first('total_on_sale_count') }}</span>
                    @endif
                </div>

                <div class="field required {{ $errors->has('price') ? 'has-error' : '' }}">
                    <label for="name">{{ __('Featured Listing') }} <span class="asterisk">*</span></label>
                    
                    {{ Form::text('price',old('price') , ['class' => 'form-control','placeholder' => 'Price']) }}

                    @if($errors->has('price'))
                        <span class="help-block">{{ $errors->first('price') }}</span>
                    @endif
                </div>
            </div>
            
            <div class="two fields">

                <div class="field required {{ $errors->has('total_on_sale_count') ? 'has-error' : '' }}">
                    <label for="name">{{ __('Duration') }} <span class="asterisk">*</span> </label>
                    
                    {{ Form::number('duration', old('duration'), ['class' => 'form-control','placeholder' => 'Duration']) }}

                    @if($errors->has('duration'))
                        <span class="help-block">{{ $errors->first('duration') }}</span>
                    @endif
                </div>

                <div class="field required {{ $errors->has('duration_type') ? 'has-error' : '' }}">
                    <label for="name">{{ __('Duration Type') }} <span class="asterisk">*</span></label>
                    
                    {{ Form::select('duration_type',['Days'=>'Days', 'Months'=>'Months', 'Weeks'=>'Weeks', 'Years'=>'Years'], old('duration_type'), ['class' => 'form-control','placeholder' => 'Select Duration Type']) }}

                    @if($errors->has('price'))
                        <span class="help-block">{{ $errors->first('duration_type') }}</span>
                    @endif
                </div>
            </div>
            
            

            <div class="container">
                <div class="two fields">
                    <div class="field">
                        <div class="form-group required {{ $errors->has('image') ? 'has-error' : '' }}">
                            <label for="status">{{ __('Image') }} </label>
                            @php
                                $filepath = '/uploads/subscriptionImages/';
                            @endphp
                            
                            

                            @if(!empty($subscription->image) && file_exists(public_path() . $filepath . $subscription->image))

                                <?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url($filepath . $subscription->image), '500', '200', '100'); ?>

                            @else

                                <?php  $imageurl=''; ?>

                            @endif
                            
                            @if($imageurl !='')

                                <input type="file" name="image" data-type="image" data-exist="{{ URL::asset('/uploads/subscriptionImages/'.$subscription->image) }}" accept="image/png, image/jpeg">
                            @else
                            
                                <input type="file" name="icon" data-type="image" data-exist="{{ URL::asset('/images/migration/no-image.png') }}" accept="image/png, image/jpeg">
                            @endif

                            @if($errors->has('status'))
                                <span class="help-block">{{ $errors->first('status') }}</span>
                            @endif
                        </div>
                    </div>
                    <div class="field">
                        <div class="form-group required {{ $errors->has('status') ? 'has-error' : '' }}">
                            <label for="status">{{ __('Status') }} </label>
                            {{ Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => '']) }}

                            @if($errors->has('status'))
                                <span class="help-block">{{ $errors->first('status') }}</span>
                            @endif
                        </div>
                    </div>
                </div>



                

       
            </div>

            <div class="wojo fitted divider"></div>
            <div class="wojo footer">
              <button type="submit" data-action="updateAccount" name="dosubmit" class="wojo positive button">Update Account</button>
               <a href="{{ route('admin.subscription.index') }}" class="wojo negative button" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
            </div>
        </div>

        {{ Form::close() }}
      </div>
  </div>
  @stop
@section('per_page_style')
<!--<link href="{{ asset('plugins/select2-develop/dist/css/select2.min.css') }}" rel="stylesheet" />-->
<style>
    .ui-sortable-helper {
        display: table;
    }
</style>
@stop


@push('scripts')
<script src="{{asset('ckeditor/ckeditor.js')}}"></script>
<script>
$(function () {
    CKEDITOR.replace('editor1_en', {
        // Remove the redundant buttons from toolbar groups defined above.
        removeButtons: 'Font,Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Styles,Specialchar'
                // removeButtons: 'Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Specialchar'
    });

     CKEDITOR.replace('editor1_kh', {
        // Remove the redundant buttons from toolbar groups defined above.
        removeButtons: 'Font,Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Styles,Specialchar'
                // removeButtons: 'Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Specialchar'
    });


})
</script>
<style>
    .slidecontainer{display: inline-flex;    width: 100%;}
    .slider {
        -webkit-appearance: none;
        width: 100%;
        height: 15px;
        border-radius: 5px;
        background: #d3d3d3;
        outline: none;
        opacity: 0.7;
        -webkit-transition: .2s;
        transition: opacity .2s;
    }

    .slider::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 25px;
        height: 25px;
        border-radius: 50%;
        background: #4CAF50;
        cursor: pointer;
    }

    .slider::-moz-range-thumb {
        width: 25px;
        height: 25px;
        border-radius: 50%;
        background: #4CAF50;
        cursor: pointer;
    }
</style>
<script>
    var slider = document.getElementById("myRange");
    var output = document.getElementById("show_listing_no");
    output.innerHTML = slider.value; // Display the default slider value

    // Update the current slider value (each time you drag the slider handle)
    slider.oninput = function () {
        output.innerHTML = this.value;
    }

</script>
@endpush
