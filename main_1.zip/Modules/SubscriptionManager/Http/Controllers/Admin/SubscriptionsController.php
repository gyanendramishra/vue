<?php

namespace Modules\SubscriptionManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Input;
use Modules\SubscriptionManager\Entities\Subscription;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use File;

class SubscriptionsController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        $title = "Subscription";
        //return view('user::Admin.pages.index', ['title' => $title]);
        return view('subscriptionmanager::Admin.subscription.index', compact('title'));
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {

        $subscriptions = Subscription::get();

        if ($request->status != '') {
            $subscriptions = $subscriptions->where('status', $request->status);
        }

        return datatables()->of($subscriptions)
                        ->addColumn('action', function ($subscriptions) {
                            $actions = "";
                            $actions .= "<a href=\"" . route('admin.subscription.show', ['id' => $subscriptions->id]) . "\" class=\"\"><i class=\"rounded outline primary icon user profile link\"></i></a>";
                            $actions .= "&nbsp;<a href=\"" . route('admin.subscription.edit', ['id' => $subscriptions->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";

                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        $title = "Add Subscription";
        return view('subscriptionmanager::Admin.subscription.createOrUpdate', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request) {

        

        $locales = config('app.locales');
        $valRule = [
            'user_type' => 'required',
            'duration' => 'required|numeric',
            'duration_type' => 'required',
            'total_listing_count' => 'required|numeric',
            'price' => 'required|numeric',
            'image' => 'sometimes|mimes:jpeg,jpg,png|max:5000'
        ];
        $valMessage = [
            'user_type.required' => 'The user type field is required.',
            'duration.required' => 'The duration field is required.',
            'duration.numeric' => 'Please enter the number.',
            'duration_type.required' => 'The duration type field is required.',
            'total_listing_count.required' => 'The Listings field is required.',
            'total_listing_count.numeric' => 'Please enter the number.',
            'image.mimes' => 'Image must be in jpeg,jpg,png format.',
            'image.max' => 'Image must be less then 5 mb.',
        ];

        foreach ($locales as $key => $value) {
            $valRule[$key . '_title'] = 'required|max:200|unique:subscription_translations,title|unique_space_check:subscription_translations,title';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_title.required'] = ' The title field is required in ' . $value . ' language.';
            $valMessage[$key . '_title.max'] = ' Sorry, you can\'t add the title more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_title.unique'] = ' Title must be unique in ' . $value . ' language.';
            $valMessage[$key . '_title.unique_space_check'] = ' Title must be unique in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $subscription_data = array();

            foreach ($locales as $key => $value) {
                $subscription_data[$key]['title'] = $request->input($key . '_title');
                $subscription_data[$key]['description'] = $request->input($key . '_description');
            }
            $subscription_data['user_type'] = $request->input('user_type');
            $subscription_data['price'] = $request->input('price');
            $subscription_data['status'] = $request->input('status');
            $subscription_data['duration'] = $request->input('duration');
            $subscription_data['duration_type'] = $request->input('duration_type');
            $subscription_data['total_on_sale_count'] = $request->input('total_on_sale_count');
            $subscription_data['total_featured_count'] = $request->input('total_featured_count');
            $subscription_data['total_listing_count'] = $request->input('total_listing_count');



            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $is_dest = "uploads/subscriptionImages/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('image');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $subscription_data['image'] = $filenameOrig;
                }
            }



            $ad = Subscription::create($subscription_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.subscription.index')->with('success', 'Subscription has been saved Successfully');
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show($id) {
        $title = "Subscription Detail";
        $subscription = Subscription::findOrFail($id)->where('id', '=', $id)->first();
        return view('subscriptionmanager::Admin.subscription.show', compact('title', 'subscription'));
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id) {
        $title = "Add Subscription";
        $subscription = Subscription::where('id', '=', $id)->first();
        
        return view('subscriptionmanager::Admin.subscription.createOrUpdate', compact('title', 'subscription'));
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id) {
        
        $locales = config('app.locales');
        $valRule = [
            'user_type' => 'required',
            'duration' => 'required|numeric',
            'duration_type' => 'required',
            'total_listing_count' => 'required|numeric',
            'price' => 'required|numeric',
            'image' => 'sometimes|mimes:jpeg,jpg,png|max:5000'
        ];
        $valMessage = [
            'user_type.required' => 'The user type field is required.',
            'duration.required' => 'The duration field is required.',
            'duration.numeric' => 'Please enter the number.',
            'duration_type.required' => 'The duration type field is required.',
            'total_listing_count.required' => 'The Listings field is required.',
            'total_listing_count.numeric' => 'Please enter the number.',
            'image.mimes' => 'Image must be in jpeg,jpg,png format.',
            'image.max' => 'Image must be less then 5 mb.',
        ];

        foreach ($locales as $key => $value) {
            $valRule[$key . '_title'] = 'required|max:200|unique:subscription_translations,title,' . $request->segment(3) . ',subscription_id|unique_space_check:subscription_translations,title,' . $request->segment(3) . ',subscription_id';
        }
        foreach ($locales as $key => $value) {
            $valMessage[$key . '_title.required'] = ' The title field is required in ' . $value . ' language.';
            $valMessage[$key . '_title.max'] = ' Sorry, you can\'t add the title more than the 200 characters in ' . $value . ' language.';
            $valMessage[$key . '_title.unique'] = ' Title must be unique in ' . $value . ' language.';
            $valMessage[$key . '_title.unique_space_check'] = ' Title must be unique in ' . $value . ' language.';
        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $subscription_data = array();

            foreach ($locales as $key => $value) {
                $subscription_data[$key]['title'] = $request->input($key . '_title');
                $subscription_data[$key]['description'] = $request->input($key . '_description');
            }
            $subscription_data['user_type'] = $request->input('user_type');
            $subscription_data['price'] = $request->input('price');
            $subscription_data['status'] = $request->input('status');
            $subscription_data['duration'] = $request->input('duration');
            $subscription_data['duration_type'] = $request->input('duration_type');
            $subscription_data['total_on_sale_count'] = $request->input('total_on_sale_count');
            $subscription_data['total_featured_count'] = $request->input('total_featured_count');
            $subscription_data['total_listing_count'] = $request->input('total_listing_count');



            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $is_dest = "uploads/subscriptionImages/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('image');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $subscription_data['image'] = $filenameOrig;
                }
            }


            $Subscription = Subscription::find($id);

            $Subscription->update($subscription_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.subscription.index')->with('success', 'Subscription has been updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id) {
        Subscription::where('id', $id)->delete();
        return redirect()->route('admin.subscription.index')->with('success', 'Subscription deleted successfully.');
    }

}
