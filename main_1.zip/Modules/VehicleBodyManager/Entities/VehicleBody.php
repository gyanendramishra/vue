<?php

namespace Modules\VehicleBodyManager\Entities;

use Illuminate\Database\Eloquent\Model;
use \Dimsav\Translatable\Translatable;

class VehicleBody extends Model {

    public $translatedAttributes = ['name'];

    use Translatable;

    protected $fillable = ["status", 'icon'];

    /**
     * Get the comments for the blog post.
     */
    public function vehicles() {

        return $this->hasMany(\Modules\VehicleManager\Entities\Vehicle::class, 'drive_types_id', 'id');
    }

    /**
     * Get the comments for the blog post.
     */
}
