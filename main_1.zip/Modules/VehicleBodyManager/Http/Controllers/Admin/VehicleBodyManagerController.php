<?php

namespace Modules\VehicleBodyManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Input;
use Modules\VehicleBodyManager\Entities\VehicleBody;
use Modules\VehicleBodyManager\Http\Requests\VehicleBodyRequest;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use File;

class VehicleBodyManagerController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        $title = "Vehicle Body";
        return view('vehiclebodymanager::Admin.vehiclebodymanager.index', compact('title'));
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {

        $vehiclebody = VehicleBody::get();

        if ($request->status != '') {
            $vehiclebody = $vehiclebody->where('status', $request->status);
        }

        return datatables()->of($vehiclebody)
                        ->addColumn('action', function ($vehiclebody) {
                            $actions = "";
                            // $actions .= "<a href=\"" . route('admin.vehiclebodymanager.show', ['id' => $vehiclebody->id]) . "\" class=\"btn btn-xs btn-primary btn-flat info-btn\"><i class=\"glyphicon glyphicon-eye-open\"></i> View</a>";
                            $actions .= "<a href=\"" . route('admin.vehiclebodymanager.edit', ['id' => $vehiclebody->id]) . "\" class=\"btn btn-xs btn-primary btn-flat info-btn\"><i class=\"glyphicon glyphicon-edit\"></i> Edit</a>";
                            //$actions .= "<a onclick=\"return confirm('Are you sure want to delete this record?')\" href=\"" . route('admin.vehiclebodymanager.delete', ['id' => $vehiclebody->id]) . "\" class=\"btn btn-xs btn-danger btn-flat info-btn\"><i class=\"glyphicon glyphicon-remove\"></i> Delete</a>";
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        $title = 'Vehicle Body';
        return view('vehiclebodymanager::Admin.vehiclebodymanager.createOrUpdate', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request) {
        $locales = config('app.locales');
         $valRule = [
            'icon' => 'sometimes|mimes:jpeg,jpg,png|max:5000'
        ];
        $valMessage = [
          'icon.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
          'icon.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
        ];
        foreach ($locales as $key => $value) {
            $valRule[$key . '_name'] = 'required|max:200|unique:vehicle_body_translations,name|unique_space_check:vehicle_body_translations,name';
        }
        foreach ($locales as $key => $value) {
             $valMessage[$key . '_name.required'] = ' The name field is required in '. $value .' language.';
            $valMessage[$key . '_name.max'] = 'Sorry, you can\'t add the name more than the 200 characters in '. $value .' language.';
            $valMessage[$key . '_name.unique'] = ' Name must be unique in '. $value .' language.';
            $valMessage[$key . '_name.unique_space_check'] = ' Name must be unique in '. $value .' language.';


        }
        $validatedData = $request->validate($valRule, $valMessage);

        try {
            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['name'] = $request->input($key . '_name');
            }
            $article_data['status'] = $request->input('status');

            if ($request->hasFile('icon')) {

                $image = $request->file('icon');
                $is_dest = "uploads/body/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('icon');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $article_data['icon'] = $filenameOrig;
                }
            }

            VehicleBody::create($article_data);
          
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.vehiclebodymanager.index')->with('success', 'Vehicle Body has been saved Successfully');
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show(VehicleBody $vehiclebody) {
        $title = 'Vehicle Body';
        return view('vehiclebodymanager::Admin.vehiclebodymanager.show', compact('vehiclebody', 'title'));
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id) {
        $title = 'Vehicle Body';
        $vehiclebody = VehicleBody::find($id);
        return view('vehiclebodymanager::Admin.vehiclebodymanager.createOrUpdate', compact('vehiclebody', 'title'));
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id) {
     $locales = config('app.locales');
      $valRule = [
            'icon' => 'sometimes|mimes:jpeg,jpg,png|max:5000'
        ];
        $valMessage = [
             'icon.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
          'icon.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
        ];
        foreach ($locales as $key => $value) {
            $valRule[$key . '_name'] = 'required|max:200|unique:vehicle_body_translations,name,' . $request->segment(3).',vehicle_body_id|unique_space_check:vehicle_body_translations,name,'. $request->segment(3).',vehicle_body_id';
        }
        foreach ($locales as $key => $value) {
             $valMessage[$key . '_name.required'] = ' The name field is required in '. $value .' language.';
            $valMessage[$key . '_name.max'] = 'Sorry, you can\'t add the name more than the 200 characters in '. $value .' language.';
            $valMessage[$key . '_name.unique'] = ' Name must be unique in '. $value .' language.';
            $valMessage[$key . '_name.unique_space_check'] = ' Name must be unique in '. $value .' language.';
            
        }
        $validatedData = $request->validate($valRule, $valMessage);


        try {

            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['name'] = $request->input($key . '_name');
            }
            $article_data['status'] = $request->input('status');


            if ($request->hasFile('icon')) {
                $image = $request->file('icon');
                $is_dest = "uploads/body/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('icon');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $article_data['icon'] = $filenameOrig;
                }
            }
            $VehicleBody = VehicleBody::find($id);

            $VehicleBody->update($article_data);
           
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.vehiclebodymanager.index')->with('success', 'Vehicle Body has been updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id) {
        VehicleBody::where('id', $id)->delete();
        return redirect()->route('admin.vehiclebodymanager.index')->with('success', 'Vehicle Body deleted successfully.');
    }

}
