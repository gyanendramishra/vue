@extends('layouts.admin.app')
@section('title', !empty($ads) ? 'Edit News' : 'Add News')
@push('styles')
    {!! Html::style('/css/migration/custom.css') !!}

    
    <link href="{{ asset('/css/migration/jquery-ui.css') }}" rel="stylesheet" />
@endpush
@section('content')

<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
         {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.news.index'],['label' => !empty($ads) ? 'Edit News' : 'Add News' ]]]) }}
    </div>
  </div>
   
  <div class="wojo-grid">

    
    @if(session()->has('success'))
        <div class="alert alert-success">
            {{ session()->get('success') }}
        </div>
    @endif

    <div class="wojo form segment">
      <div class="wojo secondary icon message"> 
        <div class="content">
          <div class="header">  {{ !empty($news) ? 'Edit News' : 'Add News' }}  </div>
          <!-- <p>Here you can edit your vehicle make </p> -->
        </div>
      </div>

     

        @if(isset($news))
            {{ Form::model($news, ['route' => ['admin.news.update', $news->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}

        @else
            {{ Form::open(['route' => 'admin.news.store','enctype'=>'multipart/form-data']) }}
        @endif

        @php

            $locales = config('app.locales');

        @endphp
        
        @include('layouts.flash.alert')
        
        <div class="wojo secondary message">

            <ul class="wojo tabs fixed clearfix">
                @foreach($locales as $key=>$val)
                    <li class="{{ ($key=='en')?'active':'' }}">
                        <a data-tab="#{{ $key.'_tab' }}" class="{{ ($key=='en')?'active show':'' }}">
                            {{ $val }}
                        </a>
                    </li>
                @endforeach
            </ul>

             

                @foreach($locales as $key=>$val)
                    <div id="{{ $key.'_tab' }}" class="wojo tab item " style="{{ ($key=='en')?'display: block;':'' }}">
                        <div class="two fields">
                            <div class="field">

                                <div class="required {{ $errors->has($key.'_title') ? 'has-error' : '' }}">
                                   <label for="name">{{ __('Title') }} </label>

                                    {{ Form::text($key.'_title',old($key.'_title', (isset($news))?$news->translate($key)['title']:"") , ['class' => 'form-control','placeholder' => 'Title']) }}

                                    @if($errors->has($key.'_title'))
                                        <span class="help-block">{{ $errors->first($key.'_title') }}</span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        
                            <div class="field">

                                <div class="required {{ $errors->has($key.'_description') ? 'has-error' : '' }}">
                                   <label for="name">{{ __('Description') }} </label>

                                     {{ Form::textarea($key.'_description',old($key.'_description',(isset($news))?$news->translate($key)['description']:""), ['class' => 'form-control','placeholder' => 'Description' , 'id'=>'editor1_'.$key, 'rows' => 8]) }}

                                    @if($errors->has($key.'_description'))
                                        <span class="help-block">{{ $errors->first($key.'_description') }}</span>
                                    @endif
                                </div>
                            </div>

                        
                    </div>
                @endforeach

             

             
                <div class="two fields">
                   
                    <div class="field">
                        <div class="required {{ $errors->has('_description') ? 'has-error' : '' }}">
                            <label for="status">{{ __('News date') }} </label>
                            {{ Form::text('publish_date', old('publish_date'), ['class' => 'form-control datepicker','placeholder' => 'Publish date']) }}
                           @if($errors->has($key.'publish_date'))
                                <span class="help-block">{{ $errors->first('publish_date') }}</span>
                            @endif
                        </div>
                    </div>
                    
                </div>



                <div class="two fields">
                    <div class="field">
                        <div class="required {{ $errors->has('status') ? 'has-error' : '' }}">
                            <label for="status">{{ __('Status') }} </label>
                            {{ Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => '']) }}

                            @if($errors->has('status'))
                                <span class="help-block">{{ $errors->first('status') }}</span>
                            @endif
                        </div>
                    </div>
                    <div class="field">

                         <div class="form-group {{ $errors->has('image') ? 'has-error' : '' }}">
                            <label for="status">{{ __('Image') }} </label>
                            

                             @if($errors->has('image'))
                                <span class="help-block">{{ $errors->first('image') }}</span>
                            @endif
                        </div>
                        
                        @php
                            $filepath = '/uploads/newsImages/';
                        @endphp

                        @if(!empty($news->image) && file_exists(public_path() . $filepath . $news->image))

                            <?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url($filepath . $news->image), '500', '200', '100'); ?>

                        @else

                            <?php  $imageurl=''; ?>

                        @endif
                    

                        

                        @if($imageurl !='')

                           
                          <input type="file" name="image" data-type="image" data-exist="{{ URL::asset('/uploads/newsImages/'.$news->image) }}" accept="image/png, image/jpeg">
                          

                        @else

                            <input type="file" name="icon" data-type="image" data-exist="{{ URL::asset('/images/migration/no-image.png') }}" accept="image/png, image/jpeg">
                        @endif
                    </div>
                </div>

                <div class="wojo fitted divider"></div>
             

            <div class="wojo fitted divider"></div>
            <div class="wojo footer">
              <button type="submit" data-action="updateAccount" name="dosubmit" class="wojo positive button">Update Account</button>
               <a href="{{ route('admin.news.index') }}" class="wojo negative button" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
            </div>
        </div>

        {{ Form::close() }}
      </div>
  </div>
  @stop


@push('scripts')

  

  <script src="{{ asset('js/migration/jquery-ui.js') }}"></script>

<!--<script src="{{ asset('plugins/select2-develop/dist/js/select2.min.js') }}"></script>-->
<script src="{{asset('ckeditor/ckeditor.js')}}"></script>
<script>
$(function () {
    CKEDITOR.replace('editor1_en', {
        // Remove the redundant buttons from toolbar groups defined above.
        removeButtons: 'Font,Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Styles,Specialchar'
                // removeButtons: 'Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Specialchar'
    });

     CKEDITOR.replace('editor1_kh', {
        // Remove the redundant buttons from toolbar groups defined above.
        removeButtons: 'Font,Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Styles,Specialchar'
                // removeButtons: 'Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Specialchar'
    });


});
$( function() {
    
    $( ".datepicker" ).datepicker({
        format:'yyyy-mm-dd'
    });
  } );
</script>
@endpush
