@extends('layouts.admin.app')


@section('content')
<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> 'News','route'=> 'admin.news.index'],['label' => 'View News']]]) }}
    </div>
  </div>
<div class="wojo-grid">
    <div class="wojo form segment">
    <table class="wojo two column table">
          <thead>
             <tr class="viewheading">
              <td colspan="2"> <span><strong> {{ __('Manage News ')}} </strong></span></td>
              <td> <a style="float:right;" href="{{route('admin.news.index')}}" class="btn btn-primary"><span>Back</span></a></td>
            </tr>

          </thead>
      @php $locales = config('app.locales');@endphp
        @foreach($locales as $key=>$val)
            <table class="wojo two column table">
                <thead>
                    <tr>
                         <th  colspan="2">{{  $val }} </th>

                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td>{{ __('Title') }}</td>
                        <td>{{ $news->translate($key)['title'] }}</td>
                    </tr>

                    <tr>
                        <td>{{ __('Description') }}</td>
                        <td>{!! $news->translate($key)['description'] !!}</td>
                    </tr>
                </tbody>
            </table>
        @endforeach
        <table class="wojo two column table">
          <thead>
            <tr>
              <td  colspan="2"> <strong> {{ __( 'General Details' ) }} </strong> </th>
             
            </tr>
          </thead>
          <tbody>
             
               <tr>
                        <td>{{ __('Publish Date') }}</td>
                        <td>{{ date('M d, Y',strtotime($news->publish_date))}}</td>
                    </tr>

                    <tr>
                        <td><?= __('Created') ?></td>
                        <td>{{ $news->created_at->toFormattedDateString() }}</td>
                    </tr>
                    <tr>
                        <td>{{ __('Modified') }}</td>
                        <td>{{ $news->updated_at->toFormattedDateString() }}</td>
                    </tr>
                    <tr>
                        <td>{{ __('Status') }}</td>
                        <td>{{ $news->status ? __('Active') : __('Inactive')  }}</td>
                    </tr>
                    
                    <tr>
                        <td>{{ __('Image') }}</td>
                        @php
                            $filepath = '/uploads/newsImages/';
                        @endphp

                        @if(!empty($news->image) && file_exists(public_path() . $filepath . $news->image))
                            
                            <?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url($filepath . $news->image), '500', '200', '100'); ?>

                        @else
                            <?php $imageurl =''; ?>
                        @endif

                        <td>
                       

                        @if($imageurl!='')

                           
                        <img height="50" width="50" src="{{ $imageurl }}">

                        @else
                            <img src="{{ URL::asset('/images/migration/no-image.png') }}">
                        </td>
                        @endif

                    </tr>
                   
            
          </tbody>
        </table>
       
      
      
    
    </div>
  </div>


@stop