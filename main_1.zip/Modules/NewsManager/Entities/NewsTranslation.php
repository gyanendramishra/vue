<?php

namespace Modules\NewsManager\Entities;

use Illuminate\Database\Eloquent\Model;

class NewsTranslation extends Model {

    public $timestamps = false;
    protected $fillable = ["title","description"];

    /**
     * Get the comments for the blog post.
     */
}
