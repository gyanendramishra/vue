<?php

namespace Modules\EnquiresManager\Entities;

use Illuminate\Database\Eloquent\Model;


class Enquiry extends Model {

    protected $table = 'enquires';
    protected $primaryKey = 'id';
    public $timestamps = true;
    protected $fillable = ['name', 'user_id','email', 'subject', 'details', 'phone'];

}
