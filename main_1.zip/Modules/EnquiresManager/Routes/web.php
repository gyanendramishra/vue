<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('admin')->middleware('auth:admin')->namespace('Admin')->as('admin.')->group(function() {
   
	Route::get('enquires/ajax/list', 'EnquiresController@ajaxList')->name('enquires.ajax.list');
	Route::get('enquiry-responses/ajax/list/{id}', 'EnquiresController@ajaxResponseList')->name('enquiry-responses.ajax.list');
	Route::get('enquires/delete/{id}', 'EnquiresController@destroy')->name('enquires.delete');
	Route::get('enquires/view-response/{id}', 'EnquiresController@reponses')->name('enquires.view-response');
    Route::post('enquires/enquiry-response', 'EnquiresController@enquiryReply')->name('enquires.enquiry-response');
	Route::resources([
        'enquires' => 'EnquiresController',
    ]);
});

/* Route::prefix('enquires')->group(function() {
    Route::get('/', 'EnquiresController@index');
}); */
