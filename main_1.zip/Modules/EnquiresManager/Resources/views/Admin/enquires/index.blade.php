@extends('layouts.admin.app')
@push('styles')
{!! Html::style('/css/bootstrap.min.css') !!}
{!! Html::style('css/datatables.net-bs/dataTables.bootstrap.min.css') !!}
<style type="text/css">
    #enquires-datatable_length label {
        display: block!important ;
    }
    .dataTables_wrapper .dataTables_length {
        width: 50%;
    }
</style>
 @endpush

@section('content')

<div id="crumbs" class="clearfix"> 
   <!--  <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">

           {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> \Request::route()->getName()],['label' => 'List Contact Enquiries']]]) }}
    
    </div>
  </div>
  <div class="wojo-grid">
    
    <div class="wojo quaternary segment">
      
     
      <div class="footer">
        <div class="content-center">
          <div class="wojo basic pagination menu">
            <a class="item" href="#">A</a>
            <a class="item" href="#">B</a>
            <a class="item" href="#">C</a>
            <a class="item" href="#">D</a>
            <a class="item" href="#">E</a>
            <a class="item" href="#">F</a>
            <a class="item" href="#">G</a>
            <a class="item" href="#">H</a>
            <a class="item" href="#">I</a>
            <a class="item" href="#">J</a>
            <a class="item" href="#">K</a>
            <a class="item" href="#">L</a>
            <a class="item" href="#">M</a>
            <a class="item" href="#">N</a>
            <a class="item" href="#">O</a>
            <a class="item" href="#">P</a>
            <a class="item" href="#">Q</a>
            <a class="item" href="#">R</a>
            <a class="item" href="#">S</a>
            <a class="item" href="#">T</a>
            <a class="item" href="#">U</a>
            <a class="item" href="#">V</a>
            <a class="item" href="#">W</a>
            <a class="item" href="#">X</a>
            <a class="item" href="#">Y</a>
            <a class="item" href="#">Z</a>
            <a class="item active" href="#">All</a>
          </div>
        </div>
      </div>
    </div>

    @include('layouts.flash.alert')
   
    <div class="wojo tertiary segment">
      <div class="header clearfix"><span>{{ __('List Contact Enquiries') }}</span>
        
      </div>
        <table class="wojo sortable table"  id="enquires-datatable" data-table="enquires">
        <thead>
            <tr>
                <th>Id</th>
                <th>Email</th>                           
                <th>Type</th>
                <th>Subject</th>                             
                <th>Details</th>                             

                <th>Created At</th>
                <th class="no-sort">Action</th>
            </tr>
        </thead>
    </table>
      
    
    </div>
    <div id="msgholder"></div>
  </div>
@stop
@push('scripts')


<script type="text/javascript">
    jQuery(function ($) {
        var t = $('#enquires-datatable').DataTable({
            processing: true,
            serverSide: true,
            aaSorting: [[0, 'desc']],
            
            language: {

                 sLengthMenu: "_MENU_",
                search: "<i class='find icon'></i>",
                searchPlaceholder: "Search...",

            },
            ajax: {
                url: "{{ route('admin.enquires.ajax.list') }}",
                type: 'GET',
                data: function (d) {

                    d.status = $('#statuss').val();
                }
            },
            columns: [
                {data: 'id', name: 'id'},
                {data: 'email', name: 'email'},
                {data: 'type', name: 'type'},
                {data: 'subject', name: 'subject'},
                {data: 'message', name: 'message'},
                {data: 'created_at', name: 'created_at'},
                {data: 'action', name: 'action'}
            ],
            "deferRender": true,
            "columnDefs": [
                {
                    "targets": 'no-sort',
                    "orderable": false,
                },
                 {
        targets: 4,
        render: function ( data, type, row ) {
            return data.substr( 0, 50 );
        }
    } ,
                {
                    "targets": 5,
                    "data": "created_at",
                    "render": function (data, type, full, meta) {
                        return moment(data).format('DD MMMM, YYYY ');
                    }
                },
                
                       
            ],
            


        })
        t.on('order.dt search.dt', function () {
            t.column(0, {search: 'applied', order: 'applied'}).nodes().each(function (cell, i) {
                cell.innerHTML = i + 1;
            });
        });
        $('#statuss').on('change', function () {

            $('#enquires-datatable').DataTable().draw(true);
        });
    })
</script>
@endpush