@extends('backpack::layout')
@section('header')
<style>
    .nodesign{ border: none; background: transparent; border-radius: none;  width: 100%}
    #example1_filter{ text-align: right !important;margin-bottom: 8px; }
    #example1_paginate { float: right; }
    .show_msg{ left: 220px;
               position: absolute;
               top: 17px;
               z-index: 9999;}
    </style>
    <section class="content-header">
    <h1>
        View Enquiry Details
    </h1>

    <p class="show_msg"></p>
    @if(Session::has('success_message'))
    <p class="alert {{ Session::get('alert-class', 'alert-success') }}">{{ Session::get('success_message') }}</p>
    @endif
    @if(Session::has('error_message'))
    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error_message') }}</p>
    @endif 
    <ol class="breadcrumb">
        <li><a href="{{ url('user/dashboard') }}">{{ config('backpack.base.project_name') }}</a></li>
        <li class="active">{{ trans('backpack::base.dashboard') }} </li>
    </ol>
</section>

@endsection
@section('content')

<div class="row">

    <div class="col-md-12">
        <div class="box box-default">

            <div class="box-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-ms-12">
                            <div class="pull-right"><a href="{{ url('')}}/admin/lead" class="btn btn-primary btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back </a></div>
                            <div class="clearfix"></div><br/>
                <table class="table table-bordered table-striped display dataTable no-footer" role="grid" aria-describedby="crudTable_info">
                                <tbody>
                                    
                                    <tr><th>Serial No</th>
                                        <td >{{ $LeadAnswer->serial_no }}</td>
                                    </tr>
                                    <tr><th>Buyer Name</th>
                                        <td >{{ $LeadAnswer->name }}</td>
                                    </tr>
                                      <tr><th>Buyer Email</th>
                                      <td >{{ $LeadAnswer->email }}</td></tr>
                                      <tr><th> Buyer Phone</th>
                                      <td >{{ $LeadAnswer->code }}  {{ $LeadAnswer->phone }}</td></tr>
                                      <tr><th>Company Name</th>
                                        <td >{{ $LeadAnswer->company_name }}</td></tr>
                                        <tr><th>Category</th>
                                        <td >{{ $LeadAnswer->category->name }}</td></tr>
                                        <tr><th>Details</th>
                                        <td >{{ $LeadAnswer->details }}</td></tr>
                                        <tr><th>Product</th>
                                        <td >{{ $LeadAnswer->product->name }}</td></tr>
                                        <tr><th>Quantity</th>
                                        <td >{{ $LeadAnswer->quantity }}</td></tr>
                                        <tr><th>Price Range</th>
                                        <td >${{ $LeadAnswer->price_range }}</td></tr>
                                        <tr><th>Currency</th>
                                        <td >{{ $LeadAnswer->currency }}</td></tr>
                                        <tr><th>Is Answered</th>
                                        <td >{{ (isset($LeadAnswer->is_answered) && $LeadAnswer->is_answered == '1') ? 'Yes' : 'No' }}</td></tr>
                                        <tr><th>Is Sample Sent</th>
                                        <td >{{ (isset($LeadAnswer->is_sample_sent) && $LeadAnswer->is_sample_sent == '1') ? 'Yes' : 'No' }}</td></tr>
                                        
                                        <tr><th>Status</th>
                                        <td>@if($LeadAnswer->status==5) Convert to order
                                         @elseif($LeadAnswer->status==4) Rejected
                                         @elseif($LeadAnswer->status==3) Close
                                         @elseif($LeadAnswer->status==2) Response
                                         @elseif($LeadAnswer->status==1) In Progress
                                        @else  New  @endif</td></tr>

                                    <tr>
                                     <th colspan="2"><h4> All Enquiry Reply </h4></th>
                                    </tr>
                                    @php $leadanswers= $LeadAnswer->lead_answer()->get(); @endphp
                                    @if(!empty($leadanswers))
                                    @foreach($leadanswers as $k=>$leads)
                                    <tr>
                                     <th>{{$k+1 }}. {{ $leads->answer }} </th>
                                     <td> {{ $leads->created_at->format('d-m-Y') }} </td>
                                    </tr>
                                    @endforeach
                                    @endif
                                </tbody>
                            </table> 
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
    @endsection
   
   





