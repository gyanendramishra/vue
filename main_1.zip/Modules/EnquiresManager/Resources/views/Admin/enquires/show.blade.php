@extends('layouts.admin.app')


@section('content')

<div class="wojo-grid">
    <div class="wojo form segment">
      
      <div id="cms" class="wojo tab item">
          @include('layouts.flash.alert')
        <table class="wojo two column table">

        <thead>
            <tr class="viewheading">
              <td  colspan="2"> <span><strong> {{ __( 'Enquiry Details' ) }} </strong></span> </th>
              <td> <a href="{{route('admin.enquires.index')}}" class="btn btn-primary"><span>Back</span></a></td>
            </tr>
          </thead>
         
          <tbody>
        
            <tr>
                <td>{{ __('Email') }}</td>
                <td>{{ $inquiry->email}}</td>
            </tr>
            <tr>
                <td>{{ __('Type') }}</td>
                <td>{{ \Config('constants.INQUERY_FOR.'.$inquiry->type) }}</td>
            </tr>
             <tr>
                <td>{{ __('Subject') }}</td>
                <td>{{ $inquiry->subject}}</td>
            </tr>
              <tr>
                <td>{{ __('Message') }}</td>
                <td>{{ $inquiry->message}}</td>
            </tr>
            <tr>
                <td><?= __('Created') ?></td>
                <td>{{ $inquiry->created_at }}</td>
            </tr>
            
          </tbody>
        </table>
      </div>
      
      
    
    </div>
  </div>


@stop