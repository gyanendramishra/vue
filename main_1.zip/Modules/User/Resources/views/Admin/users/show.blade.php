@extends('layouts.admin.app')


@section('content')

<div class="wojo-grid">
    <div class="wojo form segment">
      
       
        <table class="wojo two column table">
          <thead>
            <tr class="viewheading">
              <td  colspan="2"> <span><strong> {{ __( 'Users Manager' ) }} </strong></span> </th>
              <td> <a href="{{route('admin.users.index', ['roleSlug' => $role->slug ])}}" class="btn btn-primary"><span>Back</span></a></td>
            </tr>
          </thead>
          <tbody>
             
             <tr>
                 <td>Full Name:</strong></td>
                 <td>{{ $row->name }}</td>
             </tr>
            <tr>
                 <td>Email:</td>
                 <td>{{ $row->email  }}</td>
             </tr>
             <tr>
                 <td>Contact No.::</td>
                 <td>{{ $row->phone  }}</td>
             </tr>
             <tr>
                 <td>Role:</td>
                 <td>{{ $role->name  }}</td>
             </tr>
             <tr>
                 <td>Status:</td>
                 <td>{!! ($row->status == 1)?'<span class="label label-xs label-success"> Active </span>':'<span class="label label-danger"> In Active </span>' !!}</td>
             </tr>

            <tr>
              <td>Varify Status:</td>
              <td> {!! ($row->is_email_verified == 1)?'<span class="label label-xs label-success"> Active </span>':'<span class="label label-danger"> In Active </span>' !!}</td>
            </tr>
             <tr>
              <td>Created At:</td>
              <td>  {{ $row->created_at }}</td>
            </tr>
            
          </tbody>
        </table>
       
      
      
    
    </div>
  </div>


@stop