@extends('user::layouts.master')

@section('content')
<style>
    .box{border-top: 0px !important;}
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Role Manager
            <small>Edit Role</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="{{route('roles')}}">Roles</a></li>
            <li><a href="#">Edit</a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">

        <!-- Default box -->
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Edit Role  </h3>

                <div class="box-tools pull-right">
                    <a href="{{route('roles')}}" class="btn btn-primary">Back</a>

                </div>
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="box box-primary">

                            <!-- /.box-header -->
                            <!-- form start -->
                            {!! Form::open(array('route' => array('user.role.update', $role->id), 'id' => 'form-edit-role')) !!}


                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Name</label><span class="astrict">*</span>
                                            <input type="text" name="name" class="form-control" id="role_name" placeholder="Enter Name" value="{{$role->name}}">
                                            @if($errors->has('name'))
                                            {{$errors->first('name')}}
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Status</label><span class="astrict">*</span>
                                            <select name="status" class="form-control">
                                                <option value="">Select</option>
                                                <option value="1" {{ ($role->status==1)?'selected':''}}>Active</option>
                                                <option value="0" {{ ($role->status==0)?'selected':''}}>InActive</option>
                                            </select>
                                            @if($errors->has('status'))
                                            {{$errors->first('status')}}
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12 permissions-col chk">
                                        <input type="checkbox" id="is_menu" name="is_menu" {{($role->is_menu==1)?'checked':''}}> 
                                        <label for="is_menu">Show On Sidebar  </label>  
                                    </div>
                                </div>
                            </div>
                            <!-- /.box-body -->

                            <div class="box-footer">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                            {{ Form::close() }}
                        </div>


                    </div>
                </div>

            </div>
            <!-- /.box-body -->

            <!-- /.box-footer-->
        </div>
        <!-- /.box -->

    </section>
    <!-- /.content -->
</div>
@stop
@push('scripts')
<script type="text/javascript">
    jQuery(function ($) {
        $('#form-edit-role').validate({
            rules: {
                name: {
                    required: true,
                    maxlength: 100
                },
                status: 'required',
            },
            errorElement: 'div',
            errorClass: 'help-block',
            highlight: function (element, errorClass, validClass) {
                $(element).parents("div.form-group").addClass('has-error');
            },
            unhighlight: function (element, errorClass, validClass) {
                $(element).parents(".has-error").removeClass('has-error');
            }
        })
    });
</script>
@endpush