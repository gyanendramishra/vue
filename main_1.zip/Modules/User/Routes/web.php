<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */


Route::prefix('admin')->middleware('auth:admin')->namespace('Admin')->as('admin.')->group(function() {

  //Route::resources(['users' => 'UsersController',]);
  Route::get('users/{roleSlug}', 'UsersController@index')->where(['roleSlug' => '[a-z0-9\\-]+'])->name('users.index');
  Route::get('/users/{roleSlug}/ajax/list', 'UsersController@ajaxList')->name('users.ajax.list');

  Route::get('users/{roleSlug}/add', 'UsersController@create')->name('users.create');
  Route::post('users/add', 'UsersController@store')->name('users.store');
  Route::get('users/{roleSlug}/edit/{id}', 'UsersController@edit')->where(['id' => '[0-9]+'])->name('users.edit');

  Route::PUT('users/edit/{id}', 'UsersController@update')->where(['id' => '[0-9]+'])->name('users.update');
  Route::get('users/{roleSlug}/view/{id}', 'UsersController@show')->where(['id' => '[0-9]+'])->name('users.show');

});

/*
Route::group(['prefix' => 'user', 'middleware' => 'auth'], function() {

    Route::get('/', 'UserController@index')->name('users');
    Route::get('/role/{roleSlug}', 'UserController@index')->where(['roleSlug' => '[a-z0-9\\-]+'])->name('users');
    Route::get('/role/{roleSlug}/ajax/list', 'UserController@ajaxList')->name('user.ajax.list');
    Route::get('/add', 'UserController@create')->name('user.add');
    Route::post('/add', 'UserController@store');
    Route::get('/edit/{id}', 'UserController@edit')->where(['id' => '[0-9]+'])->name('user.edit');

    Route::post('/edit/{id}', 'UserController@update')->where(['id' => '[0-9]+']);
    Route::get('/view/{id}', 'UserController@show')->where(['id' => '[0-9]+'])->name('user.view');

});

*/
Route::group(['middleware' => ['auth']], function() {
    Route::get('/roles', 'RolesController@index')->name('roles');
    Route::get('roles/ajax/list', 'RolesController@ajaxList')->name('roles.ajax.list');
    Route::get('/add-role', 'RolesController@create')->name('roles.add');
    Route::get('roles/edit/{id}', 'RolesController@edit')->name('user.roles.edit');
    Route::get('roles/delete/{id}', 'RolesController@destroy')->name('user.roles.delete');
    Route::post('/store-role', 'RolesController@store')->name('user.role.store');
    Route::post('/update/{id?}', 'RolesController@update')->name('user.role.update');
});

