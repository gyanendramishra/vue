<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('admin')->middleware('auth:admin')->namespace('Admin')->as('admin.')->group(function() {
   
	Route::get('vehiclecylindersmanager/ajax/list', 'VehicleCylindersManagerController@ajaxList')->name('vehiclecylindersmanager.ajax.list');
	Route::get('vehiclecylindersmanager/delete/{id}', 'VehicleCylindersManagerController@destroy')->name('vehiclecylindersmanager.delete');
	Route::resources([
        'vehiclecylindersmanager' => 'VehicleCylindersManagerController',
    ]);
          Route::post('importcylender', 'VehicleCylindersManagerController@importData')->name('cylender.import.file');
});
