@extends('layouts.admin.app')
@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            {{ __( 'Manage Vehicle Cylinders' ) }}           
        </h1>

      {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> \Request::route()->getName()],['label' => 'List Vehicle Cylinders']]]) }}
    </section>

    <!-- Main content -->
    <section class="content">

        @include('layouts.flash.alert')

        <div class="box">

            <div class="box-header with-border">
                <h3 class="box-title">{{ __('List Vehicle Cylinders') }}</h3>
                <div class="box-tools pull-right">
                    <a href="{{route('admin.vehiclecylindersmanager.create')}}" class="btn btn-primary">Add New Vehicle Cylinders</a>
                </div>
               
                <div class="row">

                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Status</label>
                            <select name="status" class="form-control" id="statuss">
                                <option value="">Select</option>
                                <option value="1">Active</option>
                                <option value="0">InActive</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-body">
				<div class="custom-table-responsive">
                <table class="table table-bordered" id="vehiclecylindersmanager-datatable" data-table="vehicle_cylinders">
                    <thead>
                        <tr>
							 <th>Id</th>
							 <th>Name</th>							 
							 <th>Status</th>
							 <th>Created At</th>
							 <th class="no-sort">Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
			</div>
        </div>
    </section>
</div>
@stop

@push('scripts')
{!! Html::script('/plugins/jquery-confirm/dist/jquery-confirm.min.js') !!}
{!! Html::script('/plugins/gritter/js/jquery.gritter.js') !!}
{!! Html::script('/plugins/bootstrap-switch-master/dist/js/bootstrap-switch.js') !!}

<script type="text/javascript">
    jQuery(function ($) {
        var t = $('#vehiclecylindersmanager-datatable').DataTable({
            processing: true,
            serverSide: true,
            aaSorting: [[0, 'desc']],
            ajax: {
                url: "{{ route('admin.vehiclecylindersmanager.ajax.list') }}",
                type: 'GET',
                data: function (d) {

                    d.status = $('#statuss').val();
                }
            },
            columns: [
                {data: 'id', name: 'id'},
                {data: 'name', name: 'name'},               
                {data: 'status', name: 'status'},
                {data: 'created_at', name: 'created_at'},
                {data: 'action', name: 'action'}
            ],
            "deferRender": true,
            "columnDefs": [
                {
                    "targets": 'no-sort',
                    "orderable": false,
                },
                {
                    "targets": 3,
                    "data": "created_at",
                    "render": function (data, type, full, meta) {
                        return moment(data).format('DD MMMM, YYYY ');
                    }
                },
                {

                    "targets": 2,
                    "data": "status",
                    "render": function (data, type, full, meta) {
                         return '<input id="status" class="switch-status change-request" data-id="'+full.id+'" data-field="status" data-size="mini" '+ ((data == true)?'checked':'') +' name="status" type="checkbox">';
                    }
                }
            ],
            "fnDrawCallback": function(settings) {

              $('input.switch-status').not('[data-switch-no-init]')     .bootstrapSwitch();
                $('[data-toggle="tooltip"]').tooltip();

                $('.switch-status.change-request').on('switchChange.bootstrapSwitch', function (e, state) {
                    var _this = $(this);
                    var _id = _this.data("id")
                    var table = _this.closest("table").data("table");
                    if (e.target.checked == true) {
                        var changedval = 1;
                    } else {
                        var changedval = 0;
                    }
                    changeStatus(table , _id,  changedval, _this);
                });
            }


        })
        t.on('order.dt search.dt', function () {
            t.column(0, {search: 'applied', order: 'applied'}).nodes().each(function (cell, i) {
                cell.innerHTML = i + 1;
            });
        });
        $('#statuss').on('change', function () {

            $('#vehiclecylindersmanager-datatable').DataTable().draw(true);
        });
    })
</script>
@endpush