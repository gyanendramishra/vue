@extends('layouts.admin.master')
@section('content')
@include('layouts.admin.flash.alert')
<section class="content-header">
    <h1>
        Manage Vehicle Cylinders
        
    </h1>
    {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.vehiclecylindersmanager.index'],['label' => 'View Vehicle Cylinders Detail']]]) }}
</section>

<section class="content" data-table="emailHooks">
    @include('layouts.flash.alert')
    <div class="box">
        <div class="box-header"><h3 class="box-title">{{ $vehiclecylinders->name }}</h3>
            <a href="{{route('admin.vehiclecylindersmanager.index')}}" class="btn btn-default pull-right" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
        </div>
        <div class="box-body">
            <table class="table table-hover table-striped">
                <tr>
                    <th scope="row">{{ __('Name') }}</th>
                    <td>{{ $vehiclecylinders->name }}</td>
                </tr>
                <tr>
                    <th scope="row"><?= __('Created') ?></th>
                    <td>{{ $vehiclecylinders->created_at->toFormattedDateString() }}</td>
                </tr>
                <tr>
                    <th scope="row">{{ __('Modified') }}</th>
                    <td>{{ $vehiclecylinders->updated_at->toFormattedDateString() }}</td>
                </tr>
                <tr>
                    <th scope="row">{{ __('Status') }}</th>
                    <td>{{ $vehiclecylinders->status ? __('Active') : __('Inactive')  }}</td>
                </tr>
            </table>           
        </div>
        <div class="box-footer">
                <a href="{{route('admin.vehiclecylindersmanager.index')}}" class="btn btn-default pull-left" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
        </div>
    </div>
</section>

@endsection
