<?php

namespace Modules\VehicleBadgeManager\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Badge;

class VehicleBadgeManagerDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Badge::unguard();

        // $this->call("OthersTableSeeder");
    }
}
