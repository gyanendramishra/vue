<?php

namespace Modules\VehicleBadgeManager\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Input;
use Modules\VehicleMakeManager\Entities\VehicleMake;
use Modules\VehicleMakeManager\Entities\VehicleMakeTranslation;
use Modules\VehicleModelManager\Entities\VehicleModel;
use Modules\VehicleModelManager\Entities\VehicleModelTranslation;
use Modules\VehicleBadgeManager\Entities\VehicleBadge;
use Modules\VehicleBadgeManager\Http\Requests\VehicleBadgeRequest;
use Yajra\DataTables\Utilities\Request as DatatableRequest;
use File;
use App\Imports\BadgeImport;
use Maatwebsite\Excel\Facades\Excel;

class VehicleBadgeManagerController extends Controller {

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index() {
        $title = "Vehicle Badge";
        return view('vehiclebadgemanager::Admin.vehiclebadgemanager.index', compact('title'));
    }

    /**
     * Feeding list of users to datatable.
     * @return Response
     */
    public function ajaxList(DatatableRequest $request) {

        $vehiclebadge = VehicleBadge::with('make', 'model')->get();

        if ($request->status != '') {
            $vehiclebadge = $vehiclebadge->where('status', $request->status);
        }

        return datatables()->of($vehiclebadge)
                        ->addColumn('action', function ($vehiclebadge) {
                            $actions = "";
// $actions .= "<a href=\"" . route('admin.vehiclebadgemanager.show', ['id' => $vehiclebadge->id]) . "\" class=\"btn btn-xs btn-primary btn-flat info-btn\"><i class=\"glyphicon glyphicon-eye-open\"></i> View</a>";
                            $actions .= "<a href=\"" . route('admin.vehiclebadgemanager.edit', ['id' => $vehiclebadge->id]) . "\" class=\"\"><i class=\"rounded outline positive icon pencil link\"></i></a>";
//$actions .= "<a onclick=\"return confirm('Are you sure want to delete this record?')\" href=\"" . route('admin.vehiclebadgemanager.delete', ['id' => $vehiclebadge->id]) . "\" class=\"btn btn-xs btn-danger btn-flat info-btn\"><i class=\"glyphicon glyphicon-remove\"></i> Delete</a>";
                            return $actions;
                        })
                        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create() {
        $title = "Vehicle Badge";
        $make = VehicleMakeTranslation::whereHas('VehicleMake', function($q) {
                    return $q->where('status', 1);
                })->orderBy('name', 'DESC')->pluck('name', 'vehicle_make_id')->unique();
        $model = VehicleModelTranslation::whereHas('VehicleModel', function($q) {
                    return $q->where('status', 1);
                })->orderBy('name', 'DESC')->pluck('name', 'vehicle_model_id')->unique();
      //  $model = VehicleModel::orderBy('name', 'ASC')->where(['status' => 1])->pluck('name', 'id')->toArray();
        return view('vehiclebadgemanager::Admin.vehiclebadgemanager.createOrUpdate', compact('title', 'make', 'model'));
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request) {

        $locales = config('app.locales');
        $valRule = [
            'makes_id' => 'required',
            'models_id' => 'required',
            'icon' => 'sometimes|mimes:jpeg,jpg,png|max:5000'
        ];
        $valMessage = [
            'makes_id.required' => ' The makes field is required.',
            'models_id.required' => ' The modal field is required.',
            'icon.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
          'icon.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
        ];
        foreach ($locales as $key => $value) {
            $valRule[$key . '_name'] = 'required|max:200|unique:vehicle_badge_translations,name|unique_space_check:vehicle_badge_translations,name';
        }

        $valRule['en_name'] = 'required|string|regex:/^[\pL\pN\s\-\_]+$/u|max:200|unique:vehicle_badge_translations,name|unique_space_check:vehicle_badge_translations,name';

        foreach ($locales as $key => $value) {
            $valMessage[$key . '_name.required'] = ' The name field is required in '. $value .' language.';
            $valMessage[$key . '_name.max'] = ' Sorry, you can\'t add the name more than the 200 characters in '. $value .' language.';
            $valMessage[$key . '_name.unique'] = ' Name must be unique in '. $value .' language.';
            $valMessage[$key . '_name.unique_space_check'] = ' Name must be unique in '. $value .' language.';
            
        }

        $validatedData = $request->validate($valRule, $valMessage);
        try {
            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['name'] = $request->input($key . '_name');
            }
            $article_data['status'] = $request->input('status');
            $article_data['makes_id'] = $request->input('makes_id');
            $article_data['models_id'] = $request->input('models_id');



            if ($request->hasFile('icon')) {
                $image = $request->file('icon');
                $is_dest = "uploads/badge/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('icon');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $article_data['icon'] = $filenameOrig;
                }
                
            }
            VehicleBadge::create($article_data);
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->getMessage());
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.vehiclebadgemanager.index')->with('success', 'Vehicle Badge has been saved Successfully');
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show(VehicleBadge $vehiclebadge) {
        $title = "Vehicle Badge";
        return view('vehiclebadgemanager::Admin.vehiclebadgemanager.show', compact('vehiclebadge', 'title'));
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id) {
        $title = "Vehicle Badge";
        $vehiclebadge = VehicleBadge::find($id);
       $make = VehicleMakeTranslation::whereHas('VehicleMake', function($q) {
                    return $q->where('status', 1);
                })->orderBy('name', 'DESC')->pluck('name', 'vehicle_make_id')->unique();
        $model = VehicleModelTranslation::whereHas('VehicleModel', function($q) {
                    return $q->where('status', 1);
                })->orderBy('name', 'DESC')->pluck('name', 'vehicle_model_id')->unique();
        return view('vehiclebadgemanager::Admin.vehiclebadgemanager.createOrUpdate', compact('vehiclebadge', 'title', 'make', 'model'));
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request, $id) {
       
            $locales = config('app.locales');
        $valRule = [
            'makes_id' => 'required|min:1|max:200',
            'models_id' => 'required|min:1|max:200',
            'icon' => 'sometimes|mimes:jpeg,jpg,png|max:5000'
        ];
        $valMessage = [
            'makes_id.required' => ' The makes field is required.',
            'models_id.required' => ' The modal field is required.',
            'icon.mimes' => 'Sorry, you can\'t upload this image. Please use only JPG, JPEG, PNG image fromat.',
            'icon.max' => 'Sorry, you can\'t upload this image. Please use the image with the max limit of 5MB.',
        ];
        foreach ($locales as $key => $value) {
            $valRule[$key . '_name'] = 'required|max:200|unique:vehicle_badge_translations,name,' . $request->segment(3).',vehicle_badge_id|unique_space_check:vehicle_badge_translations,name,'. $request->segment(3).',vehicle_badge_id';
        }

        $valRule['en_name'] = 'required|string|regex:/^[\pL\pN\s\-\_]+$/u|max:200|unique:vehicle_badge_translations,name,' . $request->segment(3).',vehicle_badge_id|unique_space_check:vehicle_badge_translations,name,'. $request->segment(3).',vehicle_badge_id';

        foreach ($locales as $key => $value) {
            $valMessage[$key . '_name.required'] = ' The name field is required in '. $value .' language.';
            $valMessage[$key . '_name.max'] = ' Sorry, you can\'t add the name more than the 200 characters in '. $value .' language.';
            $valMessage[$key . '_name.unique'] = ' Name must be unique in '. $value .' language.';
            $valMessage[$key . '_name.unique_space_check'] = ' Name must be unique in '. $value .' language.';

        }

        $validatedData = $request->validate($valRule, $valMessage);
        try {
            $article_data = array();

            foreach ($locales as $key => $value) {
                $article_data[$key]['name'] = $request->input($key . '_name');
            }
            $article_data['status'] = $request->input('status');
            $article_data['makes_id'] = $request->input('makes_id');
            $article_data['models_id'] = $request->input('models_id');

             if ($request->hasFile('icon')) {
                $image = $request->file('icon');
                $is_dest = "uploads/badge/";
                if (!file_exists($is_dest)) {
                    mkdir($is_dest, 0777, true);
                }
                $directory = public_path($is_dest);
                $directory = str_replace("\\", "/", $directory);
                $file = Input::file('icon');
                $extension = pathinfo($file->getClientOriginalName(), PATHINFO_EXTENSION);
                $filenameOrig = time() . "-" . rand() . "." . $extension;

                if ($image->move($directory, $filenameOrig)) {
                    $article_data['icon'] = $filenameOrig;
                }
            }
            $vehiclebadge = VehicleBadge::find($id);
           

           

            $vehiclebadge->update($article_data);
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('admin.vehiclebadgemanager.index')->with('success', 'Vehicle Badge has been updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id) {
        VehicleBadge::where('id', $id)->delete();
        return redirect()->route('admin.vehiclebadgemanager.index')->with('success', 'Vehicle Badge deleted successfully.');
    }

    public function importData(Request $request) {

        if ($request->hasFile('badge_file')) {

            Excel::import(new BadgeImport, $request->file('badge_file'));

            return back();
        }

        return redirect()->back();
    }

}
