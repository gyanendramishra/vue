<?php

namespace Modules\VehicleBadgeManager\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use \Illuminate\Http\Request;

class VehicleBadgeRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(Request $request)
    {
        return [
            'makes_id' => 'required',          
            'models_id' => 'required',          
            'name' => 'required|min:1|max:200|unique:vehicle_badges,name,' . $this->segment(3),          
        ];
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'makes_id.required'  => 'Please select Make!',
            'models_id.required'  => 'Please select Model!',
            'name.required'  => 'Please enter name!',
            'name.min'  => 'Name must be at least 1 characters long!'            
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
}
