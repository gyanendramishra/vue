@extends('layouts.admin.app')
@section('title','View CMS Page Detail')
@section('content')
<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
     
       {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.pages.index'],['label' => 'View CMS Page']]]) }}
    </div>
  </div>
<div class="wojo-grid">
    <div class="wojo form segment">
    <table class="wojo two column table">
          <thead>
             <tr class="viewheading">
              <td colspan="2"> <span><strong> {{ __('Manage CMS Pages ')}} </strong></span></td>
              <td> <a style="float:right;" href="{{route('admin.pages.index')}}" class="btn btn-primary"><span>Back</span></a></td>
            </tr>

          </thead>
      
      @php

        $locales = config('app.locales');
      @endphp
         @foreach($locales as $key=>$val)
         <table class="wojo two column table">
          <thead>
            <tr>
              <th colspan="2"> {{  $val }}  </th>
             
            </tr>
          </thead>
          <tbody>
             
            <tr>
                <td><strong>{{ __('Title') }}</strong></td>
                <td>{{ $page->translate($key)['title'] }}</td>
            </tr>

            <tr>
                <td><strong>{{ __('Description') }}</strong></td>
                <td>{!! $page->translate($key)['description'] !!}</td>
            </tr>
            
            
          </tbody>
        </table>
        <hr>
         @endforeach 
       <table class="wojo two column table">
          <thead>
            <tr>
              <th  colspan="2"> {{ __( 'General Details' ) }}  </th>
             
            </tr>
          </thead>
          <tbody>
             
            <tr>
                <td><strong>{{ __('Slug') }}</strong></td>
                <td>{{ $page->slug }}</td>
            </tr>

            <tr>
                <td><strong><?= __('Created') ?></strong></td>
                <td>{{ $page->created_at->format('d F, Y')}}</td>
            </tr>
            <tr>
                <td><strong>{{ __('Modified') }}</strong></td>
                <td>{{ $page->updated_at->format('d F, Y') }}</td>
            </tr>
            <tr>
                <td><strong>{{ __('Status') }}</strong></td>
                <td>{{ $page->status ? __('Active') : __('Inactive')  }}</td>
            </tr>
            
          </tbody>
        </table>
     
      
      
    
    </div>
  </div>


@stop