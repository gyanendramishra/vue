<?php

namespace Modules\CmsManager\Observers;

use Modules\CmsManager\Entities\PageImage;
use Illuminate\Support\Facades\Storage;

class PageImageObserver
{
    /**
     * Handle the product image "created" event.
     *
     * @param  \App\PageImage  $PageImage
     * @return void
     */
    public function created(PageImage $pageImage)
    {
        $this->imageUploadAndUpdate($pageImage);
    }

    /**
     * Handle the product image "updated" event.
     *
     * @param  \App\PageImage  $PageImage
     * @return void
     */
    public function updated(PageImage $pageImage)
	{
        $this->imageUploadAndUpdate($pageImage);
    }

public function imageUploadAndUpdate($pageImage){
    if(!empty($pageImage->getAttribute('image'))){        
            if($pageImage->getAttribute('image') != $pageImage->getOriginal('image')){
                $existNew = Storage::disk('public')->exists('temp/'.  $pageImage->getAttribute('image'));
                if($existNew){
                    Storage::move('public/temp/' . $pageImage->getAttribute('image'), 'public/pages/' . $pageImage->getAttribute('image'));
                }

                $exists = Storage::disk('public')->exists('pages/'.  $pageImage->getOriginal('image'));
                if($exists){
                    Storage::disk('public')->delete('pages/'. $pageImage->getOriginal('image'));
                }
            }
        }
}

    /**
     * Handle the product image "deleted" event.
     *
     * @param  \App\PageImage  $PageImage
     * @return void
     */
    public function deleted(PageImage $pageImage)
    {
        $exists = Storage::disk('public')->exists('pages/'.  $pageImage->getAttribute('image'));
        if($exists){
            Storage::disk('public')->delete('pages/'. $pageImage->getAttribute('image'));
        }
    }

    /**
     * Handle the product image "restored" event.
     *
     * @param  \App\PageImage  $PageImage
     * @return void
     */
    public function restored(PageImage $pageImage)
    {
        //
    }

    /**
     * Handle the product image "force deleted" event.
     *
     * @param  \App\PageImage  $PageImage
     * @return void
     */
    public function forceDeleted(PageImage $pageImage)
    {
        echo "force";
        //dd($PageImage);
    }
}
