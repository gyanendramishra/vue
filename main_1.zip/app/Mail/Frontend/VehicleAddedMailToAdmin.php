<?php

namespace App\Mail\Frontend;

use App\EmailTemplate;
use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class VehicleAddedMailToAdmin extends Mailable {

    use Queueable,
        SerializesModels;
    
    public $vehicle;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($vehicle)
    {
        $this->vehicle = $vehicle;
    }
   
    /**
     * Build the message.
     *
     * @return $this
     */
    public function build() {
       

        $et = EmailTemplate::whereType('vehicle_added_mail_to_admin')
                ->with('translations:id,email_template_id,locale,subject,template')
                ->first(['id']);
        if ($et) {
            $subject = $et->subject;
            $body = $et->template;
            $body = str_replace('##VEHICLE_TITLE##', $this->vehical->title, $body);
            $body = str_replace('##VEHICLE_CODE##', $this->vehical->id, $body);
            $body = str_replace('##NAME##', $this->vehical->user->name, $body);
            $body = str_replace('##EMAIL##',$this->vehical->user->email, $body);
            $body = str_replace('##PHONE##', $this->vehical->user->phone, $body);
            $body = str_replace('##POSTCODE##', $this->vehical->postcode, $body);

            $this->subject($subject)
                    ->view('frontend.emails.template')
                    ->with(['template' => $body]);
        }
    }

}
