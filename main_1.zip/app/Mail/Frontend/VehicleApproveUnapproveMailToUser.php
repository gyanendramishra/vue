<?php

namespace App\Mail\Frontend;

use App\EmailTemplate;
use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class VehicleApproveUnapproveMailToUser extends Mailable {

    use Queueable,
        SerializesModels;
    
    public $vehicle;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($vehicle)
    {
        $this->vehicle = $vehicle;
    }
   
    /**
     * Build the message.
     *
     * @return $this
     */
    public function build() {
       

        $et = EmailTemplate::whereType('vehicle_approve_unapprove_mail_to_user')
                ->with('translations:id,email_template_id,locale,subject,template')
                ->first(['id']);
        if ($et) {
            if($this->vehicle->status == 0){
                $status = 'Disapproved';
            } else {
                 $status = 'Approved';
            }
            $subject = $et->subject;
            $body = $et->template;
            $body = str_replace('##STATUS##', $status, $subject);
            $body = str_replace('##STATUS##', $status, $body);
            $body = str_replace('##USER##', $vehical->user->name, $body);
            $body = str_replace('##VEHICLE##', $vehical->title, $body);
            $body = str_replace('##VEHICLE_CODE##', $vehical->id, $body);
          

            $this->subject($subject)
                    ->view('frontend.emails.template')
                    ->with(['template' => $body]);
        }
    }

}
