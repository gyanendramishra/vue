<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Auth;

class AppServiceProvider extends ServiceProvider {

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register() {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot() {
        // https://laravel.com/docs/master/migrations#creating-indexes
        // MariaDB key lenght issue solved.
        Schema::defaultStringLength(191);

        \Illuminate\Support\Facades\View::composer('*', function ($view) {
            $view->with('adminUser', Auth::guard('admin')->user());
        });

        \Illuminate\Support\Facades\View::composer('*', function ($view) {
            $action = app('request')->route() ? app('request')->route()->getAction() : '';
            if (isset($action['controller'])) {
                $controller = class_basename($action['controller']);
                
                if(count(explode('@', $controller)) > 1){
                    list($controller, $action) = explode('@', $controller);
                    $view->with(['getController' => str_replace('Controller', '', $controller), 'getAction' => $action]);
                }
            }
        });

        $this->validateUniqueSpaceCheck();
    }

    public function validateUniqueSpaceCheck() {
        \Validator::extend('unique_space_check', function($attribute, $value, $parameters) {
         
            $attribute = (isset($parameters[1])) ? $parameters[1] : $attribute;

            $value = trim(preg_replace('/\s\s+/', ' ', $value));
            if(isset($parameters[2]) || isset($parameters[3])){
                $check = \DB::table($parameters[0])->where($attribute, $value)->where($parameters[3],'!=', $parameters[2])->count();
            }else{
                $check = \DB::table($parameters[0])->where($attribute, $value)->count();
            }
            

            return ($check > 0) ? false : true;
        }, 'The :attribute has already been taken.');
    }





}
