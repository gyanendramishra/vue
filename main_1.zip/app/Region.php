<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Region extends Model {
    
    /**
     * Get the country that owns the region.
     */
    public function country()
    {
        return $this->belongsTo('App\Country');
    }

    /**
     * The cities that belong to the region.
     */
    public function cities()
    {
        return $this->hasMany('App\City');
    }
}
