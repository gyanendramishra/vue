<?php
namespace App\Repositories;

use Illuminate\Http\Request;
use Modules\NewsManager\Entities\News;
use App\Repositories\Interfaces\NewsInterface;

class NewsRepository implements NewsInterface {
    

    /* Get home news */
    public function getHomeNews(){
        return News::select('id', 'image', 'publish_date')
                    ->with('translations:id,news_id,locale,title')
                    ->active()
                    ->whereDate('publish_date','<=',\Carbon\Carbon::now())
                    ->take(10)
                    ->inRandomOrder()
                    ->get();
    }

}
