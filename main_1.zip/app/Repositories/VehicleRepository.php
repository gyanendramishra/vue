<?php
namespace App\Repositories;

use App\City;
use App\Region;
use App\Country;
use Illuminate\Support\Arr;
use Illuminate\Http\Request;
use Modules\VehicleManager\Entities\Vehicle;
use Modules\CategoryManager\Entities\Category;
use App\Repositories\Interfaces\VehicleInterface;
use Modules\VehicleManager\Entities\VehicleImage;
use Modules\VehicleMakeManager\Entities\VehicleMake;
use Modules\VehicleBadgeManager\Entities\VehicleBadge;
use Modules\VehicleModelManager\Entities\VehicleModel;
use Modules\VehicleSeriesManager\Entities\VehicleSeries;
use Modules\VehicleColorsManager\Entities\VehicleColors;
use Modules\VehicleFeatureManager\Entities\VehicleFeature;
use Modules\VehicleFuelTypesManager\Entities\VehicleFuelTypes;
use Modules\VehicleBodyStyleManager\Entities\VehicleBodyStyle;
use Modules\VehicleLifestyleManager\Entities\VehicleLifestyle;
use Modules\VehicleDriveTypesManager\Entities\VehicleDriveTypes;
use Modules\VehicleTransmissionsManager\Entities\VehicleTransmissions;

class VehicleRepository implements VehicleInterface {
    /* Extract search uri segments */
    public function extractFilters(Request $request){
        $filters = [];
        $segments = $request->segments();
        //remove first segment
        array_shift($segments);
        
        $segmentables = ["make", 'model', 'type', 'style', 'fule', 'over', 'under', 'price', 'state', 'region'];
        if(!empty($segments)){

            foreach($segments as $segment){
                $seg = explode('-', $segment, 2);
                if((count($seg) == 1) || !in_array($seg[0], $segmentables)){
                    continue;
                }
                //dd($seg);
                if($seg[0] == 'make'){
                    $filters['make'] = $seg[1];
                }elseif($seg[0] == 'model'){
                    $filters['model'] = $seg[1];
                }elseif($seg[0] == 'type'){
                    $filters['type'] = $seg[1];
                }elseif($seg[0] == 'style'){
                    $filters['body_type'] = $seg[1];
                }elseif($seg[0] == 'fule'){
                    $filters['fuel_type'] = $seg[1];
                }elseif($seg[0] == 'over'){
                    $filters['min_price'] = $seg[1];
                }elseif($seg[0] == 'under'){
                    $filters['max_price'] = $seg[1];
                }elseif($seg[0] == 'price'){
                    $price  = explode('-', $seg[1]);
                    if(count($price) > 2){
                        continue;
                    }
                    $filters['min_price'] = $price[0];
                    $filters['max_price'] = $price[1];
                }elseif($seg[0] == 'state'){
                    $filters['state'] = $seg[1];
                }elseif($seg[0] == 'region'){
                    $filters['city'] = $seg[1];
                }else{

                }
            }
        }
        $filters['sort_by'] = 1;
        return $filters;
    }
    /* Search vehicle */
    public function search(Request $request){
        /* Extract segment filters */
        $segmentFilters =  $this->extractFilters($request);
        
        /* merge query string and segment filters */
        $request->merge($segmentFilters);
        /* Vehicle query instance */
        $query = Vehicle::query();
        /* Check if active */
        $query->active();
            
        /* Filter by type */
        $query->when($request->query('type'), function($q) use($request){
            $q->whereHas('category', function($q) use($request){
                $q->whereSlug($request->query('type'));
            });
        });
        /* Filter by make */
        $query->when($request->query('make'), function($q) use($request){
            $q->whereHas('make', function($q) use($request){
                $q->whereSlug($request->query('make'));
            });
        });
        /* Filter by model */
        $query->when($request->query('model'), function($q) use($request){
            $q->whereHas('model', function($q) use($request){
                $q->whereSlug($request->query('model'));
            });
        });
        /* Filter by badge */
        $query->when($request->query('badge'), function($q) use($request){
            $q->where('badge_id', $request->query('badge'));
        });
        /* Filter by series */
        $query->when($request->query('series'), function($q) use($request){
            $q->where('series_id', $request->query('series'));
        });
        /* Filter by min price */
        $query->when(($request->query('min_price') && !$request->query('max_price')), function($q) use($request){
            $q->where('price', ">=", $request->query('min_price'));
        });
        /* Filter by max price */
        $query->when(($request->query('max_price') && !$request->query('min_price')), function($q) use($request){
            $q->where('price', "<=", $request->query('max_price'));
        });
        /* Filter by price */
        $query->when(($request->query('min_price') && $request->query('max_price')), function($q) use($request){
            $q->whereBetween('price', [$request->query('min_price'), $request->query('max_price')]);
        });
        /* Filter by state */
        $query->when($request->query('state'), function($q) use($request){
            $q->whereHas('region', function($q) use($request){
                $q->where('name', str_replace('-', ' ', $request->query('state')));
            });
        });

        /* Filter by city */
        $query->when($request->query('city'), function($q) use($request){
            $q->whereHas('city', function($q) use($request){
                $q->where('name', str_replace('-', ' ', $request->query('city')));
            });
        });
        /* Filter by city */
        // $query->when($request->query('city'), function($q) use($request){
        //     $q->where('city_id', $request->query('city'));
        // });
        /* Filter by style */
        $query->when($request->query('body_type'), function($q) use($request){
            $q->whereHas('bodystyle', function($q) use($request){
                $q->whereSlug($request->query('body_type'));
            });
        });
        /* Filter by drive type */
        $query->when($request->query('drive_type'), function($q) use($request){
            $q->where('drive_types_id', $request->query('drive_type'));
        });
        /* Filter by fuel */
        $query->when($request->query('fuel_type'), function($q) use($request){
            $q->whereHas('fuel_type', function($q) use($request){
                $q->whereSlug($request->query('fuel_type'));
            });
        });
        /* Filter by fuel economy */
        $query->when($request->query('fuel_economy'), function($q) use($request){
            $q->where('fuel_economy_id', $request->query('fuel_economy'));
        });
        /* Filter by transmission */
        $query->when($request->query('transmission'), function($q) use($request){
            $q->where('transmissions_id', $request->query('transmission'));
        });
        /* Filter by cylinder */
        $query->when($request->query('cylinder'), function($q) use($request){
            $q->where('cylinders_id', $request->query('cylinder'));
        });
        /* Filter by lifestyle */
        $query->when($request->query('lifestyle'), function($q) use($request){
            $q->where('lifestyle_id', $request->query('lifestyle'));
        });
        /* Filter by features */
        $query->when($request->query('features'), function($q) use($request){
            $q->whereHas('vehicleFeatures', function($q) use($request){
                $q->whereIn('vehicle_feature_id', explode(',', $request->query('features')));
            });
        });
        /* Filter by interior color */
        $query->when($request->query('interior_color'), function($q) use($request){
            $q->where('interior_colour_id', $request->query('interior_color'));
        });
        /* Filter by exterior color */
        $query->when($request->query('exterior_color'), function($q) use($request){
            $q->where('exterior_colour_id', $request->query('exterior_color'));
        });

        /* Filter by doors */
        $query->when($request->query('doors'), function($q) use($request){
            $q->where('doors', $request->query('doors'));
        });

        /* Filter by min year */
        $query->when(($request->query('min_year') && !$request->query('max_year')), function($q) use($request){
            $q->where('year_build', ">=", $request->query('min_year'));
        });
        /* Filter by max year */
        $query->when(($request->query('max_year') && !$request->query('min_year')), function($q) use($request){
            $q->where('year_build', "<=", $request->query('max_year'));
        });
        /* Filter by year between */
        $query->when(($request->query('min_year') && $request->query('max_year')), function($q) use($request){
            $q->whereBetween('year_build', [$request->query('min_year'), $request->query('max_year')]);
        });

        /* Filter by min seats */
        $query->when(($request->query('min_seats') && !$request->query('max_seats')), function($q) use($request){
            $q->where('seats', ">=", $request->query('min_seats'));
        });
        /* Filter by max seats */
        $query->when(($request->query('max_seats') && !$request->query('min_seats')), function($q) use($request){
            $q->where('seats', "<=", $request->query('max_seats'));
        });

        /* Filter by seats between */
        $query->when(($request->query('min_seats') && $request->query('max_seats')), function($q) use($request){
            $q->whereBetween('seats', [$request->query('min_seats'), $request->query('max_seats')]);
        });

        /* Filter by min engine capacity */
        $query->when(($request->query('min_engine_size') && !$request->query('max_engine_size')), function($q) use($request){
            $q->where('engine_capacity', ">=", $request->query('min_engine_size'));
        });
        /* Filter by max engine capacity */
        $query->when(($request->query('max_engine_size') && !$request->query('min_engine_size')), function($q) use($request){
            $q->where('engine_capacity', "<=", $request->query('max_engine_size'));
        });

        /* Filter by engine capacity between */
        $query->when(($request->query('min_engine_size') && $request->query('max_engine_size')), function($q) use($request){
            $q->whereBetween('engine_capacity', [$request->query('min_engine_size'), $request->query('max_engine_size')]);
        });

        /* Filter by keyword */
        $query->when($request->query('keyword'), function($q) use($request){
            $q->where(function ($q) use ($request) {
                $keywords = explode( ' ', $request->query('keyword'));
                foreach($keywords as $keyword){
                    $q->where('title', 'like', '%' . $keyword . '%');
                }
            });
        });

        /* Filter by distance */
        $query->when(($request->query('postcode') && $request->query('distance')), function($q) use($request){
            $url = "https://maps.googleapis.com/maps/api/geocode/json?address=" . urlencode($request->query('postcode')) . "&sensor=false&key=AIzaSyAs37E0maZBfXAsVlrOvSoXyOIlAhlmfzA";
            $result_string = file_get_contents($url);
            $result = json_decode($result_string, true);
            if (!empty($result['results'])) {
                $zipLat = $result['results'][0]['geometry']['location']['lat'];
                $ziplng = $result['results'][0]['geometry']['location']['lng'];
                $q->isWithinMaxDistance($zipLat, $ziplng, $request->query('distance'));
            }
        });

        $query->when($request->query('sort_by'), function ($q) use($request) {
            
            if($request->query('sort_by') == 1){
                $q->orderBy('id', 'DESC');
            }elseif($request->query('sort_by') == 2){
                $q->orderBy('is_featured', 'ASC');
            }elseif($request->query('sort_by') == 3){
                $q->orderBy('price', 'DESC');
            }elseif($request->query('sort_by') == 4){
                $q->orderBy('price', 'ASC');
            }elseif($request->query('sort_by') == 5){
                $q->orderBy('year_build', 'DESC');
            }elseif($request->query('sort_by') == 6){
                $q->orderBy('year_build', 'ASC');
            }elseif($request->query('sort_by') == 7){
                $q->orderBy('fuel_economy_id', 'DESC');
            }elseif($request->query('sort_by') == 8){
                $q->orderBy('fuel_economy_id', 'ASC');
            }else{
                $q->orderBy('id', 'DESC');
            }
        });
        
        $query->select(
            'id', 
            'category_id', 
            'makes_id', 
            'models_id', 
            'badge_id', 
            'body_styles_id',
            'fuel_types_id',
            'series_id',
            'transmissions_id',
            'title',
            'role',
            'odometer',
            'price',
            'country', 
            'state',
            'city',
            'slug'
            )
            ->with([
                'main_image:id,vehicle_id,image,caption',
                'category:id',
                'category.translations:id,category_id,name,locale',
                'make:id',
                'make.translations:id,vehicle_make_id,name,locale',
                'model:id,makes_id',
                'model.translations:id,vehicle_model_id,name,locale',
                'badge:id,models_id',
                'badge.translations:id,vehicle_badge_id,name,locale',
                'series:id,badges_id',
                'series.translations:id,vehicle_series_id,name,locale',
                'transmissions:id',
                'transmissions.translations:id,vehicle_transmissions_id,name,locale',
                'bodystyle:id',
                'bodystyle.translations:id,vehicle_body_style_id,locale,name',
                'fuel_type:id',
                'fuel_type.translations:id,vehicle_fuel_types_id,locale,name'
            ])
            ->withCount('vehicle_images');
        return [
            "filters"=> $segmentFilters,
            "results"=> $query->paginate(10)
        ];
    }

    /* Get vehicle types */
    public function getAllType(){
        return Category::select('id', 'icon', 'slug')
                    ->with('translations:id,category_id,locale,name')
                    ->active()
                    ->get();
    }

    /* Get vehicle makes */
    public function getAllMake(){
        return VehicleMake::select('id', 'icon', 'slug')
                    ->with('translations:id,vehicle_make_id,locale,name')
                    ->active()
                    ->get();
    }

    /* Get vehicle body styles */
    public function getAllBodyType(){
        return VehicleBodyStyle::select('id', 'icon', 'slug')
                        ->with('translations:id,vehicle_body_style_id,locale,name')
                        ->active()
                        ->get();
    }

    /* Get vehicle fuel types */
    public function getAllFuelType(){
        return  VehicleFuelTypes::select('id', 'icon', 'slug')
                        ->with('translations:id,vehicle_fuel_types_id,locale,name')
                        ->active()
                        ->get();
    }

    /* Get vehicle features */
    public function getAllFeatures(){
        return  VehicleFeature::select('id')
                        ->with('translations:id,vehicle_feature_id,locale,name')
                        ->active()
                        ->get();
    }

    /* Get vehicle lifestyles */
    public function getAllLifestyles(){
        return  VehicleLifestyle::select('id')
                        ->with('translations:id,vehicle_lifestyle_id,locale,name')
                        ->active()
                        ->get();
    } 

    /* Get all vehicle colors */
    public function getAllColors(){
        return  VehicleColors::select('id')
                        ->with('translations:id,vehicle_colors_id,locale,name')
                        ->active()
                        ->get();
    }

    /* Get all vehicle transmissions */
    public function getAllTransmissions(){
        return  VehicleTransmissions::select('id', 'icon')
                        ->with('translations:id,vehicle_transmissions_id,locale,name')
                        ->active()
                        ->get();
    }

    /* Get all vehicle drive types */
    public function getDriveTypes(){
        return  VehicleDriveTypes::select('id', 'icon')
                        ->with('translations:id,vehicle_drive_types_id,locale,name')
                        ->active()
                        ->get();
    }

    /* Get country with regions */
    public function getAllCountryWithRegions(){
        return Country::select('id', 'name', 'code')
                //->whereIn('code', ['au', 'kh'])
                ->where('code', 'kh')
                ->with('regions')
                ->get();
    }

    /* Get cambodia regions */
    public function getCambodiaRegions(){
        return Region::select('id', 'name')
                ->where('country_id', 106)
                ->get();
    }

    /* Get cities by region */
    public function getStateCitiesById($region){
        return City::select('id', 'name')
                    ->whereHas('region', function($q) use($region){
                        $q->whereName(str_replace("-", " ", $region));
                    })
                    ->get();
    }

    /* Get vehicle make models */
    public function getMakeModelBySlug($makeSlug){
        return VehicleModel::select('id', 'icon', 'slug')
                    ->whereHas('make', function($q) use($makeSlug){
                        $q->whereSlug($makeSlug);
                    })
                    ->with('translations:id,vehicle_model_id,locale,name')
                    ->active()
                    ->get();
    }

    /* Get vehicle make models by id*/
    public function getMakeModelById($makeId){
        return VehicleModel::select('id', 'icon', 'slug')
                    ->where('makes_id', $makeId)
                    ->with('translations:id,vehicle_model_id,locale,name')
                    ->active()
                    ->get();
    }

    /* Get vehicle badge by model slug */
    public function getModelBadgeBySlug($modelSlug){
        return VehicleBadge::select('id', 'icon', 'slug')
                    ->whereHas('model', function($q) use($modelSlug){
                        $q->whereSlug($modelSlug);
                    })
                    ->with('translations:id,vehicle_badge_id,locale,name')
                    ->active()
                    ->get();
    }
    /* Get vehicle badge by model id */
    public function getModelBadgeById($modelId){
        return VehicleBadge::select('id', 'icon', 'slug')
                    ->where('models_id', $modelId)
                    ->with('translations:id,vehicle_badge_id,locale,name')
                    ->active()
                    ->get();
    }
    /* Get vehicle series by badge id */
    public function getBadgeSeriesById($badgeId){
        return VehicleSeries::select('id', 'icon', 'slug')
                    ->where('badges_id', $badgeId)
                    ->with('translations:id,vehicle_series_id,locale,name')
                    ->active()
                    ->get();
    }

    /* Get vehicle make by slug */
    public function getMakeBySlug($slug){
        return VehicleMake::select('id', 'icon', 'slug')
                    ->whereSlug($slug)
                    ->with('translations:id,vehicle_make_id,locale,name')
                    ->active()
                    ->first();
    }

    /* Get vehicle model by slug */
    public function getModelBySlug($slug){
        return VehicleModel::select('id', 'icon', 'slug')
                    ->whereSlug($slug)
                    ->with('translations:id,vehicle_make_id,locale,name')
                    ->active()
                    ->first();
    }

    /* Get vehicle by slug */
    public function getVehicleBySlug($slug){
        return Vehicle::select(
                        'id',
                        'user_id',
                        'category_id',
                        'makes_id',
                        'models_id',
                        'badge_id',
                        'series_id',
                        'body_styles_id',
                        'drive_types_id',
                        'fuel_types_id',
                        'fuel_economy_id',
                        'cylinders_id',
                        'interior_colour_id',
                        'exterior_colour_id',
                        'transmissions_id',
                        'lifestyle_id',
                        'address',
                        'country',
                        'state',
                        'city',
                        'title',
                        'price',
                        'month_build',
                        'year_build',
                        'year_complied',
                        'seats',
                        'doors',
                        'gears',
                        'turbo',
                        'role',
                        'expiry_month',
                        'expiry_year',
                        'odometer',
                        'roadworthy',
                        'written_off',
                        'is_registered',
                        'engine_capacity',
                        'chassis_number',
                        'plate_number',
                        'slug'    
                    )
                    ->whereSlug($slug)
                    ->with([
                        'translations:id,vehicle_id,locale,description',
                        'vehicle_images:id,vehicle_id,image_type,image,caption',
                        'category:id',
                        'category.translations:id,category_id,name,locale',
                        'make:id',
                        'make.translations:id,vehicle_make_id,name,locale',
                        'model:id',
                        'model.translations:id,vehicle_model_id,name,locale',
                        'badge:id',
                        'badge.translations:id,vehicle_badge_id,name,locale',
                        'series:id,badges_id',
                        'series.translations:id,vehicle_series_id,name,locale',
                        'bodystyle:id',
                        'bodystyle.translations:id,vehicle_body_style_id,locale,name',
                        'fuel_type:id',
                        'fuel_type.translations:id,vehicle_fuel_types_id,locale,name',
                        'drive_types:id',
                        'drive_types.translations:id,vehicle_drive_types_id,locale,name',
                        'transmissions:id',
                        'transmissions.translations:id,vehicle_transmissions_id,name,locale',
                        'vehicleFeatures:id',
                        'vehicleFeatures.translations:id,vehicle_feature_id,name,locale',
                        'vehicleLifestyle:id',
                        'vehicleLifestyle.translations:id,vehicle_lifestyle_id,name,locale',
                        'interiorColor:id',
                        'interiorColor.translations:id,vehicle_colors_id,name,locale',
                        'exteriorColor:id',
                        'exteriorColor.translations:id,vehicle_colors_id,name,locale'
                    ])
                    ->active()
                    ->first();
    }
    /* Get vehicle with it's general info */
    public function getVehicleWithGeneralBySlug($slug){
        return Vehicle::select(
            'id',
            'user_id',
            'category_id',
            'makes_id',
            'models_id',
            'badge_id',
            'series_id',
            'body_styles_id',
            'drive_types_id',
            'fuel_types_id',
            'transmissions_id',
            'cylinders_id',
            'title',
            'month_build',
            'year_build',
            'year_complied',
            'seats',
            'doors',
            'gears',
            'turbo',
            'engine_capacity',
            'chassis_number',
            'steps',
            'slug'    
        )
        ->whereSlug($slug)
        ->first();
    }
    /* Get vehicle with it's features */
    public function getVehicleWithFeaturesBySlug($slug){
        return Vehicle::select(
            'id',
            'user_id',
            'title',
            'steps',
            'slug'    
        )
        ->whereSlug($slug)
        ->with([
            'vehicleFeatures:id',
            'vehicleFeatures.translations:id,vehicle_feature_id,name,locale'
        ])
        ->first();
    }
    /* Get vehicle with it's detail */
    public function getVehicleWithDetailsBySlug($slug){
        return Vehicle::select(
            'id',
            'user_id',
            'title',
            'address',
            'country',
            'state',
            'city',
            'postcode',
            'latitude',
            'longitude',
            'odometer',
            'price',
            'discount_price',
            'interior_colour_id',
            'exterior_colour_id',
            'lifestyle_id',
            'plate_number',
            'expiry_month',
            'expiry_year',
            'fuel_economy_id',
            'phone',
            'written_off',
            'is_registered',
            'roadworthy',
            'steps',
            'slug'    
        )
        ->with([
            'translations:id,vehicle_id,locale,description'
        ])
        ->whereSlug($slug)
        ->first();
    }
    /* Get vehicle with it's photos */
    public function getVehicleWithPhotosBySlug($slug){
        return Vehicle::select(
            'id',
            'user_id',
            'title',
            'steps',
            'slug'    
        )
        ->whereSlug($slug)
        ->with([
            'vehicle_images:id,vehicle_id,image_type,image,caption',
        ])
        ->first();
    }
    /* Get vehicle with it's preview by slug */
    public function getVehicleWithPreviewBySlug($slug){
        return Vehicle::select(
                        'id',
                        'user_id',
                        'category_id',
                        'makes_id',
                        'models_id',
                        'badge_id',
                        'series_id',
                        'body_styles_id',
                        'drive_types_id',
                        'fuel_types_id',
                        'fuel_economy_id',
                        'cylinders_id',
                        'interior_colour_id',
                        'exterior_colour_id',
                        'transmissions_id',
                        'lifestyle_id',
                        'title',
                        'price',
                        'address',
                        'month_build',
                        'year_build',
                        'year_complied',
                        'seats',
                        'doors',
                        'gears',
                        'turbo',
                        'role',
                        'phone',
                        'expiry_month',
                        'expiry_year',
                        'odometer',
                        'roadworthy',
                        'written_off',
                        'is_registered',
                        'engine_capacity',
                        'chassis_number',
                        'plate_number',
                        'slug',
                        'steps'   
                    )
                    ->whereSlug($slug)
                    ->with([
                        'translations:id,vehicle_id,locale,description',
                        'main_image:id,vehicle_id,image,caption',
                        'category:id',
                        'category.translations:id,category_id,name,locale',
                        'make:id',
                        'make.translations:id,vehicle_make_id,name,locale',
                        'model:id',
                        'model.translations:id,vehicle_model_id,name,locale',
                        'badge:id',
                        'badge.translations:id,vehicle_badge_id,name,locale',
                        'series:id,badges_id',
                        'series.translations:id,vehicle_series_id,name,locale',
                        'bodystyle:id',
                        'bodystyle.translations:id,vehicle_body_style_id,locale,name',
                        'fuel_type:id',
                        'fuel_type.translations:id,vehicle_fuel_types_id,locale,name',
                        'drive_types:id',
                        'drive_types.translations:id,vehicle_drive_types_id,locale,name',
                        'transmissions:id',
                        'transmissions.translations:id,vehicle_transmissions_id,name,locale',
                        'vehicleFeatures:id',
                        'vehicleFeatures.translations:id,vehicle_feature_id,name,locale',
                        'vehicleLifestyle:id',
                        'vehicleLifestyle.translations:id,vehicle_lifestyle_id,name,locale',
                        'interiorColor:id',
                        'interiorColor.translations:id,vehicle_colors_id,name,locale',
                        'exteriorColor:id',
                        'exteriorColor.translations:id,vehicle_colors_id,name,locale'
                    ])
                    ->first();
    }
    /* Get vehicle with it's photos */
    public function getVehicleWithStatusAndGeneralBySlug($slug){
        return Vehicle::select(
            'id',
            'user_id',
            'title',
            'steps',
            'slug',
            'status'    
        )
        ->whereSlug($slug)
        ->first();
    }
    /* Get similar vehicle by price */
    public function getSimilarVehiclesByPrice($id, $price){
        $twentyPercentOfPrice = $price*20/100;
        $minPrice = ($price - $twentyPercentOfPrice);
        $maxPrice = ($price + $twentyPercentOfPrice);
        return Vehicle::select('id', 'title', 'year_build')
            ->where('id', '!=', $id)
            ->whereBetween('price', [$minPrice, $maxPrice])
            ->with('main_image:id,vehicle_id,image,caption')
            ->active()
            ->take(10)
            ->get();
    }

    /* Get  vehicle getCarOfTheWeek */
    public function getCarOfTheWeek(){
        
        return Vehicle::select('id', 'title','year_build','slug')
            ->where('car_of_the_week', 1)
            ->with('main_image:id,vehicle_id,image,caption')
            ->active()
            ->first();
    }

    

}
