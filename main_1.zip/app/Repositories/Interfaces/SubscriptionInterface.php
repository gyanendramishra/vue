<?php
namespace App\Repositories\Interfaces;

use Illuminate\Http\Request;

interface SubscriptionInterface {
    
    public function getSubscriptionPlansAsPerUserRoles($roles);
}
