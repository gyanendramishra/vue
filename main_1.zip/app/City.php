<?php

namespace App;


use Illuminate\Database\Eloquent\Model;

class City extends Model {

    /**
     * Get the region that owns the country.
     */
    public function region()
    {
        return $this->belongsTo('App\Region');
    }
    
}
