<?php

namespace App\Http\Middleware;

use Closure;
use DB;

class CheckAuthorization {


    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next) {
        $authInformation = apache_request_headers();
       
        if (isset($authInformation['Authorization']) && !empty($authInformation['Authorization'])) {
            $token = str_replace("Bearer", " ", $authInformation['Authorization']);
            $token = trim($token);
            $user = DB::table('users')->where('api_token', $token)->first();
            if (empty($user)) {
                $data['data'] = (object) [];
                $data['status'] = false;
                $data['message'] = 'You are not authorize to access any more.';
                $data['code'] = 401;
                return response()->json($data);
            } else {

                if ($user->status == 0) {
                    $data['data'] = (object) [];
                    $data['status'] = false;
                    $data['message'] = 'You account has been deactivated,Please contact the admin.';
                    $data['code'] = 401;
                    return response()->json($data);
                } else {
                    $request->attributes->set('Auth', $user);
                    return $next($request);
                }
            }
        } else {
            $data['data'] = (object) [];
                    $data['status'] = false;
                    $data['message'] = 'You are not authorize to access.';
                    $data['code'] = 401;
                    return response()->json($data);
        }
    }

}

