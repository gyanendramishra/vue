<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Mail\Frontend\InquiryMail;
use Modules\EnquiresManager\Entities\Inquiry;
use App\Http\Requests\Frontend\InquiryRequest;

class InquiryController extends Controller
{
    /**
     * Display contact us view.
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        return view('frontend.inquiry');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Backend\InquiryRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function sendInquiry(InquiryRequest $request){
        try {
            \DB::beginTransaction();
            $inquiry = new Inquiry($request->all());
            if($inquiry->save()){
                // DB commit
                \DB::commit();

                // Send inquiry mail to admin
                if(!empty(config('get.ADMIN_EMAIL'))){
                    \Mail::to(config('get.ADMIN_EMAIL'))->send(new InquiryMail($inquiry));
                }
                
                return response()->json([
                    "status"=>"success",
                    "message"=>__('frontend.ENQUIRED')
                ], 200);
            }

            \DB::rollBack();
            return response()->json([
                "status"=>"error",
                "message"=>__('frontend.NOT_ENQUIRED')
            ], 200);
            
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                "status"=>"error",
                "message"=>__('frontend.OOPS')
            ], 200);
        }
    }
}
