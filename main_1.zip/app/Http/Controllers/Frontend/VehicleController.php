<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\AdRepository;
use App\Repositories\VehicleRepository;

class VehicleController extends Controller
{
    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;

    /**
     * Ad repository.
     *
     * @var string
     */
    private $adRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        VehicleRepository $vehicleRepository,
        AdRepository $adRepository
    ){
        $this->vehicleRepository = $vehicleRepository;
        $this->adRepository = $adRepository;
    }

    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request, $slug = null){
        $vehicle = $this->vehicleRepository->getVehicleBySlug($slug);
        if($vehicle){
            $similarVehicles = $this->vehicleRepository->getSimilarVehiclesByPrice($vehicle->id, $vehicle->price);
            $features = $this->vehicleRepository->getAllFeatures();
            $ads = $this->adRepository->getDetailPageAds();
            return view('frontend.vehicle.info', compact(
                'vehicle', 
                'features', 
                'similarVehicles',
                'ads'
            ));
        }
        abort(404);
    }
}
