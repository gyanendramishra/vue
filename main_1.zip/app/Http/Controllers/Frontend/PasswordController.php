<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Http\Requests\Frontend\PasswordRequest;

class PasswordController extends Controller
{
    /**
     * Display change password view.
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        return view('frontend.user.password');
    }

    /**
     * Handle password update.
     *
     * @param  App\Http\Request\Frontend\PasswordRequest  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response
     */
    public function updatePassword(PasswordRequest $request)
    {
        try{
            \DB::beginTransaction();
            $user = \Auth::guard('user')->user();
            $user->password = bcrypt($request->new_password);
            if($user->save()){
                \DB::commit();
                return response()->json([
                    "status"=>"success",
                    "message"=>__('frontend.CHANGE_PASSWORD_SUCCESS')
                ], 200);
            }else{
                return response()->json([
                    "status"=>"error",
                    "message"=>__('frontend.CHANGE_PASSWORD_FAILED')
                ], 200);
            }
        }catch(\Exception $e){
            \DB::rollBack();
            return response()->json([
                "status"=>"error",
                "message"=>__('frontend.OOPS')
            ], 200);
        }
    }
}
