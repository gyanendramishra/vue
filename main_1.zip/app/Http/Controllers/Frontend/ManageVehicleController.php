<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\AdRepository;
use App\Repositories\VehicleRepository;
use App\Repositories\UserRepository;
use Modules\VehicleManager\Entities\Vehicle;

class ManageVehicleController extends Controller {

    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;

    /**
     * Ad repository.
     *
     * @var string
     */
    private $adRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
    VehicleRepository $vehicleRepository, AdRepository $adRepository, UserRepository $userRepository
    ) {
        $this->vehicleRepository = $vehicleRepository;
        $this->adRepository = $adRepository;
        $this->userRepository = $userRepository;
    }

    /**
     * Display a listing of the my ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function getMyVehicles(Request $request) {
        if($request->ajax()){
            try {
                $vehicles = $this->userRepository->getMyVehicle();
                return response()->json([
                        "status"=> "success",
                        "data"=> $vehicles
                    ], 200);
            } catch (\Exception $e) {
                return response()->json([
                    "status"=>"error",
                    "message"=>__('frontend.OOPS')
                ], 200);
            }
        }else{
            try {
                $vehicles = $this->userRepository->getMyVehicle();
                return view('frontend.user.ads', compact('vehicles'));
            } catch (\Exception $e) {
                return redirect()
                            ->route('frontend.dashboard');
            }
        }
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function createVehicle(Request $request, $slug = null) {
        $types = $this->vehicleRepository->getAllType();
        $fuelTypes = $this->vehicleRepository->getAllFuelType();
        $transmissions = $this->vehicleRepository->getAllTransmissions();
        $driveTypes = $this->vehicleRepository->getDriveTypes();
        return view('frontend.manage_ad.general_info', compact(
            'types', 
            'fuelTypes', 
            'transmissions', 
            'driveTypes'
        ));
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function saveVehicleGeneral(Request $request, $slug) {
        $vehicle = $this->vehicleRepository->getVehicleWithGeneralBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        
        $types = $this->vehicleRepository->getAllType();
        $fuelTypes = $this->vehicleRepository->getAllFuelType();
        $transmissions = $this->vehicleRepository->getAllTransmissions();
        $driveTypes = $this->vehicleRepository->getDriveTypes();
        $models = $this->vehicleRepository->getMakeModelById($vehicle->makes_id);
        $badges = $this->vehicleRepository->getModelBadgeById($vehicle->models_id);
        $series = $this->vehicleRepository->getBadgeSeriesById($vehicle->badge_id);
        return view('frontend.manage_ad.general_info', compact(
            'types', 
            'fuelTypes', 
            'transmissions', 
            'driveTypes',
            'models',
            'badges',
            'series',
            'vehicle'
        ));
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function saveVehicleFeatures(Request $request, $slug) {
        $vehicle = $this->vehicleRepository->getVehicleWithFeaturesBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        
        $features = $this->vehicleRepository->getAllFeatures();
        return view('frontend.manage_ad.features', compact('features', 'vehicle'));
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function saveVehicleDetails(Request $request, $slug) {
        $vehicle = $this->vehicleRepository->getVehicleWithDetailsBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        $colors = $this->vehicleRepository->getAllColors();
        $lifestyles = $this->vehicleRepository->getAllLifestyles();
        return view('frontend.manage_ad.details', compact('vehicle', 'colors', 'lifestyles'));
    }

    /**
     * Show the form for creating a new ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function saveVehiclePhotos(Request $request, $slug) {
        $vehicle = $this->vehicleRepository->getVehicleWithPhotosBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        return view('frontend.manage_ad.photos', compact('vehicle'));
    }

    /**
     * Show the preview form of ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function vehiclePreview(Request $request, $slug) {
        $vehicle = $this->vehicleRepository->getVehicleWithPreviewBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        return view('frontend.manage_ad.preview', compact('vehicle'));
    }
    /**
     * Show the preview form of ad.
     *
     * @return \Illuminate\Http\Response
     */
    public function vehicleThankYou(Request $request, $slug) {
        $vehicle = $this->vehicleRepository->getVehicleWithStatusAndGeneralBySlug($slug);
        if (!$vehicle) {
            abort(404);
        }
        return view('frontend.manage_ad.thank_you', compact('vehicle'));
    }

}
