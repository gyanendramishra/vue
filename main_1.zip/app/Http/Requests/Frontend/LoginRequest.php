<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class LoginRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'email' => 'bail|required|max:50',
            'password' => 'bail|required|min:8|max:12',
        ];
    }

    /**
     * Configure the validator instance.
     *
     * @param \Illuminate\Validation\Validator $validator
     *
     * @return void
     */
    public function withValidator($validator) {
        $validator->after(function ($validator) {
            if ($this->has('email')) {
                if (is_numeric($this->email)) {
                    if (!preg_match('/^[0-9]{10}+$/', $this->email)) {
                        $validator->errors()->add('email', 'Please enter a valid Phone number.');
                    }
                } else {
                    if (!filter_var($this->email, FILTER_VALIDATE_EMAIL)) {
                        $validator->errors()->add('email', 'Please enter a valid email address.');
                    }
                }
            }
        });
    }

}
