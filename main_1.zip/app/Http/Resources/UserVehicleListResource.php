<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Collection\ImageCollection;

class UserVehicleListResource extends JsonResource {

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request) {
       
        $features = [];
        foreach ($this->vehicleFeatures as $vehicleFeatures) {
            $features[] = $vehicleFeatures->name;
        }
        $feature_id = [];
        foreach ($this->vehicleFeatures as $vehicleFeatures) {
            $feature_id[] = $vehicleFeatures->id;
        }
        $data = [
            'id' => $this->id,
            'title' => $this->year ." ".$this->title ,
            'slug' => $this->slug,
            'year_build' => $this->year_build,
            'engine_size' => $this->engine_size,
            'year_complied' => $this->year_complied,
            'doors' => $this->doors,
            'make' => $this->make->name,
            'model' => $this->model->name,
         //   'badge' => $this->badge->name,
            'year' => $this->year,
            'price' => $this->price,
            'seats' => $this->seats,
            'chassis_number' => $this->chassis_numbe,
            'plate_number' => $this->plate_number,
            'gears' => $this->gears,
            'fuel_economy' => $this->fuel_economy,
            'turbo' => $this->turbo,
            'odometer' => $this->odometer,
            'expiry_month' => $this->expiry_month,
            'expiry_year' => $this->expiry_year,
            'description' => $this->description,
            'images' =>  new ImageCollection($this->vehicle_images()->get()),
            //'region' => ($this->region)?$this->region->name:'',
            //'city' => ($this->city)?$this->city->name:'',
            'role' => $this->role,
            'created_at' => $this->created_at,
            'features' => $features,
            'feature_id' => $feature_id,
            
        ];
      
        $data['is_favourite'] = $this->is_favourite($this->id);
      
        if ($this->category) {
            $data['category'] = $this->category->name;
        }
        if ($this->drive_types) {
            $data['drive_type'] = $this->drive_types->name;
        }

        if ($this->bodystyle) {
            $data['body_style'] = $this->bodystyle->name;
        }
        if ($this->series) {
            $data['series'] = $this->series->name;
        }
        if ($this->lifestyle) {
            $data['lifestyle_id'] = $this->lifestyle->name;
        }
        if ($this->fuel_type) {
            $data['fuel_type'] = $this->fuel_type->name;
        }
        if ($this->suspensions) {
            $data['suspensions'] = $this->suspensions->name;
        }
        if ($this->transmissions) {
            $data['transmissions'] = $this->transmissions->name;
        }
        if ($this->cylinders) {
            $data['cylinders'] = $this->cylinders->name;
        }

        return $data;
    }
    
    protected  function is_favourite($value) {
        if (\Auth::guard('api')->check()) {
           
            if (\Auth::guard('api')->user()->favouriteVehicles()->wherePivot('vehicle_id', $value)->first()) {
               $user = \Auth::guard('api')->user()->favouriteVehicles()->wherePivot('vehicle_id', $value)->first();
               return $user->pivot->is_favourite;
            }
        }
        return 0;
    }

}
