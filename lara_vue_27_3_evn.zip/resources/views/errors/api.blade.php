@extends('layouts.app')

@section('content')

<div class="topInnerBanner" style="background-image:url(/images/login_body_bg.jpg);">
	<div class="container">
	    <div class="topBannerMidCol">
	      	<h1>
	      		<strong>Error</strong>
	      	</h1>
	    </div>
	</div>
</div>
<div class="breadcrumb-sec">
  	<div class="container">
	    <ul>
		    <li>
		      	<a href="{{ route('home') }}">
			      	Home
			    </a>
		    </li>
	        <li>
		        Error
		    </li>
	    </ul>
  	</div>
</div>
<div class="mainWpapContainer">
	<div class="container">
		<h5>ERROR</h5>
		<p>
			We're sorry but we can't process your request .
		</p>
		<h6>This could be because:</h6>
		<p>{{ $message }}</p>
	</div>
</div>

@endsection
