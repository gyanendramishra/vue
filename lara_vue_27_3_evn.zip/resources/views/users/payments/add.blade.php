@extends('users.master')
@section('page_header_title')
	Add <span>Payment Details</span>
@endsection
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        Add payment detail
    </li>
@endsection

@section('dashboard_content')
  	<add-payment-component></add-payment-component>
@endsection

