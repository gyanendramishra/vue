@extends('users.master')
@section('page_header_title')
	Add <span>Services</span>
@endsection
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        Add services
    </li>
@endsection

@section('dashboard_content')
  	<add-service-component></add-service-component>
@endsection

