<template>
    <div class="mainWpapContainer">
        <div class="login-sec register-page">
            <div class="container">
                <div v-if="isRegistered === false">
                    <div class="login-title">
                        <h1>Regis<span>ter</span></h1>
                    </div>
                    <div class="login-box">
                        <div class="loginForm">
                            <form @submit.prevent="register">
                                <div class="field-required">
                                    <p>Please fill the fields given below</p>
                                </div>
                                <div class="login-form-row">
                                    <div class="form-group">
                                        <label>
                                            Name 
                                            <span class="red-color">*</span>
                                        </label>
                                        <div class="form-icon-col">
                                            <i class="fa fa-user"></i> 
                                            <input type="text" placeholder="Enter Your Name" name="name" v-model="fields.name">
                                        </div>
                                        <div v-if="errors && errors.name" class="text-danger">
                                            {{ errors.name[0] }}
                                        </div>
                                    </div>
                                    <div class="form-group last-input">
                                        <label>
                                            E-Mail Address 
                                            <span class="red-color">*</span>
                                        </label>
                                        <div class="form-icon-col">
                                            <i class="fa fa-envelope"></i> 
                                            <input type="text" placeholder="Enter Your Email" name="email" v-model="fields.email">
                                        </div>
                                        <div v-if="errors && errors.email" class="text-danger">
                                            {{ errors.email[0] }}
                                        </div>
                                    </div>
                                </div>
                                <div class="login-form-row">
                                    <div class="form-group">
                                        <label>
                                            Password 
                                            <span class="red-color">*</span>
                                        </label>
                                        <div class="form-icon-col">
                                            <i class="fa fa-lock"></i> 
                                            <input type="password" placeholder="Enter Your Password" name="password" v-model="fields.password">
                                        </div>
                                        <div v-if="errors && errors.password" class="text-danger">
                                            {{ errors.password[0] }}
                                        </div>
                                    </div>
                                    <div class="form-group last-input">
                                        <label>
                                            Confirm Password 
                                            <span class="red-color">*</span>
                                        </label>
                                        <div class="form-icon-col">
                                            <i class="fa fa-lock"></i> 
                                            <input type="password" placeholder="Confirm Your Password" name="confirm_password" v-model="fields.confirm_password">
                                        </div>
                                        <div v-if="errors && errors.confirm_password" class="text-danger">
                                            {{ errors.confirm_password[0] }}
                                        </div>
                                    </div>
                                </div>
                                <div class="login-form-row">
                                    <div class="form-group">
                                        <label>
                                            Mobile number 
                                            <span class="red-color">*</span>
                                        </label>
                                        <div class="form-icon-col">
                                            <i class="fa fa-phone"></i> 
                                            <input type="text" placeholder="Enter Your Mobile Number" name="mobile" v-model="fields.mobile">
                                        </div>
                                        <div v-if="errors && errors.mobile" class="text-danger">
                                            {{ errors.mobile[0] }}
                                        </div>
                                    </div>
                                    <div class="form-group last-input">
                                        <div class="form-group">
                                            <label>
                                                Profile Photo
                                            </label>
                                            <input type="file" placeholder="" name="profile_photo_file" ref="profile_photo_file" v-on:change="handleFileUpload()">
                                            <div v-if="errors && errors.profile_photo_file" class="text-danger">
                                                {{ errors.profile_photo_file[0] }}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="login-form-row">
                                    <div class="form-group-1">
                                        <div class="checkbox abc-checkbox propertyCheck">
                                            <input type="checkbox" class="styled" id="checkbox1" name="accept" v-model="fields.accept">
                                            <label for="checkbox1"> Accept <span><a href="/terms-and-conditions" target="_blank">terms & conditions</a> </span></label>
                                        </div>
                                        <div v-if="errors && errors.accept" class="text-danger">
                                            {{ errors.accept[0] }}
                                        </div>
                                    </div>
                                </div>
                                <div class="full-btn-col">
                                    <div v-if="!loading">
                                        <input type="submit" value="Register" name="">
                                    </div>
                                    <div v-else>
                                        <input type="submit" value="loading..." disable="disabled">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div v-else>
                    <div class="login-title">
                        <h1>Verify <span>Account</span></h1>
                    </div>
                    <div class="login-box verify-email-box">
                        <div class="loginForm">
                            <form @submit.prevent="verify">
                                <div class="field-required">
                                    <p>Please verify your account</p>
                                </div>
                                <div class="login-form-row">
                                    <div class="form-group">
                                        <label>
                                            OTP 
                                            <span class="red-color">*</span>
                                        </label>
                                        <div class="form-icon-col">
                                            <i class="fa fa-user"></i> 
                                            <input type="text" placeholder="OTP" name="verification_otp" v-model="fields.verification_otp">
                                        </div>
                                        <div v-if="errors && errors.verification_otp" class="text-danger">
                                            {{ errors.verification_otp[0] }}
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div v-if="!loading">
                                            <div>
                                                <input type="submit" value="Verify" name="">
                                            </div> 
                                            <div class="forgotPassword">
                                                <a href="javascript:;" @click="resendOtp">Resend OTP</a>
                                            </div>
                                        </div>
                                        <div v-else>
                                            <input type="submit" value="loading..." disable="disabled">
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                isRegistered : false,
                loading : false,
                fields: {},
                errors: {},
            }
        },
        methods: {
            register() {
                this.loading = true;
                this.errors = {};
                /*
                    Initialize the form data
                */
                let formData = new FormData();

                /*
                    Add the form data we need to submit
                */
                if(this.fields.name){
                    formData.append('name', this.fields.name);
                }
                if(this.fields.email){
                    formData.append('email', this.fields.email);
                }
                if(this.fields.password){
                    formData.append('password', this.fields.password);
                }
                if(this.fields.confirm_password){
                    formData.append('confirm_password', this.fields.confirm_password);
                }
                if(this.fields.mobile){
                    formData.append('mobile', this.fields.mobile);
                }
                if(this.fields.profile_photo_file){
                    formData.append('profile_photo_file', this.fields.profile_photo_file);
                }
                if(this.fields.accept){
                    formData.append('accept', this.fields.accept);
                }
                
                axios.post('/register', formData, {
                    headers:{
                        'Content-Type': 'multipart/form-data'
                    }
                }).then(response => {
                    if(response.data.status === true){
                        this.isRegistered = true;
                        flash(response.data.message, 'success');
                    }else{
                        flash(response.data.message, 'error');
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },

            resendOtp() {
                this.errors = {};
                axios.post('/resend/otp', this.fields).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                    }else{
                        flash(response.data.message, 'error');
                    }
                }).catch(error => {
                    this.errors = error;
                    console.log(this.errors);
                });
            },

            verify() {
                this.loading = true;
                this.errors = {};
                axios.post('/email/verify', this.fields).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                        window.location = '/user/dashboard';
                    }else{
                        flash(response.data.message, 'error');
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },
            /*
                Handles a change on the file upload
            */
            handleFileUpload(){
                this.fields.profile_photo_file = this.$refs.profile_photo_file.files[0];
            }
        },
    }
</script>
