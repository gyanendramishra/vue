<template>
    <div class="formBox editProfileForm">
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div v-if="isPaymentAdded === false">
                    <div class="field-required">
                        <p>Add payment detail</p>
                    </div>
                    <form @submit.prevent="addAccount">
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Country Code
                                    <span class="red-color">*</span>
                                </label>
                                <select v-model="fields.stripe_country">
                                    <option value="">Select Country code</option>
                                    <option value="AU">Australia </option>
                                    <option value="US">USA </option>
                                </select>
                                <div v-if="errors && errors.stripe_country" class="text-danger">
                                    {{ errors.stripe_country[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Email
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Email" v-model="fields.stripe_email">
                                <div v-if="errors && errors.stripe_email" class="text-danger">
                                    {{ errors.stripe_email[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="full-btn-col">
                            <div v-if="!loading">
                                <input type="submit" value="Submit" name="">
                            </div>
                            <div v-else>
                                <input type="submit" value="loading..." disable="disabled">
                            </div>
                        </div>
                    </form>
                </div>
                <div v-else>
                    <div class="field-required">
                        <p>Update payment detail</p>
                    </div>
                    <form @submit.prevent="UpdateAccount">
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    First Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="First Name" v-model="fields.first_name">
                                <div v-if="errors && errors.first_name" class="text-danger">
                                    {{ errors.first_name[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Last Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Last Name" v-model="fields.last_name">
                                <div v-if="errors && errors.last_name" class="text-danger">
                                    {{ errors.last_name[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Date of birth (must be atleast 13 year old)
                                    <span class="red-color">*</span>
                                </label>
                                <date-picker v-model="fields.dob" placeholder="Date of birth" lang="en"></date-picker>
                                <div v-if="errors && errors.dob" class="text-danger">
                                    {{ errors.dob[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Address
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Address" v-model="fields.address">
                                <div v-if="errors && errors.address" class="text-danger">
                                    {{ errors.address[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Country Code
                                    <span class="red-color">*</span>
                                </label>
                                <select v-model="fields.country">
                                    <option disabled value="">Select Country</option>
                                    <option value="AU">Australia </option>
                                    <option value="US">USA </option>
                                </select>
                                <div v-if="errors && errors.country" class="text-danger">
                                    {{ errors.country[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    State
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Address" v-model="fields.state">
                                <div v-if="errors && errors.state" class="text-danger">
                                    {{ errors.state[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    City
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="City" v-model="fields.city">
                                <div v-if="errors && errors.city" class="text-danger">
                                    {{ errors.city[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Postal Code
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Postal Code" v-model="fields.postal_code">
                                <div v-if="errors && errors.postal_code" class="text-danger">
                                    {{ errors.postal_code[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Business Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Business Name" v-model="fields.stripe_business_name">
                                <div v-if="errors && errors.stripe_business_name" class="text-danger">
                                    {{ errors.stripe_business_name[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Legal Business Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Legal Business Name" v-model="fields.legal_business_name">
                                <div v-if="errors && errors.legal_business_name" class="text-danger">
                                    {{ errors.legal_business_name[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Account Holder Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Account Holder Name" v-model="fields.account_holder_name">
                                <div v-if="errors && errors.account_holder_name" class="text-danger">
                                    {{ errors.account_holder_name[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Account Number
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Account Number" v-model="fields.account_number">
                                <div v-if="errors && errors.account_number" class="text-danger">
                                    {{ errors.account_number[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Sort Code
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Sort Code" v-model="fields.sort_code">
                                <div v-if="errors && errors.sort_code" class="text-danger">
                                    {{ errors.sort_code[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Currency
                                    <span class="red-color">*</span>
                                </label>
                                <select v-model="fields.currency">
                                    <option disabled value="">Select Country</option>
                                    <option value="AUD">AUD </option>
                                    <option value="USD">USD </option>
                                </select>
                                <div v-if="errors && errors.currency" class="text-danger">
                                    {{ errors.currency[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="full-btn-col">
                            <div v-if="!loading">
                                <input type="submit" value="Submit" name="">
                            </div>
                            <div v-else>
                                <input type="submit" value="loading..." disable="disabled">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    //require('bootstrap-datepicker/dist/js/bootstrap-datepicker.js');
    import DatePicker from 'vue2-datepicker'
    export default {
        name: "add-payment-component",
        components: { DatePicker },
        data: function () {
            return {
                fields:{},
                errors: {},
                loading: false,
                isPaymentAdded : false
            }
        },
        methods: {
            addAccount() {
                this.loading = true;
                this.errors = {};
                axios.post('/user/add/account', this.fields).then(response => {
                    if(response.data.status === true){
                        this.isPaymentAdded = true;
                        flash(response.data.message, 'success');
                    }else{
                        if(response.data.error){
                            var message =  response.data.error[0];
                            flash(message.replace('_', ' '), 'error');
                        }else{
                            flash(response.data.message, 'error');
                        }
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },
            UpdateAccount() {
                this.loading = true;
                this.errors = {};
                axios.post('/user/update/account', this.fields).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                        window.location = "/user/dashboard"
                    }else{
                        if(response.data.error){
                            var message =  response.data.error[0];
                            flash(message.replace('_', ' '), 'error');
                        }else{
                            flash(response.data.message, 'error');
                        }
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },

        },
        mounted(){
            //this.$refs.email.datepicker();
        }
    }
</script>

