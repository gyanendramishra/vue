<template>
    <div>
        <div class="formBox editProfileForm">
            <div class="formBoxInner">
                <div class="dashbord-sec">

                    <form @submit.prevent="addService">
                        <div class="field-required">
                            <p>Please fill the detail given below</p>
                        </div>
                    
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Job Title 
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Job Title" v-model="fields.title">
                                <div v-if="errors && errors.title" class="text-danger">
                                    {{ errors.title[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Select Service 
                                    <span class="red-color">*</span>
                                </label>
                                <select v-model="fields.parent_service_id" v-on:change="getSubCategories()">
                                    <option  value="" selected="true">Select Service</option>
                                    <option v-for="parentCategory in parentCategories" :value="parentCategory.id">{{ parentCategory.title }}</option>
                                </select>
                                <div v-if="errors && errors.parent_service_id" class="text-danger">
                                    {{ errors.parent_service_id[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Select Service Category 
                                    <span class="red-color">*</span>
                                </label>
                                <select v-model="fields.category_id">
                                    <option disabled value="">Select Service Category</option>
                                    <option v-for="subCategory in SubCategories" :value="subCategory.id">{{ subCategory.title }}</option>
                                </select>
                                <div v-if="errors && errors.category_id" class="text-danger">
                                    {{ errors.category_id[0] }}
                                </div>
                            </div>
                            <div class="form-group last-input">
                                <label>
                                    Address 
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Address" name="address" ref="address" @click="populateModal" v-model="fields.address">
                                <input type="hidden" placeholder="Address" name="latitude" v-model="fields.latitude">
                                <input type="hidden" placeholder="Address" name="longitude"  v-model="fields.longitude" lazy>
                                <div v-if="errors && errors.address" class="text-danger">
                                    {{ errors.address[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Min Ammount 
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="" v-model="fields.price">
                                <div v-if="errors && errors.price" class="text-danger">
                                    {{ errors.price[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Choose Banner image <span class="red-color">*</span></label>
                                <input type="file" placeholder="" ref="image_file" v-on:change="handleFileUpload()">
                                <div v-if="errors && errors.image_file" class="text-danger">
                                    {{ errors.image_file[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row full-input-box">
                            <div class="form-group">
                                <label>
                                    Description 
                                    <span class="red-color">*</span>
                                </label>
                                <textarea v-model="fields.description"></textarea>
                                <div v-if="errors && errors.description" class="text-danger">
                                    {{ errors.description[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="full-btn-col">
                            <div v-if="!loading">
                                <input type="submit" value="Submit" name="">
                            </div>
                            <div v-else>
                                <input type="submit" value="loading..." disable="disabled">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal address-field-map-model" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Select your address</h5>
                </div>
                <div class="modal-body" ref="address_field_google_map"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Use this location</button>
                </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    //require('bootstrap-datepicker/dist/js/bootstrap-datepicker.js');
    //import AddressOnMapComponent from './../fields/AddressOnMapComponent.vue';
    import GoogleMapsLoader from 'google-maps'
    GoogleMapsLoader.KEY = 'AIzaSyDViIP3wUAOLAGs1fWCak4PnQuGw4YnSZQ';
    export default {
        name: "add-service-component",
        data: function () {
            return {
                fields:{},
                errors: {},
                loading: false,
                parentCategories: {},
                SubCategories: {}
            }
        },
        methods: {
            addService() {
                
                this.loading = true;
                this.errors = {};
                /*
                    Initialize the form data
                */
                let formData = new FormData();

                /*
                    Add the form data we need to submit
                */
                if(this.fields.title){
                    formData.append('title', this.fields.title);
                }
                if(this.fields.parent_service_id){
                    formData.append('parent_service_id', this.fields.parent_service_id);
                }
                if(this.fields.category_id){
                    formData.append('category_id', this.fields.category_id);
                }
                if(this.fields.address){
                    formData.append('address', this.fields.address);
                }
                if(this.fields.latitude){
                    formData.append('latitude', this.fields.latitude);
                }
                if(this.fields.longitude){
                    formData.append('longitude', this.fields.longitude);
                }
                if(this.fields.price){
                    formData.append('price', this.fields.price);
                }
                if(this.fields.description){
                    formData.append('description', this.fields.description);
                }
                if(this.fields.image_file){
                    formData.append('image_file', this.fields.image_file);
                }

                axios.post('/user/service/save', formData, {
                    headers:{
                        'Content-Type': 'multipart/form-data'
                    }
                }).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                        window.location = '/user/dashboard';
                    }else{
                        flash(response.data.message, 'error');
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },
            getParentCategories() {
                this.errors = {};
                axios.get('/user/service/parent/categories').then(response => {
                    if(response.data.status === true){
                        this.SubCategories = {};
                        this.parentCategories = response.data.data.main_category;
                    }else{
                        console.log(response.data.message);
                    }
                }).catch(error => {
                    this.errors = error;
                    console.log(this.errors);
                });
            },

            getSubCategories() {
                this.errors = {};
                axios.post('/user/service/sub/categories', {parent_id: this.fields.parent_service_id}).then(response => {
                    if(response.data.status === true){
                        this.SubCategories = response.data.data.categories;
                    }else{
                        console.log(response.data.message);
                    }
                }).catch(error => {
                    this.errors = error;
                    console.log(this.errors);
                });
            },

            /*
                Handles a change on the file upload
            */
            handleFileUpload(){
                this.fields.image_file = this.$refs.image_file.files[0];
            },

            populateModal() {
                $('.modal').modal('show');
            },

        },

        mounted: function () {
            this.getParentCategories();

            var vm = this;
            vm.fields = {};
            GoogleMapsLoader.load(function(google) {
                let geocoder = new google.maps.Geocoder();
                let infowindow = new google.maps.InfoWindow();
                let myLatlng = new google.maps.LatLng(26.9124,75.7873);
                let map = new google.maps.Map(vm.$refs.address_field_google_map, {
                    zoom: 15,
                    center: myLatlng,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                });

                var marker = new google.maps.Marker(
                    {
                        position: myLatlng,
                        map: map,
                        draggable:true
                    }
                );
                geocoder.geocode({'latLng': myLatlng }, function(results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        if (results[0]) {
                            vm.fields.latitude = marker.position.lat().toFixed(6);
                            vm.fields.longitude = marker.position.lng().toFixed(6);
                            vm.fields.address = results[0].formatted_address;
                            vm.$refs.address.value = results[0].formatted_address;

                            infowindow.setContent(results[0].formatted_address);
                            infowindow.open(map, marker);
                        }
                    }       
                });
                google.maps.event.addListener(
                    marker,
                    'dragend',
                    function() {
                        geocoder.geocode({'latLng': marker.getPosition()}, function(results, status) {
                            if (status == google.maps.GeocoderStatus.OK) {
                                if (results[0]) {
                                    vm.fields.latitude = marker.position.lat().toFixed(6);
                                    vm.fields.longitude = marker.position.lng().toFixed(6);
                                    vm.fields.address = results[0].formatted_address;
                                    vm.$refs.address.value = results[0].formatted_address;
                                    infowindow.setContent(results[0].formatted_address);
                                    infowindow.open(map, marker);
                                }
                            }
                        });
                });  
            });
        }
        
    }
</script>
<style scoped>
    .address-field-map-model .modal-body {
        width: 100%;
        height: 400px;
    }
</style>

