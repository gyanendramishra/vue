<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\ServicesService;
use App\Http\Requests\ServiceRequest;

class UserServiceController extends Controller
{ 

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {}

    /**
     * Show the application user dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(){
    
        //return view('users.dashboard');
    }

    /**
     * Show the application create service view.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function createService(Request $request){
        $user = $request->session()->get('auth_user');
        if(!$user->isServiceProvider){
            $message = "You can't perform this actions. please switch your accout to as service provider.";
            return view('errors.500', compact('message'));
        }
        return view('users.services.add');
    }

    /**
     * Save use service.
     *
     * @param App\Http\Requests\ServiceRequest $request
     * @param ServicesService $service
     * @return \Illuminate\Http\Response
     */
    public function saveService(ServiceRequest $request, ServicesService $service){
        try{
            $file = $request->file('image_file');
            $data = [
                        [
                            'name'     => 'title',
                            'contents' => $request->title,
                            'headers'  => [
                                            'content-type' => 'application/x-www-form-urlencoded',
                                        ]
                        ],
                        [
                            'name' => 'category_id',
                            'contents' => $request->category_id,
                            'headers' => [
                                            'content-type' => 'application/x-www-form-urlencoded',
                                        ]
                        ],
                        [
                            'name' => 'address',
                            'contents' => $request->address,
                            'headers' => [
                                        'content-type' => 'application/x-www-form-urlencoded',
                                    ]
                        ],
                        [
                            'name' => 'longitude',
                            'contents' => $request->longitude,
                            'headers' => [
                                        'content-type' => 'application/x-www-form-urlencoded',
                                    ]
                        ],
                        [
                            'name' => 'latitude',
                            'contents' => $request->latitude,
                            'headers' => [
                                        'content-type' => 'application/x-www-form-urlencoded',
                                    ]
                        ],
                        [
                            'name' => 'description',
                            'contents' => $request->description,
                            'headers' => [
                                        'content-type' => 'application/x-www-form-urlencoded',
                                    ]
                        ],
                        [
                            'name' => 'price',
                            'contents' => $request->price,
                            'headers' => [
                                        'content-type' => 'application/x-www-form-urlencoded',
                                    ]
                        ],
                        [
                            'name' => 'image_file',
                            'filename' => $file->getClientOriginalName(),
                            'Mime-Type'=> $file->getmimeType(),
                            'contents' => fopen($file->getPathname(), 'r'),
                            'headers' => [
                                        'content-type' => 'multipart/form-data',
                                    ]
                        ],
                        
                ];
            $response = $service->addServiceServices($data);
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Get the parent service categories.
     *
     * @param Request $request
     * @param ServicesService $service
     * @return \Illuminate\Http\Response
     */
    public function getParentServiceCategories(Request $request, ServicesService $service){
        try{
            $response = $service->getParentCategoryServices();
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Get the parent service categories.
     *
     * @param Request $request
     * @param ServicesService $service
     * @return \Illuminate\Http\Response
     */
    public function getSubServiceCategories(Request $request, ServicesService $service){
        try{
            $response = $service->getSubCategoryServices($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
