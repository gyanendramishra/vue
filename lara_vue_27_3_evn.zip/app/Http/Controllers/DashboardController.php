<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\UserService;

class DashboardController extends Controller
{ 

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {}

    /**
     * Show the application user dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request){
        $user = $request->session()->get('auth_user');
        return view('users.dashboard');
    }

    /**
     * Show the application user profile.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function profile(Request $request){
        $user = $request->session()->get('auth_user');
        return view('users.profile', compact('user'));
    }


    /**
     * Switch account.
     *
     * @param  Request $request
     * @param  (string) $accountType
     * @return \Illuminate\Http\Response
     */
    public function switchAccountAs(Request $request, $accountType){
        try{
            $user = $request->session()->get('auth_user');
            if($accountType == 'service-provider'){
                $user->isServiceProvider = true;
            }else{
                $user->isServiceProvider = false;
            }
            $request->session()->forget('auth_user');
            $request->session()->put('auth_user', $user);

            return redirect()->route('user.dashboard');

        }catch(\Exception $e){
            $message = $e->getMessage();
            return view('errors.500', compact('message'));
        }
    }
}
