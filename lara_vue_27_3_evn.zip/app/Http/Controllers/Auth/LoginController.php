<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Services\AuthService;
use App\Http\Requests\LoginRequest;
use App\Http\Controllers\Controller;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {

        $this->middleware('guest')->except('logout');
    }

    /**
     * Show the application login form.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(){
        return view('auth.login');
    }

    /**
     * Login the user.
     *
     * @param  LoginRequest $request
     * @param  AuthService $service
     * @return Illuminate\Http\Response
     */
    public function login(LoginRequest $request, AuthService $service){
        try{
            $data = [
                'email' => $request->email,
                'password' => $request->password,
                'device_type' =>'Web',
                'device_id' => 123456,
            ];
            $response = $service->loginService($data);

            if($response->status == true){
                $request->session()->forget('auth_user');
                $request->session()->put('auth_user', $response->data);
            }

            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>"Somthing went wrong try again later."
            ], 200);
        }

    }

    /**
     * Logout the user.
     *
     * @param  LoginRequest $request
     * @param  AuthService $service
     * @return Illuminate\Http\Response
     */
    public function logout(Request $request, AuthService $service){
        try{
            $response = $service->logoutService();
        }catch(\Exception $e){}
        $request->session()->forget('auth_user');
        return redirect()->route('user.login.form');
    }
}
