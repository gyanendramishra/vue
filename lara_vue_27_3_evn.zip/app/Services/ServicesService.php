<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class ServicesService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/services/';

    /**
     * Get the parent servic categories.
     *
     * @return Illuminate\Http\Response
     */
    public function getParentCategoryServices() {

        $uri = $this->base_uri;
        $uri .= 'getService';
        return $this->getServiceRequest($uri);
    }

    /**
     * Get the sub servic categories.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function getSubCategoryServices($data) {

        $uri = 'api/categories/sublisting';

        return $this->postServiceRequest($uri, $data);
    }

    /**
     * Add service.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function addServiceServices($data) {

        $uri = $this->base_uri;
        $uri .= 'add';

        return $this->postFileRequest($uri, $data);
    }

    /**
     * Add payment service.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function addStripeAccountServices($data) {

        $uri = 'api/stripes/addAccount';

        return $this->postServiceRequest($uri, $data);
    }

    /**
     * Add payment service.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function updateStripeAccountServices($data) {

        $uri = 'api/stripes/updateAccount';

        return $this->postServiceRequest($uri, $data);
    }

    

}