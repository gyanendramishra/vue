<template>
    <div class="formBox editProfileForm">
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div v-if="isPaymentAdded === false">
                    <div class="field-required">
                        <p>Add payment detail</p>
                    </div>
                    <form @submit.prevent="addAccount">
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Country Code
                                    <span class="red-color">*</span>
                                </label>
                                <select v-model="fields.stripe_country" class="country-picker">
                                    <option value="">Select Country code</option>
                                    <option value="AU">Australia </option>
                                    <option value="US">USA </option>
                                </select>
                                <div v-if="errors && errors.stripe_country" class="text-danger">
                                    {{ errors.stripe_country[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Email
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Email" class="country-picker" v-model="fields.stripe_email">
                                <div v-if="errors && errors.stripe_email" class="text-danger">
                                    {{ errors.stripe_email[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="full-btn-col">
                            <div v-if="!loading">
                                <input type="submit" value="Submit" name="">
                            </div>
                            <div v-else>
                                <input type="submit" value="loading..." disable="disabled">
                            </div>
                        </div>
                    </form>
                </div>
                <div v-else>
                    <div class="field-required">
                        <p>Update payment detail</p>
                    </div>
                    <form @submit.prevent="UpdateAccount">
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    First Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="First Name" v-model="fields.first_name">
                                <div v-if="errors && errors.first_name" class="text-danger">
                                    {{ errors.first_name[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Last Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Last Name" v-model="fields.last_name">
                                <div v-if="errors && errors.last_name" class="text-danger">
                                    {{ errors.last_name[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Date of birth (must be atleast 13 year old)
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" class="datepicker" placeholder="Date of birth" v-model="fields.dob">
                                <div v-if="errors && errors.dob" class="text-danger">
                                    {{ errors.dob[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Address
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Address" v-model="fields.address">
                                <div v-if="errors && errors.address" class="text-danger">
                                    {{ errors.address[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Country Code
                                    <span class="red-color">*</span>
                                </label>
                                <select v-model="fields.country">
                                    <option disabled value="">Select Country</option>
                                    <option value="AU">Australia </option>
                                    <option value="US">USA </option>
                                </select>
                                <div v-if="errors && errors.country" class="text-danger">
                                    {{ errors.country[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    State
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Address" v-model="fields.state">
                                <div v-if="errors && errors.state" class="text-danger">
                                    {{ errors.state[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    City
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="City" v-model="fields.city">
                                <div v-if="errors && errors.city" class="text-danger">
                                    {{ errors.city[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Postal Code
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Postal Code" v-model="fields.postal_code">
                                <div v-if="errors && errors.postal_code" class="text-danger">
                                    {{ errors.postal_code[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Business Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Business Name" v-model="fields.stripe_business_name">
                                <div v-if="errors && errors.stripe_business_name" class="text-danger">
                                    {{ errors.stripe_business_name[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Legal Business Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Legal Business Name" v-model="fields.legal_business_name">
                                <div v-if="errors && errors.legal_business_name" class="text-danger">
                                    {{ errors.legal_business_name[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Account Holder Name
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Account Holder Name" v-model="fields.account_holder_name">
                                <div v-if="errors && errors.account_holder_name" class="text-danger">
                                    {{ errors.account_holder_name[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Account Number
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Account Number" v-model="fields.account_number">
                                <div v-if="errors && errors.account_number" class="text-danger">
                                    {{ errors.account_number[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>
                                    Sort Code
                                    <span class="red-color">*</span>
                                </label>
                                <input type="text" placeholder="Sort Code" v-model="fields.sort_code">
                                <div v-if="errors && errors.sort_code" class="text-danger">
                                    {{ errors.sort_code[0] }}
                                </div>
                            </div>
                            <div class="form-group">
                                <label>
                                    Currency
                                    <span class="red-color">*</span>
                                </label>
                                <select v-model="fields.currency">
                                    <option disabled value="">Select Country</option>
                                    <option value="AUD">AUD </option>
                                    <option value="USD">USD </option>
                                </select>
                                <div v-if="errors && errors.currency" class="text-danger">
                                    {{ errors.currency[0] }}
                                </div>
                            </div>
                        </div>
                        <div class="full-btn-col">
                            <div v-if="!loading">
                                <input type="submit" value="Submit" name="">
                            </div>
                            <div v-else>
                                <input type="submit" value="loading..." disable="disabled">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import "bootstrap-datepicker/dist/css/bootstrap-datepicker.css";
    import "select2/dist/css/select2.css";
    import "flag-icon-css/css/flag-icon.css";
    import datepicker from "bootstrap-datepicker";
    //import select2 from "select2";
    import 'select2/dist/js/select2.full.js'
    export default {
        name: "add-payment-component",
        data: function () {
            return {
                fields:{
                    stripe_country: "",
                    country: "",
                    currency: "",
                },
                errors: {},
                loading: false,
                isPaymentAdded : false,
                isoCountries : [
                    { id: 'AF', text: 'Afghanistan' , currency: 'AFN'},
                    { id: 'AL', text: 'Albania', currency: 'ALL'},
                    { id: 'DZ', text: 'Algeria', currency: 'DZD'},
                    { id: 'AS', text: 'American Samoa', currency: 'USD'},
                    { id: 'AD', text: 'Andorra', currency: 'EUR'},
                    { id: 'AO', text: 'Angola', currency: 'AOA'},
                    { id: 'AI', text: 'Anguilla', currency: 'XCD'},
                    { id: 'AG', text: 'Antigua And Barbuda', currency: 'XCD'},
                    { id: 'AR', text: 'Argentina', currency: 'ARS'},
                    { id: 'AM', text: 'Armenia', currency: 'AMD'},
                    { id: 'AW', text: 'Aruba', currency: 'AWG'},
                    { id: 'AU', text: 'Australia', currency: 'AUD'},
                    { id: 'AT', text: 'Austria', currency: 'EUR'},
                    { id: 'AZ', text: 'Azerbaijan', currency: 'AZN'},
                    { id: 'BS', text: 'Bahamas', currency: 'BSD'},
                    { id: 'BH', text: 'Bahrain', currency: 'BHD'},
                    { id: 'BD', text: 'Bangladesh', currency: 'BDT'},
                    { id: 'BB', text: 'Barbados', currency: 'BBD'},
                    { id: 'BY', text: 'Belarus', currency: 'BYR'},
                    { id: 'BE', text: 'Belgium', currency: 'EUR'},
                    { id: 'BZ', text: 'Belize', currency: 'BZD'},
                    { id: 'BJ', text: 'Benin', currency: 'XOF'},
                    { id: 'BM', text: 'Bermuda', currency: 'BMD'},
                    { id: 'BT', text: 'Bhutan', currency: 'BTN'},
                    { id: 'BO', text: 'Bolivia', currency: 'BOB'},
                    { id: 'BA', text: 'Bosnia And Herzegovina', currency: 'BAM'},
                    { id: 'BW', text: 'Botswana', currency: 'BWP'},
                    { id: 'BV', text: 'Bouvet Island', currency: 'NOK'},
                    { id: 'BR', text: 'Brazil', currency: 'BRL'},
                    { id: 'IO', text: 'British Indian Ocean Territory', currency: 'USD'},
                    { id: 'BN', text: 'Brunei Darussalam', currency: 'BND'},
                    { id: 'BG', text: 'Bulgaria', currency: 'BGN'},
                    { id: 'BF', text: 'Burkina Faso', currency: 'XOF'},
                    { id: 'BI', text: 'Burundi', currency: 'BIF'},
                    { id: 'KH', text: 'Cambodia', currency: 'KHR'},
                    { id: 'CM', text: 'Cameroon', currency: 'XAF'},
                    { id: 'CA', text: 'Canada', currency: 'CAD'},
                    { id: 'CV', text: 'Cape Verde', currency: 'BOB'},
                    { id: 'KY', text: 'Cayman Islands', currency: 'KYD'},
                    { id: 'CF', text: 'Central African Republic', currency: 'XAF'},
                    { id: 'TD', text: 'Chad', currency: 'XAF'},
                    { id: 'CL', text: 'Chile', currency: 'CLF'},
                    { id: 'CN', text: 'China', currency: 'CNY'},
                    { id: 'CX', text: 'Christmas Island'},
                    { id: 'CC', text: 'Cocos (Keeling) Islands'},
                    { id: 'CO', text: 'Colombia'},
                    { id: 'KM', text: 'Comoros'},
                    { id: 'CG', text: 'Congo'},
                    { id: 'CD', text: 'Congo}, Democratic Republic'},
                    { id: 'CK', text: 'Cook Islands'},
                    { id: 'CR', text: 'Costa Rica'},
                    { id: 'CI', text: 'Cote D\'Ivoire'},
                    { id: 'HR', text: 'Croatia'},
                    { id: 'CU', text: 'Cuba'},
                    { id: 'CY', text: 'Cyprus'},
                    { id: 'CZ', text: 'Czech Republic'},
                    { id: 'DK', text: 'Denmark'},
                    { id: 'DJ', text: 'Djibouti'},
                    { id: 'DM', text: 'Dominica'},
                    { id: 'DO', text: 'Dominican Republic'},
                    { id: 'EC', text: 'Ecuador'},
                    { id: 'EG', text: 'Egypt'},
                    { id: 'SV', text: 'El Salvador'},
                    { id: 'GQ', text: 'Equatorial Guinea'},
                    { id: 'ER', text: 'Eritrea'},
                    { id: 'EE', text: 'Estonia'},
                    { id: 'ET', text: 'Ethiopia'},
                    { id: 'FK', text: 'Falkland Islands (Malvinas)'},
                    { id: 'FO', text: 'Faroe Islands'},
                    { id: 'FJ', text: 'Fiji'},
                    { id: 'FI', text: 'Finland'},
                    { id: 'FR', text: 'France'},
                    { id: 'GF', text: 'French Guiana'},
                    { id: 'PF', text: 'French Polynesia'},
                    { id: 'TF', text: 'French Southern Territories'},
                    { id: 'GA', text: 'Gabon'},
                    { id: 'GM', text: 'Gambia'},
                    { id: 'GE', text: 'Georgia'},
                    { id: 'DE', text: 'Germany'},
                    { id: 'GH', text: 'Ghana'},
                    { id: 'GI', text: 'Gibraltar'},
                    { id: 'GR', text: 'Greece'},
                    { id: 'GL', text: 'Greenland'},
                    { id: 'GD', text: 'Grenada'},
                    { id: 'GP', text: 'Guadeloupe'},
                    { id: 'GU', text: 'Guam'},
                    { id: 'GT', text: 'Guatemala'},
                    { id: 'GG', text: 'Guernsey'},
                    { id: 'GN', text: 'Guinea'},
                    { id: 'GW', text: 'Guinea-Bissau'},
                    { id: 'GY', text: 'Guyana'},
                    { id: 'HT', text: 'Haiti'},
                    { id: 'HM', text: 'Heard Island & Mcdonald Islands'},
                    { id: 'VA', text: 'Holy See (Vatican City State)'},
                    { id: 'HN', text: 'Honduras'},
                    { id: 'HK', text: 'Hong Kong'},
                    { id: 'HU', text: 'Hungary'},
                    { id: 'IS', text: 'Iceland'},
                    { id: 'IN', text: 'India'},
                    { id: 'ID', text: 'Indonesia'},
                    { id: 'IR', text: 'Iran}, Islamic Republic Of'},
                    { id: 'IQ', text: 'Iraq'},
                    { id: 'IE', text: 'Ireland'},
                    { id: 'IM', text: 'Isle Of Man'},
                    { id: 'IL', text: 'Israel'},
                    { id: 'IT', text: 'Italy'},
                    { id: 'JM', text: 'Jamaica'},
                    { id: 'JP', text: 'Japan'},
                    { id: 'JE', text: 'Jersey'},
                    { id: 'JO', text: 'Jordan'},
                    { id: 'KZ', text: 'Kazakhstan'},
                    { id: 'KE', text: 'Kenya'},
                    { id: 'KI', text: 'Kiribati'},
                    { id: 'KR', text: 'Korea'},
                    { id: 'KW', text: 'Kuwait'},
                    { id: 'KG', text: 'Kyrgyzstan'},
                    { id: 'LA', text: 'Lao People\'s Democratic Republic'},
                    { id: 'LV', text: 'Latvia'},
                    { id: 'LB', text: 'Lebanon'},
                    { id: 'LS', text: 'Lesotho'},
                    { id: 'LR', text: 'Liberia'},
                    { id: 'LY', text: 'Libyan Arab Jamahiriya'},
                    { id: 'LI', text: 'Liechtenstein'},
                    { id: 'LT', text: 'Lithuania'},
                    { id: 'LU', text: 'Luxembourg'},
                    { id: 'MO', text: 'Macao'},
                    { id: 'MK', text: 'Macedonia'},
                    { id: 'MG', text: 'Madagascar'},
                    { id: 'MW', text: 'Malawi'},
                    { id: 'MY', text: 'Malaysia'},
                    { id: 'MV', text: 'Maldives'},
                    { id: 'ML', text: 'Mali'},
                    { id: 'MT', text: 'Malta'},
                    { id: 'MH', text: 'Marshall Islands'},
                    { id: 'MQ', text: 'Martinique'},
                    { id: 'MR', text: 'Mauritania'},
                    { id: 'MU', text: 'Mauritius'},
                    { id: 'YT', text: 'Mayotte'},
                    { id: 'MX', text: 'Mexico'},
                    { id: 'FM', text: 'Micronesia}, Federated States Of'},
                    { id: 'MD', text: 'Moldova'},
                    { id: 'MC', text: 'Monaco'},
                    { id: 'MN', text: 'Mongolia'},
                    { id: 'ME', text: 'Montenegro'},
                    { id: 'MS', text: 'Montserrat'},
                    { id: 'MA', text: 'Morocco'},
                    { id: 'MZ', text: 'Mozambique'},
                    { id: 'MM', text: 'Myanmar'},
                    { id: 'NA', text: 'Namibia'},
                    { id: 'NR', text: 'Nauru'},
                    { id: 'NP', text: 'Nepal'},
                    { id: 'NL', text: 'Netherlands'},
                    { id: 'AN', text: 'Netherlands Antilles'},
                    { id: 'NC', text: 'New Caledonia'},
                    { id: 'NZ', text: 'New Zealand'},
                    { id: 'NI', text: 'Nicaragua'},
                    { id: 'NE', text: 'Niger'},
                    { id: 'NG', text: 'Nigeria'},
                    { id: 'NU', text: 'Niue'},
                    { id: 'NF', text: 'Norfolk Island'},
                    { id: 'MP', text: 'Northern Mariana Islands'},
                    { id: 'NO', text: 'Norway'},
                    { id: 'OM', text: 'Oman'},
                    { id: 'PK', text: 'Pakistan'},
                    { id: 'PW', text: 'Palau'},
                    { id: 'PS', text: 'Palestinian Territory}, Occupied'},
                    { id: 'PA', text: 'Panama'},
                    { id: 'PG', text: 'Papua New Guinea'},
                    { id: 'PY', text: 'Paraguay'},
                    { id: 'PE', text: 'Peru'},
                    { id: 'PH', text: 'Philippines'},
                    { id: 'PN', text: 'Pitcairn'},
                    { id: 'PL', text: 'Poland'},
                    { id: 'PT', text: 'Portugal'},
                    { id: 'PR', text: 'Puerto Rico'},
                    { id: 'QA', text: 'Qatar'},
                    { id: 'RE', text: 'Reunion'},
                    { id: 'RO', text: 'Romania'},
                    { id: 'RU', text: 'Russian Federation'},
                    { id: 'RW', text: 'Rwanda'},
                    { id: 'BL', text: 'Saint Barthelemy'},
                    { id: 'SH', text: 'Saint Helena'},
                    { id: 'KN', text: 'Saint Kitts And Nevis'},
                    { id: 'LC', text: 'Saint Lucia'},
                    { id: 'MF', text: 'Saint Martin'},
                    { id: 'PM', text: 'Saint Pierre And Miquelon'},
                    { id: 'VC', text: 'Saint Vincent And Grenadines'},
                    { id: 'WS', text: 'Samoa'},
                    { id: 'SM', text: 'San Marino'},
                    { id: 'ST', text: 'Sao Tome And Principe'},
                    { id: 'SA', text: 'Saudi Arabia'},
                    { id: 'SN', text: 'Senegal'},
                    { id: 'RS', text: 'Serbia'},
                    { id: 'SC', text: 'Seychelles'},
                    { id: 'SL', text: 'Sierra Leone'},
                    { id: 'SG', text: 'Singapore'},
                    { id: 'SK', text: 'Slovakia'},
                    { id: 'SI', text: 'Slovenia'},
                    { id: 'SB', text: 'Solomon Islands'},
                    { id: 'SO', text: 'Somalia'},
                    { id: 'ZA', text: 'South Africa'},
                    { id: 'GS', text: 'South Georgia And Sandwich Isl.'},
                    { id: 'ES', text: 'Spain'},
                    { id: 'LK', text: 'Sri Lanka'},
                    { id: 'SD', text: 'Sudan'},
                    { id: 'SR', text: 'Suriname'},
                    { id: 'SJ', text: 'Svalbard And Jan Mayen'},
                    { id: 'SZ', text: 'Swaziland'},
                    { id: 'SE', text: 'Sweden'},
                    { id: 'CH', text: 'Switzerland'},
                    { id: 'SY', text: 'Syrian Arab Republic'},
                    { id: 'TW', text: 'Taiwan'},
                    { id: 'TJ', text: 'Tajikistan'},
                    { id: 'TZ', text: 'Tanzania'},
                    { id: 'TH', text: 'Thailand'},
                    { id: 'TL', text: 'Timor-Leste'},
                    { id: 'TG', text: 'Togo'},
                    { id: 'TK', text: 'Tokelau'},
                    { id: 'TO', text: 'Tonga'},
                    { id: 'TT', text: 'Trinidad And Tobago'},
                    { id: 'TN', text: 'Tunisia'},
                    { id: 'TR', text: 'Turkey'},
                    { id: 'TM', text: 'Turkmenistan'},
                    { id: 'TC', text: 'Turks And Caicos Islands'},
                    { id: 'TV', text: 'Tuvalu'},
                    { id: 'UG', text: 'Uganda'},
                    { id: 'UA', text: 'Ukraine'},
                    { id: 'AE', text: 'United Arab Emirates'},
                    { id: 'GB', text: 'United Kingdom'},
                    { id: 'US', text: 'United States'},
                    { id: 'UM', text: 'United States Outlying Islands'},
                    { id: 'UY', text: 'Uruguay'},
                    { id: 'UZ', text: 'Uzbekistan'},
                    { id: 'VU', text: 'Vanuatu'},
                    { id: 'VE', text: 'Venezuela'},
                    { id: 'VN', text: 'Viet Nam'},
                    { id: 'VG', text: 'Virgin Islands}, British'},
                    { id: 'VI', text: 'Virgin Islands}, U.S.'},
                    { id: 'WF', text: 'Wallis And Futuna'},
                    { id: 'EH', text: 'Western Sahara'},
                    { id: 'YE', text: 'Yemen'},
                    { id: 'ZM', text: 'Zambia'},
                    { id: 'ZW', text: 'Zimbabwe'}
                ]
            }
        },
        methods: {
            addAccount() {
                this.loading = true;
                this.errors = {};
                axios.post('/user/add/account', this.fields).then(response => {
                    if(response.data.status === true){
                        this.isPaymentAdded = true;
                        flash(response.data.message, 'success');
                    }else{
                        if(response.data.error){
                            var message =  response.data.error[0];
                            flash(message.replace('_', ' '), 'error');
                        }else{
                            flash(response.data.message, 'error');
                        }
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },
            UpdateAccount() {
                this.loading = true;
                this.errors = {};
                axios.post('/user/update/account', this.fields).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                        window.location = "/user/dashboard"
                    }else{
                        if(response.data.error){
                            var message =  response.data.error[0];
                            flash(message.replace('_', ' '), 'error');
                        }else{
                            flash(response.data.message, 'error');
                        }
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },

            formatCountry(country) {
              if (!country.id) { return country.text; }
              var $country = $(
                '<span class="flag-icon flag-icon-'+ country.id.toLowerCase() +' flag-icon-squared"></span> ' +
                '<span class="flag-text">'+ country.text+"</span>"
              );
              return $country;
            }

        },
        mounted(){
            $(".datepicker").datepicker({
                format: "dd-mm-yyyy"
            });

            $(".country-picker").select2({
                placeholder: "Select a country",
				templateResult: this.formatCountry,
                data: this.isoCountries
            });
        }
    }
</script>
<style scoped>
    .flag-text { margin-left: 10px; }
</style>

