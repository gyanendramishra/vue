<template>
    <div class="formBox editProfileForm">
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div class="field-required">
                    <p>Change your password</p>
                </div>
                <form @submit.prevent="changePassword">
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                Old Password
                                <span class="red-color">*</span>
                            </label>
                            <input type="password" placeholder="Password" v-model="fields.old_password">
                            <div v-if="errors && errors.old_password" class="text-danger">
                                {{ errors.old_password[0] }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                Password
                                <span class="red-color">*</span>
                            </label>
                            <input type="password" placeholder="Password" v-model="fields.password">
                            <div v-if="errors && errors.password" class="text-danger">
                                {{ errors.password[0] }}
                            </div>
                        </div>
                    </div>
                    <div class="form-row full-input-box">
                        <div class="form-group">
                            <label>
                                Confirm Password
                                <span class="red-color">*</span>
                            </label>
                            <input type="password" placeholder="Confirm Password" v-model="fields.confirm_password">
                            <div v-if="errors && errors.confirm_password" class="text-danger">
                                {{ errors.confirm_password[0] }}
                            </div>
                        </div>
                    </div>
                    <div class="full-btn-col">
                        <div v-if="!loading">
                            <input type="submit" value="Update" name="">
                        </div>
                        <div v-else>
                            <input type="submit" value="loading..." disable="disabled">
                        </div>
                    </div>
                </form>
                
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        name: "change-password-component",
        data: function () {
            return {
                fields:{},
                errors: {},
                loading: false
            }
        },
        methods: {
            changePassword() {
                this.loading = true;
                this.errors = {};
                axios.post('/user/update-password', this.fields).then(response => {
                    if(response.data.status === true){
                        this.field = {};
                        flash(response.data.message, 'success');
                    }else{
                        if(response.data.error){
                            var message =  response.data.error[0];
                            flash(message.replace('_', ' '), 'error');
                        }else{
                            flash(response.data.message, 'error');
                        }
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            }

        }
    }
</script>

