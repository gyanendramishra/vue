<template>
    <div>
        <div class="mainWpapContainer">
            <div class="login-sec">
                <div class="container">
                    <div class="login-title">
                        <h1>Log<span>In</span></h1>
                    </div>
                    <div class="login-box">
                        <div class="row">
                            <div class="col-md-6 left-log-bar">
                                <div class="left-log">
                                    <h2>Login with</h2>
                                    <div class="or-icon">or</div>
                                    <div class="login-social-icons">
                                        <a href="login/facebook">
                                            <img src="/images/fb_icon.png" alt="" />
                                        </a>
                                        <a href="login/google">
                                            <img src="/images/google_plus_icon.png" alt="" />
                                        </a>
                                    </div>
                                    <div class="login-left-bg">
                                        <img src="/images/login_laft_pannel_bg.png" alt="" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 right-log-bar">
                                <div class="loginForm">
                                    <div v-if="isVerified === true">
                                        <form @submit.prevent="login">
                                            <div class="form-group">
                                                <label>
                                                    Email address 
                                                    <span class="red-color">*</span>
                                                </label>
                                                <div class="form-icon-col">
                                                    <i class="fa fa-envelope"></i> 
                                                    <input type="text" placeholder="Email address" name="email" v-model="fields.email">
                                                </div>
                                                <div v-if="errors && errors.email" class="text-danger">
                                                    {{ errors.email[0] }}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>
                                                    Password 
                                                    <span class="red-color">*</span>
                                                </label>
                                                <div class="form-icon-col">
                                                    <i class="fa fa-lock"></i> 
                                                    <input type="password" placeholder="Password" name="password" v-model="fields.password">
                                                </div>
                                                <div v-if="errors && errors.password" class="text-danger">
                                                    {{ errors.password[0] }}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div v-if="!loading">
                                                    <input type="submit" value="Login" name="">
                                                </div>
                                                <div v-else>
                                                    <input type="submit" value="loading..." disable="disabled">
                                                </div>
                                                <div class="forgotPassword">
                                                    <a href="/password/reset">Forgot Password?</a> 
                                                </div>
                                            </div>
                                            <div class="form-group margin-B-0">
                                                If your are not an existing customer, you need to 
                                                <a href="/register">register</a>
                                            </div>
                                        </form>
                                    </div>
                                    <div v-else>
                                        <form @submit.prevent="verify">
                                            <div class="form-group">
                                                <label>
                                                    OTP 
                                                    <span class="red-color">*</span>
                                                </label>
                                                <div class="form-icon-col">
                                                    <i class="fa fa-envelope"></i> 
                                                    <input type="text" placeholder="OTP" name="verification_otp" v-model="fields.verification_otp">
                                                </div>
                                                <div v-if="errors && errors.verification_otp" class="text-danger">
                                                    {{ errors.verification_otp[0] }}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div v-if="!loading">
                                                    <div>
                                                        <input type="submit" value="Verify" name="">
                                                    </div> 
                                                    <div class="forgotPassword">
                                                        <a href="javascript:;" @click="resendOtp">Resend OTP</a>
                                                    </div>
                                                </div>
                                                <div v-else>
                                                    <input type="submit" value="loading..." disable="disabled">
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="login-type-step" v-show="step === 2">
            <div class="login-type-step-inner">
                <h3>Switch account as</h3>
                <div class="login-type-btn-col">
                    <a href="/user/switch-account-to/service-provider">
                        Service Provider
                    </a>
                    <a href="/user/switch-account-to/user">
                        User
                    </a>
                </div>
            </div> 
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                step : 1,
                isVerified: true,
                loading : false,
                fields: {},
                errors: {},
            }
        },
        methods: {
            login() {
                this.loading = true;
                this.errors = {};
                axios.post('/login', this.fields).then(response => {
                    if(response.data.status === true){
                        this.step = 2;
                        flash(response.data.message, 'success');
                        //window.location = '/user/dashboard';
                    }else{
                        if(response.data.code === 449){
                            this.isVerified = false;
                        }
                        if(response.data.error){
                            var message =  response.data.error[0];
                            flash(message.replace('_', ' '), 'error');
                        }else{
                            flash(response.data.message, 'error');
                        }
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            },

            resendOtp() {
                this.errors = {};
                axios.post('/resend/otp', this.fields).then(response => {
                    if(response.data.status === true){
                        flash(response.data.message, 'success');
                    }else{
                        if(response.data.error){
                            var message =  response.data.error[0];
                            flash(message.replace('_', ' '), 'error');
                        }else{
                            flash(response.data.message, 'error');
                        }
                    }
                }).catch(error => {
                    this.errors = error;
                    console.log(this.errors);
                });
            },

            verify() {
                this.loading = true;
                this.errors = {};
                axios.post('/email/verify', this.fields).then(response => {
                    if(response.data.status === true){
                        this.step = 2;
                        flash(response.data.message, 'success');
                        //window.location = '/user/dashboard';
                    }else{
                        if(response.data.error){
                            var message =  response.data.error[0];
                            flash(message.replace('_', ' '), 'error');
                        }else{
                            flash(response.data.message, 'error');
                        }
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    if (error.response.status === 422) {
                        this.errors = error.response.data.errors || {};
                    }
                });
            }
        },
    }
</script>
