@extends('users.master')
@section('page_header_title')
	Change <span>Password</span>
@endsection
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        Change Password
    </li>
@endsection

@section('dashboard_content')
  	<change-password-component></change-password-component>
@endsection

