<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class UserService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/users/';

    /**
     * Login the user.
     *
     * @param  array  $data
     * @return Illuminate\Http\Response
     */
    public function changePasswordService(array $data) {
        $uri = $this->base_uri;
        $uri .= 'changePassword'; 
        return $this->postServiceRequest($uri, $data);
    }

    

}