<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ServiceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title'       =>'bail|required|max:255',
            'parent_service_id' =>'bail|required|integer',
            'category_id' =>'bail|required|integer',
            'address'     => 'bail|required|max:255',
            'longitude'   => 'bail|required|max:255',
            'latitude'    => 'bail|required|max:255',
            'description' => 'bail|required|string',
            'price'       => 'bail|required|integer',
            'image_file'  => 'bail|required|image|mimes:jpg,png,jpeg'
        ];
    }

    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'parent_service_id.required' => 'The service field is required.',
            'parent_service_id.integer' => 'The service field should be integer.',
            'category_id.required' => 'The category field is required.',
            'category_id.integer' => 'The category field should be integer.',
            'image_file.required' => 'The file field is required.',
            'image_file.image' => 'The file must be an image. ',
            'image_file.mimes' => 'The file must be jpg,png,jpeg.',
        ];
    }
}
