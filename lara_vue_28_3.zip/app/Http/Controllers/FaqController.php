<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\CmsService;

class FaqController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request, CmsService $service) {
        try{
    		$page = $service->getFaq();
        	return view('faq', compact('page'));
    	}catch(\Exception $e){
    		$message = $e->getMessage();
    		return view('errors.500', compact('message'));
    	}
    }
}
