<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\ServicesService;
use App\Http\Requests\AddPaymentRequest;
use App\Http\Requests\UpdatePaymentRequest;

class StripeController extends Controller
{ 

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {}

    /**
     * Show the application create service view.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function addPayments(Request $request){
        
        return view('users.payments.add');
    }


    /**
     * Get the parent service categories.
     *
     * @param App\Http\Requests\AddPaymentRequest
     * @param ServicesService $service
     * @return \Illuminate\Http\Response
     */
    public function addAccount(AddPaymentRequest $request, ServicesService $service){
        try{
            $response = $service->addStripeAccountServices($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Get the parent service categories.
     *
     * @param App\Http\Requests\UpdatePaymentRequest $request
     * @param ServicesService $service
     * @return \Illuminate\Http\Response
     */
    public function updateAccount(UpdatePaymentRequest $request, ServicesService $service){
        try{
            $response = $service->updateStripeAccountServices($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }
}
