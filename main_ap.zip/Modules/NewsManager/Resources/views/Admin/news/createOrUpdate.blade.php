@extends('layouts.admin.app')
@section('title', !empty($ads) ? 'Edit News' : 'Add News')
@push('styles')
    <link href="{{ asset('/css/migration/jquery-ui.css') }}" rel="stylesheet" />
    <style>
        .hide{display: none;}
        
    </style>
@endpush
@section('content')

<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
         {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.news.index'],['label' => !empty($ads) ? 'Edit News' : 'Add News' ]]]) }}
    </div>
  </div>
   
  <div class="wojo-grid">

    
    @if(session()->has('success'))
        <div class="alert alert-success">
            {{ session()->get('success') }}
        </div>
    @endif

    <div class="wojo form segment">
      <div class="wojo secondary icon message"> 
        <div class="content">
          <div class="header">  {{ !empty($news) ? 'Edit News' : 'Add News' }}  </div>
        </div>
      </div>
        @if(isset($news))
            {{ Form::model($news, ['route' => ['admin.news.update', $news->id], 'method' => 'patch','enctype'=>'multipart/form-data']) }}
        @else
            {{ Form::open(['route' => 'admin.news.store','enctype'=>'multipart/form-data']) }}
        @endif

        @php
            $locales = config('app.locales');
        @endphp
        
        @include('layouts.flash.alert')
        
        <div class="wojo secondary message">
            <ul class="wojo tabs fixed clearfix">
                @foreach($locales as $key=>$val)
                    <li class="{{ ($key=='en')?'active':'' }}">
                        <a data-tab="#{{ $key.'_tab' }}" class="{{ ($key=='en')?'active show':'' }}">
                            {{ $val }}
                        </a>
                    </li>
                @endforeach
            </ul>

                @foreach($locales as $key=>$val)
                    <div id="{{ $key.'_tab' }}" class="wojo tab item " style="{{ ($key=='en')?'display: block;':'' }}">
                        <div class="two fields">
                            <div class="field">

                                <div class="required {{ $errors->has($key.'_title') ? 'has-error' : '' }}">
                                   <label for="name">{{ __('Title') }} </label>

                                    {{ Form::text($key.'_title',old($key.'_title', (isset($news))?$news->translate($key)['title']:"") , ['class' => 'form-control','placeholder' => 'Title']) }}

                                    @if($errors->has($key.'_title'))
                                        <span class="help-block">{{ $errors->first($key.'_title') }}</span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        
                            <div class="field">

                                <div class="required {{ $errors->has($key.'_description') ? 'has-error' : '' }}">
                                   <label for="name">{{ __('Description') }} </label>

                                     {{ Form::textarea($key.'_description',old($key.'_description',(isset($news))?$news->translate($key)['description']:""), ['class' => 'form-control','placeholder' => 'Description' , 'id'=>'editor1_'.$key, 'rows' => 8]) }}

                                    @if($errors->has($key.'_description'))
                                        <span class="help-block">{{ $errors->first($key.'_description') }}</span>
                                    @endif
                                </div>
                            </div>

                        
                    </div>
                @endforeach

             

             
                <div class="two fields">
                   
                    <div class="field">
                        <div class="required {{ $errors->has('start_date') ? 'has-error' : '' }}">
                            <label for="status">{{ __('Start date') }} </label>
                            {{ Form::text('start_date', old('start_date'), ['class' => 'form-control datepicker_start','placeholder' => 'Start date']) }}
                           @if($errors->has('start_date'))
                                <span class="help-block">{{ $errors->first('start_date') }}</span>
                            @endif
                        </div>
                    </div>
                    <div class="field">
                        <div class="required {{ $errors->has('end_date') ? 'has-error' : '' }}">
                            <label for="status">{{ __('End date') }} </label>
                            {{ Form::text('end_date', old('end_date'), ['class' => 'form-control datepicker_end','placeholder' => 'End date']) }}
                           @if($errors->has('end_date'))
                                <span class="help-block">{{ $errors->first('end_date') }}</span>
                            @endif
                        </div>
                    </div>
                    
                </div>



                <div class="two fields ">
                    <div class="field type {{ $errors->has('news_type') ? 'has-error' : '' }}">
                        <label for="title">{{ __('Type') }} </label>
                          {!!Form::select('news_type', [0=>'Image',1=>'Video'],  old('news_type'), ['class' => 'news_type'])!!}
                          @if($errors->has('news_type'))
                            <span class="help-block">{{  $errors->first('news_type')  }}</span>
                          @endif
                    </div>
                    
                    <div class="field image ">
                         <div class="form-group {{ $errors->has('image') ? 'has-error' : '' }}">
                            <label for="status">{{ __('Image') }} </label>
                             @if($errors->has('image'))
                                <span class="help-block">{{ $errors->first('image') }}</span>
                            @endif
                        </div>
                        
                        @php
                            $filepath = '/uploads/newsImages/';
                        @endphp

                        @if(!empty($news->image) && file_exists(public_path() . $filepath . $news->image))

                            <?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url($filepath . $news->image), '500', '200', '100'); ?>

                        @else

                            <?php  $imageurl=''; ?>

                        @endif

                        @if($imageurl !='')                           
                          <input type="file" name="image" data-type="image" data-exist="{{ URL::asset('/uploads/newsImages/'.$news->image) }}" accept="image/png, image/jpeg">
                        @else
                            <input type="file" name="icon" data-type="image" data-exist="{{ URL::asset('/images/migration/no-image.png') }}" accept="image/png, image/jpeg">
                        @endif
                    </div>
                    <div class="field video hide">
                        <div class="required {{ $errors->has('video') ? 'has-error' : '' }}">
                            <label for="status">{{ __('Video Url') }} </label>
                            {{ Form::text('video', old('video'), ['class' => 'form-control','placeholder' => 'Video Url']) }}
                           @if($errors->has('video'))
                                <span class="help-block">{{ $errors->first('video') }}</span>
                            @endif
                        </div>
                    </div>
                    <div class="field">
                        <div class="required {{ $errors->has('status') ? 'has-error' : '' }}">
                            <label for="status">{{ __('Status') }} </label>
                            {{ Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => '']) }}

                            @if($errors->has('status'))
                                <span class="help-block">{{ $errors->first('status') }}</span>
                            @endif
                        </div>
                    </div>
                </div>

                <div class="wojo fitted divider"></div>
             

            <div class="wojo fitted divider"></div>
            <div class="wojo footer">
              <button type="submit" data-action="updateAccount" name="dosubmit" class="wojo positive button">Update Account</button>
               <a href="{{ route('admin.news.index') }}" class="wojo negative button" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
            </div>
        </div>

        {{ Form::close() }}
      </div>
  </div>
  @stop


@push('scripts')

<script src="{{ asset('js/migration/jquery-ui.js') }}"></script>
<script src="{{asset('ckeditor/ckeditor.js')}}"></script>
<script>
$(function () {
    CKEDITOR.replace('editor1_en', {
        // Remove the redundant buttons from toolbar groups defined above.
        removeButtons: 'Font,Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Styles,Specialchar'
                // removeButtons: 'Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Specialchar'
    });

    CKEDITOR.replace('editor1_kh', {
       // Remove the redundant buttons from toolbar groups defined above.
       removeButtons: 'Font,Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Styles,Specialchar'
               // removeButtons: 'Iframe,PageBreak,Flash,bootstrapTabs,Copy,Save,Print,Preview,Subscript,Superscript,Anchor,Specialchar'
   });


});
$( function() {
     var type = $('.news_type option:selected').val();
     if(type == 0){
            $('.image').removeClass('hide');
            $('.video').addClass('hide');
        }else{
           
            $('.video').removeClass('hide');
            $('.image').addClass('hide');
        }
   
    $(".datepicker_start").datepicker({
      
         dateFormat:'yy-mm-dd',
        onSelect: function (selected) {
            var dt = new Date(selected);
            dt.setDate(dt.getDate() + 1);
            $(".datepicker_end").datepicker("option", "minDate", dt);
        }
    });
    $(".datepicker_end").datepicker({
      
         dateFormat:'yy-mm-dd',
        onSelect: function (selected) {
            var dt = new Date(selected);
            dt.setDate(dt.getDate() - 1);
            $(".datepicker_start").datepicker("option", "maxDate", dt);
        }
    });
    jQuery('.news_type').on('change',function(){
     
        if($(this).val() == 0){
            $('.image').removeClass('hide');
            $('.video').addClass('hide');
        }else{
           
            $('.video').removeClass('hide');
            $('.image').addClass('hide');
        }
    })
  });
</script>
@endpush
