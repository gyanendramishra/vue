@extends('layouts.admin.app')
@push('styles')
{!! Html::style('/css/bootstrap.min.css') !!}
{!! Html::style('css/datatables.net-bs/dataTables.bootstrap.min.css') !!}
@section('content')
<div id="crumbs" class="clearfix"> 
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> \Request::route()->getName()],['label' => 'List Vehicle Feature']]]) }}
    </div>
</div>
<div class="wojo-grid">
    <div class="wojo secondary icon message">
        <div class="content">
            <div class="header">  {{ __('List Vehicle Feature') }}       
            </div>
        </div>
    </div>
    @include('layouts.flash.alert')
    <div class="wojo quaternary segment">
        <div class="header">Filtering Options</div>
        <div class="content">
            <div class="wojo form">
                <div class="three fields">
                    <div class="field">
                        <label>Status</label>
                        {{ Form::select('status', ['' => 'Select',1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control','id'=>'statuss','data-cover'=>'true']) }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{ Form::hidden('searchslug', '',array('id'=>'searchslug')) }}
    <div class="wojo tertiary segment">
        <div class="header clearfix"><span>{{ __('List Vehicle Feature') }}</span>
            <a class="wojo large top right detached action label" data-content="Add Feature" href="{{route('admin.vehiclefeaturemanager.create')}}"><i class="icon plus"></i></a>
        </div>
        <table class="wojo sortable table"  id="vehiclefeaturemanager-datatable" data-table="vehicle_features">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th class="no-sort">Action</th>
                </tr>
            </thead>
        </table>


    </div>
    <div id="msgholder"></div>
</div>
@stop

@push('scripts')
<script type="text/javascript">
    jQuery(function ($) {
        var t = $('#vehiclefeaturemanager-datatable').DataTable({
            processing: true,
            serverSide: true,
            aaSorting: [[0, 'desc']],
            language: {
                sLengthMenu: "_MENU_",
                search: "<i class='find icon'></i>",
                searchPlaceholder: "Search...",

            },
            ajax: {
                url: "{{ route('admin.vehiclefeaturemanager.ajax.list') }}",
                type: 'GET',
                data: function (d) {

                    d.status = $('#statuss').val();
                    d.slug = $('#searchslug').val();
                }
            },
            columns: [
                {data: 'id', name: 'id'},
                {data: 'name', name: 'name'},
                {data: 'status', name: 'status'},
                {data: 'created_at', name: 'created_at'},
                {data: 'action', name: 'action'}
            ],
            "deferRender": true,
            "columnDefs": [
                {
                    "targets": 'no-sort',
                    "orderable": false,
                },
                {
                    "targets": 3,
                    "data": "created_at",
                    "render": function (data, type, full, meta) {
                        return moment(data).format('DD MMMM, YYYY ');
                    }
                },
                {

                    "targets": 2,
                    "data": "status",
                    "render": function (data, type, full, meta) {
                        return '<input id="status" class="switch-status change-request" data-id="' + full.id + '" data-field="status" data-size="mini" ' + ((data == true) ? 'checked' : '') + ' name="status" type="checkbox">';
                    }
                }
            ],
            "fnDrawCallback": function (settings) {

                $('input.switch-status').not('[data-switch-no-init]').bootstrapSwitch();
                $('[data-toggle="tooltip"]').tooltip();

                $('.switch-status.change-request').on('switchChange.bootstrapSwitch', function (e, state) {
                    var _this = $(this);
                    var _id = _this.data("id")
                    var table = _this.closest("table").data("table");
                    if (e.target.checked == true) {
                        var changedval = 1;
                    } else {
                        var changedval = 0;
                    }
                    changeStatus(table, _id, changedval, _this);
                });
            }


        })
        t.on('order.dt search.dt', function () {
            t.column(0, {search: 'applied', order: 'applied'}).nodes().each(function (cell, i) {
                cell.innerHTML = i + 1;
            });
        });
        $('#statuss').on('change', function () {

            $('#vehiclefeaturemanager-datatable').DataTable().draw(true);
        });

        var alphabet = $('<div class="alphabet"/>').append('Search: ');

        $('<span class="clear active"/>')
                .data('letter', '')
                .html('None')
                .appendTo(alphabet);

        for (var i = 0; i < 26; i++) {
            var letter = String.fromCharCode(65 + i);

            $('<span/>')
                    .data('letter', letter)
                    .html(letter)
                    .appendTo(alphabet);
        }

        alphabet.insertBefore(t.table().container());

        alphabet.on('click', 'span', function () {
            alphabet.find('.active').removeClass('active');
            $(this).addClass('active');
            _alphabetSearch = $(this).data('letter');
            $("#searchslug").val(_alphabetSearch);

            t.draw();
        });
    })
</script>
@endpush
