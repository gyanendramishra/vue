<?php

namespace Modules\AdsManager\Entities;

use Illuminate\Database\Eloquent\Model;

class AdTranslation extends Model {

    protected $table = 'adsence_advertisement_translations';
    protected $fillable = ["title", "description", "image",'image_type','image_scripts','url'];
    public $timestamps = false;

}
