<?php

namespace Modules\SubscriptionManager\Entities;

use Illuminate\Database\Eloquent\Model;

class SubscriptionTranslation extends Model {

    public $timestamps = false;
    protected $fillable = ["type","title", "description"];

    /**
     * Get the comments for the blog post.
     */
    public function subscription() {

        return $this->belongsTo(\Modules\SubscriptionManager\Entities\Subscription::class);
    }

}
