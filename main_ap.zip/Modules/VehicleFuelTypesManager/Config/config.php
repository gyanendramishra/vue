<?php

return [
    'name' => 'VehicleFuelTypesManager'
];
