<?php

namespace Modules\VehicleEnquiresManager\Entities;

use Illuminate\Database\Eloquent\Model;

class ConversationMessage extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['conversation_id', 'user_id', 'content'];

    /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    protected $appends = ['date_time'];

    /**
     * Get the conversation that belongs to message.
     */
    public function conversation()
    {
        return $this->belongsTo(\Modules\VehicleEnquiresManager\Entities\Conversation::class, 'conversation_id');
    }

    /**
     * Get the user that belongs to message.
     */
    public function user()
    {
        return $this->belongsTo(\App\User::class);
    }

    /**
     * Get the created at.
     *
     * @param  string  $value
     * @return string
     */
    public function getHumansDateAttribute() {
        return \Carbon\Carbon::parse($this->created_at)->format('d M Y');
    }

    /**
     * Get the created at.
     *
     * @param  string  $value
     * @return string
     */
    public function getDateTimeAttribute() {
        return \Carbon\Carbon::parse($this->created_at)->format('H:i A | d M Y');
    }

    /*
     * make dynamic attribute for human readable time
     *
     * @return string
     * 
     */
    public function getHumansTimeAttribute() {
        return \Carbon\Carbon::parse($this->created_at)->diffForHumans();
    }

}
