<?php

namespace Modules\VehicleEnquiresManager\Entities;

use Illuminate\Database\Eloquent\Model;

class Conversation extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['vehicle_id', 'type', 'title'];

    /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    protected $appends = ['last_message_content', 'last_message_human_time'];

    /**
     * Get the participants that belongs to conversation.
     */
    public function participants()
    {
        return $this->belongsToMany(\App\User::class, 'conversation_participants', 'conversation_id', 'user_id')
            ->withPivot(['name', 'email', 'phone']);
    }

     /**
     * Get the messages of the conversation.
     */
    public function messages()
    {
        return $this->hasMany(\Modules\VehicleEnquiresManager\Entities\ConversationMessage::class, 'conversation_id');
    }

    /**
     * Get the vehicle that owns the conversation.
     */
    public function vehicle()
    {
        return $this->belongsTo(\Modules\VehicleManager\Entities\Vehicle::class, 'vehicle_id');
    }


    /**
     * Get the last message content of vehicle.
     * 
     * @return string
     */
    public function getLastMessageContentAttribute() 
    {
        if($this->messages->isNotEmpty()){
            return $this->messages->last()->content;
        }
        return '';
    }

    /**
     * Get the last message content of vehicle.
     * 
     * @return string
     */
    public function getLastMessageHumanTimeAttribute() 
    {
        if($this->messages->isNotEmpty()){
            return \Carbon\Carbon::parse($this->messages->last()->created_at)->diffForHumans();
        }
        return '';
    }


}
