@extends('layouts.admin.app')
@section('title','View Enquiry')
@section('content')

<div class="wojo-grid">
    <div class="wojo form segment">
      
    
        <table class="wojo two column table">
        <thead>
            <tr class="viewheading">
              <td  colspan="2"> <span><strong> {{ __( 'Vehicle Enquiry Details' ) }} </strong></span> </th>
              <td> <a href="{{route('admin.vehicleenquires.index')}}" class="btn btn-primary"><span>Back</span></a></td>
            </tr>
          </thead>
          
          <tbody>
             
             <tr>
                 <td>{{ __('Car Name') }}:</td>
                 <td><a href="{{route('admin.vehicle.show',@$inquiry->vehicle->id)}}">{{$inquiry->vehicle->title}}</a></td>
             </tr>
            <tr>
                <td>{{ __('Name') }}</td>
                <td>{{ $inquiry->name}}</td>
            </tr>
            <tr>
                <td>{{ __('Email') }}</td>
                <td>{{ $inquiry->email}}</td>
            </tr>
            <tr>
                <td>{{ __('Phone') }}</td>
                <td>{{ $inquiry->phone}}</td>
            </tr>
            <tr>
                <td>{{ __('PostCode') }}</td>
                <td>{{ $inquiry->postcode}}</td>
            </tr>
            <tr>
                <td>{{ __('Message') }}</td>
                <td>{{ $inquiry->details}}</td>
            </tr>
            <tr>
                <td><?= __('Created') ?></td>
                <td>{{ $inquiry->created_at->toFormattedDateString() }}</td>
            </tr>
            
          </tbody>
        </table>
       
      
      
    
    </div>
  </div>


@stop
