<?php

namespace Modules\User\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateUserRequest extends FormRequest {

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        if (\Auth::user()->roles()->first()->slug == 'admin') {
            $rules = [
                'secud_gender' => 'required',
                'secud_exref' => 'max:200',
                'secud_fname' => 'required|max:200',
                'secud_mname' => 'max:200',
                'secud_sname' => 'required|max:200',
                'meuser_name' => 'required|string|max:200|unique:users,meuser_name,' . $this->route('id'),
                'email' => 'required|email|unique:users,email,' . $this->route('id'),
                'secud_mobile' => 'max:50',
                'secud_landline' => 'max:50',
                'role_id' => 'required',
                'secud_dob' => '',
                'secud_address' => '',
                'secud_suburb' => 'max:200',
                'secud_state' => 'max:200',
                'secud_country' => 'max:200',
                'secud_postcode' => 'max:200',
                'secud_icename' => 'max:200',
                'secud_iceemail' => 'nullable|email|max:200',
                'secud_icemobile' => 'max:50',
                'secud_icelandline' => 'max:50',
                'secud_previous' => '',
                'secud_essstart' => '',
                'secud_enddate' => '',
                'secud_interests' => '',
                'secud_community' => '',
                'profile_image' => 'sometimes|image|mimes:jpeg,png,jpg,gif|max:2048',
                'status' => '',
                'password' => '',
                'password_confirmation' => '',
                'secud_cont' => '',
            ];
        } else {
            $rules = [
                'secud_gender' => 'required',
                'secud_exref' => 'max:200',
                'secud_fname' => 'required|max:200',
                'secud_mname' => 'max:200',
                'secud_sname' => 'required|max:200',
                'meuser_name' => 'required|string|max:200|unique:users,meuser_name,' . $this->route('id'),
                'email' => 'required|email|unique:users,email,' . $this->route('id'),
                'secud_mobile' => 'max:50',
                'secud_landline' => 'max:50',
                'role_id' => 'required',
                'secud_dob' => '',
                'secud_address' => '',
                'secud_suburb' => 'max:200',
                'secud_state' => 'max:200',
                'secud_country' => 'max:200',
                'secud_postcode' => 'max:200',
                'secud_icename' => 'max:200',
                'secud_iceemail' => 'nullable|email|max:200',
                'secud_icemobile' => 'max:50',
                'secud_icelandline' => 'max:50',
                'secud_previous' => '',
                'secud_essstart' => '',
                'secud_enddate' => '',
                'secud_interests' => '',
                'secud_community' => '',
                'profile_image' => 'sometimes|image|mimes:jpeg,png|max:2048',
                'status' => '',
                'password' => '',
                'password_confirmation' => '',
                'secud_cont' => '',
            ];
        }

        return $rules;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Setting up custom messages for errors.
     *
     * @return array
     */
    /* public function messages(){

      } */

    /**
     * Correcting attribute names.
     *
     * @return array
     */
    public function attributes() {
        $attributes = [
            'secud_gender' => 'Gender',
            'secud_exref' => 'External ID',
            'secud_fname' => 'First Name',
            'secud_mname' => 'Middle Name(s)',
            'secud_sname' => 'Surname',
            'meuser_name' => 'Username',
            'email' => 'Email',
            'secud_mobile' => 'Mobile',
            'secud_landline' => 'Landline',
            'role_id' => 'Role',
            'secud_dob' => 'Date of birth',
            'secud_address' => 'Address',
            'secud_suburb' => 'Suburb',
            'secud_state' => 'State',
            'secud_country' => 'Country',
            'secud_postcode' => 'Post Code',
            'secud_icename' => 'I.C.E. Full Name',
            'secud_iceemail' => 'I.C.E. Email',
            'secud_icemobile' => 'I.C.E. Mobile',
            'secud_icelandline' => 'I.C.E. Landline',
            'secud_previous' => 'Previous Experience',
            'secud_essstart' => 'Start Date',
            'secud_enddate' => 'End Date',
            'secud_interests' => 'Personal Interests & Hobbies',
            'secud_community' => 'Community/Volunteer Projects',
            'profile_image' => 'Photo',
            'password' => 'password',
        ];
        return $attributes;
    }

}
