-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 18, 2020 at 09:26 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sellmycar`
--

-- --------------------------------------------------------

--
-- Table structure for table `adsence_advertisements`
--

CREATE TABLE `adsence_advertisements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `page_location_id` bigint(20) UNSIGNED NOT NULL,
  `position_id` bigint(20) UNSIGNED NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adsence_advertisement_translations`
--

CREATE TABLE `adsence_advertisement_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `ad_id` bigint(20) UNSIGNED NOT NULL,
  `image_type` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1=image,2=scripts',
  `image_scripts` text CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `url` text CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `front_view` tinyint(1) DEFAULT 0,
  `icon` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `category_translations`
--

CREATE TABLE `category_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

CREATE TABLE `email_templates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(191) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0->inactive, 1->active',
  `is_html` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `email_template_translations`
--

CREATE TABLE `email_template_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(222) NOT NULL,
  `email_template_id` bigint(20) UNSIGNED NOT NULL,
  `subject` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `template` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `inquiries`
--

CREATE TABLE `inquiries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_04_02_193005_create_translations_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `newss`
--

CREATE TABLE `newss` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `news_type` tinyint(1) DEFAULT 0 COMMENT '0=image,1=video',
  `image` varchar(191) DEFAULT NULL,
  `video` varchar(191) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `slug` varchar(191) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `news_translations`
--

CREATE TABLE `news_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) NOT NULL,
  `news_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=active, 0=in active',
  `position` tinyint(1) NOT NULL DEFAULT 2 COMMENT '1=copyright,2=Footer',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `page_locations`
--

CREATE TABLE `page_locations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `page_locations`
--

INSERT INTO `page_locations` (`id`, `slug`, `name`, `created`, `modified`) VALUES
(1, 'vehicle_detail', 'Vehicle Detail', '2018-01-05 00:00:00', '2019-12-17 15:57:50'),
(2, 'vehicle_listing', 'Vehicle Listing', '2018-01-05 00:00:00', '2019-12-17 14:46:31'),
(3, 'home', 'Home', '0000-00-00 00:00:00', '2019-11-26 09:53:27'),
(4, 'app_filter', 'App Filter', '0000-00-00 00:00:00', '2019-12-18 06:53:35');

-- --------------------------------------------------------

--
-- Table structure for table `page_translations`
--

CREATE TABLE `page_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `page_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(222) NOT NULL,
  `title` varchar(222) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `sub_title` varchar(222) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `short_description` text CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `meta_title` varchar(222) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `meta_keyword` varchar(222) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `meta_description` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('kiran@yopmail.com', '$2y$10$6p2ySreizP2CT111mxbdxOXEEbPXERDr5UrFhovgPL67EgY8U9j0.', '2019-11-27 04:49:11'),
('!@mailinator.com', '$2y$10$jVBz/fOXLbh/0Bayx5DvuO6dBx5m99eG1pyVLueCEsZfbgxNUU7ae', '2019-12-19 04:47:28');

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE `positions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `positions`
--

INSERT INTO `positions` (`id`, `name`, `status`, `created`, `modified`) VALUES
(1, 'Top', 1, '2018-01-24 00:00:00', '2018-01-24 00:00:00'),
(2, 'Side Left', 1, '2018-01-24 00:00:00', '2018-01-24 00:00:00'),
(3, 'Side Right', 1, '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(5, 'Mid', 1, '2019-12-16 00:00:00', '2019-12-16 00:00:00'),
(6, 'Bottom', 1, '2019-12-16 00:00:00', '2019-12-16 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `is_menu` tinyint(4) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `manager` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `title`, `slug`, `config_value`, `manager`, `field_type`, `created_at`, `updated_at`) VALUES
(1, 'Website Name', 'SYSTEM_APPLICATION_NAME', 'S.P Car Market', 'general', 'text', '2019-02-27 06:03:36', '2019-12-24 01:25:23'),
(2, 'Admin Email', 'ADMIN_EMAIL', 'ratanakpisith.dotsquares@yopmail.com', 'general', 'text', '2019-02-27 06:03:36', '2020-01-08 00:11:36'),
(4, 'Owner Name', 'WEBSITE_OWNER', 'Kiran', 'general', 'text', '2019-02-27 06:03:36', '2019-11-25 00:42:55'),
(6, 'Admin Page Limit', 'ADMIN_PAGE_LIMIT', '20', 'general', 'text', '2019-02-27 06:03:36', '2019-11-26 03:04:23'),
(8, 'Admin Date Format', 'ADMIN_DATE_FORMAT', 'd F, Y H:i A', 'general', 'text', '2019-02-27 06:03:36', '2019-11-26 04:57:15'),
(9, 'Admin Date Time Format', 'ADMIN_DATE_TIME_FORMAT', 'd F, Y H:i A', 'general', 'text', '2019-02-27 06:03:36', '2019-02-27 06:03:36'),
(47, 'Main Favicon', 'MAIN_FAVICON', 'qE3MG0PosiEuCyfS3sCPox4etiGvAJG8LYUIDOiX.png', 'theme_images', 'text', '2019-02-28 02:39:43', '2019-11-28 04:24:49'),
(48, 'MAIN LOGO', 'MAIN_LOGO', 'AIj9OartxNNDhJa51KY0V4CWueO2PO9O9scc27Yp.png', 'theme_images', 'text', '2019-02-28 02:39:43', '2019-12-16 09:42:47'),
(54, 'Linkedin Url', 'LINKEDIN_URL', 'https://in.linkedin.com/', 'general', 'text', '2019-03-26 00:59:59', '2019-10-09 00:19:24'),
(56, 'Facebook Url', 'FACEBOOK_URL', 'https://www.facebook.com/CarMarketsKh/?modal=admin_todo_tour', 'general', 'text', '2019-03-26 01:00:43', '2020-01-13 05:03:34'),
(60, 'Dealer car', 'HOME_DEALER_CAR', '<p>test Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. </p>\r\n                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. </p>', 'general', 'text', '2019-08-02 03:56:23', '2019-12-18 00:56:28'),
(61, 'About us', 'HOME_ABOUT_US', '<p>Carmarket.com.kh was founded in 2019 to help Cambodian people in unlocking their purchasing and selling potential. Carmarket.com.kh is an interactive platform that allows its users to search for, inquire, contact, and set up purchases and sales. </p>\r\n                            <p> Carmarket.com.kh envision a much more efficient future for vehicle buyer and seller in Cambodia. We believe that buyers should be able to make the maximum use of their budget to purchase for their dream car, and not having to spend valuable time and money to tirelessly search for their dream vehicle. Furthermore, we envisage a future where vehicle sellers regardless of being private or dealer are able to effectively and efficiently reach their target audience. </p>', 'general', 'text', '2019-09-19 18:30:00', '2020-01-13 04:59:40'),
(62, 'Instagram Url', 'INSTAGRAM_URL', 'https://www.instagram.com/', 'general', 'text', '2019-09-23 18:30:00', '2019-10-09 00:19:43'),
(63, 'Phone', 'PHONE1', '1234567890', 'general', 'text', '2019-09-23 18:30:00', '2019-11-25 00:43:13'),
(64, 'Phone 2', 'PHONE2', '1234567890', 'general', 'text', '2019-09-23 18:30:00', '2019-11-25 00:43:23'),
(65, 'Address', 'ADDRESS', '60 Grant Avenue, Carteret NJ 07089', 'general', 'text', '2019-09-23 18:30:00', '2019-12-18 01:27:30'),
(66, 'Copyright footer text', 'COPYRIGHT', 'Copyright © 2019-2020', 'general', 'text', NULL, '2019-11-26 03:02:40'),
(67, 'Postal Address', 'POSTAL_ADDRESS', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 'general', 'text', '2019-12-17 07:54:26', '2019-12-17 07:54:26'),
(68, 'Youtube Url', 'YOUTUBE_URL', 'https://youtube.com', 'general', 'text', '2019-12-16 18:30:00', '2019-12-16 18:30:00'),
(69, 'Twitter Url', 'TWITTER_URL', 'https://twitter.com', 'general', 'text', '2019-12-16 18:30:00', '2019-12-16 18:30:00'),
(70, 'Seller car', 'HOME_SELLER_CAR', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. </p>\r\n                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. </p>', 'general', 'text', '2019-08-02 03:56:23', '2019-11-25 00:44:34');

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) NOT NULL,
  `user_type` varchar(50) DEFAULT NULL,
  `duration` int(11) DEFAULT 0,
  `duration_type` enum('Days','Weeks','Months','Years','Unlimited') DEFAULT 'Days',
  `price` decimal(16,2) DEFAULT NULL,
  `minimum_price` double(16,2) DEFAULT NULL,
  `total_on_sale_count` smallint(6) NOT NULL DEFAULT 0,
  `total_featured_count` smallint(6) NOT NULL DEFAULT 0,
  `total_listing_count` smallint(6) NOT NULL DEFAULT 0,
  `count_of_until_sold` smallint(6) NOT NULL DEFAULT 0,
  `image` varchar(191) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `sort_order` smallint(6) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_translations`
--

CREATE TABLE `subscription_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) NOT NULL,
  `subscription_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_otp_verified` tinyint(4) NOT NULL DEFAULT 0,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `admin` tinyint(4) NOT NULL DEFAULT 1,
  `api_token` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_vehicle`
--

CREATE TABLE `user_vehicle` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_id` bigint(20) UNSIGNED NOT NULL,
  `is_favourite` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_verifications`
--

CREATE TABLE `user_verifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `otp` int(11) DEFAULT NULL,
  `otp_type` tinyint(4) DEFAULT 0 COMMENT '1=register,2=forgot',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT 0,
  `makes_id` bigint(20) UNSIGNED DEFAULT NULL,
  `models_id` bigint(20) UNSIGNED DEFAULT NULL,
  `badge_id` bigint(20) UNSIGNED DEFAULT NULL,
  `series_id` bigint(20) UNSIGNED DEFAULT NULL,
  `body_styles_id` bigint(20) UNSIGNED DEFAULT NULL,
  `drive_types_id` bigint(20) UNSIGNED DEFAULT NULL,
  `fuel_types_id` bigint(20) UNSIGNED DEFAULT NULL,
  `engine_type_id` bigint(20) UNSIGNED DEFAULT NULL,
  `transmissions_id` bigint(20) UNSIGNED DEFAULT NULL,
  `interior_colour_id` bigint(20) UNSIGNED DEFAULT NULL,
  `exterior_colour_id` bigint(20) UNSIGNED DEFAULT NULL,
  `lifestyle_id` bigint(20) UNSIGNED DEFAULT NULL,
  `cylinders_id` bigint(20) UNSIGNED DEFAULT NULL,
  `fuel_economy_id` bigint(20) UNSIGNED DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `price` double(9,2) DEFAULT NULL,
  `discount_price` double(9,2) DEFAULT NULL,
  `month_build` varchar(10) DEFAULT NULL,
  `plate_number` varchar(191) DEFAULT NULL,
  `chassis_number` varchar(191) DEFAULT NULL,
  `doors` int(11) DEFAULT NULL,
  `gears` int(11) DEFAULT NULL,
  `seats` int(11) DEFAULT NULL,
  `year_build` varchar(200) DEFAULT NULL,
  `year_complied` varchar(200) DEFAULT NULL,
  `engine_capacity` int(11) DEFAULT NULL,
  `turbo` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `odometer` bigint(20) UNSIGNED DEFAULT NULL,
  `expiry_month` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `expiry_year` year(4) DEFAULT NULL,
  `written_off` tinyint(1) DEFAULT NULL,
  `is_registered` tinyint(1) DEFAULT 0,
  `role` varchar(191) DEFAULT NULL,
  `phone` bigint(20) DEFAULT NULL,
  `postcode` varchar(50) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `longitude` varchar(191) DEFAULT NULL,
  `is_featured` tinyint(4) NOT NULL DEFAULT 0,
  `sort_order` int(11) DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT 0,
  `is_approved` tinyint(1) DEFAULT 0,
  `car_of_the_week` tinyint(1) NOT NULL DEFAULT 0,
  `steps` tinyint(1) DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_badges`
--

CREATE TABLE `vehicle_badges` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `makes_id` bigint(20) UNSIGNED DEFAULT NULL,
  `models_id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) NOT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_badge_translations`
--

CREATE TABLE `vehicle_badge_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `locale` varchar(255) NOT NULL,
  `vehicle_badge_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_body_styles`
--

CREATE TABLE `vehicle_body_styles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `icon` varchar(191) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_body_style_translations`
--

CREATE TABLE `vehicle_body_style_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(222) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `locale` varchar(222) NOT NULL,
  `vehicle_body_style_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_colors`
--

CREATE TABLE `vehicle_colors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_colors_translations`
--

CREATE TABLE `vehicle_colors_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `locale` varchar(255) NOT NULL,
  `vehicle_colors_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_drive_types`
--

CREATE TABLE `vehicle_drive_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `icon` varchar(191) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_drive_types_translations`
--

CREATE TABLE `vehicle_drive_types_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `vehicle_drive_types_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_enquires`
--

CREATE TABLE `vehicle_enquires` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_id` bigint(20) UNSIGNED NOT NULL,
  `postcode` varchar(191) DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(50) CHARACTER SET utf8 NOT NULL,
  `details` text CHARACTER SET utf8 NOT NULL,
  `is_dealer_response` tinyint(4) NOT NULL DEFAULT 0,
  `is_trade_in` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_features`
--

CREATE TABLE `vehicle_features` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `icon` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_feature_translations`
--

CREATE TABLE `vehicle_feature_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_feature_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL,
  `locale` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_fuel_types`
--

CREATE TABLE `vehicle_fuel_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `slug` varchar(191) NOT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_fuel_types_translations`
--

CREATE TABLE `vehicle_fuel_types_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `locale` varchar(255) NOT NULL,
  `vehicle_fuel_types_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_images`
--

CREATE TABLE `vehicle_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_id` bigint(20) UNSIGNED NOT NULL,
  `sort_order` varchar(20) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `caption` text DEFAULT NULL,
  `image_type` enum('front','rear','side','other') DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_lifestyles`
--

CREATE TABLE `vehicle_lifestyles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_lifestyle_translations`
--

CREATE TABLE `vehicle_lifestyle_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `locale` varchar(191) NOT NULL,
  `vehicle_lifestyle_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_makes`
--

CREATE TABLE `vehicle_makes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `icon` varchar(191) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_make_translations`
--

CREATE TABLE `vehicle_make_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) NOT NULL,
  `vehicle_make_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_models`
--

CREATE TABLE `vehicle_models` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `makes_id` int(11) DEFAULT NULL,
  `slug` varchar(191) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `icon` varchar(191) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_model_translations`
--

CREATE TABLE `vehicle_model_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `vehicle_model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_reviews`
--

CREATE TABLE `vehicle_reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` double(8,2) NOT NULL,
  `review` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_seriess`
--

CREATE TABLE `vehicle_seriess` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `makes_id` bigint(20) UNSIGNED DEFAULT NULL,
  `models_id` bigint(20) UNSIGNED NOT NULL,
  `badges_id` bigint(20) UNSIGNED DEFAULT NULL,
  `slug` varchar(191) NOT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_series_translations`
--

CREATE TABLE `vehicle_series_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `locale` varchar(255) NOT NULL,
  `vehicle_series_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_translations`
--

CREATE TABLE `vehicle_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_transmissions`
--

CREATE TABLE `vehicle_transmissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `icon` varchar(191) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_transmissions_translations`
--

CREATE TABLE `vehicle_transmissions_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `locale` varchar(255) NOT NULL,
  `vehicle_transmissions_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_vehicle_feature`
--

CREATE TABLE `vehicle_vehicle_feature` (
  `vehicle_id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_feature_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adsence_advertisements`
--
ALTER TABLE `adsence_advertisements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `page_location` (`page_location_id`),
  ADD KEY `position_id` (`position_id`);

--
-- Indexes for table `adsence_advertisement_translations`
--
ALTER TABLE `adsence_advertisement_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ad_id` (`ad_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_translations`
--
ALTER TABLE `category_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `email_templates`
--
ALTER TABLE `email_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_template_translations`
--
ALTER TABLE `email_template_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email_template_id` (`email_template_id`);

--
-- Indexes for table `inquiries`
--
ALTER TABLE `inquiries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newss`
--
ALTER TABLE `newss`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_translations`
--
ALTER TABLE `news_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `news_id` (`news_id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_personal_access_clients_client_id_index` (`client_id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_locations`
--
ALTER TABLE `page_locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_translations`
--
ALTER TABLE `page_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `page_id` (`page_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `positions`
--
ALTER TABLE `positions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`role_id`),
  ADD KEY `role_id` (`role_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_slug_unique` (`slug`);

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription_translations`
--
ALTER TABLE `subscription_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subscription_id` (`subscription_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- Indexes for table `user_vehicle`
--
ALTER TABLE `user_vehicle`
  ADD PRIMARY KEY (`user_id`,`vehicle_id`),
  ADD KEY `vehicle_id` (`vehicle_id`);

--
-- Indexes for table `user_verifications`
--
ALTER TABLE `user_verifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `badge_id` (`badge_id`),
  ADD KEY `body_styles_id` (`body_styles_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `drive_types_id` (`drive_types_id`),
  ADD KEY `exterior_colour_id` (`exterior_colour_id`),
  ADD KEY `interior_colour_id` (`interior_colour_id`),
  ADD KEY `fuel_types_id` (`fuel_types_id`),
  ADD KEY `lifestyle_id` (`lifestyle_id`),
  ADD KEY `makes_id` (`makes_id`),
  ADD KEY `models_id` (`models_id`),
  ADD KEY `series_id` (`series_id`),
  ADD KEY `transmissions_id` (`transmissions_id`);

--
-- Indexes for table `vehicle_badges`
--
ALTER TABLE `vehicle_badges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_badge_translations`
--
ALTER TABLE `vehicle_badge_translations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_body_styles`
--
ALTER TABLE `vehicle_body_styles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_body_style_translations`
--
ALTER TABLE `vehicle_body_style_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_body_style_id` (`vehicle_body_style_id`);

--
-- Indexes for table `vehicle_colors`
--
ALTER TABLE `vehicle_colors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_colors_translations`
--
ALTER TABLE `vehicle_colors_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_colors_id` (`vehicle_colors_id`);

--
-- Indexes for table `vehicle_drive_types`
--
ALTER TABLE `vehicle_drive_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_drive_types_translations`
--
ALTER TABLE `vehicle_drive_types_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_drive_types_id` (`vehicle_drive_types_id`);

--
-- Indexes for table `vehicle_enquires`
--
ALTER TABLE `vehicle_enquires`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_id` (`vehicle_id`);

--
-- Indexes for table `vehicle_features`
--
ALTER TABLE `vehicle_features`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_feature_translations`
--
ALTER TABLE `vehicle_feature_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_feature_id` (`vehicle_feature_id`);

--
-- Indexes for table `vehicle_fuel_types`
--
ALTER TABLE `vehicle_fuel_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_fuel_types_translations`
--
ALTER TABLE `vehicle_fuel_types_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_fuel_types_id` (`vehicle_fuel_types_id`);

--
-- Indexes for table `vehicle_images`
--
ALTER TABLE `vehicle_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_id` (`vehicle_id`);

--
-- Indexes for table `vehicle_lifestyles`
--
ALTER TABLE `vehicle_lifestyles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_lifestyle_translations`
--
ALTER TABLE `vehicle_lifestyle_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_lifestyle_id` (`vehicle_lifestyle_id`);

--
-- Indexes for table `vehicle_makes`
--
ALTER TABLE `vehicle_makes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_make_translations`
--
ALTER TABLE `vehicle_make_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_make_id` (`vehicle_make_id`);

--
-- Indexes for table `vehicle_models`
--
ALTER TABLE `vehicle_models`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_model_translations`
--
ALTER TABLE `vehicle_model_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_model_id` (`vehicle_model_id`);

--
-- Indexes for table `vehicle_reviews`
--
ALTER TABLE `vehicle_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_reviews_vehicle_id_index` (`vehicle_id`),
  ADD KEY `vehicle_reviews_user_id_index` (`user_id`);

--
-- Indexes for table `vehicle_seriess`
--
ALTER TABLE `vehicle_seriess`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_series_translations`
--
ALTER TABLE `vehicle_series_translations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_translations`
--
ALTER TABLE `vehicle_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_id` (`vehicle_id`);

--
-- Indexes for table `vehicle_transmissions`
--
ALTER TABLE `vehicle_transmissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_transmissions_translations`
--
ALTER TABLE `vehicle_transmissions_translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_transmissions_id` (`vehicle_transmissions_id`);

--
-- Indexes for table `vehicle_vehicle_feature`
--
ALTER TABLE `vehicle_vehicle_feature`
  ADD PRIMARY KEY (`vehicle_id`,`vehicle_feature_id`),
  ADD KEY `vehicle_feature_id` (`vehicle_feature_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adsence_advertisements`
--
ALTER TABLE `adsence_advertisements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `adsence_advertisement_translations`
--
ALTER TABLE `adsence_advertisement_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `category_translations`
--
ALTER TABLE `category_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `email_templates`
--
ALTER TABLE `email_templates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `email_template_translations`
--
ALTER TABLE `email_template_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inquiries`
--
ALTER TABLE `inquiries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `newss`
--
ALTER TABLE `newss`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `news_translations`
--
ALTER TABLE `news_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_locations`
--
ALTER TABLE `page_locations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `page_translations`
--
ALTER TABLE `page_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `positions`
--
ALTER TABLE `positions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription_translations`
--
ALTER TABLE `subscription_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_verifications`
--
ALTER TABLE `user_verifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_badges`
--
ALTER TABLE `vehicle_badges`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_badge_translations`
--
ALTER TABLE `vehicle_badge_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_body_styles`
--
ALTER TABLE `vehicle_body_styles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_body_style_translations`
--
ALTER TABLE `vehicle_body_style_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_colors`
--
ALTER TABLE `vehicle_colors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_colors_translations`
--
ALTER TABLE `vehicle_colors_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_drive_types`
--
ALTER TABLE `vehicle_drive_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_drive_types_translations`
--
ALTER TABLE `vehicle_drive_types_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_enquires`
--
ALTER TABLE `vehicle_enquires`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_features`
--
ALTER TABLE `vehicle_features`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_feature_translations`
--
ALTER TABLE `vehicle_feature_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_fuel_types`
--
ALTER TABLE `vehicle_fuel_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_fuel_types_translations`
--
ALTER TABLE `vehicle_fuel_types_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_images`
--
ALTER TABLE `vehicle_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_lifestyles`
--
ALTER TABLE `vehicle_lifestyles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_lifestyle_translations`
--
ALTER TABLE `vehicle_lifestyle_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_makes`
--
ALTER TABLE `vehicle_makes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_make_translations`
--
ALTER TABLE `vehicle_make_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_models`
--
ALTER TABLE `vehicle_models`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_model_translations`
--
ALTER TABLE `vehicle_model_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_reviews`
--
ALTER TABLE `vehicle_reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_seriess`
--
ALTER TABLE `vehicle_seriess`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_series_translations`
--
ALTER TABLE `vehicle_series_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_translations`
--
ALTER TABLE `vehicle_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_transmissions`
--
ALTER TABLE `vehicle_transmissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_transmissions_translations`
--
ALTER TABLE `vehicle_transmissions_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `adsence_advertisement_translations`
--
ALTER TABLE `adsence_advertisement_translations`
  ADD CONSTRAINT `adsence_advertisement_translations_ibfk_1` FOREIGN KEY (`ad_id`) REFERENCES `adsence_advertisements` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `category_translations`
--
ALTER TABLE `category_translations`
  ADD CONSTRAINT `category_translations_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `email_template_translations`
--
ALTER TABLE `email_template_translations`
  ADD CONSTRAINT `email_template_translations_ibfk_1` FOREIGN KEY (`email_template_id`) REFERENCES `email_templates` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `news_translations`
--
ALTER TABLE `news_translations`
  ADD CONSTRAINT `news_translations_ibfk_1` FOREIGN KEY (`news_id`) REFERENCES `newss` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `page_translations`
--
ALTER TABLE `page_translations`
  ADD CONSTRAINT `page_translations_ibfk_1` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_user_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_vehicle`
--
ALTER TABLE `user_vehicle`
  ADD CONSTRAINT `user_vehicle_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_vehicle_ibfk_2` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_verifications`
--
ALTER TABLE `user_verifications`
  ADD CONSTRAINT `user_verifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicles_ibfk_10` FOREIGN KEY (`makes_id`) REFERENCES `vehicle_makes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicles_ibfk_11` FOREIGN KEY (`models_id`) REFERENCES `vehicle_models` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicles_ibfk_12` FOREIGN KEY (`series_id`) REFERENCES `vehicle_seriess` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicles_ibfk_13` FOREIGN KEY (`transmissions_id`) REFERENCES `vehicle_transmissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicles_ibfk_2` FOREIGN KEY (`badge_id`) REFERENCES `vehicle_badges` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicles_ibfk_3` FOREIGN KEY (`body_styles_id`) REFERENCES `vehicle_body_styles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicles_ibfk_4` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicles_ibfk_5` FOREIGN KEY (`drive_types_id`) REFERENCES `vehicle_drive_types` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicles_ibfk_6` FOREIGN KEY (`exterior_colour_id`) REFERENCES `vehicle_colors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicles_ibfk_7` FOREIGN KEY (`interior_colour_id`) REFERENCES `vehicle_colors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicles_ibfk_8` FOREIGN KEY (`fuel_types_id`) REFERENCES `vehicle_fuel_types` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicles_ibfk_9` FOREIGN KEY (`lifestyle_id`) REFERENCES `vehicle_lifestyles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_body_style_translations`
--
ALTER TABLE `vehicle_body_style_translations`
  ADD CONSTRAINT `vehicle_body_style_translations_ibfk_1` FOREIGN KEY (`vehicle_body_style_id`) REFERENCES `vehicle_body_styles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_colors_translations`
--
ALTER TABLE `vehicle_colors_translations`
  ADD CONSTRAINT `vehicle_colors_translations_ibfk_1` FOREIGN KEY (`vehicle_colors_id`) REFERENCES `vehicle_colors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_drive_types_translations`
--
ALTER TABLE `vehicle_drive_types_translations`
  ADD CONSTRAINT `vehicle_drive_types_translations_ibfk_1` FOREIGN KEY (`vehicle_drive_types_id`) REFERENCES `vehicle_drive_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_enquires`
--
ALTER TABLE `vehicle_enquires`
  ADD CONSTRAINT `vehicle_enquires_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_feature_translations`
--
ALTER TABLE `vehicle_feature_translations`
  ADD CONSTRAINT `vehicle_feature_translations_ibfk_1` FOREIGN KEY (`vehicle_feature_id`) REFERENCES `vehicle_features` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_fuel_types_translations`
--
ALTER TABLE `vehicle_fuel_types_translations`
  ADD CONSTRAINT `vehicle_fuel_types_translations_ibfk_1` FOREIGN KEY (`vehicle_fuel_types_id`) REFERENCES `vehicle_fuel_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_images`
--
ALTER TABLE `vehicle_images`
  ADD CONSTRAINT `vehicle_images_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_lifestyle_translations`
--
ALTER TABLE `vehicle_lifestyle_translations`
  ADD CONSTRAINT `vehicle_lifestyle_translations_ibfk_1` FOREIGN KEY (`vehicle_lifestyle_id`) REFERENCES `vehicle_lifestyles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_make_translations`
--
ALTER TABLE `vehicle_make_translations`
  ADD CONSTRAINT `vehicle_make_translations_ibfk_1` FOREIGN KEY (`vehicle_make_id`) REFERENCES `vehicle_makes` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_model_translations`
--
ALTER TABLE `vehicle_model_translations`
  ADD CONSTRAINT `vehicle_model_translations_ibfk_1` FOREIGN KEY (`vehicle_model_id`) REFERENCES `vehicle_models` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_reviews`
--
ALTER TABLE `vehicle_reviews`
  ADD CONSTRAINT `vehicle_reviews_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicle_reviews_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_translations`
--
ALTER TABLE `vehicle_translations`
  ADD CONSTRAINT `vehicle_translations_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_transmissions_translations`
--
ALTER TABLE `vehicle_transmissions_translations`
  ADD CONSTRAINT `vehicle_transmissions_translations_ibfk_1` FOREIGN KEY (`vehicle_transmissions_id`) REFERENCES `vehicle_transmissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_vehicle_feature`
--
ALTER TABLE `vehicle_vehicle_feature`
  ADD CONSTRAINT `vehicle_vehicle_feature_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicle_vehicle_feature_ibfk_2` FOREIGN KEY (`vehicle_feature_id`) REFERENCES `vehicle_features` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
