<?php
namespace App\Repositories;

use Illuminate\Http\Request;
use App\Repositories\Interfaces\ConversationInterface;
use Modules\VehicleEnquiresManager\Entities\Conversation;
use Modules\VehicleEnquiresManager\Entities\ConversationMessage;

class ConversationRepository implements ConversationInterface {
    

    /* Get all conversations */
    public function getAllConversations(){
        return Conversation::first();
    }

    /* Get user all conversations */
    public function getUserAllConversations($userId){
        return  Conversation::select('id', 'vehicle_id', 'title')
                    ->whereHas('participants', function($q) use($userId){
                        $q->where('user_id', $userId);
                    })
                    ->with([
                        'vehicle:id,user_id,title,price',
                        'vehicle.user:id,name,email,phone',
                        'vehicle.main_image:id,vehicle_id,image,caption'
                    ])          
                    ->orderBy('id', 'DESC')
                    ->get();
    }

    /* Get conversation messages */
    public function getConversationMessages($conversationId){
        return ConversationMessage::select('id', 'user_id', 'content', 'created_at')
                    ->where('conversation_id', $conversationId)
                    ->with('user:id,name,profile_image')
                    ->orderBy('id', 'DESC')
                    ->paginate(20);
    }

    /* Get message by message id */
    public function getMessageById($messageId){
        return ConversationMessage::select('id', 'user_id', 'content', 'created_at')
                    ->where('id', $messageId)
                    ->with('user:id,name,profile_image')
                    ->first();
    }

    /* Get vehicle all conversations */
    public function getVehicleConversations($vehicleId){
        $query = Conversation::select('id', 'vehicle_id', 'title')
                    ->where('vehicle_id', $vehicleId)
                    ->with([
                        'vehicle:id,user_id,title,price',
                        'vehicle.user:id,name,email,phone',
                        'vehicle.main_image:id,vehicle_id,image,caption'
                    ]);         
        return $query->orderBy('id', 'DESC')
                    ->get();
    }

}
