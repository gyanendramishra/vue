<?php
namespace App\Repositories\Interfaces;

interface NewsInterface {
    
    public function getAllNews();
    
    public function getHomeNews();

    public function getNewsBySlug($slug);
}
