<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\UserRepository;

class DashboardController extends Controller {

     /**
     * User repository.
     *
     * @var string
     */
    private $userRepository;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        UserRepository $userRepository
    ){
        $this->userRepository = $userRepository;
    }
    
    
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request) {
        
        $totalVehicles =  $this->userRepository->getTotalVehicle();
        $totalFeaturedVehicles =  $this->userRepository->getTotalFeaturedVehicle();
        $totalVehiclesInquiry =  $this->userRepository->getTotalVehiclesInquiry();
        $totalFavouriteVehicles =  $this->userRepository->getTotalFavouriteVehicles();
        
        return view('frontend.user.dashboard', compact('totalVehicles','totalFeaturedVehicles','totalVehiclesInquiry','totalFavouriteVehicles'));
    }

}
