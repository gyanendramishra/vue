<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\UserRepository;

class SavedVehicleController extends Controller {

    /**
     * User repository.
     *
     * @var string
     */
    private $userRepository;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        UserRepository $userRepository
    ){
        $this->userRepository = $userRepository;
    }
    
    
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request) {
        if($request->ajax()){
            try {
                $vehicles =  $this->userRepository->getSavedVehicle();
                return response()->json([
                        "status"=> "success",
                        "data"=> $vehicles
                    ], 200);
            } catch (\Exception $e) {
                return response()->json([
                    "status"=>"error",
                    "message"=>__('frontend.OOPS')
                ], 200);
            }
        }else{
            try {
                $vehicles =  $this->userRepository->getSavedVehicle();
                return view('frontend.user.saved_vehicle', compact('vehicles'));
            } catch (\Exception $e) {
                return redirect()
                            ->route('frontend.dashboard');
            }
        }
    }

}
