<?php

namespace App\Http\Controllers\Frontend\Api;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\ConversationRepository;

class ConversationController extends Controller {

    /**
     * Conversation repository.
     *
     * @var string
     */
    private $conversationRepository;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        ConversationRepository $conversationRepository
    ){
        $this->conversationRepository = $conversationRepository;
    }

    /**
     * Get conversation messages.
     *
     * @return \Illuminate\Http\Response
     */
    public function getMessagesByConversationId($id) {
        try {
            $messages = $this->conversationRepository->getConversationMessages($id);
            return response()->json([
                        "status" => "success",
                        "messages" => $messages
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function sendMessage(Request $request) {
        try {
            \DB::beginTransaction();
            $message = new \Modules\VehicleEnquiresManager\Entities\ConversationMessage($request->all());
            if ($message->save()) {
                // DB commit
                \DB::commit();

                $message = $this->conversationRepository->getMessageById($message->id);

                return response()->json([
                            "status" => "success",
                            "message" => $message
                        ], 200);
            }
            throw new Exception(__('frontend.OOPS'));
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * Get conversation messages.
     *
     * @return \Illuminate\Http\Response
     */
    public function getVehicleConversation($vehicleId) {
        try {
            $conversations = $this->conversationRepository->getVehicleConversations($vehicleId);
            return response()->json([
                        "status" => "success",
                        "conversations" => $conversations
                            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

}
