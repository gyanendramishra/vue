<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\VehicleRepository;

class VehicleCompareController extends Controller
{
    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;


    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        VehicleRepository $vehicleRepository
    ){
        $this->vehicleRepository = $vehicleRepository;
    }

    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request, $slug){
        /* Exctact slugs form string */
        $slugs = explode('-vs-', $slug);
        /* take only first 4 elements from array */
        $slugs = array_slice($slugs, 0, 4);
        /* Get vehicles by slug */
        $vehicles = $this->vehicleRepository->getVehiclesBySlugs($slugs);
        //dd($vehicles);
        if($vehicles->isNotEmpty()){
            $features = $this->vehicleRepository->getAllFeatures();
            return view('frontend.vehicle.compare', compact('vehicles', 'features'));
        }else{
            abort(404);
        }
    }
}
