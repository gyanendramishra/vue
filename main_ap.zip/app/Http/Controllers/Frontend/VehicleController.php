<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\AdRepository;
use App\Repositories\ReviewRepository;
use App\Repositories\VehicleRepository;

class VehicleController extends Controller
{
    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;

    /**
     * Review repository.
     *
     * @var string
     */
    private $reviewRepository;

    /**
     * Ad repository.
     *
     * @var string
     */
    private $adRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        VehicleRepository $vehicleRepository,
        ReviewRepository $reviewRepository,
        AdRepository $adRepository
    ){
        $this->vehicleRepository = $vehicleRepository;
        $this->reviewRepository = $reviewRepository;
        $this->adRepository = $adRepository;
    }

    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request, $slug){
        if($request->ajax()){
            try {
                $vehicle = $this->vehicleRepository->getVehicleBySlug($slug);
                $vehicleReviews = $this->reviewRepository->getVehicleReviews($vehicle->id);
                return response()->json([
                        "status"=> "success",
                        "data"=> $vehicleReviews
                    ], 200);
            } catch (\Exception $e) {
                return response()->json([
                    "status"=>"error",
                    "message"=>__('frontend.OOPS')
                ], 200);
            }
        }else{
            $vehicle = $this->vehicleRepository->getVehicleBySlug($slug);
            if($vehicle){
                $checkApproval = true;
                if(\Auth::guard('user')->check()){
                    if($vehicle->user_id === \Auth::guard('user')->id()){
                        $checkApproval = false;
                    }
                }
                if($checkApproval && ($vehicle->is_approved == 0)){
                    abort(404);
                }
                $vehicleReviews = $this->reviewRepository->getVehicleReviews($vehicle->id);
                $similarVehicles = $this->vehicleRepository->getSimilarVehiclesByPrice($vehicle->id, $vehicle->price);
                $features = $this->vehicleRepository->getAllFeatures();
                $ads = $this->adRepository->getDetailPageAds();
                
                return view('frontend.vehicle.info', compact(
                    'vehicle',
                    'vehicleReviews', 
                    'features', 
                    'similarVehicles',
                    'ads'
                ));
            }
        }
    }
}
