<?php

namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\VehicleMakeManager\Entities\VehicleMake;
use Modules\AdsManager\Entities\Ad;
use App\PageLocation;
use Modules\VehicleBodyStyleManager\Entities\VehicleBodyStyle;
use Modules\VehicleManager\Entities\Vehicle;
use Modules\VehicleTransmissionsManager\Entities\VehicleTransmissions;
use Modules\VehicleFuelTypesManager\Entities\VehicleFuelTypes;
use Modules\VehicleFeatureManager\Entities\VehicleFeature;
use Modules\CategoryManager\Entities\Category;
use Modules\VehicleLifestyleManager\Entities\VehicleLifestyle;
use Modules\VehicleColorsManager\Entities\VehicleColors;
use App\Http\Resources\Collection\MakeCollection as MakeCollection;
use App\Http\Resources\Collection\TransmissionsCollection as TransmissionsCollection;
use App\Http\Resources\Collection\FuelTypesCollection as FuelTypesCollection;
use App\Http\Resources\Collection\BodyTypeCollection as BodyTypeCollection;
use App\Http\Resources\Collection\ColorCollection as ColorCollection;
use App\Http\Resources\Collection\CategoryCollection as CategoryCollection;
use App\Http\Resources\Collection\CountryCollection as CountryCollection;
use App\Http\Resources\Collection\FeatureCollection as FeatureCollection;
use App\Http\Resources\Collection\LifestyleCollection as LifestyleCollection;
use Config;
use Modules\NewsManager\Entities\News;

class HomeController extends Controller {

    public $successStatus = 200;

    /**
     * Instantiate a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request) {
        //$authInformation = $request->header();
        if ($request->header('language')) {
            \App::setLocale($request->header('language'));
        } else {
            \App::setLocale('en');
        }

        session()->put('locale', $request->header('language'));
    }

    /**
     * Home api
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {

        $data = [];
        try {
            $page_location_id = PageLocation::where('slug', request()->segment(2))->first()->id;
            $datas['top_banner'] = url('images/bannerImg.jpg');
            $vahiclemakes = VehicleMake::withTranslation()->where('status', 1);
            $datas['makes_total'] = $vahiclemakes->count();
            $makeslist = $vahiclemakes->limit(6)->get();
            $makes = [];
            foreach ($makeslist AS $key => $row) {
                $makes[$key] = $row;
                if (!empty($row->icon)) {
                    $makes[$key]->icon = url('uploads/make/' . $row->icon);
                }
            }
            $datas['makes'] = $makes;
            $body_types = VehicleBodyStyle::withTranslation()->where('status', 1);
            $datas['body_type_total'] = $body_types->count();
            $typeslist = $body_types->limit(6)->get();
            $types = [];
            foreach ($typeslist AS $key => $row) {
                $types[$key] = $row;
                if (!empty($row->icon)) {
                    $types[$key]->icon = url('uploads/bodyStyle/' . $row->icon);
                }
            }
            $datas['body_types'] = $types;
            $datas['review'] = [];
            $news = News::select('id', 'image', 'start_date','end_date')
                    ->with('translations:id,news_id,locale,title')
                    ->active()
                    ->take(10)
                    ->inRandomOrder()
                    ->get();
            foreach ($news as $k => $news) {
                $newss[$k]['image'] = url('uploads/newsImages/' . $news->image);
                $newss[$k]['title'] = $news->title;
                $newss[$k]['description'] = $news->description;
                $newss[$k]['start_date'] = $news->start_date;
                $newss[$k]['end_date'] = $news->end_date;
            }

            $datas['news'] = $newss;
            $caroftheweek['image'] = "";
            $caroftheweek = [];
            $caroftheweeks = Vehicle::withTranslation()->with('vehicle_images')->where('status', 1)->where('car_of_the_week', 1)->first();
            if ($caroftheweeks) {
                if ($caroftheweeks->vehicle_images->isNotEmpty()) {
                    $caroftheweek['image'] = url('storage/vehicle/' . @$caroftheweeks->vehicle_images()->first()->image);
                }
                $caroftheweek['web_url'] = "https://carmarket.projectstatus.in/vehicle/" . $caroftheweeks->slug;
                $caroftheweek['slug'] = $caroftheweeks->slug;
                $caroftheweek['description'] = "Car of the Year is a common abbreviation for numerous awards";
                $datas['caroftheweek'] = $caroftheweek;
            }

            $advertisement = [];
            $ads = [];
            if (Ad::withTranslation()->where(['status' => 1, 'page_location_id' => $page_location_id])->exists()) {
                $ads[] = Ad::withTranslation()->where(['status' => 1, 'page_location_id' => $page_location_id])->inRandomOrder()->first('id', 'title', 'image_type', 'image', 'image_scripts', 'url')->setAttribute("type", "home")->setAppends(['image_full_path']);
            }
            if (Ad::withTranslation()->where(['status' => 1, 'page_location_id' => 4])->exists()) {
                $ads[] = Ad::withTranslation()->where(['status' => 1, 'page_location_id' => 4])->inRandomOrder()->first('id', 'title', 'image_type', 'image', 'image_scripts', 'url')->setAppends(['image_full_path'])->setAttribute("type", "filter");
            }

            $datas['advertisement'] = $ads;
            $data['data'] = $datas;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {

            $data['data'] = [];
            $data['status'] = false;
            $data['message'] = $ex->getMessage();
            $data['code'] = 401;
            return response()->json($data);
        }
    }

    /**
     * Master api
     *
     * @return \Illuminate\Http\Response
     */
    public function masters(Request $request) {

        try {
            $datas = [
                ["item" => "Make", "value" => new MakeCollection(VehicleMake::withTranslation()->get())],
                ["item" => "Any Distance", "value" => []],
                ["item" => "Year", "value" => []],
                ["item" => "Price", "value" => []],
                ["item" => "Ad Type", "value" => new CategoryCollection(Category::withTranslation()->get())],
                ["item" => "Keywords", "value" => []],
                ["item" => "Transmissions", "value" => new TransmissionsCollection(VehicleTransmissions::withTranslation()->get())],
                ["item" => "Fuel Types", "value" => new FuelTypesCollection(VehicleFuelTypes::withTranslation()->get())],
                ["item" => "Fuel Economy", "value" => Config::get('constants.FUEL_ECONOMYS')],
                ["item" => "Cylinder", "value" => Config::get('constants.Cylinders')],
                ["item" => "Engine Size", "value" => []],
                ["item" => "Body Type", "value" => new BodyTypeCollection(VehicleBodyStyle::withTranslation()->get())],
                ["item" => "Color", "value" => new ColorCollection(VehicleColors::withTranslation()->get())],
                ["item" => "Seats", "value" => []],
                ["item" => "Doors", "value" => Config::get('constants.DOORS')],
                ["item" => "Features", "value" => new FeatureCollection(VehicleFeature::withTranslation()->get())],
                ["item" => "Lifestyle", "value" => new LifestyleCollection(VehicleLifestyle::withTranslation()->get())],
            ];
            $data['data'] = $datas;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            return response()->json([
                        'status' => FALSE,
                        'message' => $ex->getMessage(),
                        'data' => '',
                            ], 401);
        }
    }

    /**
     * 
     * @param Request $request
     * @return type
     */
    public function location(Request $request) {
        try {
            $datas = [
                ["item" => "Location", "value" => new CountryCollection(\App\Country::whereIn('id', [12])->get())],
            ];
            $data['data'] = $datas;
            $data['status'] = true;
            $data['code'] = 200;
            return response()->json($data);
        } catch (Exception $ex) {
            return response()->json([
                        'status' => FALSE,
                        'message' => $ex->getMessage(),
                        'data' => '',
                            ], 401);
        }
    }

}
