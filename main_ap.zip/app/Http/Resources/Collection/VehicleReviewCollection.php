<?php

namespace App\Http\Resources\Collection;

use Illuminate\Http\Resources\Json\ResourceCollection;
use App\Http\Resources\VehicleReviewResource as VehicleReviewResource;

class VehicleReviewCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return VehicleReviewResource::collection($this->collection);
    }
}
