<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class VehicleReviewResource extends JsonResource {

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request) {
     
        $data = [
            'id' => $this->id,
            'title' => $this->title,
            'slug' => $this->slug,
            'avg_rating' => $this->getAverageRatingAttribute(),
            'last_review' => $this->getLatestReviewTitleAttribute(),
            'image' => url('storage/vehicle/') . "/" . $this->main_image->image,
            'video' => $this->video,
            'vehicle_reviews_count' => $this->vehicle_reviews_count,
          
        ];


        return $data;
    }

}
