<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Modules\VehicleFeatureManager\Entities\VehicleFeature;
use App\Http\Resources\Collection\FeatureCollection as FeatureCollection;
use App\Http\Resources\Collection\ImageCollection;

class VehicalDetailResource extends JsonResource {

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request) {

        $features = [];
        foreach ($this->vehicleFeatures as $vehicleFeatures) {
            $features[] = $vehicleFeatures->name;
        }
        $data = [
            'id' => $this->id,
            'title' => $this->year . " " . $this->title,
            'year_build' => $this->year_build,
            'engine_size' => $this->engine_size,
            'year_complied' => $this->year_complied,
            'doors' => $this->doors,
            'make' => $this->make->name,
            'model' => $this->model->name,
            'badge' => $this->badge->name,
            'year' => $this->year,
            'price' => '$' . $this->price,
            'seats' => $this->seats,
            'chassis_number' => $this->chassis_numbe,
            'plate_number' => $this->plate_number,
            'gears' => $this->gears,
            'fuel_economy' => $this->fuel_economy,
            'fuel_type' => $this->fuel_type->name,
            'transmissions' => $this->transmissions->name,
            'turbo' => $this->turbo,
            'odometer' => $this->odometer,
            'expiry_month' => $this->expiry_month,
            'expiry_year' => $this->expiry_year,
            'description' => $this->description,
            'phone' => $this->phone,
            'images' => $this->vehicle_images()->get(),
            'created_at' => $this->created_at,
            'owner_id' => ($this->user)?$this->user->id:'',
            //'is_favourite ' => $this->created_at,
        ];

        $overview = [
            array('key' => 'Vehicle', 'value' => $this->title),
            array('key' => 'Price', 'value' => '$' . $this->price),
            array('key' => 'Kilometers', 'value' => $this->odometer . " km"),
            array('key' => 'Exterior Colour', 'value' => ($this->exteriorColor) ? $this->exteriorColor->name : ''),
            array('key' => 'Interior Colour', 'value' => ($this->interiorColor) ? $this->interiorColor->name : ''),
            array('key' => 'Transmission', 'value' => $this->transmissions->name),
            array('key' => 'Body', 'value' => ($this->bodystyle->name) ? $this->bodystyle->name : ''),
            array('key' => 'Registration Plate', 'value' => $this->plate_number),
            array('key' => 'Registration Expiry', 'value' => $this->expiry_month . " " . $this->expiry_year),
            array('key' => 'Build Date', 'value' => $this->year_build),
            array('key' => 'Compliance Date', 'value' => $this->year_complied),
        ];
        $spec = [
            array('key' => 'Fuel Type', 'value' => ($this->fuel_type->name) ? $this->fuel_type->name : ''),
            array('key' => 'Drive Type', 'value' => ($this->drive_types->name) ? $this->drive_types->name : ''),
            array('key' => 'Doors', 'value' => $this->doors),
            array('key' => 'Seats', 'value' => $this->seats),
            array('key' => 'Gears', 'value' => $this->gears),
            array('key' => 'Cylinders', 'value' => ($this->cylinders_id) ? $this->cylinders_id : ''),
            array('key' => 'Forced Induction', 'value' => $this->turbo),
            array('key' => 'Fuel Economy', 'value' => \Config::get('constants.FUEL_ECONOMYS.') . $this->fuel_economy_id),
        ];
        $data['is_favourite'] = $this->is_favourite($this->id);
        $data['spec'] = $spec;
        $data['overview'] = $overview;
        $data['images'] = new ImageCollection($this->vehicle_images()->get());
        $data['features'] = $features;
        $data['allFeatures'] = new FeatureCollection(VehicleFeature::withTranslation()->get());

        return $data;
    }

    protected function is_favourite($value) {
        if (\Auth::guard('api')->check()) {

            if (\Auth::guard('api')->user()->favouriteVehicles()->wherePivot('vehicle_id', $value)->first()) {
                $user = \Auth::guard('api')->user()->favouriteVehicles()->wherePivot('vehicle_id', $value)->first();
                return $user->pivot->is_favourite;
            }
        }
        return 0;
    }

}
