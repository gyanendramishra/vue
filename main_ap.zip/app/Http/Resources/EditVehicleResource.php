<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Modules\VehicleFeatureManager\Entities\VehicleFeature;
use App\Http\Resources\Collection\FeatureCollection as FeatureCollection;
use App\Http\Resources\Collection\ImageCollection;

class EditVehicleResource extends JsonResource {

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request) {
      
        $features = [];
        $feature_id = [];
        foreach ($this->vehicleFeatures as $vehicleFeatures) {
            $features[] = $vehicleFeatures->name;
            
        }
        foreach ($this->vehicleFeatures as $vehicleFeatures) {
            $feature_id[] = $vehicleFeatures->id;
            
        }
        $data = [
            'id' => $this->id,
            'title' => $this->year_build . " " . $this->title,
            'slug' => $this->slug,
            'makes_id' => $this->makes_id,
            'make' => $this->make->name,
            'model' => $this->model->name,
            'badge' => $this->badge->name,
            'series' => $this->series->name,
            'models_id' => $this->models_id,
            'badge_id' => $this->badge_id,
            'series_id' => $this->series_id,
            'body_styles_id' => $this->body_styles_id,
            'fuel_types_id' => $this->fuel_types_id,
            'drive_types_id' => $this->drive_types_id,
            'transmissions_id' => $this->transmissions_id,
             'body_styles' => ($this->bodystyle)?$this->bodystyle->name:'',
            'fuel_types' => $this->fuel_type->name,
            'drive_types' =>( $this->drive_types)? $this->drive_types->name:'',
            'transmissions' => ($this->transmissions)?$this->transmissions->name:'',
            'door' => $this->doors,
            'doors' => $this->doors,
            'seats' => $this->seats,
            'gears' => $this->gears,
            'cylinders' => $this->cylinders_id,
            'cylinders_id' => $this->cylinders_id,
            'year_build' => $this->year_build,
            'month_build' => $this->month_build,
            'year_complied' => $this->year_complied,
            'turbo' => $this->turbo,
            'engine_capacity' => $this->engine_capacity,
            'chassis_number' => $this->chassis_number,
            'category_id' => $this->category_id,
            'odometer' => $this->odometer,
            'price' => $this->price,
            'discount_price' => $this->discount_price,
            'interior_colour_id' => $this->interior_colour_id,
            'interior_colour' => ($this->interiorColor)?$this->interiorColor->name:'',
            'exterior_colour_id' => $this->exterior_colour_id,
            'exterior_colour' => ($this->exteriorColor)?$this->exteriorColor->name:'',
            'expiry_month' => $this->expiry_month,
            'expiry_year' => $this->expiry_year,
            'plate_number' => $this->plate_number,
            'written_off' => $this->written_off,
            'approved_certified' => $this->approved_certified,
            'phone' => $this->phone,
            'address' => $this->address,
            'postcode' => $this->postcode,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'city' => $this->city,
            'state' => $this->state,
            'country' => $this->country,
            'fuel_economy_id' => $this->fuel_economy_id,
            'fuel_economy' => \Config('constants.FUEL_ECONOMY.'.$this->fuel_economy_id),
            'features' => $features,
            'feature_id' => $feature_id,
            'en_description' => $this->translate('en')['description'],
            'kh_description' => $this->translate('kh')['description '],
            'lifestyle_id' => $this->lifestyle_id,
            'lifestyle' => ($this->vehicleLifestyle)?$this->vehicleLifestyle->name:'',
            'vehicle_images' => new ImageCollection($this->vehicle_images()->get()),
        ];


        return $data;
    }

   

}
