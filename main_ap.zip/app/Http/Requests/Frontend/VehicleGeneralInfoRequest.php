<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class VehicleGeneralInfoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('user')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title'            =>'required|max:100',
            'type'             =>'required|integer',
            'make_id'          =>'required|integer',
            'model_id'         =>'required|integer',
            'badge_id'         =>'required|integer',
            'series_id'        =>'required|integer',
            'body_type_id'     =>'required|integer',
            'fuel_type_id'     =>'required|integer',
            'drive_type_id'    =>'required|integer',
            'transmission_id'  =>'required|integer',
            'doors'            =>'required|integer',
            'seats'            =>'required|integer',
            'gears'            =>'required|integer',
            'cylinders'        =>'required|integer',
            'year_built'       =>'required',
            'month_built'      =>'required',
            'year_complied'    =>'nullable',
            'turbo'            =>'required',
            'engine_capacity'  =>'required|max:10',
            'chassis_number'   =>'nullable|max:17'
        ];
    }
}
