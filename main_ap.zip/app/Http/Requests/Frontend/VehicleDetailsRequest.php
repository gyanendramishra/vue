<?php

namespace App\Http\Requests\Frontend;

use Illuminate\Foundation\Http\FormRequest;

class VehicleDetailsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::guard('user')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'vehicle_slug'              =>'required',
            'address'                   =>'required|max:100',
            'country'                   =>'nullable|max:50',
            'state'                     =>'nullable|max:50',
            'city'                      =>'nullable|max:50',
            'postcode'                  =>'nullable|max:10',
            'latitude'                  =>'nullable|max:30',
            'longitude'                 =>'nullable|max:30',
            'odometer'                  =>'required|numeric|digits_between:1,10',
            'sale_price'                =>'required|numeric|digits_between:1,10',
            'discounted_price'          =>'required|numeric|digits_between:1,10',
            'interior_color_id'         =>'required|integer',
            'exterior_color_id'         =>'required|integer',
            'lifestyle_id'              =>'required|integer',
            'registration_plate_number' =>'required|string|max:9',
            'registration_expiry_month' =>'required',
            'registration_expiry_year'  =>'required',
            'fuel_economy_id'           =>'required|integer',
            'contact_phone_number'      =>'required|numeric|regex:/^([0-9\s\-\+\(\)]*)$/|digits_between:4,16',
            'english_comment'           =>'nullable|string|min:100|max:500',
            'khmer_comment'             =>'nullable|string|min:100|max:500',
            'is_written_off'            =>'required|boolean',
            'is_car_registered'         =>'required|boolean'
        ];
    }
}
