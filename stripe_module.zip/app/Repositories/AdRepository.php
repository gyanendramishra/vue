<?php
namespace App\Repositories;

use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Modules\AdsManager\Entities\Ad;
use App\Repositories\Interfaces\AdInterface;

class AdRepository implements AdInterface {
    

    /* Get home ad's */
    public function getHomeAds(){
        return Ad::select('id', 'page_location_id', 'position_id')
                    ->with('translations:id,ad_id,title,image,image_type,image_scripts,url,locale,title')
                    ->whereHas('page_location', function($q){
                        $q->whereName('Home');
                    })
                    ->whereHas('position', function($q){
                        $q->whereName('Mid');
                    })
                    ->active()
                    ->take(3)
                    ->inRandomOrder()
                    ->get();
    }

    /* Get listing page ad's */
    public function getListingPageAds(){
        $ads = new \stdClass;
        $ads->top_ad = $this->getLisitngPageTopAd();
        $ads->left_ad = $this->getLisitngPageLeftAd();
        $ads->bottom_ad = $this->getLisitngPageBottomAd();
        return $ads;
    }

    /* Get detail page ad's */
    public function getDetailPageAds(){
        $ads = new \stdClass;
        $ads->top_ad = $this->getDetailPageTopAd();
        $ads->left_ad = $this->getDetailPageLeftAd();
        $ads->bottom_ad = $this->getDetailPageBottomAd();
        return $ads;
    }

    /* Get listing page left ad */
    public function getLisitngPageLeftAd(){
        return Ad::select('id', 'page_location_id', 'position_id')
                    ->with('translations:id,ad_id,title,image,image_type,image_scripts,url,locale,title')
                    ->whereHas('page_location', function($q){
                        $q->whereName('Vehicle Listing');
                    })
                    ->whereHas('position', function($q){
                        $q->whereName('Side Left');
                    })
                    ->active()
                    ->inRandomOrder()
                    ->first();
    }

    /* Get listing page top ad */
    public function getLisitngPageTopAd(){
        return Ad::select('id', 'page_location_id', 'position_id')
                    ->with('translations:id,ad_id,title,image,image_type,image_scripts,url,locale,title')
                    ->whereHas('page_location', function($q){
                            $q->whereName('Vehicle Listing');
                    })
                    ->whereHas('position', function($q){
                        $q->whereName('Top');
                    })
                    ->active()
                    ->inRandomOrder()
                    ->first();
    }

    /* Get listing page bottom ad */
    public function getLisitngPageBottomAd(){
        return Ad::select('id', 'page_location_id', 'position_id')
                    ->with('translations:id,ad_id,title,image,image_type,image_scripts,url,locale,title')
                    ->whereHas('page_location', function($q){
                        $q->whereName('Vehicle Listing');
                    })
                    ->whereHas('position', function($q){
                        $q->whereName('Bottom');
                    })
                    ->active()
                    ->inRandomOrder()
                    ->first();
    }

    /* Get detail page left ad */
    public function getDetailPageLeftAd(){
        return Ad::select('id', 'page_location_id', 'position_id')
                    ->with('translations:id,ad_id,title,image,image_type,image_scripts,url,locale,title')
                    ->whereHas('page_location', function($q){
                        $q->whereName('Vehicle Detail');
                    })
                    ->whereHas('position', function($q){
                        $q->whereName('Side Left');
                    })
                    ->active()
                    ->inRandomOrder()
                    ->first();
    }

    /* Get detail page top ad */
    public function getDetailPageTopAd(){
        return Ad::select('id', 'page_location_id', 'position_id')
                    ->with('translations:id,ad_id,title,image,image_type,image_scripts,url,locale,title')
                    ->whereHas('page_location', function($q){
                        $q->whereName('Vehicle Detail');
                    })
                    ->whereHas('position', function($q){
                        $q->whereName('Top');
                    })
                    ->active()
                    ->inRandomOrder()
                    ->first();
    }

    /* Get detail page bottom ad */
    public function getDetailPageBottomAd(){
        return Ad::select('id', 'page_location_id', 'position_id')
                    ->with('translations:id,ad_id,title,image,image_type,image_scripts,url,locale,title')
                    ->whereHas('page_location', function($q){
                        $q->whereName('Vehicle Detail');
                    })
                    ->whereHas('position', function($q){
                        $q->whereName('Bottom');
                    })
                    ->active()
                    ->inRandomOrder()
                    ->first();
    }

}
