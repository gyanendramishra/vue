<?php

namespace App\Http\Middleware;

use Illuminate\Auth\Middleware\Authenticate as Middleware;

class Authenticate extends Middleware {

    /**
     * Get the path the user should be redirected to when they are not authenticated.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return string
     */
    protected function redirectTo($request) {
        if (!$request->expectsJson()) {
            if ($request->is('api') || $request->is('api/*')) {
                // return response('Hello World', 200)
                // ;
                return route('api.test.user');
                // return $this->sendError($data, $this->messageDefault('You are not authorize to access.'), '401');
            } else {
                 if($request->is('admin') || $request->is('admin/*')){
                    return route('admin.login');
                }
                return route('frontend.login');
            }
        }
    }

}
