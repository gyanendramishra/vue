<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\AdRepository;
use App\Repositories\NewsRepository;
use App\Repositories\ReviewRepository;
use App\Repositories\VehicleRepository;

class HomeController extends Controller
{

    /**
     * Vehicle repository.
     *
     * @var string
     */
    private $vehicleRepository;

    /**
     * Review repository.
     *
     * @var string
     */
    private $reviewRepository;

    /**
     * News repository.
     *
     * @var string
     */
    private $newsRepository;

    /**
     * Ad repository.
     *
     * @var string
     */
    private $adRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        VehicleRepository $vehicleRepository, 
        ReviewRepository $reviewRepository,
        NewsRepository $newsRepository,
        AdRepository $adRepository
    ){
        $this->vehicleRepository = $vehicleRepository;
        $this->reviewRepository = $reviewRepository;
        $this->newsRepository = $newsRepository;
        $this->adRepository = $adRepository;
    }

    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {  
        $types = $this->vehicleRepository->getAllType(); 
        $fuelTypes = $this->vehicleRepository->getAllFuelType(); 
        $reviews = $this->reviewRepository->getHomeReviews();
        $news = $this->newsRepository->getHomeNews();   
        $ads = $this->adRepository->getHomeAds();
        $carOfTheWeek = $this->vehicleRepository->getCarOfTheWeek(); 
       
        return view('frontend.home', compact(
            'types',  
            'fuelTypes',
            'reviews', 
            'news',
            'ads',
            'carOfTheWeek'
        ));
    }
}
