<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Repositories\AdRepository;
use App\Repositories\NewsRepository;

class NewsController extends Controller
{

    /**
     * News repository.
     *
     * @var string
     */
    private $newsRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        NewsRepository $newsRepository,
        AdRepository $adRepository
    ){
        $this->newsRepository = $newsRepository;
        $this->adRepository = $adRepository;
    }
    /**
     * Display news view.
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if($request->ajax()){
            try {
                $news = $this->newsRepository->getAllNews();
                return response()->json([
                        "status"=> "success",
                        "data"=> $news
                    ], 200);
            } catch (\Exception $e) {
                return response()->json([
                    "status"=>"error",
                    "message"=>__('frontend.OOPS')
                ], 200);
            }
        }else{
            $news = $this->newsRepository->getAllNews();
            return view('frontend.news.index', compact('news'));
        }
    }

    /**
     * Display news detail view.
     *
     * @param  Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function info(Request $request, $slug)
    {
        $news = $this->newsRepository->getNewsBySlug($slug);
        if($news){
            return view('frontend.news.info', compact('news'));
        }
        abort(404);
    }

}
