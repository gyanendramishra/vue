<?php

namespace App\Http\Controllers\Frontend\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Frontend\LoginRequest;
use \Illuminate\Http\Request;
use App\User;
use Aloha\Twilio\Twilio;

class LoginController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest:user')->except('logout');
    }

    /**
     * Display a login view of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {

        return view('frontend.auth.login');
    }
    /**
     * Login user into the system.
     *
     * @param  \App\Http\Requests\Backend\LoginRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function login(LoginRequest $request) {

        try {
            // Attempt user login
            if (Auth::guard('user')->attempt([
                         (is_numeric($request->get('email')))?'phone':'email'=>$request->get('email'),
                        'password' => $request->password
                            ])) {
                $user = \Auth::guard('user')->user();
                $error = 0;
                // Check if user is active
                if ($user->is_otp_verified == 0) {
                    $error = 1;
                }
                // Check if user is verified
                if ($user->status == 0) {
                    $error = 2;
                }
                if($error != 0){
                    \Auth::guard('user')->logout();
                    if($error == 1){
                        $RandomNumber = rand(100000, 999999);
                        $account_id = env('TWILIO_SID');
                        $auth_token = env('TWILIO_TOKEN');
                        $from_phone_number = env('TWILIO_FROM');
                        $twilio = new Twilio($account_id, $auth_token, $from_phone_number);
                        \App\UserVerification::where('user_id',$user->id)->where('otp_type',1)->delete();
                        \App\UserVerification::create([
                            'user_id'=>$user->id,
                            'otp'=>'123456',
                            'otp_type'=>1,
                        ]);
                        $str = '123456' . ' is your one time password (OTP) for car market phone verification';
                        if(!$request->countryCode){
                           $phoneNo = $user->country_code . $user->phone;
                        }else{
                            $phoneNo = $request->countryCode . $user->phone;
                        }

                        $twilio->message($phoneNo, $str);

                        return response()->json([
                                    "phone" => $user->phone,
                                    "status" => "success",
                                    "s_code"=> 105,
                                    "message" => __('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_VERIFICATION')
                                        ], 200);
                    }
                    if($error == 2){
                        return response()->json([
                                "status" => "error",
                                "message" => __('frontend.LOGIN_FAILED_DUE_TO_ACCOUNT_ACTIVATION')
                                    ], 200);
                    }
                }

                // Login success
                $target_url = \Redirect::intended('dashboard')->getTargetUrl();
                if (\Str::contains($target_url, 'admin/')) {
                    $target_url = route('frontend.dashboard');
                }
                
                return response()->json([
                            "status" => "success",
                            'target_url' => $target_url,
                            "message" => __('frontend.LOGIN_SUCCESS')
                                ], 200);
            }
            // Failed login
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.LOGIN_FAILED')
                            ], 200);
        } catch (\Exception $e) {
           
            return response()->json([
                        "status" => "error",
                        "message" => __('frontend.OOPS')
                            ], 200);
        }
    }

    /**
     * customize the guard.
     *
     * @return object
     */
    protected function guard() {
        return Auth::guard('user');
    }

    /**
     * Remove user from session.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function logout(Request $request) {
        $this->guard()->logout($request);
        return redirect()
                        ->route('frontend.login')
                        ->withFlashSuccess(__('frontend.LOGOUT_SUCCESS'));
    }

}
