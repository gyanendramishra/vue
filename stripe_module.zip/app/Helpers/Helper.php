<?php
namespace App\Helpers;

class Helper
{
    /**
     * Format as currency.
     *
     * @param $amount
     * @return string
     */
    public static function format_currency($amount): string
    {
        $amount = (float) $amount;
        $amount = number_format($amount);
        return '$'.str_replace('.00', '', $amount);
    }

    /**
     * Format as number.
     *
     * @param $number
     * @return string
     */
    public static function format_number($number): string
    {
        $number = (float) $number;
        $number = number_format($number);
        return str_replace('.00', '', $number);
    }
    /**
     * getStingWithEmoji
     * @return String
     */
    public static function imageUrl($path, $width = null, $height = null, $quality = null, $crop = null)
    {
        if (!$width && !$height) {
            $url = $path;
        } else {
            $url = url('/') . '/timthumb.php?src=' . $path;
            if (isset($width)) {
                $url .= '&w=' . $width;
            }
            if (isset($height) && $height > 0) {
                $url .= '&h=' . $height;
            }
            if (isset($crop)) {
                $url .= "&zc=" . $crop;
            } else {
                $url .= "&zc=1";
            }
            if (isset($quality)) {
                $url .= '&q=' . $quality . '&s=1';
            } else {
                $url .= '&q=95&s=1';
            }
        }
        return $url;
    }
}