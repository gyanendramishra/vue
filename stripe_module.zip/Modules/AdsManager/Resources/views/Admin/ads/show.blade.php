@extends('layouts.admin.app')
@section('title','View CMS Page Detail')
@section('content')
<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
     
       {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.ads.index'],['label' => 'View Ad Detail']]]) }}
    </div>
  </div>
<div class="wojo-grid">
    <div class="wojo form segment">
    
          
      @php

        $locales = config('app.locales');
      @endphp
      @foreach($locales as $key=>$val)
                @if($key=='en')
         <table class="wojo two column table">
         <thead>
             <tr class="viewheading">
              <td colspan="2"> <span><strong> {{ __('Manage Ads ')}} </strong></span></td>
              <td> <a style="float:right;" href="{{route('admin.ads.index')}}" class="btn btn-primary"><span>Back</span></a></td>
            </tr>

          </thead>
           
                    <tr>
                        <td><strong>{{ __('Title') }}</strong></td>
                        <td>{{ $ads->translate($key)['title'] }}</td>
                    </tr>
                    @if($ads->translate($key)['image_scripts'] == 2)
                        @if(!empty($ads->translate($key)['image_scripts']))
                        <tr>
                            <td><strong>{{ __('Google Script') }}</strong></td>
                            <td><strong>{{ $ads->translate($key)['image_scripts'] }}</strong></td>
                        </tr>
                        @endif
                    @else
                            @if(!empty($ads->translate($key)['image']))
                                <tr>
                                    <td><strong>{{ __('Image') }}</strong></td>
                                    @php
                                        $filepath = '/uploads/adsImages/';
                                    @endphp
                                    @if(!empty($ads->translate($key)['image']) && file_exists(public_path() . $filepath . $ads->translate($key)['image']))
                                    @php $imageurl=\App\Helpers\MenuHelpers::imageUrl(url($filepath. $ads->translate($key)['image']),'500','200','100'); @endphp

                                    <td><img src="{{$imageurl}}"></td>
                                    @endif
                               

                            </tr>
                        @endif
                    @endif


                    <!--  <div class="box-header with-border"> -->
                    <!--  <h3 class="box-title">General Details</h3>
                                          <table class="table table-hover table-striped"> -->
                    <tr>
                        <td><strong>{{ __('Page Loction') }}</strong></td>
                        <td>{{ $ads->page_location->name }}</td>
                    </tr>

                    <tr>
                        <td><strong>{{ __('position') }}</strong></td>
                        <td>{{ $ads->position->name }}</td>
                    </tr>                       
                    @if(!empty($ads->url))  
                    <tr>
                        <td><strong>{{ __('Url') }}</strong></td>
                        <td>{{ $ads->url }}</td>
                    </tr>
                    @endif                      
                    <tr>
                        <td><strong><?= __('Created') ?></strong></td>
                        <td>{{ $ads->created_at->format('d F, Y') }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Modified') }}</strong></td>
                        <td>{{ $ads->updated_at->format('d F, Y') }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Status') }}</strong></td>
                        <td>{{ $ads->status ? __('Active') : __('Inactive')  }}</td>
                    </tr>
                </table>
                @endif
                @endforeach
       
     
      
      
    
    </div>
  </div>


@stop