<?php

return [
    'name' => 'VehicleCylindersManager'
];
