<?php

return [
    'name' => 'VehicleComfortConvenienceManager'
];
