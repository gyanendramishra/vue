@extends('layouts.admin.master')
@section('title','View Category Detail')
@section('content')
@include('layouts.admin.flash.alert')
<section class="content-header">
    <h1>
        Manage Category        
    </h1>
    {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.category.index'],['label' => 'View Category Detail']]]) }}
</section>

<section class="content" data-table="emailHooks">
    @include('layouts.flash.alert')
    <div class="box">
        <div class="box-header"><h3 class="box-title">{{ $category->name }}</h3>
            <a href="{{route('admin.category.index')}}" class="btn btn-default pull-right" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
        </div>
        <div class="box-body">
            <table class="table table-hover table-striped">
                <tr>
                    <th scope="row">{{ __('Name') }}</th>
                    <td>{{ $category->name }}</td>
                </tr>
                <tr>
                    <th scope="row"><?= __('Created') ?></th>
                    <td>{{ $category->created_at->toFormattedDateString() }}</td>
                </tr>
                <tr>
                    <th scope="row">{{ __('Modified') }}</th>
                    <td>{{ $category->updated_at->toFormattedDateString() }}</td>
                </tr>
                <tr>
                    <th scope="row">{{ __('Status') }}</th>
                    <td>{{ $category->status ? __('Active') : __('Inactive')  }}</td>
                </tr>
            </table>           
        </div>
        <div class="box-footer">
                <a href="{{route('admin.category.index')}}" class="btn btn-default pull-left" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Cancel</a>
        </div>
    </div>
</section>

@endsection
