<?php

namespace Modules\SubscriptionManager\Entities;

use Illuminate\Database\Eloquent\Model;

class SubscriptionPlanTranslation extends Model {

    public $timestamps = false;
    protected $fillable = ["type","title", "description"];

    /**
     * Get the comments for the blog post.
     */
    public function subscriptionPlan() {

        return $this->belongsTo(\Modules\SubscriptionManager\Entities\SubscriptionPlan::class);
    }

}
