@extends('layouts.admin.app')
@section('title','View Subscription Detail')
@section('content')
<div id="crumbs" class="clearfix"> <!-- <span class="wojo primary label">en</span> -->
    <div class="wojo breadcrumb">
        {{ Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.subscription.index'],['label' => 'View Subscription Detail']]]) }}
    </div>
</div>

<div class="wojo-grid">
    <div class="wojo form segment">    

        <table class="wojo two column table">
            <tdead>
                <tr class="viewheading">
                    <td colspan="2"> <span><strong> {{ __('Manage Subscription')}} </strong></span></td>
                    <td> <a style="float:right;" href="{{route('admin.subscription.index')}}" class="btn btn-primary"><span>Back</span></a></td>
                </tr>

            </tdead>
            @php $locales = config('app.locales');@endphp
            @foreach($locales as $key=>$val)
            <table class="wojo two column table">
                <tdead>
                    <tr>
                        <td  colspan="2">{{  $val }} </td>
                    </tr>
                </tdead>
                <tbody>
                    <tr>
                        <td>{{ __('Title') }}</td>
                        <td>{{ $subscription->translate($key)['title'] }}</td>
                    </tr>
                </tbody>
            </table>
            @endforeach
            <table class="wojo two column table">
                <tdead>
                    <tr>
                        <td  colspan="2"> <strong> {{ __( 'General Details' ) }} </strong> </td>
                    </tr>
                </tdead>
                <tbody>
                    <tr>
                        <td><strong>{{ __('User Type') }}</strong></td>
                        <td>{{ $subscription->user_type }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Duration') }}</strong></td>
                        <td>{{ $subscription->duration }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Duration Type') }}</strong></td>
                        <td>{{ $subscription->duration_type }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Price') }} ($)</strong></td>
                        <td>{{ $subscription->price }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Minimum Ad Price') }}</strong></td>
                        <td>{{ $subscription->minimum_price }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Number Of Listing') }}</strong></td>
                        <td>{{ $subscription->total_listing_count }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Number Of On Sale Listing') }}</strong></td>
                        <td>{{ $subscription->total_on_sale_count }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Number Of Featured Listing') }}</strong></td>
                        <td>{{ $subscription->total_featured_count }}</td>
                    </tr>
                    <tr>
                        <td><strong>{{ __('Number Of Until Sold Listing') }}</strong></td>
                        <td>{{ $subscription->count_of_until_sold }}</td>
                    </tr>
                    <tr>
                        <td><strong><?= __('Created') ?></strong></td>
                        <td>{{ $subscription->created_at->toFormattedDateString() }}</td>
                    </tr>

                    <tr>
                        <td><strong>{{ __('Status') }}</strong></td>
                        <td>{{ $subscription->status ? __('Active') : __('Inactive')  }}</td>
                    </tr>
                </tbody>
            </table>
    </div>
</div>


@stop