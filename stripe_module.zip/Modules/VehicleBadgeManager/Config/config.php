<?php

return [
    'name' => 'VehicleBadgeManager'
];
