<?php

namespace Modules\VehicleBodyStyleManager\Entities;

use Illuminate\Database\Eloquent\Model;
use \Dimsav\Translatable\Translatable;
use Cviebrock\EloquentSluggable\Sluggable;

class VehicleBodyStyle extends Model {

    const ACTIVE = 1;
    const IN_ACTIVE = 0;
    use Sluggable;

    public $translatedAttributes = ['name'];

    use Translatable;

    protected $fillable = ["status", 'icon'];

    /**

     * Scope a query to only include active competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query) {
        return $query->where('status', self::ACTIVE);
    }

    /**
     * Scope a query to include given type of competitions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfActive($query, $type) {
        return $query->whereStatus($type);
    }

    /**
     * Get the comments for the blog post.
     */
    public function vehicles() {

        return $this->hasMany(\Modules\VehicleManager\Entities\Vehicle::class, 'body_styles_id', 'id');
    }

     /* 07-01 */
     public function VehicleBodyStyleTranslation() {

        return $this->hasMany(\Modules\VehicleBodyStyleManager\Entities\VehicleBodyStyleTranslation::class, 'vehicle_body_style_id', 'id');
    }

    /**
     * Get the comments for the blog post.
     */
    public function sluggable() {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }
}
