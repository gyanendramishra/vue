@extends('user::layouts.master')

@push('styles')
{!! Html::style('/plugins/jquery-confirm/dist/jquery-confirm.min.css') !!}
{!! Html::style('/plugins/gritter/css/jquery.gritter.css') !!}
{!! Html::style('/plugins/bootstrap-switch-master/dist/css/bootstrap3/bootstrap-switch.css') !!}
@endpush

@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Role Manager
            <small>Role Manager</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{route('dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="{{route('roles')}}">Roles</a></li>
            <li><a href="#">Lists</a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">

        <!-- Default box -->
        <div class="box">
            @if(session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
            @endif

            <div class="box-header with-border">
                <h3 class="box-title">Roles List</h3>

                <div class="box-tools pull-right">
                    <a href="{{route('roles.add')}}" class="btn btn-primary">Add Role</a>

                </div>
            </div>
            <div class="box-body">
                <table class="table table-bordered" id="roles-datatable" data-table="roles">
                    <thead>
                        <tr>
                            <th>Role Name</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th class="no-sort">Actions</th>
                        </tr>
                    </thead>
                </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
                <div class="pull-right">{{ $roles->links() }}</div>
            </div>
            <!-- /.box-footer-->
        </div>
        <!-- /.box -->

    </section>
    <!-- /.content -->
</div>
@stop

@push('scripts')

{!! Html::script('/plugins/jquery-confirm/dist/jquery-confirm.min.js') !!}
{!! Html::script('/plugins/gritter/js/jquery.gritter.js') !!}
{!! Html::script('/plugins/bootstrap-switch-master/dist/js/bootstrap-switch.js') !!}

<script>
    $(document).ready(function () {
        $('#roles-datatable').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('roles.ajax.list') }}",
            columns: [
                {data: 'name', name: 'name'},
                {data: 'created_at', name: 'created_at'},
                {data: 'status', name: 'status'},
                {data: 'action', name: 'action'},
            ],
            "deferRender": true,
            "columnDefs": [{
                    "targets": 'no-sort',
                    "orderable": false,
                },
                {
                    "targets": 2,
                    "data": "status",
                    "render": function (data, type, full, meta) {
                         return '<input id="status" class="switch-status change-request" data-id="'+full.id+'" data-field="status" data-size="mini" '+ ((data == true)?'checked':'') +' name="status" type="checkbox">';
                    }
                }
            ],
            "fnDrawCallback": function(settings) {

              $('input.switch-status').not('[data-switch-no-init]')     .bootstrapSwitch();
                $('[data-toggle="tooltip"]').tooltip();

                $('.switch-status.change-request').on('switchChange.bootstrapSwitch', function (e, state) {
                    var _this = $(this);
                    var _id = _this.data("id")
                    var table = _this.closest("table").data("table");
                    if (e.target.checked == true) {
                        var changedval = 1;
                    } else {
                        var changedval = 0;
                    }
                    changeStatus(table , _id,  changedval, _this);
                });
            }
        });
    });

</script>
@endpush