<?php

namespace Modules\User\Entities;

use Illuminate\Database\Eloquent\Model;


class SubModule extends Model {

   
    protected $fillable = [];

}
