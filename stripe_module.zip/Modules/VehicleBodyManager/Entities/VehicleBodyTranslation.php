<?php

namespace Modules\VehicleBodyManager\Entities;

use Illuminate\Database\Eloquent\Model;


class VehicleBodyTranslation extends Model
{
  

    public $timestamps = false;
    protected $fillable = ['name'];

	 /**
     * Get the comments for the blog post.
     */
   

   
}
