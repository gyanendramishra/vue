<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec operational-time-page">
                <form @submit.prevent="updateOpeningTimes">
                    <div class="form-row" v-for="(operational_time, index) in operational_times">
                        <div class="day-title-col">
                            <h5>{{ operational_time.day }}</h5>
                            <div class="day-on-of-btn-sec">
                                <div class="onoffswitch">
                                    <input type="checkbox" :id="'toggle-'+operational_time.day" class="onoffswitch-checkbox" v-model="operational_times[index].is_close">
                                    <label class="onoffswitch-label" :for="'toggle-'+operational_time.day">
                                        <span class="onoffswitch-inner"></span>
                                        <span class="onoffswitch-switch"></span>
                                    </label>
                                </div>
                                <input type="hidden" class="days_cls" v-model="operational_times[index].day">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>
                                Opening Time 
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="" v-timepicker:opening_time="index" v-model="operational_times[index].opening_time" v-validate="'required|date_format:hh:mm a'" data-vv-as="opening time" :key="'opening_time'+index" :name="'opening_time'+index" readonly>
                            <div v-if="errors.has('opening_time'+index)" class="text-danger">
                                {{ errors.first('opening_time'+index) }}
                            </div>
                        </div>
                        <div class="form-group last-input">
                            <label>
                                Closing Time 
                                <span class="red-color">*</span>
                            </label>
                            <input type="text" placeholder="" v-timepicker:closing_time="index" v-model="operational_times[index].closing_time"  v-validate="'required|date_format:hh:mm a'" data-vv-as="closing time" :key="'closing_time'+index" :name="'closing_time'+index" readonly>
                            <div v-if="errors.has('closing_time'+index)" class="text-danger">
                                {{ errors.first('closing_time'+index) }}
                            </div>
                        </div>
                    </div>
                    <div class="full-btn-col">
                        <input type="submit" value="Submit" :disabled="errors.any()">
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
    import "bootstrap-datepicker/dist/css/bootstrap-datepicker.css";
    import "bootstrap-timepicker/css/bootstrap-timepicker.css";
    import LoaderComponent from "../LoaderComponent.vue";
    import datepicker from "bootstrap-datepicker";
    import timepicker from "bootstrap-timepicker";
    import mixin from '../../mixin/mixin.js';
    import VeeValidate from 'vee-validate';
    import moment from "moment";
    Vue.use(VeeValidate);
    export default {
        name: "operational-time-component",
        mixins: [mixin],
        components:{
            LoaderComponent
        },
        data: function () {
            return {
                loading: false,
                operational_times: [
                    {
                        opening_time: "",
                        closing_time: "",
                        is_close: "",
                        day: ""
                    },
                    {
                        opening_time: "",
                        closing_time: "",
                        is_close: "",
                        day: ""
                    },
                    {
                        opening_time: "",
                        closing_time: "",
                        is_close: "",
                        day: ""
                    },
                    {
                        opening_time: "",
                        closing_time: "",
                        is_close: "",
                        day: ""
                    },
                    {
                        opening_time: "",
                        closing_time: "",
                        is_close: "",
                        day: ""
                    },
                    {
                        opening_time: "",
                        closing_time: "",
                        is_close: "",
                        day: ""
                    },
                    {
                        opening_time: "",
                        closing_time: "",
                        is_close: "",
                        day: ""
                    },
                ]
            }
        },
        created: function(){
            this.getOpeningTimes();
        },
        directives: {
            timepicker: {
                bind: function (el, binding, vnode) {
                    $(el).timepicker({
                        autoclose: true,
                        format: 'HH:mm',
                        icons:{
                            up: 'fa fa-arrow-up',
                            down: 'fa fa-arrow-down'
                        }
                    }).on('changeTime.timepicker', function(e) {
                        if(vnode.context.errors.has(binding.arg+binding.value)){
                            vnode.context.errors.remove(binding.arg+binding.value);
                        }
                        if(e.time.value.length < 8){
                            vnode.context.operational_times[binding.value][binding.arg] = "0"+e.time.value;
                        }else{
                            vnode.context.operational_times[binding.value][binding.arg] = e.time.value;
                        }
                        
                    });
                },
                update: function (el) {
                },
            }
        },
        methods: {
            getOpeningTimes() {
                this.loading = true;
                axios.get('/operational-times/get').then(response => {
                    if(response.data.status === true){
                        this.operational_times = response.data.data;
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            updateOpeningTimes() {
                this.loading = true;
                this.$validator.validate().then(valid => {
                    if (valid) {
                        axios.post('/operational-times/update', {
                            opening_days_data: this.operational_times
                        }).then(response => {
                            if(response.data.status === true){
                                this.operational_times = response.data.data;
                                flash(response.data.message, 'success');
                            }else{
                                this.authorize(response);
                            }
                            this.loading = false;
                        }).catch(error => {
                            this.loading = false;
                            console.log(error);
                        });
                    }else{
                        this.loading = false;
                    }
                });
            }
        }
    }
</script>

