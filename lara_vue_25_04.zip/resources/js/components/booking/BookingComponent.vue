<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">     
                <div class="my-booking-sec">
                    <div class="filter-list">
                        <span>Filter By</span>
                        <select v-model="filters.status" v-on:change="filterByStatus">
                            <option value="">All</option>
                            <option value="awaiting">Awaiting</option>
                            <option value="accepted">Accepted</option>
                            <option value="rejected">Rejected</option>
                            <option value="scheduled">Scheduled</option>
                            <option value="started">Started</option>
                            <option value="cancelled">Cancelled</option>
                            <option value="complained">Complained</option>
                            <option value="ended">Ended</option>
                            <option value="refunded">Refunded</option>
                            <option value="completed">Completed</option>
                        </select>
                    </div>
                    <div v-if="results.bookings.length > 0">
                        <div class="booking-row" v-for="booking in results.bookings">
                            <div class="booking-row-inner">
                                <h4>{{ booking.title }}</h4>
                                <div class="booking-row-text">
                                    <p>{{ booking.description }}</p>
                                    <a :href="booking.title | prepareSlug('/booking/detail', booking.id)" class="view-booking-btn">View More <i class="fa fa-long-arrow-right"></i></a>
                                </div>
                                <div class="booking-bottom-date-sec">
                                    <span class="booking-date-col">
                                        {{ booking.service_date_time | formatDate }}
                                    </span>
                                    <span :class="'booking-status-label '+ booking.status">
                                        {{ booking.status }}
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="pro-pagination">
                            <div class="pager-result"> {{ results.total_count }} Items found</div>
                            <div class="pager" v-if="results.last_page > 1">
                                <ul>
                                    <li class="pager-arrow" :class="(filters.page === 1)?'disabled':''">
                                        <a href="javascript:;" v-on:click="paginate((filters.page - 1))">
                                            <i class="fa fa-angle-left"></i>
                                        </a>
                                    </li>
                                    <li :class="(filters.page === 1)?'current':''">
                                        <a href="javascript:;" v-on:click="paginate(1)">
                                            1
                                        </a>
                                    </li>
                                    <li :class="(filters.page === 2)?'current':''" v-if="results.last_page >= 2">
                                        <a href="javascript:;" v-on:click="paginate(2)">
                                            2
                                        </a>
                                    </li>
                                    <li :class="(filters.page === 3)?'current':''" v-if="results.last_page >= 3">
                                        <a href="javascript:;" v-on:click="paginate(3)">
                                            3
                                        </a>
                                    </li>
                                    <li :class="(filters.page === 4)?'current':''" v-if="results.last_page >= 4">
                                        <a href="javascript:;" v-on:click="paginate(4)">
                                            4
                                        </a>
                                    </li>
                                    <li class="pager-arrow" :class="(filters.page === results.last_page)?'disabled':''">
                                        <a href="javascript:;" v-on:click="paginate((filters.page + 1))">
                                            <i class="fa fa-angle-right"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div v-else>
                        <div class="booking-row">
                            <div class="booking-row-inner">
                                <p>Sorry we have not found any {{ filters.status }} booking of you.</p>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import moment from "moment";
    import mixin from '../../mixin/mixin.js';
    import LoaderComponent from "../LoaderComponent.vue";
    export default {
        name: "booking-component",
        components:{
            LoaderComponent
        },
        mixins: [mixin],
        props:["isServiceProvider"],
        data: function () {
            return {
                loading: false,
                results: {
                    bookings: {}
                },
                filters: {
                    page: 1,
                    account_type_id : 1,
                    status: ""
                }
            }
        },
        created: function(){
            this.loading = true;
            if(this.isServiceProvider === true){
                this.filters.account_type_id = 1;
            }else{
                this.filters.account_type_id = 2;
            }
            this.getBookings();
        },
        filters: {
            formatDate : function(date){
                return moment(date).format('DD MMM YYYY h:mm a');
            },
            prepareSlug (str, uri, id) {
                if(!str) return "";
                str = str.toLowerCase();
                str = str.replace(/[^a-zA-Z0-9]/g, '-');
                str = str.replace(/[-]+/g, '-');
                return uri+"/"+str+"-"+id;
            }
        },
        methods: {
            getBookings() {
                this.loading = true;
                axios.post('/booking/get', this.filters).then(response => {
                    if(response.data.status === true){
                        this.results = response.data.data;
                    }else{
                        this.authorize(response);
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            filterByStatus(){
                this.filters.page = 1;
                this.getBookings();
            },
            paginate(page) {
                if((page <= this.results.last_page) && (page >= 1)){
                    this.filters.page = page;
                    this.getBookings();
                }
            }
        },
    }
</script>

