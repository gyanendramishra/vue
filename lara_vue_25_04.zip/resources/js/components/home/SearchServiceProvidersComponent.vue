<template>
    <div class="top-booking-form-col">
        <form method="post" action="/service-providers">
            <input type="hidden" name="_token" v-model="filters._token">
            <div class="booking-input-row">
                <div class="booking-input-col">
                    <label>Search</label>
                    <input type="text" placeholder="Enter your keyword" name="keyword" v-model="filters.keyword" />
                </div>
                <div class="booking-input-col">
                    <label>Category</label>
                    <select name="parent_category_id" v-model="filters.parent_category_id" v-on:change="getSubCategories()">
                        <option value="">Select Category</option>
                        <option v-for="parentCategory in parentCategories" :value="parentCategory.id">{{ parentCategory.title }}</option>
                    </select>
                </div>
                <div class="booking-input-col">
                    <label>Sub Category</label>
                    <select name="category_id[]" v-model="filters.sub_category_id">
                        <option value="">Select Sub Category</option>
                        <option v-for="subCategory in SubCategories" :value="subCategory.id">{{ subCategory.title }}</option>
                    </select>
                </div>
            </div>
            <div class="booking-input-row">
                <div class="booking-input-col calendar-col">
                    <label>Availability</label>
                    <input type="text" placeholder="Availability" name="availability" ref="availability" v-model="filters.availability" />
                </div>
                <div class="booking-input-col">
                    <label>Rating</label>
                    <select name="rating" v-model="filters.rating">
                        <option disabled value="">Select rating</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>
                <div class="booking-input-col price-input-col">
                    <label>Price</label>
                    <input type="text" placeholder="Min" name="min_price" v-model="filters.min_price" />
                    <input type="text" placeholder="Max" name="max_price" v-model="filters.max_price" />
                </div>
            </div>
            <button type="submit">
                <i class="fa fa-long-arrow-right"></i>
            </button>
        </form>
    </div>
</template>
<script>
    import "bootstrap-datepicker/dist/css/bootstrap-datepicker.css";
    import datepicker from "bootstrap-datepicker";
    export default {
        name: "search-service-providers-component",
        data: function () {
            return {
                loading: false,
                filters: {
                    _token: $('meta[name="csrf-token"]').attr("content"),
                    keyword: "",
                    parent_category_id: "",
                    sub_category_id: "",
                    availability: "",
                    min_price: "",
                    max_price: "",
                    rating: ""
                },
                parentCategories: {},
                SubCategories: {}
            }
        },
        mounted: function () {
            this.getParentCategories();
            var vm = this;
            Vue.nextTick(function(){
                $(vm.$refs.availability).datepicker({
                    format: "yyyy-mm-dd",
                    startDate: new Date(),
                    autoclose: true
                }).on('changeDate', function(e) {
                    vm.filters.availability = e.format();
                }).on('changeMonth', function(e) {
                    vm.filters.availability = e.format();
                }).on('changeYear', function(e) {
                    vm.filters.availability = e.format();
                });
            }.bind(this));
        },
        methods: {
            getParentCategories() {
                axios.get('/listing/get-categories').then(response => {
                    if(response.data.status === true){
                        this.parentCategories = response.data.data.categories;
                    }
                }).catch(error => {
                    console.log(error);
                });
            },

            getSubCategories() {
                axios.post('/listing/get-sub-categories', {parent_id: this.filters.parent_category_id}).then(response => {
                    if(response.data.status === true){
                        this.SubCategories = response.data.data.categories;
                    }
                }).catch(error => {
                    console.log(error);
                });
            },
        },
    }
</script>

