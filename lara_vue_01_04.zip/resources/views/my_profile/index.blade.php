@extends('layouts.dashboard')
@section('page_header_title')
	 My <strong>Profile</strong>
@endsection
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        My profile
    </li>
@endsection

@section('dashboard_content')
  	<my-profile-component></my-profile-component>
@endsection

