@extends('layouts.app')

@section('content')

<div class="topInnerBanner" style="background-image:url(/images/login_body_bg.jpg);">
	<div class="container">
	    <div class="topBannerMidCol">
	      	<h1>
	      		500 <strong>Error</strong>
	      	</h1>
	    </div>
	</div>
</div>
<div class="breadcrumb-sec">
  	<div class="container">
	    <ul>
		    <li>
		      	<a href="{{ route('home') }}">
			      	Home
			    </a>
		    </li>
	        <li>
		        500
		    </li>
	    </ul>
  	</div>
</div>
<div class="mainWpapContainer">
	<div class="inner-page-content">
		<div class="container">
			<h5>500 - INTERNAL SERVER ERROR</h5>
			<p>
				We're sorry but that page cannot be found.
			</p>
			<h6>This could be because:</h6>
			<p>{{ $message }}</p>
		</div>
	</div>
</div>

@endsection
