@extends('layouts.app')

@section('content')

<div class="topInnerBanner" style="background-image:url(/images/login_body_bg.jpg);">
	<div class="container">
	    <div class="topBannerMidCol">
	      	<h1>
	      		Service <strong>Providers</strong>
	      	</h1>
	    </div>
	</div>
</div>
<div class="breadcrumb-sec">
  	<div class="container">
	    <ul>
		    <li>
		      	<a href="{{ route('home') }}">
			      	Home
			    </a>
		    </li>
	        <li>
		        Service Providers
		    </li>
	    </ul>
  	</div>
</div>
<div class="mainWpapContainer">
  	<div class="product-listing-sec padding-T-0">
 		<div class="container">
 			<service-providers-component :filters='@json($filters)'></service-providers-component>
 		</div>
 	</div>
</div>

@endsection
