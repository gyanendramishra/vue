<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\CategoryService;
use App\Services\ServiceProvidersService;

class ServiceProvidersController extends Controller
{
    /**
     * Show the service providers.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\ServiceProvidersService $service
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request){
    	$filters = $request->all();
        $filters = [
            "page" => 1,
            "keyword" => "test",
            "category_id" => [],
            "min_price" => "",
            "max_price" => "",
            "availability" => "",
            "rating" => "",
        ];
        return view('service_provider.index', compact('filters'));
    }

    /**
     * Filter the service provider.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\ServiceProvidersService $service
     * @return \Illuminate\Http\Response
     */
    public function filterServiceProviders(Request $request, ServiceProvidersService $service){
        try{
            /*$filters = [
                "page" => 1,
                "keyword" => "test",
                "category_id" => "",
                "price_range" => "",
                "rating" => "",
                "service_date" => ""
            ];*/
            $response = $service->getServiceProvidersService($request->all());
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

    /**
     * Get the categories provider.
     *
     * @param Illuminate\Http\Request $request
     * @param App\Services\CategoryService $service
     * @return \Illuminate\Http\Response
     */
    public function getCategories(Request $request, CategoryService $service){
        try{
            $response = $service->getFilterCategoriesService();
            return response()->json($response, 200);
        }catch(\Exception $e){
            return response()->json([
                "status"=> false,
                "code"=> 500,
                "message"=>$e->getMessage()
            ], 200);
        }
    }

}
