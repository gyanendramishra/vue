@extends('layouts.app')

@section('title', $page->page_data->meta_title)
@section('description', $page->page_data->meta_description)
@section('keywords', $page->page_data->meta_keyword)

@section('content')
<div class="topInnerBanner" style="background-image:url(/images/login_body_bg.jpg);">
	<div class="container">
	    <div class="topBannerMidCol">
	      	<h1>
	      		About Us
	      	</h1>
	    </div>
	</div>
</div>
<div class="breadcrumb-sec">
  	<div class="container">
	    <ul>
		    <li>
		      	<a href="{{ route('home') }}">
			      	Home
			    </a>
		    </li>
	        <li>
		        About Us
		    </li>
	    </ul>
  	</div>
</div>
<div class="mainWpapContainer">
	<about-us-component></about-us-component>
</div>
@endsection
