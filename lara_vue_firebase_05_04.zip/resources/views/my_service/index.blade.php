@extends('layouts.dashboard')
@section('page_header_title')
	My Services
@endsection
@section('page_breadcrumb')
	<li>
      	<a href="{{ route('home') }}">
	      	Home
	    </a>
    </li>
    <li>
        My services
    </li>
@endsection
@section('dashboard_content')
    <my-service-component :is-completed='{{ $isCompleted }}'></my-service-component>
@endsection

