<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">
                <div class="chat-booking-page">
                    <div class="right-chat-screen">
                        <div class="chat_area">
                            <ul class="list-unstyled">
                                <li class="left clearfix">
                                    <span class="chat-img1 pull-left">
                                        <img src="/images/top_category_img01.jpg" alt="User Avatar">
                                    </span>
                                    <div class="chat-body1 clearfix">
                                        <div class="chat-user-name-left">Me</div>
                                        <div class="chatarea-col">Contrary to popular belief</div>
                                        <div class="chat_time pull-right">21st September 06:48:07 AM</div>
                                    </div>
                                </li>
                                <li class="left clearfix admin_chat">
                                    <span class="chat-img1 pull-right">
                                        <img src="/images/top_category_img03.jpg" alt="User Avatar">
                                    </span>
                                    <div class="chat-body1 clearfix">
                                        <div class="chat-user-name-right">Thomas</div>
                                        <div class="chatarea-col">Contrary to popular belief, Lorem Ipsum.</div>
                                        <div class="chat_time pull-left">21st September 06:48:07 AM</div>
                                    </div>
                                </li>
                                <li class="left clearfix">
                                    <span class="chat-img1 pull-left">
                                        <img src="/images/top_category_img01.jpg" alt="User Avatar">
                                    </span>
                                    <div class="chat-body1 clearfix">
                                        <div class="chat-user-name-left">Me</div>
                                        <div class="chatarea-col">Contrary to popular belief, Lorem Ipsum is not simply random text.</div>
                                        <div class="chat_time pull-right">21st September 06:48:07 AM</div>
                                    </div>
                                </li>
                                <li class="left clearfix admin_chat">
                                    <span class="chat-img1 pull-right">
                                        <img src="/images/top_category_img03.jpg" alt="User Avatar">
                                    </span>
                                    <div class="chat-body1 clearfix">
                                        <div class="chat-user-name-right">Thomas</div>
                                        <div class="chatarea-col">Contrary to popular</div>
                                        <div class="chat_time pull-left">21st September 06:48:07 AM</div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="chatting-text-box">
                            <textarea></textarea>
                        </div>
                        <div class="chatting-sms-btn-sec">
                            <div class="browse-btn">BROWSE <input type="file" /></div>
                            <button class="btn btn-sm btn-yellow">SEND MESSAGE</button>          
                        </div>
                    </div>
                </div>  
            </div>
        </div>
    </div>
</template>
<script>
    import fb from '../../firebase/init';
    import moment from "moment";
    import LoaderComponent from "../LoaderComponent.vue";
    export default {
        name: "booking-chat-component",
        components:{
            LoaderComponent
        },
        props:["bookingId"],
        data: function () {
            return {
                loading: false,
                booking: {},
                messages: [],
                newMessage: ""
            }
        },
        created: function(){
            this.loading = true;
            this.getBooking();
            let ref = fb.collection('messages').orderBy('timestamp');

            ref.onSnapshot(snapshot => {
                snapshot.docChanges().forEach(change => {
                    if (change.type == 'added') {
                        let doc = change.doc;
                        this.messages.push({
                            id: doc.id,
                            name: doc.data().name,
                            message: doc.data().message,
                            timestamp: moment(doc.data().timestamp).format('LTS')
                        });
                    }
                });
            });
        },
        filters: {
            prepareSlug (str, id) {
                if(!str) return "";
                return str.toLowerCase().replace(/ /g, '-')+"-"+id;
            }
        },
        methods: {
            getBooking() {
                this.loading = true;
                axios.post('/booking/get/data', {
                    id: this.bookingId
                }).then(response => {
                    if(response.data.status === true){
                        this.booking = response.data.data;
                        this.review.booking_id = this.booking.id;
                        this.review.service_id = this.booking.service_id;
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            createMessage () {
                if (this.newMessage) {
                    fb.collection('messages').add({
                        message: this.newMessage,
                        name: this.name,
                        timestamp: Date.now()
                    }).catch(err => {
                        console.log(err);
                    });
                    this.newMessage = null;
                } else {
                    alert("A message must be entered!", "error")
                }
            }
        }
    }
</script>
