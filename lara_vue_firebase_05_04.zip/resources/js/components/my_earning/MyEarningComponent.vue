<template>
    <div class="formBox editProfileForm">
        <loader-component :loading="loading"></loader-component>
        <div class="formBoxInner">
            <div class="dashbord-sec">     
                <div class="my-booking-sec">
                    <div v-if="results.payments.length > 0">
                        <div class="booking-row" v-for="earning in results.payments">
                            <div class="booking-row-inner">
                                <h4>{{ earning.title }}</h4>
                                <div class="booking-row-text">
                                    <p>{{ earning.description }}</p>
                                </div>
                                <div class="booking-bottom-date-sec">
                                    <span class="booking-date-col">
                                        {{ earning.service_date_time | formatDate }}
                                    </span>
                                    <span class="'booking-status-label '+ booking.status" :style="'background-color:'+earning.color">
                                        {{ earning.amount_status }}
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="pro-pagination">
                            <div class="pager-result"> {{ results.total_count }} Items found</div>
                            <div class="pager" v-if="results.last_page > 1">
                                <ul>
                                    <li class="pager-arrow" :disabled="filters.page === 1">
                                        <a href="javascript:;" v-on:click="paginate((filters.page - 1))">
                                            <i class="fa fa-angle-left"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:;" v-on:click="paginate(1)">
                                            1
                                        </a>
                                    </li>
                                    <li v-if="results.last_page >= 2">
                                        <a href="javascript:;" v-on:click="paginate(2)">
                                            2
                                        </a>
                                    </li>
                                    <li v-if="results.last_page >= 3">
                                        <a href="javascript:;" v-on:click="paginate(3)">
                                            3
                                        </a>
                                    </li>
                                    <li v-if="results.last_page >= 4">
                                        <a href="javascript:;" v-on:click="paginate(4)">
                                            4
                                        </a>
                                    </li>
                                    <li class="pager-arrow" :disabled="filters.page === results.last_page">
                                        <a href="javascript:;" v-on:click="paginate((filters.page + 1))">
                                            <i class="fa fa-angle-right"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div v-else>
                        <div class="booking-row">
                            <div class="booking-row-inner">
                                <p>Sorry we have not found any earnings of you.</p>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import moment from "moment";
    import VeeValidate from 'vee-validate';
    import LoaderComponent from "../LoaderComponent.vue";
    Vue.use(VeeValidate);
    export default {
        name: "my-earning-component",
        components:{
            LoaderComponent
        },
        data: function () {
            return {
                loading: false,
                results:{
                    payments:{}
                },
                filters: {
                    page: 1,
                    account_type_id : 1,
                    limit: 10
                }
            }
        },
        filters: {
            formatDate : function(date){
                return moment(date, 'YYYY-MM-DD H:i:s').format('DD MMM YYYY h:mm a');
            }
        },
        created: function(){
            this.getEarnings();
        },
        methods: {
            getEarnings() {
                this.loading = true;
                axios.post('/my-earnings/get', this.filters).then(response => {
                    if(response.data.status === true){
                        this.results = response.data.data;
                    }else{
                        flash(response.data.message, 'error');
                    }
                    this.loading = false;
                }).catch(error => {
                    this.loading = false;
                    console.log(error);
                });
            },
            paginate(page) {
                this.filters.page = page;
                this.getEarnings();
            }
        }
    }
</script>

