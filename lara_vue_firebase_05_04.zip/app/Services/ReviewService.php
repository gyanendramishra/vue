<?php

namespace App\Services;

use App\Services\Traits\ServiceTrait;

class ReviewService {

    use ServiceTrait;

    /**
     * The base uri.
     *
     */
    protected $base_uri = 'api/reviews/';

    /**
     * Add booking review.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function addReviewService($data) {
        $uri = $this->base_uri;
        $uri .= 'add';
        return $this->postServiceRequest($uri, $data);
    }

    /**
     * Get my reviews.
     *
     * @param array $data
     * @return Illuminate\Http\Response
     */
    public function getMyReviewsService($data) {
        $uri = $this->base_uri;
        $uri .= 'reviewList';
        return $this->postServiceRequest($uri, $data);
    }

}