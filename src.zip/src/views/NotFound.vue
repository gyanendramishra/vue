<template>
  <div class="not-found">
    <div class="alert alert-danger" role="alert">
      <h4 class="alert-heading">Oop's 404</h4>
      <p>Page not found</p>
      <hr>
      <p class="mb-0">Please navigate the route in proper way.</p>
    </div>
  </div>
</template>
<script>
export default {
  name: "not-found"
};
</script>
