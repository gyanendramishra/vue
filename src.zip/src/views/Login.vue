<template>
  <div class="card">
    <div class="card-header">Login</div>
    <div class="card-body">
      <form @submit.prevent="login">
        <div class="form-group row">
          <label for="email" class="col-md-4 col-form-label text-md-right"
            >E-Mail Address</label
          >
          <div class="col-md-6">
            <input
              id="email"
              type="text"
              class="form-control"
              name="email"
              v-model="fields.email"
            />
            <div v-if="errors && errors.email" class="text-danger">
              {{ errors.email[0] }}
            </div>
          </div>
        </div>
        <div class="form-group row">
          <label for="password" class="col-md-4 col-form-label text-md-right"
            >Password</label
          >
          <div class="col-md-6">
            <input
              id="password"
              type="password"
              class="form-control"
              name="password"
              v-model="fields.password"
            />
            <div v-if="errors && errors.password" class="text-danger">
              {{ errors.password[0] }}
            </div>
          </div>
        </div>
        <div class="form-group row mb-0">
          <div class="col-md-6 offset-md-4">
            <button type="submit" class="btn btn-primary">
              Login <span v-if="loading">...</span>
            </button>
            <a class="btn btn-link" href="/password/reset"
              >Forgot Your Password
            </a>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      loading: false,
      fields: {},
      errors: {}
    };
  },
  methods: {
    login() {
      this.loading = true;
      this.errors = {};
      this.$http
        .post("/login", this.fields)
        .then(response => {
          if (response.data.status === true) {
            flash(response.data.message, "success");
            window.location = "/user/dashboard";
          } else {
            flash(response.data.message, "danger");
          }
          this.loading = false;
        })
        .catch(error => {
          this.loading = false;
          if (error.response.status === 422) {
            this.errors = error.response.data.errors || {};
          }
        });
    }
  }
};
</script>
