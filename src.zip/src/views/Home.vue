<template>
  <div id="home">
    <div id="app-slider">
      <main-sliders></main-sliders>
    </div>
    <div class="mainWpapContainer">
      <div id="how-it-works">
        <how-it-works></how-it-works>
      </div>
      <div id="near-service-providers">
        <near-service-providers></near-service-providers>
      </div>
      <div id="top-categories">
        <top-categories></top-categories>
      </div>
    </div>
  </div>
</template>
<script>
import MainSliders from "@/components/home/MainSliders.vue";
import HowItWorks from "@/components/home/HowItWorks.vue";
import NearServiceProviders from "@/components/home/NearServiceProviders.vue";
import TopCategories from "@/components/home/TopCategories.vue";
export default {
  name: "home",
  components: {
    MainSliders,
    HowItWorks,
    NearServiceProviders,
    TopCategories
  }
};
</script>
