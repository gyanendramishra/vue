<template>
  <div class="mainWpapContainer">
    <div class="login-sec">
      <div class="container">
        <div class="login-title">
          <h1>Log<span>In</span></h1>
        </div>
        <div class="login-box">
          <div class="row">
            <div class="col-md-6 left-log-bar">
              <div class="left-log">
                <h2>Login with</h2>
                <div class="or-icon">or</div>
                <div class="login-social-icons">
                  <a href="#">
                    <img src="@/assets/images/fb_icon.png" alt="" />
                  </a>
                  <a href="#">
                    <img src="@/assets/images/google_plus_icon.png" alt="" />
                  </a>
                </div>
                <div class="login-left-bg">
                  <img src="@/assets/images/login_laft_pannel_bg.png" alt="" />
                </div>
              </div>
            </div>
            <div class="col-md-6 right-log-bar">
              <app-errors :errors="errors"></app-errors>
              <div class="loginForm">
                <form @submit.prevent="login">
                  <div class="form-group">
                    <label>
                      Email address <span class="red-color">*</span>
                    </label>
                    <div class="form-icon-col">
                      <i class="fa fa-envelope"></i> 
                      <input type="text" placeholder="Email address" id="email" name="email" v-model="fields.email">
                    </div>
                  </div>
                  <div class="form-group">
                    <label>
                      Password <span class="red-color">*</span>
                    </label>
                    <div class="form-icon-col">
                      <i class="fa fa-lock"></i> 
                      <input type="password" placeholder="Password" name="password" v-model="fields.password">
                    </div>
                  </div>
                  <div class="form-group">
                    <input type="submit" value="Login">
                    <div class="forgotPassword">
                      <a href="#">Forgot Password?</a> 
                    </div>
                  </div>
                  <div class="form-group margin-B-0">
                    If your are not an exiting customer, you need to 
                    <a href="#">register</a>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import AppErrors from "@/components/shared/AppErrors.vue";
export default {
  components: {
    AppErrors
  },
  data() {
    return {
      fields: {},
      errors: {}
    };
  },
  computed: {
    isLoading: function() {
      return this.$store.getters.isLoading;
    }
  },
  methods: {
    login: function() {
      this.$store
        .dispatch("login", this.fields)
        .then(() => {
          this.$router.push("/user/dashboard");
        })
        .catch(error => {
          if (error.data.error) {
            this.errors = error.data.error || {};
          } else {
            this.errors = [error.data.message];
          }
        });
    }
  }
};
</script>
