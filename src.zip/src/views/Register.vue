<template>
  <div class="card">
    <div class="card-header">Register</div>
    <div class="card-body">
      <form @submit.prevent="register">
        <div class="form-group row">
          <label for="name" class="col-md-4 col-form-label text-md-right"
            >Name</label
          >
          <div class="col-md-6">
            <input
              id="name"
              type="text"
              class="form-control"
              name="name"
              v-model="fields.name"
            />
            <div v-if="errors && errors.name" class="text-danger">
              {{ errors.name[0] }}
            </div>
          </div>
        </div>
        <div class="form-group row">
          <label for="email" class="col-md-4 col-form-label text-md-right"
            >E-Mail Address</label
          >
          <div class="col-md-6">
            <input
              id="email"
              type="text"
              class="form-control"
              name="email"
              v-model="fields.email"
            />
            <div v-if="errors && errors.email" class="text-danger">
              {{ errors.email[0] }}
            </div>
          </div>
        </div>
        <div class="form-group row">
          <label for="password" class="col-md-4 col-form-label text-md-right"
            >Password</label
          >
          <div class="col-md-6">
            <input
              id="password"
              type="password"
              class="form-control"
              name="password"
              v-model="fields.password"
            />
            <div v-if="errors && errors.password" class="text-danger">
              {{ errors.password[0] }}
            </div>
          </div>
        </div>
        <div class="form-group row">
          <label
            for="password-confirm"
            class="col-md-4 col-form-label text-md-right"
            >Confirm Password</label
          >
          <div class="col-md-6">
            <input
              id="password-confirm"
              type="password"
              class="form-control"
              name="confirm_password"
              v-model="fields.confirm_password"
            />
            <div v-if="errors && errors.confirm_password" class="text-danger">
              {{ errors.confirm_password[0] }}
            </div>
          </div>
        </div>
        <div class="form-group row">
          <label for="mobile" class="col-md-4 col-form-label text-md-right"
            >Mobile</label
          >
          <div class="col-md-6">
            <input
              id="mobile"
              type="text"
              class="form-control"
              name="mobile"
              v-model="fields.mobile"
            />
            <div v-if="errors && errors.mobile" class="text-danger">
              {{ errors.mobile[0] }}
            </div>
          </div>
        </div>
        <div class="form-group row mb-0">
          <div class="col-md-6 offset-md-4">
            <button type="submit" class="btn btn-primary">
              Register <span v-if="loading">...</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      loading: false,
      fields: {},
      errors: {}
    };
  },
  methods: {
    registerOld() {
      this.loading = true;
      this.errors = {};
      this.$http
        .post("/register", this.fields)
        .then(response => {
          if (response.data.status === true) {
            //flash(response.data.message, "success");
          } else {
            //flash(response.data.message, "danger");
          }
          this.loading = false;
        })
        .catch(error => {
          this.loading = false;
          if (error.response.status === 422) {
            this.errors = error.response.data.errors || {};
          }
        });
    },
    register: function() {
      this.$store
        .dispatch("register", this.fields)
        .then(response => {
          if (response.data.status === true) {
            //flash(response.data.message, "success");
          } else {
            //flash(response.data.message, "danger");
          }
          this.loading = false;
        })
        .catch(error => {
          this.loading = false;
          if (error.response.status === 422) {
            this.errors = error.response.data.errors || {};
          }
        });
    }
  }
};
</script>
