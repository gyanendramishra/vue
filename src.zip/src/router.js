import Vue from "vue";
import Router from "vue-router";
import store from "./store/store.js";
import Home from "./views/Home.vue";

Vue.use(Router);

let router = new Router({
  mode: "history",
  base: process.env.BASE_URL,
  //linkActiveClass: "active",
  linkExactActiveClass: "active",
  routes: [
    {
      path: "/",
      name: "home",
      component: Home
    },
    {
      path: "/about",
      name: "about",
      component: function() {
        return import("./views/About.vue");
      }
    },
    {
      path: "/login",
      name: "login",
      component: function() {
        return import("./views/auth/Login.vue");
      },
      meta: {
        guest: true
      }
    },
    {
      path: "/register",
      name: "register",
      component: function() {
        return import("./views/auth/Register.vue");
      },
      meta: {
        guest: true
      }
    },
    {
      path: "/user/dashboard",
      name: "dashboard",
      component: function() {
        return import("./views/users/Dashboard.vue");
      },
      meta: {
        requiresAuth: true
      }
    },
    {
      path: "*",
      name: "404",
      component: function() {
        return import("./views/NotFound.vue");
      }
    }
  ]
});

router.beforeEach((to, from, next) => {
  if (to.matched.some(record => record.meta.requiresAuth)) {
    if (store.getters.isLoggedIn) {
      return next();
    }
    return next("/login");
  } else if (to.matched.some(record => record.meta.guest)) {
    if (store.getters.isLoggedIn) {
      return next({ name: "dashboard" });
    } else {
      return next();
    }
  } else {
    return next();
  }
});

export default router;
