<template>
  <div class="sliderWrap global-slider-controls">
    <div id="home-slider">
      <div
        class="item fill"
        v-for="slider in sliders"
        v-bind:key="slider"
        :style="{
          backgroundImage: 'url(' + require('@/assets/images/' + slider) + ')'
        }"
      ></div>
    </div>
    <div class="top-booking-form-sec">
      <div class="container">
        <div class="booking-title-col">
          <div class="booking-title-col-inner">
            <h2>Offering <span>easy</span></h2>
            <p>
              to-book services, in person or<br />
              virtually on demand.
            </p>
          </div>
        </div>
        <div class="top-booking-form-col">
          <form method="post">
            <div class="booking-input-row">
              <div class="booking-input-col">
                <label>Search</label>
                <input type="text" placeholder="Enter your keyword" />
              </div>
              <div class="booking-input-col">
                <label>Category</label>
                <select>
                  <option>Select</option>
                  <option>Test</option>
                  <option>Test2</option>
                  <option>Test3</option>
                </select>
              </div>
              <div class="booking-input-col">
                <label>Sub Category</label>
                <select>
                  <option>Select</option>
                  <option>Test</option>
                  <option>Test2</option>
                  <option>Test3</option>
                </select>
              </div>
            </div>
            <div class="booking-input-row">
              <div class="booking-input-col calendar-col">
                <label>Availability</label>
                <input type="text" placeholder="Enter your keyword" />
              </div>
              <div class="booking-input-col">
                <label>Rating</label>
                <select>
                  <option>Select</option>
                  <option>Test</option>
                  <option>Test2</option>
                  <option>Test3</option>
                </select>
              </div>
              <div class="booking-input-col price-input-col">
                <label>Price</label>
                <input type="text" placeholder="Min" />
                <input type="text" placeholder="Max" />
              </div>
            </div>
            <button type="submit">
              <i class="fa fa-long-arrow-right"></i>
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "main-sliders",
  data() {
    return {
      sliders: ["slide_01.jpg", "slide_01.jpg", "slide_01.jpg"]
    };
  }
};
</script>
