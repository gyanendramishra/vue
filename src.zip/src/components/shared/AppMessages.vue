<template>
  <div v-if="variant && message">
    <div :class="variant" role="alert">
	  {{ message }}
	</div>
  </div>
</template>
<script>
export default {
  name: "app-messages",
  props: ["variant", "message"]
};
</script>

<style scoped>
.flash {
  position: fixed;
  right: 5px;
  top: 60px;
  z-index: 1000;
  padding: 0.75rem 1.25rem;
  margin-bottom: 1rem;
  border: 1px solid transparent;
  border-top-color: transparent;
  border-right-color: transparent;
  border-bottom-color: transparent;
  border-left-color: transparent;
  border-radius: 0.25rem;
}

.flash-success {
  color: #155724;
  background-color: #d4edda;
  border-color: #c3e6cb;
}
.flash-error {
  color: #721c24;
  background-color: #f8d7da;
  border-color: #f5c6cb;
}
.flash-warning {
  color: #856404;
  background-color: #fff3cd;
  border-color: #ffeeba;
}
.flash-info {
  color: #0c5460;
  background-color: #d1ecf1;
  border-color: #bee5eb;
}
</style>
