<template>
  <div class="header">
    <div class="mainMenuWrap">
      <div class="container">
        <div class="mainMenuBar">
          <nav class="nav" role="navigation">
            <div class="wrapper-flush">
              <button class="nav-toggle">
                <span class="icon-menu">
                  <span class="line line-1"></span>
                  <span class="line line-2"></span>
                  <span class="line line-3"></span>
                </span>
              </button>
              <div class="logo">
                <router-link to="/">
                  <img src="@/assets/images/logo.png" alt="logo" title="" />
                </router-link>
              </div>
              <div class="nav-container">
                <ul class="nav-menu menu">
                  <li class="menu-item">
                    <router-link to="/about" class="menu-link"
                      >about us</router-link
                    >
                  </li>
                  <li class="menu-item">
                    <a href="#" class="menu-link">Services</a>
                  </li>
                  <li class="menu-item">
                    <a href="#" class="menu-link"> fAQ’S</a>
                  </li>
                </ul>
                <div class="top-right-login">
                  <div class="languageBox">
                    <div class="dropdown">
                      <a
                        href="#"
                        data-toggle=""
                        data-hover="dropdown"
                        class="languageBtn"
                        aria-expanded="true"
                      >
                        <img src="@/assets/images/language_icon.png" /> Us
                        <i class="caret"></i>
                      </a>
                      <ul class="dropdown-menu">
                        <li><a href="#">test</a></li>
                        <li><a href="#">test</a></li>
                        <li><a href="#">test</a></li>
                      </ul>
                    </div>
                  </div>
                  <ul class="login-menu" v-if="isLoggedIn">
                    <li>
                      <a href="#">
                        <img src="@/assets/images/login_icon.png" /> Username
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;" @click="logout">
                        <img src="@/assets/images/signup_icon.png" /> Logout
                      </a>
                    </li>
                  </ul>
                  <ul class="login-menu" v-else>
                    <li>
                      <router-link to="/login">
                        <img src="@/assets/images/login_icon.png" /> Login
                      </router-link>
                    </li>
                    <li>
                      <router-link to="/register">
                        <img src="@/assets/images/signup_icon.png" /> Signup
                      </router-link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "app-header",
  computed: {
    isLoggedIn: function() {
      return this.$store.getters.isLoggedIn;
    }
  },
  created: function() {
    this.$http.interceptors.response.use(undefined, function(err) {
      return new Promise(function() {
        if (err.status === 401 && err.config && !err.config.__isRetryRequest) {
          this.$store.dispatch("logout");
        }
        throw err;
      });
    });
  },
  methods: {
    logout: function() {
      this.$store.dispatch("logout").then(() => {
        this.$router.push("/login");
      });
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped></style>
