<template>
  <div v-if="errors" class="text-danger">
    <ul>
      <li v-for="error in errors">
        {{ error }}
      </li>
    </ul>
  </div>
</template>
<script>
export default {
  name: "app-errors",
  props: ["errors"]
};
</script>

<style scoped>
</style>
