<template>
  <div id="app">
    <div id="flash">
      <app-flash></app-flash>
    </div>
    <div id="header">
      <app-header></app-header>
    </div>
    <div class="container" id="main">
      <router-view />
    </div>
    <div id="footer">
      <app-footer></app-footer>
    </div>
  </div>
</template>
<script>
// @ is an alias to /src
import AppHeader from "@/components/shared/AppHeader.vue";
import AppFooter from "@/components/shared/AppFooter.vue";
import AppFlash from "@/components/AppFlash.vue";
import "bootstrap";
export default {
  name: "app",
  components: {
    AppHeader,
    AppFooter,
    AppFlash
  }
};
</script>
<style>
@import url("./assets/css/owl.carousel.css");
@import url("./assets/css/owlcarouseltheme.css");
@import url("./assets/css/animate.css");
@import url("./assets/css/style.css");
@import url("https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700");
@import url('https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN');
</style>
