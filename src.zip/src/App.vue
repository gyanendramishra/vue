<template>
  <div id="app">
    <div id="flash">
      <app-flash></app-flash>
    </div>
    <div id="header">
      <app-header></app-header>
    </div>
    <div class="container" id="main">
      <router-view />
    </div>
    <div id="footer">
      <app-footer></app-footer>
    </div>
  </div>
</template>
<script>
// @ is an alias to /src
import AppHeader from "@/components/shared/AppHeader.vue";
import AppFooter from "@/components/shared/AppFooter.vue";
import AppFlash from "@/components/AppFlash.vue";

export default {
  name: 'app',
  components: {
    AppHeader,
    AppFooter,
    AppFlash
  }
};
</script>
<style></style>
