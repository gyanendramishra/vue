<template>
  <div id="app">
    <Flash></Flash>
    <div id="header">
      <Header></Header>
    </div>
    <div class="container" id="main">
      <router-view />
    </div>
    <div id="footer">
      <Footer></Footer>
    </div>
  </div>
</template>
<script>
// @ is an alias to /src
import Header from "@/components/shared/Header.vue";
import Footer from "@/components/shared/Footer.vue";
import Flash from "@/components/Flash.vue";

export default {
  name: "app",
  components: {
    Header,
    Footer,
    Flash
  }
};
</script>
<style></style>
