<template>
  <div id="app">
    <app-flash></app-flash>
    <div id="header">
      <app-header></app-header>
    </div>
    <div class="container" id="main">
      <router-view />
    </div>
    <div id="footer">
      <app-footer></app-footer>
    </div>
  </div>
</template>
<script>
// @ is an alias to /src
import AppHeader from "@/components/shared/AppHeader.vue";
import AppFooter from "@/components/shared/AppFooter.vue";
import AppFlash from "@/components/AppFlash.vue";

export default {
  name: "app",
  components: {
    AppHeader,
    AppFooter,
    AppFlash
  },
  computed : {
    isLoggedIn : function(){ 
      return this.$store.getters.isLoggedIn;
    }
  },
  created: function () {
    this.$http.interceptors.response.use(undefined, function (err) {
      return new Promise(function (resolve) {
        if (err.status === 401 && err.config && !err.config.__isRetryRequest) {
          this.$store.dispatch(logout);
        }
        throw err;
      });
    });
  },
  methods: {
    logout: function () {
      this.$store.dispatch("logout")
      .then(() => {
        this.$router.push("/login");
      });
    }
  },
};
</script>
<style></style>
