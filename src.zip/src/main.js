import Vue from "vue";
import Axios from "axios";
import App from "./App.vue";
import router from "./router";
import store from "./store/store.js";
import "bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

Vue.config.productionTip = true;
Vue.prototype.$http = Axios;

const token = localStorage.getItem("token");

Vue.prototype.$http.defaults.baseURL = "http://192.168.4.164/ondemand/api/";
//Vue.prototype.$http.defaults.baseURL = "http://ds15.projectstatus.co.uk/ondemand/api/";
/*Vue.prototype.$http.defaults.headers.common["Content-Type"] = "application/x-www-form-urlencoded";*/
Vue.prototype.$http.defaults.headers.common["Accept"] = "application/json";
Vue.prototype.$http.defaults.headers.common["Device-Type"] = "iOS";
Vue.prototype.$http.defaults.headers.common["Version-Code"] = 1;

if (token) {
  Vue.prototype.$http.defaults.headers.common["Authorization"] = token;
}

window.events = new Vue();
window.flash = function(message, variant) {
  window.events.$emit("flash", {
    message,
    variant
  });
};

new Vue({
  router,
  store,
  render: function(h) {
    return h(App);
  }
}).$mount("#app");
