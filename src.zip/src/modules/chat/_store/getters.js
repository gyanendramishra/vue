const messages = state => state.messages;

export default {
  messages
};
