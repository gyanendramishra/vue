const MESSAGES_UPDATED = (state, messages) => {
  state.messages = messages;
};

export default {
  MESSAGES_UPDATED
};
