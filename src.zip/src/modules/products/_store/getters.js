const products = state => state.products;

export default {
  products,
};
