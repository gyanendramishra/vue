const PRODUCTS_UPDATED = (state, products) => {
  state.products = products;
};

export default {
  PRODUCTS_UPDATED
};
