import axios from "axios";

export default {
  state: {
    status: "",
    token: localStorage.getItem('token') || '',
    user: {}
  },
  mutations: {
    auth_request(state) {
      state.status = "loading";
    },
    
    login(state, token, user) {
      state.status = "success";
      state.token = token;
      state.user = user;
    },
    auth_error(state) {
      state.status = "error";
    },
    logout(state) {
      state.status = "";
      state.token = "";
    }
  },
  actions: {
    login({ commit }, user) {
      return new Promise((resolve, reject) => {
        commit("auth_request");
        user.device_type = 'web';
        user.device_id = 'web0101';
        axios.post("users/login", user)
          .then(response => {
            if(response.data.status == true){
              const token = response.data.data.token;
              const user = response.data.data;
              localStorage.setItem("token", token);
              axios.defaults.headers.common["Authorization"] = token;
              commit("login", token, user);
              resolve(response);
            }else{
              commit("auth_error");
              reject(response);
            }
          })
          .catch(err => {
            commit("auth_error");
            localStorage.removeItem("token");
            reject(err);
          });
      });
    },
    register({ commit }, user) {
      return new Promise((resolve, reject) => {
        commit("auth_request");
        axios({
          url: "192.168.4.164/ondemand/api/users/register",
          data: user,
          method: "POST"
        })
          .then(resp => {
            resolve(resp);
          })
          .catch(err => {
            reject(err);
          });
      });
    },
    logout({ commit }) {
      return new Promise(resolve => {
        commit("logout");
        localStorage.removeItem("token");
        //localStorage.removeItem("user");
        delete axios.defaults.headers.common["Authorization"];
        resolve();
      });
    }
  },
  getters: {
    isLoggedIn: state => !!state.token,
    isLoading: state => (state.status == 'loading')? true: false,
  }
};
